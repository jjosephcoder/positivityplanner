/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/matrix_fwd.h"
#include "mmlib/container/raw/type_decl.h"
#include "mmlib/func/raw/disp.h"
#include "mmlib/matrix_traits.h"
#include "mmlib/details/debug.h"
#include "mmlib/container/container_pool.h"

namespace mmlib { namespace details
{

class MMLIB_EXPORT matrix_container_base : public refcount_str
{
	private:
        enums::mat_type                 m_type;

	protected:
		matrix_container_base(enums::mat_type type);        

	private:
		matrix_container_base(const matrix_container_base&);
		matrix_container_base& operator=(const matrix_container_base&);

		friend class mmlib::Matrix;

	public:
        ~matrix_container_base(){};

        virtual void            destroy_data() = 0;
        enums::mat_type         get_type() const        { return m_type; };

		Integer					rows() const; 
		Integer					cols() const;
		Integer					nnz() const;
		Integer					ldiags() const;
		Integer					udiags() const;
		int_tup_2				size() const;
		bool					is_scalar_true() const;
        type_info               get_ti() const;
        mmlib::Matrix            get_scalar() const;

        const struct_flag&      get_struct() const;
        struct_flag&            get_struct();
        void                    set_struct(const struct_flag&);
        void                    check_struct() const;

        mmlib::Matrix            reserve(Integer r, Integer c) const;
        mmlib::Matrix            resize(Integer r, Integer c) const;
        mmlib::Matrix            reserve_band(Integer r, Integer c, Integer ld, Integer ud) const;
        mmlib::Matrix            resize_band(Integer r, Integer c, Integer ld, Integer ud) const;

		void					disp(disp_stream& os) const;

	private:
        SERIALIZE_MACRO
        void save(oarchive_impl & , const unsigned int ) const {};
        void load(iarchive_impl & , const unsigned int )
        {
            m_refcount = 0;
        };   
};

template<class val_type, class str_type>
class matrix_container : public matrix_container_base
{
	public:
		typedef raw::Matrix<val_type,str_type>	Matrix;

	private:
		Matrix	m_matrix;	

        matrix_container()
            :matrix_container_base(matrix_traits::mat_type_info_type_2<val_type,str_type>::matrix_code)
            ,m_matrix(gd::get_raw_ti())
        {};

		friend class mmlib::Matrix;

	public:		
		matrix_container(const Matrix& mat);
        ~matrix_container() {};

        virtual void            destroy_data()              { m_matrix.destroy_data(); };

		Matrix&					get()						{ return m_matrix;};
		const Matrix&			get() const					{ return m_matrix;};	

		Integer					rows_impl() const			{ return m_matrix.rows(); }; 
		Integer					cols_impl() const			{ return m_matrix.cols(); };
		Integer					ldiags_impl() const;
		Integer					udiags_impl() const;
		int_tup_2				size_impl() const			{ return int_tup_2(rows(),cols()); };		
        Integer					nnz_impl() const            { return m_matrix.nnz(); }; 		
        type_info               get_ti_impl() const         { return m_matrix.get_ti(); };
        const struct_flag&      get_struct_impl() const     { return m_matrix.get_struct(); };
        struct_flag&            get_struct_impl()           { return m_matrix.get_struct(); };
        void                    check_struct_impl() const   { return m_matrix.check_struct(); };

        bool					is_scalar_true_impl() const;
        void					disp_impl(disp_stream& os) const;
        void                    set_struct_impl(const struct_flag& fl);

		mmlib::Matrix			get_elem(Integer i) const;
		mmlib::Matrix			get_elem(Integer i,Integer j) const;
        mmlib::Matrix            get_scalar_impl() const;

        Matrix                  reserve_impl(Integer r, Integer c) const;
        Matrix                  resize_impl(Integer r, Integer c) const;

        void *                  operator new(size_t size);
        void                    operator delete(void *p);

	private:
        SERIALIZE_MACRO
        void save(oarchive_impl & ar, const unsigned int ) const
        {
            matrix_container& tmp = const_cast<matrix_container&>(*this);
			ar << boost::serialization::base_object<matrix_container_base>(tmp);
			ar << m_matrix;
        };
        void load(iarchive_impl & ar, const unsigned int )
        {
			ar >> boost::serialization::base_object<matrix_container_base>(*this);
			ar >> m_matrix;
        };
};

template<class value_type,class struct_type>
inline matrix_container_base* 
create_matrix_container(const raw::Matrix<value_type,struct_type>& val)
{   
    typedef matrix_container<value_type,struct_type> container_type;
    typedef raw::Matrix<value_type,struct_type> matrix_type;
    return new container_type(val);
};
inline void free_container(matrix_container_base* ptr)
{
    if (ptr)
    {
        container_pool::get(ptr->get_type()).free(ptr);
    };
};
inline void destroy_container(matrix_container_base* ptr)
{
    ptr->destroy_data();
    free_container(ptr);
};

template<class T,bool is_mat>
struct matrix_container_type
{
	typedef typename details::promote_scalar<T>::type type;
};
template<class T>
struct matrix_container_type<T,true>
{
	typedef T type;
};

template<class T>
class create_container
{
	public:
		typedef typename matrix_container_type
				<T	,details::is_matrix<T>::value
				>::type								matrix_type;

		static details::matrix_container_base* eval(const T& val)
		{
			return eval_impl<details::is_matrix<T>::value>(val);
		};
	private:
		template<bool is_mat>
		static details::matrix_container_base* eval_impl(const T& val)
		{
			typedef typename details::promote_scalar<T>::type value_type;
			typedef amlpp::Matrix<value_type,struct_dense> Matrix;
			return eval_matrix(Matrix(value_type(val)));
		};
		template<>
		static details::matrix_container_base* eval_impl<true>(const T& val)
		{
			return eval_matrix(val);
		};
		template<class value_type, class struct_type>
		static details::matrix_container_base* eval_matrix(const raw::Matrix<value_type,struct_type>& val)
		{
            return details::create_matrix_container<value_type,struct_type>(val);
		};
};


};};