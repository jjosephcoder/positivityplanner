/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/container/matrix_container.inl"
#include "mmlib/base/integer.h"

namespace mmlib { namespace details
{

Integer matrix_container_base::rows() const
{
    return eval_type_rows::make(this);
}; 
Integer matrix_container_base::cols() const
{
    return eval_type_cols::make(this);
}; 
Integer matrix_container_base::nnz() const
{
    return eval_type_nnz::make(this);
}; 
Integer matrix_container_base::ldiags() const
{
    return eval_type_ldiags::make(this);
}; 
Integer matrix_container_base::udiags() const
{
    return eval_type_udiags::make(this);
}; 
int_tup_2 matrix_container_base::size() const
{
    return eval_type_size::make(this);
}; 
bool matrix_container_base::is_scalar_true() const
{
    return eval_type_is_scalar_true::make(this);
}; 
type_info matrix_container_base::get_ti() const
{
    return eval_type_get_ti::make(this);
}; 

void matrix_container_base::disp(disp_stream& os) const
{
    return eval_type_disp::make<const matrix_container_base,disp_stream&>(this,os);
}; 
struct_flag& matrix_container_base::get_struct()
{
    return eval_type_get_struct::make(this);
};
const struct_flag& matrix_container_base::get_struct() const
{
    return eval_type_get_struct_const::make(this);
};
void matrix_container_base::set_struct(const struct_flag& fl)
{
    return eval_type_set_struct::make(this,fl);
};
mmlib::Matrix matrix_container_base::get_scalar() const
{
    return eval_type_get_scalar::make(this);
};

mmlib::Matrix matrix_container_base::reserve(Integer r, Integer c) const
{ 
    return eval_type_reserve::make(this,r,c);
};
mmlib::Matrix matrix_container_base::resize(Integer r, Integer c) const
{
    return eval_type_resize::make(this,r,c);
};
struct int_4
{
    Integer r,c,ld,ud;
    int_4(Integer r, Integer c, Integer ld, Integer ud)
        :r(r),c(c),ld(ld),ud(ud)
    {};
};
mmlib::Matrix matrix_container_base::reserve_band(Integer r, Integer c, Integer ld, Integer ud) const
{
    return eval_type_reserve_band::make(this,int_4(r,c,ld,ud));
};
mmlib::Matrix matrix_container_base::resize_band(Integer r, Integer c, Integer ld, Integer ud) const
{
    return eval_type_resize_band::make(this,int_4(r,c,ld,ud));
};
void matrix_container_base::check_struct() const
{
    return eval_check_struct::make(this);
};

};};