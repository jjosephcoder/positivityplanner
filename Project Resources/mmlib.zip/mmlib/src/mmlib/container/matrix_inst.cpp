/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/container/matrix2.inl"
#include "mmlib/details/type_codes.h"
#include "mmlib/details/utils.h"
#include "mmlib/container/matrix_container.inl"
#include "mmlib/exception.h"
#include "mmlib/matrix_traits.h"
#include "mmlib/matrix_gen.h"
#include "mmlib/manip.h"
#include "mmlib/details/scalfunc_helpers.h"
#include "mmlib/details/type_info_utils.h"

#pragma warning( push )
#pragma warning(disable:4127)	// conditional expression is constant
#pragma warning(disable:4702)	// unreachable code

namespace mmlib
{

namespace details
{
    template<class T>
    MMLIB_EXPORT const T* get_array_helper<T>::eval_const(const Matrix& m)
    {
        typedef raw::Matrix<T,struct_dense> DM;
        const DM& mat = m.get_impl<DM>();
        return mat.ptr();
    };

    template<class T>
    MMLIB_EXPORT  T* get_array_helper<T>::eval(Matrix& m)
    {
        typedef raw::Matrix<T,struct_dense> DM;
        DM& mat = m.get_impl_unique<DM>();
        mat.get_struct().reset(false);
        return mat.ptr();
    };


	template<class M, class T>
	struct get_scalar
	{
		static M eval(const T& val)
		{
            return mmlib::convert_scalar<M,T>(val);
		};
		static M& eval(T& )
		{
			enums::mat_type ret = matrix_traits::mat_type_info_type<M>::matrix_code;
			enums::mat_type in = matrix_traits::mat_type_info_type<T>::matrix_code;
			throw error::error_type_get(ret,in);
		};
	};
	template<class M>
	struct get_scalar<M,M>
	{
		static M eval(const M& val)
		{
			return val;
		};
		static M& eval(M& val)
		{
			return val;
		};
	};

	template<class M>
	M get_scalar_functor<M>::eval(const matrix_base& mat)
	{
		switch(mat.m_type)
		{
			case enums::integer_scalar:
			{
				return get_scalar<M,Integer>::eval(mat.m_value.val_int);
			}
			case enums::real_scalar:
			{
				return get_scalar<M,Real>::eval(mat.m_value.val_real);
			}
			case enums::complex_scalar:
			{
				return get_scalar<M,Complex>::eval(*reinterpret_cast<const Complex*>(&mat.m_value.val_complex));
			}
			case enums::object_scalar:
			{
				return get_scalar<M,Object>::eval(mat.get_object());
			}
			default:
			{
                return eval(matrix_data_accesser::get_base(mat.m_value.m_mat.mat_ptr->get_scalar()));
			}
		};
	};
	template<class M>
	M& get_scalar_functor<M>::eval(matrix_base& mat)
	{
		switch(mat.m_type)
		{
			case enums::integer_scalar:
			{
				return get_scalar<M,Integer>::eval(mat.m_value.val_int);
			}
			case enums::real_scalar:
			{
				return get_scalar<M,Real>::eval(mat.m_value.val_real);
			}
			case enums::complex_scalar:
			{
				return get_scalar<M,Complex>::eval(*reinterpret_cast<Complex*>(&mat.m_value.val_complex));
			}
			case enums::object_scalar:
			{
				return get_scalar<M,Object>::eval(mat.get_object());
			}
			default:
			{
				enums::mat_type ret = matrix_traits::mat_type_info_type<M>::matrix_code;
				enums::mat_type in = mat.m_type;
				throw error::error_type_get(ret,in);
			}
		};
	};

	template<class T,class TS>
	struct to_scalar_impl
	{
		static TS eval(const T& val)
		{
			return val(1,1);
		};
	};
	template<class T>
	struct to_scalar
	{
		typedef typename T::value_type TS;
		static TS eval(const T& val)
		{
			return to_scalar_impl<T,TS>::eval(val);
		};
	};
	template<class T,bool is_scal>
	struct constructor_helper_impl
	{
		static bool eval(const T& val,bool allow_conv, matrix_base& mat)
		{
			if (allow_conv)                
			{
                if (val.rows() == 1 && val.cols() == 1)
                {
				    constructor_helper_scal<T::value_type>::eval(to_scalar<T>::eval(val),mat);
				    return false;
                }
                else
                {
                    Matrix tmp = val.fast_optim();
                    mat.reset(matrix_data_accesser::get_base(tmp));
    				return true;
                };
			}
			else
			{
				mat.m_value.m_mat.mat_ptr   = create_container<T>::eval(val);
                mat.m_value.m_mat.m_ref     = val.get_refstr();
				mat.m_type			        = type_to_code<create_container<T>::matrix_type>::value;
				return true;
			};
		};
	};

	template<class T>
	struct constructor_helper_scal
	{};
	template<>
	struct constructor_helper_scal<Integer>
	{
		static void eval(Integer val,matrix_base& mat)
		{
			mat.m_value.val_int = val;
			mat.m_type = enums::integer_scalar; 
		};
	};
	template<>
	struct constructor_helper_scal<Real>
	{
		static void eval(Real val,matrix_base& mat)
		{
			mat.m_value.val_real = val;
			mat.m_type = enums::real_scalar; 
		};
	};
	template<>
	struct constructor_helper_scal<Object>
	{
		static void eval(Object val,matrix_base& mat)
		{
			mat.get_object() = val;
			mat.m_type = enums::object_scalar; 
		};
	};
	template<>
	struct constructor_helper_scal<Complex>
	{
		static void eval(const Complex& val,matrix_base& mat)
		{
			mat.m_value.val_complex[0] = mmlib::complex::real(val);
            mat.m_value.val_complex[1] = mmlib::complex::imag(val);
			mat.m_type = enums::complex_scalar; 
		};
	};
	template<class T>
	struct constructor_helper_impl<T,true>
	{
		static bool eval(const T& val,bool ,matrix_base& mat)
		{
			typedef details::promote_scalar<T>::type scalar_type;
			constructor_helper_scal<scalar_type>::eval(static_cast<scalar_type>(val),mat);
			return false;
		};
	};
	template<class T>
	bool constructor_helper<T>::eval(const T& val,bool allow_conv,matrix_base& mat)
	{
		return constructor_helper_impl<T,is_scalar<T>::value>::eval(val,allow_conv,mat);
	};
};


namespace details
{

template<class NT, class OT,bool isv>
struct convert_scal_impl
{
    static NT eval(details::type_info ,OT val)
	{
		return NT(val);
	};
};
template<class OT>
struct convert_scal_impl<Object,OT,true>
{
    static Object eval(details::type_info ti,OT val)
	{
		return Object(ti,val);
	};
};
template<class NT, class OT>
struct convert_scal_impl<NT,OT,false>
{
	static NT eval(details::type_info, OT )
	{
		assertion(0,"this case should be already removed");
		throw;
	};
};
template<class NT, class OT>
struct convert_scal
{
	static NT eval(details::type_info ti, OT val)
	{
		static const bool isv = (details::value_to_code<OT>::value <= details::value_to_code<NT>::value);
		return convert_scal_impl<NT,OT,isv>::eval(ti, val);
	};
};

};

template<class val_type, class str_type>
void details::matrix_container<val_type,str_type>::disp_impl(disp_stream& os) const	
{ 
	raw::disp(os,m_matrix); 
};

template MMLIB_EXPORT void details::matrix_container<Integer,struct_dense>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Integer,struct_sparse>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Integer,struct_banded>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Real,struct_dense>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Real,struct_sparse>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Real,struct_banded>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Complex,struct_dense>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Complex,struct_sparse>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Complex,struct_banded>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Object,struct_dense>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Object,struct_sparse>::disp_impl(disp_stream& os) const;
template MMLIB_EXPORT void details::matrix_container<Object,struct_banded>::disp_impl(disp_stream& os) const;
};


#define MACRO_INST_CONSTRUCTOR(type,arg,arg2)	\
	template struct mmlib::details::constructor_helper<type>;


MACRO_FOREACH_CODE(MACRO_INST_CONSTRUCTOR,,)
MACRO_INST_CONSTRUCTOR(bool,,)
MACRO_INST_CONSTRUCTOR(unsigned char,,)
MACRO_INST_CONSTRUCTOR(unsigned short,,)
MACRO_INST_CONSTRUCTOR(unsigned int,,)
MACRO_INST_CONSTRUCTOR(unsigned long,,)
MACRO_INST_CONSTRUCTOR(signed char,,)
MACRO_INST_CONSTRUCTOR(signed short,,)
MACRO_INST_CONSTRUCTOR(signed int,,)
MACRO_INST_CONSTRUCTOR(signed long,,)
MACRO_INST_CONSTRUCTOR(float,,)
MACRO_INST_CONSTRUCTOR(double,,)
MACRO_INST_CONSTRUCTOR(long double,,)
MACRO_INST_CONSTRUCTOR(mmlib::Complex,,)
MACRO_INST_CONSTRUCTOR(mmlib::Integer,,)
MACRO_INST_CONSTRUCTOR(mmlib::Real,,)
MACRO_INST_CONSTRUCTOR(mmlib::Object,,)


namespace mmlib
{
	template struct details::get_scalar_functor<Integer>;
	template struct details::get_scalar_functor<Real>;
	template struct details::get_scalar_functor<Complex>;
    template struct details::get_scalar_functor<Object>;

	template struct details::get_array_helper<Integer>;
	template struct details::get_array_helper<Real>;
	template struct details::get_array_helper<Complex>;
    template struct details::get_array_helper<Object>;

	template MMLIB_EXPORT Integer* Matrix::get_array_unique<Integer>();
	template MMLIB_EXPORT Real* Matrix::get_array_unique<Real>();
	template MMLIB_EXPORT Complex* Matrix::get_array_unique<Complex>();
    template MMLIB_EXPORT Object* Matrix::get_array_unique<Object>();

	template MMLIB_EXPORT const Integer* Matrix::get_array<Integer>() const;
	template MMLIB_EXPORT const Real* Matrix::get_array<Real>() const;
	template MMLIB_EXPORT const Complex* Matrix::get_array<Complex>() const;
    template MMLIB_EXPORT const Object* Matrix::get_array<Object>() const;
};

#pragma warning( pop )