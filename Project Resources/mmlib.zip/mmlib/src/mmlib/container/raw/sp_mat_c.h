/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/container/raw/sp_mat.h"

namespace mmlib { namespace raw 
{

template<>
class MMLIB_EXPORT Matrix<Complex,struct_sparse> : public sparse_matrix_base<Complex>
{
	public:
		typedef sparse_matrix_base<Complex>		base_type;
		typedef struct_sparse					struct_type;
		typedef Complex							value_type;

	 public:
		Matrix(type_info ti)
                : base_type(ti){}
		Matrix(type_info ti,Integer r, Integer c) 
				: base_type(ti,r, c) {}
		Matrix(type_info ti,Integer r, Integer c, Integer nzmax)
				: base_type(ti,r, c, nzmax) {}
		Matrix(type_info ti,const Integer *ri, const Integer *ci, const Real *xr, const Real *xi,
				Integer r, Integer c, Integer nnz)
				: base_type(ti,ri, ci, xr, xi, r, c, nnz)  {}
		Matrix(type_info ti,const Integer *ri, const Integer *ci, const Complex *x,
				Integer r, Integer c, Integer nnz)
				: base_type(ti,ri, ci, x, r, c, nnz) {}
		Matrix(type_info ti, const Integer *ri, const Integer *ci, const Complex *x,
				Integer r, Integer c, Integer nnz, Integer nzmax)
				: base_type(ti,ri, ci, x, r, c, nnz, nzmax) {}
		Matrix(type_info ti, const Integer *ri, const Integer *ci, const Real *xr, const Real *xi,
				Integer r, Integer c, Integer nnz, Integer nzmax)
				: base_type(ti,ri, ci, xr, xi, r, c, nnz, nzmax) {}
		Matrix(const base_type &m)
				: base_type(m) {}

		~Matrix() {}

        mmlib::Matrix    fast_optim() const;
        Matrix          drop() const;

    private:
        Matrix&     operator=(const Matrix&);
};

};};