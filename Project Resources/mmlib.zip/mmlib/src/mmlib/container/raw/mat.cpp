/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/container/raw/mat.h"

#include "mmlib/object.h"
#include "mmlib/error/error_check.h"
#include "mmlib/matrix.h"
#include "mmlib/base/alloc.h"
#include "mmlib/base/serialize.h"
#include "mmlib/container/matrix_container.h"

namespace mmlib { namespace raw 
{

namespace details
{

template<class val_type>
void mat_data<val_type>::alloc(Integer n)
{
    if (n)
    {
		if (n <= 0)
		{
			error::check_alloc(0, n);
		};
		void* arr = mmlib::details::aligned_malloc<val_type>(m_ti,n);
        error::check_alloc(arr, imult_c(n,sizeof(val_type)));

        m_root_ptr  = (val_type*)arr;
        m_ptr       = m_root_ptr;        
    }
    else
    {
        m_root_ptr  = NULL;
        m_ptr       = NULL;
    };
};
template<class val_type>
mat_data<val_type>::mat_data(mmlib::details::type_info ti, Integer r, Integer c)
:m_rows(r), m_cols(c), m_max_rows(r), m_max_cols(c), m_ti(ti), m_flag(struct_flag::general)
{
    error::check_size(r, c);
    m_ld   = std::max(r,1L);
    m_size = imult(m_rows,m_cols);

    alloc(m_size);

    m_refcount = refcount_str::create(1);
};
template<class val_type>
void mat_data<val_type>::destroy_data()
{
    if (m_root_ptr)
    {
        mmlib::details::aligned_free(m_root_ptr, m_size); 
        m_root_ptr = NULL;
        m_ptr = NULL;
    };
};
template<class val_type>
void mat_data<val_type>::reset(Integer r, Integer c)
{
    destroy_data();
    error::check_size(r, c);

    m_rows      = r;
    m_cols      = c;
    m_max_rows  = r;
    m_max_cols  = c;
    m_ld        = std::max(r,1L);
    m_size      = imult(m_rows,m_cols);

    m_flag.reset(false);
    alloc(m_size);
};

template<class val_type>
mat_data<val_type>& mat_data<val_type>::operator=(const mat_data& other)
{
    other.m_refcount->increase();
 
    if (m_refcount->decrease())
    {
        destroy_data();
        m_refcount->destroy();
    };

    m_refcount  = other.m_refcount;
    m_rows      = other.m_rows;
    m_cols      = other.m_cols;
    m_max_rows  = other.m_rows;
    m_max_cols  = other.m_cols;
    m_ld        = other.m_ld;
    m_size      = other.m_size;
    m_root_ptr  = other.m_root_ptr;
    m_ptr       = other.m_ptr;
    m_ti        = other.m_ti;
    m_flag      = other.m_flag;

    return *this;
};
template<class val_type>
mat_data<val_type>::~mat_data()
{
    if (m_refcount->decrease())
    {       
        destroy_data();
        m_refcount->destroy();
    }
};

template<class value_type> 
inline void mat_data<value_type>::save(oarchive_impl & ar, const unsigned int v) const
{
    Integer m_ld_s = std::max(m_rows,1L);
    ar << m_size;
    ar << m_rows;
    ar << m_cols;
    ar << m_ld_s;
    mmlib::details::serialize_save(ar,m_ti,v);
    mmlib::details::serialize_save(ar,m_flag,v);

    const value_type* loc_ptr = ptr();

    for (Integer j = 0; j < m_cols; ++j)
    {
        for (Integer i = 0; i < m_rows; ++i)
        {
            mmlib::details::serialize_save(ar,loc_ptr[i],v);
        };
        loc_ptr += m_ld;
    };
};
template<class value_type> 
void mat_data<value_type>::load(iarchive_impl & ar, const unsigned int v)
{  
	ar >> m_size;
    ar >> m_rows;    
    ar >> m_cols;
    ar >> m_ld;
    mmlib::details::serialize_load(ar,m_ti,v);
    mmlib::details::serialize_load(ar,m_flag,v);

    m_max_rows = m_rows;
    m_max_cols = m_cols;

    error::check_size(m_rows, m_cols);
    alloc(m_size);

	try
	{
		for (Integer i = 0; i < m_size; ++i)
		{
            mmlib::details::serialize_load(ar,m_ptr[i],v);
		};
	}
	catch(...)
	{
		destroy_data();
		throw;
	};
};

};

template <class value_type>
dense_matrix_base<value_type>::dense_matrix_base(mmlib::details::type_info ti, Integer r, Integer c)
:m_data(ti,r,c)
{
};

template <class value_type>
dense_matrix_base<value_type>::dense_matrix_base(const dense_matrix_base &mat) 
: m_data(mat.m_data)
{
}

template <class value_type>
dense_matrix_base<value_type>&
dense_matrix_base<value_type>::reset_unique()
{
    m_data.reset();
    return *this;
}


template <class value_type>
dense_matrix_base<value_type>&
dense_matrix_base<value_type>::reset_unique(Integer r, Integer c)
{
    m_data.reset(r,c);
    return *this;
}
template <class value_type>
mmlib::details::type_info dense_matrix_base<value_type>::get_ti() const
{
    return m_data.get_ti();
};
template <class value_type>
dense_matrix_base<value_type>&
dense_matrix_base<value_type>::operator=(const dense_matrix_base &mat)
{
    m_data = mat.m_data;
    return *this;
}

template <class value_type>
void dense_matrix_base<value_type>::read_from(const value_type* ptr)
{
	if (m_data.m_size == 0)
	{
		return;
	};
    value_type* this_ptr = m_data.ptr();
    for(Integer i = 0; i < m_data.m_cols; ++i)
    {
        for (Integer j = 0; j < m_data.m_rows; ++j)
        {
            this_ptr[j] = *(ptr++);
        };
        this_ptr += m_data.m_ld;
    };
};

template<class value_type> 
inline void dense_matrix_base<value_type>::save(oarchive_impl & ar, const unsigned int ) const
{
    ar << m_data;
};
template<class value_type> 
void dense_matrix_base<value_type>::load(iarchive_impl & ar, const unsigned int )
{  
	ar >> m_data;
};

};};

template struct mmlib::raw::details::mat_data<mmlib::Integer>;
template struct mmlib::raw::details::mat_data<mmlib::Real>;
template struct mmlib::raw::details::mat_data<mmlib::Complex>;
template struct mmlib::raw::details::mat_data<mmlib::Object>;

template class mmlib::raw::dense_matrix_base<mmlib::Integer>;
template class mmlib::raw::dense_matrix_base<mmlib::Real>;
template class mmlib::raw::dense_matrix_base<mmlib::Complex>;
template class mmlib::raw::dense_matrix_base<mmlib::Object>;
