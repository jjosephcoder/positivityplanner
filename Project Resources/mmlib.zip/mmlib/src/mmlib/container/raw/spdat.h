/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/config.h"
#include "mmlib/details/fwd_decls.h"
#include "mmlib/scalar_types.h"
#include "mmlib/details/refcount.h"
#include "mmlib/details/struct_flag.h"
#include "mmlib/base/archive_impl.h"

namespace mmlib { namespace raw
{
    template<class V> class sparse_matrix_base;
};};

namespace mmlib { namespace raw { namespace details
{

template<class value_type>
class MMLIB_EXPORT spdat
{
    private:
        typedef mmlib::details::type_info                type_info;
        typedef mmlib::details::refcount_str             refcount_str;

	public:
		spdat(type_info ti);
		spdat(type_info ti,Integer r, Integer c, Integer nzmax);
		spdat(const spdat&);
		~spdat();		        

        bool                is_unique() const;
		Integer				refcount() const;		
		spdat				copy(bool keep_maxcol) const;        
        void                destroy_data();

		void				memadd(Integer s = 0);
		void				sort();
        bool                is_sorted() const;
		void				adddupl();

        bool				isentry(Integer i, Integer j, Integer &k) const;
        value_type			get_elem(Integer i, Integer j) const;
        void				addentry(Integer i, Integer j, Integer k);
        void				dropentry(Integer i, Integer j, Integer k);

        refcount_str*       get_refstr() const      { return m_refcount; };
		const Integer*	    ptr_c() const	        { return m_c; }
		const Integer*	    ptr_r() const	        { return *m_r; }
		const value_type*	ptr_x() const	        { return *m_x; }
        Integer*	        ptr_c() 	            { return m_c; }
		Integer*	        ptr_r()    	            { return *m_r; }
		value_type*	        ptr_x()    	            { return *m_x; }

        Integer             offset() const          { return m_offset; };

		Integer				rows() const			{ return m_rows; }
		Integer				cols() const			{ return m_cols; }
        Integer				max_cols() const	    { return m_max_cols; }
        //nzmax is meaningfull only for newly created matrix, which are always nonconst
		Integer				nzmax() 			    { return *m_nzmax; }
		Integer				nnz() const				{ return m_c? m_c[m_cols]-m_offset : 0; }
        type_info           get_ti() const          { return m_ti; };
        const struct_flag&  get_struct() const      { return m_flag; };
        struct_flag&        get_struct()            { return m_flag; };
        void				assign(const spdat& o)  { operator=(o); };

	private:
		void				alloc(Integer, Integer, Integer);
        void				resize(Integer, Integer, Integer);

        refcount_str*       m_refcount;
        Integer             m_rows;
        Integer             m_cols;
        Integer             m_max_cols;
        Integer             m_offset;
		Integer *			m_nzmax;
        Integer *			m_c_root;
		Integer *			m_c;
		Integer **			m_r;
		value_type **		m_x;
        type_info           m_ti;  
        struct_flag         m_flag;

        spdat&				operator=(const spdat&);

	private:
        SERIALIZE_MACRO
        void			    save(oarchive_impl & ar, const unsigned int version) const;
        void				load(iarchive_impl & ar, const unsigned int version);

        friend class mmlib::raw::sparse_matrix_base<value_type>;
};


};};};
