/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/fwd_decls.h"
#include "mmlib/container/raw/mat.h"

namespace mmlib { namespace raw 
{

template<class value_type>
class MMLIB_EXPORT Matrix<value_type,struct_banded> : public dense_matrix_base<value_type>
{
	public:
		typedef dense_matrix_base<value_type>			base_type;
		typedef value_type								value_type;
		typedef struct_banded							struct_type;
        typedef mmlib::details::refcount_str             refcount_str;

	private:
		typedef Matrix<value_type,struct_dense>			DenseMatrix;
        typedef mmlib::details::type_info                type_info;

        SERIALIZE_MACRO
        void			    save(oarchive_impl & ar, const unsigned int version) const;
        void				load(iarchive_impl & ar, const unsigned int version); 

        using base_type::ptr;

	public:
		Matrix(type_info ti);
		Matrix(type_info ti, Integer r, Integer c, Integer l = 0, Integer u = 0);
		Matrix(const Matrix&);		

		~Matrix() {};

        Matrix              copy(bool keep_bufor = false) const;
        refcount_str*       get_refstr() const   { return base_type::get_refstr(); };
		Matrix&				reset_unique();
		Matrix&				reset_unique(Integer r, Integer c, Integer l, Integer u);
        void                destroy_data();
		
		const value_type&	operator()(Integer i, Integer j) const; //1 base
        void                assign(const Matrix&);

		Integer				rows() const;
		Integer				cols() const;
		Integer				ldiags() const;
		Integer				udiags() const;
		Integer				nnz() const;
        Integer				ld() const;
        Integer             max_udiags() const;
        Integer             max_ldiags() const;

		Integer				first_row(Integer col) const;
		Integer				last_row(Integer col) const;
		Integer				first_col(Integer) const;
		Integer				last_col(Integer) const;
		Integer				first_elem_pos(Integer col) const;
		Integer				first_elem_pos_row(Integer row) const;
		const value_type*	rep_ptr() const;
		value_type*			rep_ptr();

        void                check_struct() const;

		DenseMatrix			get_diag(Integer = 0) const;
        mmlib::Matrix        fast_optim() const;

        Matrix              make_view(Integer rcs, Integer re, Integer ce) const;
        Matrix              make_view(Integer rcs, Integer re, Integer ce, Integer l, Integer u) const;

        Matrix              reserve(Integer r, Integer c, Integer l = 0, Integer u = 0) const;
        Matrix              resize(Integer r, Integer c) const;
        Matrix              resize(Integer r, Integer c);
        Matrix              resize(Integer r, Integer c, Integer l, Integer u) const;
        Matrix              resize(Integer r, Integer c, Integer l, Integer u);

	protected:
		Integer				m_ldiags;
		Integer				m_udiags;
		Integer			    m_rows;
		Integer			    m_cols;      

    private:
        Matrix&			    operator=(const Matrix&);
        Matrix              get_diag_band() const;
};

};};

#include "mmlib/container/raw/mat_b.inl"
