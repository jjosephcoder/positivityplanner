/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/container/raw/mat_d.inl"
#include "mmlib/object.h"
#include "mmlib/matrix.h"
#include "mmlib/container/raw/sp_mat_c.h"
#include "mmlib/container/raw/sp_mat_i.h"
#include "mmlib/container/raw/sp_mat_o.h"
#include "mmlib/container/raw/sp_mat_r.h"
#include "mmlib/container/raw/mat_b.h"
#include "mmlib/base/optim_params.h"
#include "mmlib/func/raw/converter.h"
#include "mmlib/utils/utils.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/func/raw/mmul.h"
#include "mmlib/func/raw/scalfunc.h"
#include "mmlib/matrix_func_binary.h"

namespace mmlib { namespace raw 
{

template <class value_type>
Matrix<value_type,struct_dense>::Matrix(type_info ti,const value_type *arr, Integer r, Integer c)
    : base_type(ti, r, c)
{
    read_from(arr);	
}
template <class value_type>
Matrix<value_type,struct_dense>::Matrix(type_info ti, const value_type &val, Integer r, Integer c)
    : base_type(ti, r, c)
{
    set_to_all(val);
}
template<>
template<>
Matrix<Complex,struct_dense>::Matrix(type_info ti, const Real* xr, const Real* xi, Integer r, Integer c,
	    const void*)
    : base_type(ti, r, c)
{
	if (m_data.m_size == 0)
	{
		return;
	};
    Complex* this_ptr = m_data.ptr();
    for(Integer i = 0; i < m_data.m_size; ++i)
    {
        *(this_ptr++) = Complex(*(xr++),*(xi++));
    };
};

template <class value_type>
void Matrix<value_type,struct_dense>::set_to_all(const value_type& val)
{
	if (m_data.m_size == 0)
	{
		return;
	};
	value_type* ptr_this = m_data.ptr();
	for (Integer i = 0; i < m_data.m_size; ++i)
	{
		*(ptr_this++) = val;
	};
};

template<class value_type>
Matrix<value_type,struct_dense> Matrix<value_type,struct_dense>::copy(bool keep_bufor) const
{
    Integer c   = (keep_bufor == true)? max_cols() : cols();
    Integer r   = (keep_bufor == true)? max_rows() : rows();

    Matrix out(get_ti(), r, c);
    out.m_data.m_rows = rows();
    out.m_data.m_cols = cols();
    out.m_data.m_size = m_data.m_size;
    out.m_data.m_flag = m_data.m_flag;

    const value_type* ptr_this  = ptr();
    value_type* ptr_out         = out.ptr();

    for(Integer j = 0; j < cols(); ++j)
    {
        for(Integer i = 0; i < rows(); ++i)
        {
            ptr_out[i] = ptr_this[i];
        };
        ptr_out += out.ld();
        ptr_this += ld();
    };

    return out;
};
template<class value_type>
mmlib::Matrix Matrix<value_type,struct_dense>::fast_optim() const
{
	if (rows() == 1 && cols() == 1)
	{
		return *ptr();
	};
    //struct switch
    switch(get_struct().get())
    {            
        case mmlib::struct_flag::zero:
            return mmlib::Matrix(raw::Matrix<value_type,struct_sparse>(get_ti(),rows(),cols()),false);
        case mmlib::struct_flag::id:
        case mmlib::struct_flag::diag:
        {
            typedef Matrix<value_type,struct_banded> BM;
            BM tmp = converter<BM,Matrix>::eval(get_ti(),*this);
            return mmlib::Matrix(tmp,false);
        }
        default:
            break;
    };
    return check_change_struct();
};
template<class value_type>
mmlib::Matrix Matrix<value_type,struct_dense>::check_change_struct() const
{
    if (size() > mmlib::optim_params::min_size_to_test_sparsity)
    {
        Real density = estim_density();
        if (density < mmlib::optim_params::max_sparse_density_min)
        {
            typedef raw::Matrix<value_type,struct_sparse> SparseMatrix;
            return mmlib::Matrix(raw::converter<SparseMatrix,Matrix>::eval(get_ti(),*this),false);
        };
    };
    return mmlib::Matrix(*this,false);
};
template<class value_type>
Real Matrix<value_type,struct_dense>::estim_density() const
{
    static const Integer n_sample = mmlib::optim_params::n_sample_to_test_sparsity;
    Integer step = size()/n_sample;
    step = (step < 3 ? 3:step);
    const value_type* x = ptr();
    Real nz = 0.5, z = 0.5;

    if (ld() == rows() || rows() == 0)
    {
        for (Integer i = 0; i < size(); i += step)
        {
            if (mmlib::details::is_zero(*x) == false)
            {
                ++nz;
            }
            else
            {
                ++z;
            };
            x += step;
        };
    }
    else
    {
        for (Integer i = 0, pos = 0; i < size(); i += step, pos += step)
        {
            while(pos >= rows())
            {
                pos -= rows();
                x += ld();
            };

            if (mmlib::details::is_zero(x[pos]) == false)
            {
                ++nz;
            }
            else
            {
                ++z;
            };
        };
    };
    return nz/(nz+z);
};

template<class value_type>
Matrix<value_type,struct_banded>
Matrix<value_type,struct_dense>::get_diag_band() const
{
    typedef Matrix<value_type,struct_banded> BandMatrix;
    BandMatrix out(get_ti(), m_data.m_rows, m_data.m_cols, 0, 0);

    Integer s = std::min(m_data.m_cols, m_data.m_rows);

	value_type * ptr            = out.rep_ptr();
	const value_type * ptr_this = Matrix::ptr();

    for (Integer i = 0; i < s; ++i)
	{
		*ptr        = *ptr_this;

        ptr         += out.ld();
		ptr_this    += ld() + 1;
	};

    out.get_struct() = this->get_struct();
    return out;
};

template<class value_type>
Matrix<value_type,struct_dense> Matrix<value_type,struct_dense>::make_explicit() const
{
    if (ld() == rows() || rows() == 0 || cols() <= 1)
    {
        return *this;
    };

    Matrix out(get_ti(),rows(), cols());
    value_type* ptr_out = out.ptr();
    const value_type* ptr_this = ptr();

    for(Integer j = 0; j < cols(); ++j)
    {
        for(Integer i = 0; i < rows(); ++i)
        {
            ptr_out[i] = ptr_this[i];
        };
        ptr_out += out.ld();
        ptr_this += ld();
    };
    return out;
};

template <class value_type>
Matrix<value_type,struct_dense>
Matrix<value_type,struct_dense>::get_diag(Integer d) const
{
	error::check_diag(d, base_type::m_data.m_rows, base_type::m_data.m_cols);

    Integer r = base_type::m_data.m_rows;
    Integer c = base_type::m_data.m_cols;

	Integer st, s;
    if (d >= 0)
    {
        st = imult(d,r);
        s = (r + d >= c) ? c - d : r;
    }
    else
    {
        st = - d;
        s = (r + d >= c) ? c : r + d;
    }

	Matrix res(get_ti(), s, 1);

	if (s == 0)
	{
		return res;
	};

	value_type * ptr            = res.ptr();
	const value_type * this_ptr = base_type::ptr() + st;

    for (Integer i = 0; i < s; ++i)
	{
		*ptr = *this_ptr;

		this_ptr += ld() + 1;
        ptr += 1;
	}

    return res;
};
template<class value_type>
Matrix<value_type,struct_dense> Matrix<value_type,struct_dense>::reshape(Integer r, Integer c) const
{
    error::check_reshape(rows(), cols(), r, c);

    if (r == rows() && c == cols())
    {
        return *this;
    };

    if (ld() == rows() || rows() == 0)
    {
        Matrix out(*this);    
        out.m_data.m_rows   = r;
        out.m_data.m_cols   = c;
        out.m_data.m_ld     = std::max(r,1L);

        if (rows() == r && cols() == c)
        {
            out.get_struct() = get_struct();
        }
        else
        {
            out.get_struct().reset(true);
        };
        return out;
    }
    else
    {
        return this->copy().reshape(r,c);
    };    
};

template<class value_type>
Matrix<value_type,struct_dense> Matrix<value_type,struct_dense>::reserve(Integer r, Integer c) const
{
    if (r <= m_data.m_max_rows && c <= m_data.m_max_cols)
    {
        return *this;
    };

    Integer m_c = cols();
    Integer m_r = rows();

    Matrix out(get_ti(), std::max(r,max_rows()), std::max(c,max_cols()));

    out.m_data.m_rows   = m_r;
    out.m_data.m_cols   = m_c;
    out.m_data.m_size   = imult(m_r,m_c);
    out.set_struct(get_struct());

    const value_type* this_ptr = ptr();
    value_type* ptr = out.ptr();

    for (Integer j = 0; j < m_c; ++j)
    {
        for (Integer i = 0; i < m_r; ++i)
        {
            ptr[i]  = this_ptr[i];
        }
        ptr += out.ld();
        this_ptr += this->ld();
    }; 

    return out;
};

template<class value_type>
Matrix<value_type,struct_dense> Matrix<value_type,struct_dense>::resize(Integer r, Integer c) const
{
    error::check_resize(r,c);

    if (r <= rows() && c <= cols())
    {
        return make_view(1,r,1,c);
    };
    if (r <= m_data.m_max_rows && c <= m_data.m_max_cols)
    {
        Matrix out = copy(true);
        return out.resize(r,c);
    };

    Matrix out = reserve(r,c);
    return out.resize(r,c);
};
template<class value_type>
Matrix<value_type,struct_dense> Matrix<value_type,struct_dense>::resize(Integer r, Integer c)
{
    error::check_resize(r,c);

    if (r <= rows() && c <= cols())
    {
        return make_view(1,r,1,c);
    };

    Matrix out = reserve(r,c);

    value_type* ptr = out.ptr();

    Integer m_c = cols();
    Integer m_r = rows();

    value_type Z = mmlib::details::default_value<value_type>(get_ti());

    if (m_r < r)
    {
        for (Integer j = 0; j < m_c; ++j)
        {
            for (Integer i = m_r; i < r; ++i)
            {
                ptr[i]  = Z;
            }
            ptr += out.ld();
        }; 
    }
    else
    {
        ptr += imult(m_c,out.ld());
    };  

    for (Integer j = m_c; j < c; ++j)
    {
        for (Integer i = 0; i < r; ++i)
        {
            ptr[i]  = Z;
        }
        ptr += out.ld();
    }; 

    out.m_data.m_rows = r;
    out.m_data.m_cols = c;
    out.m_data.m_size = imult(r,c);

    bool is_sym = (r == c);
    out.m_data.get_struct() = out.m_data.get_struct().get_resize(is_sym);

    return out;
};

template<class value_type>
Matrix<value_type,struct_dense> 
Matrix<value_type,struct_dense>::make_view(Integer r_start, Integer r_end) const
{
    if (r_end-r_start+1 <= rows() || ld() == rows() || rows() == 0)
    {
        Matrix out(*this);    
        out.m_data.m_rows = r_end-r_start+1;
        out.m_data.m_cols = 1;
        out.m_data.m_size = out.m_data.m_rows;
        out.get_struct().reset(true);

        if (rows() != 0)
        {
            Integer pos = r_start - 1;
            Integer c = pos / rows();
            Integer r = pos % rows();
            out.m_data.m_ptr = const_cast<value_type*>(ptr() + r + c*ld());
        };

        return out;
    };
    Integer r = r_end-r_start+1;
    Matrix out(get_ti(),r,1);
    value_type* ptr_out = out.ptr();
    const value_type* ptr_this = ptr();

    for (Integer i = 0, pos = r_start - 1; i < r; ++i, ++pos)
    {
        while (pos >= rows())
        {
            pos -= rows();
            ptr_this += ld();
        };
        ptr_out[i] = ptr_this[pos];
    };

    return out;
};
template<class value_type>
Matrix<value_type,struct_dense>
Matrix<value_type,struct_dense>::make_view(Integer r_start, Integer r_end, Integer c_start, Integer c_end) const
{
    Matrix out(*this);    
    out.m_data.m_rows = r_end-r_start+1;
    out.m_data.m_cols = c_end-c_start+1;
    out.m_data.m_size = imult(out.m_data.m_rows,out.m_data.m_cols);
    out.m_data.m_ptr = const_cast<value_type*>(ptr() + r_start - 1 + (c_start - 1)*ld());

    if (r_start == c_start)
    {
        bool is_sym = (r_end == c_end);
        out.m_data.get_struct() = out.m_data.get_struct().get_rectangle_view(is_sym);
    }
    else
    {
        out.m_data.get_struct().reset(true);
    }

    return out;
};
template<class value_type>
void Matrix<value_type,struct_dense>::check_struct() const
{
    switch (get_struct().get())
    {
        case struct_flag::zero:    goto check_struct_zero;
        case struct_flag::id:      goto check_struct_id;
        case struct_flag::diag:    goto check_struct_diag;
        case struct_flag::tril:    goto check_struct_tril;
        case struct_flag::triu:    goto check_struct_triu;
        case struct_flag::sym:     goto check_struct_sym;
        case struct_flag::her:     goto check_struct_her;
        case struct_flag::unitary: goto check_struct_unitary;
        case struct_flag::qtril:   goto check_struct_qtril;
        case struct_flag::qtriu:   goto check_struct_qtriu;
        case struct_flag::general: return;
        default:
        {
            assertion(0,"unknown case");
            throw;
        }
    };
    check_struct_tril:
    {
        Integer ud = raw::get_ud(*this,0,false);
        if (ud > 0)
        {
            throw error::error_invalid_struct(struct_flag::tril);
        };
        return;
    }

    check_struct_triu:
    {
        Integer ld = raw::get_ld(*this,0,false);
        if (ld > 0)
        {
            throw error::error_invalid_struct(struct_flag::triu);
        };
        return;
    }

    check_struct_diag:
    {
        Integer ud = raw::get_ud(*this,0,false);
        if (ud > 0)
        {
            throw error::error_invalid_struct(struct_flag::diag);
        };
        Integer ld = raw::get_ld(*this,0,false);
        if (ld > 0)
        {
            throw error::error_invalid_struct(struct_flag::diag);
        };
        return;
    }

    check_struct_zero:
    {
        Integer ud = raw::get_ud(*this,0,false);
        if (ud > 0)
        {
            throw error::error_invalid_struct(struct_flag::zero);
        };
        Integer ld = raw::get_ld(*this,0,false);
        if (ld > 0)
        {
            throw error::error_invalid_struct(struct_flag::zero);
        };

        Integer s = std::min(rows(), cols());
        const value_type* ptr = this->ptr();
        for (Integer i = 0; i < s; ++i)
        {
            value_type val = *ptr;

            if (mmlib::details::is_zero(val) == false)
            {
                throw error::error_invalid_struct(struct_flag::zero);
            };

            ptr += this->ld() + 1;
        };
        return;
    }
    check_struct_id:
    {
        if (rows() != cols())
        {
            throw error::error_invalid_struct(struct_flag::id);
        };

        Integer ud = raw::get_ud(*this,0,false);
        if (ud > 0)
        {
            throw error::error_invalid_struct(struct_flag::id);
        };
        Integer ld = raw::get_ld(*this,0,false);
        if (ld > 0)
        {
            throw error::error_invalid_struct(struct_flag::id);
        };

        Integer s = std::min(rows(), cols());
        const value_type* ptr = this->ptr();
        for (Integer i = 0; i < s; ++i)
        {
            value_type val = *ptr;

            if (mmlib::details::is_one(val) == false)
            {
                throw error::error_invalid_struct(struct_flag::id);
            };

            ptr += this->ld() + 1;
        };
        return;
    }

    check_struct_qtril:
    {
        Integer ud = raw::get_ud(*this,1,false);
        if (ud > 1)
        {
            throw error::error_invalid_struct(struct_flag::qtril);
        };
        if (ud == 0)
        {
            return;
        };
        Integer s = std::min(rows(), cols()-1);
        const value_type* ptr = this->ptr() + this->ld();        
        bool z = false;
        for (Integer i = 0; i < s; ++i)
        {
            value_type val = *ptr;

            if (mmlib::details::is_zero(val) == false)
            {
                if (z)  throw error::error_invalid_struct(struct_flag::qtril);
                else    z = true;
            }
            else
            {
                z = false;
            };

            ptr += this->ld() + 1;
        };
        return;
    }

    check_struct_qtriu:
    {
        Integer ld = raw::get_ld(*this,1,false);
        if (ld > 1)
        {
            throw error::error_invalid_struct(struct_flag::qtriu);
        };
        if (ld == 0)
        {
            return;
        };
        Integer s = std::min(rows()-1, cols());
        const value_type* ptr = this->ptr() + 1;
        bool z = false;
        for (Integer i = 0; i < s; ++i)
        {
            value_type val = *ptr;

            if (mmlib::details::is_zero(val) == false)
            {
                if (z)  throw error::error_invalid_struct(struct_flag::qtriu);
                else    z = true;
            }
            else
            {
                z = false;
            };

            ptr += this->ld() + 1;
        };
        return;
    }

    check_struct_sym:
    {
        bool is_sym = raw::is_sym(*this,false);
        if (is_sym == false)
        {
            throw error::error_invalid_struct(struct_flag::sym);
        };
        return;
    }

    check_struct_her:
    {
        bool is_sym = raw::is_her(*this,false);
        if (is_sym == false)
        {
            throw error::error_invalid_struct(struct_flag::her);
        };
        return;
    }

    check_struct_unitary:
        return;
};

};};

template class mmlib::raw::Matrix<mmlib::Integer,mmlib::struct_dense>;
template class mmlib::raw::Matrix<mmlib::Real,mmlib::struct_dense>;
template class mmlib::raw::Matrix<mmlib::Complex,mmlib::struct_dense>;
template class mmlib::raw::Matrix<mmlib::Object,mmlib::struct_dense>;
