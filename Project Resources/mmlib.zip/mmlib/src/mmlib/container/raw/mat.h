/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/fwd_decls.h"
#include "mmlib/details/refcount.h"
#include "mmlib/details/struct_flag.h"
#include "mmlib/base/archive_impl.h"

namespace mmlib { namespace raw 
{
 
namespace details
{
    template<class val_type>
    struct MMLIB_EXPORT mat_data
    {
        public:
            typedef mmlib::details::type_info                type_info;
            typedef mmlib::details::refcount_str             refcount_str;

            mat_data(mmlib::details::type_info ti);
            mat_data(mmlib::details::type_info ti, Integer r, Integer c);

            mat_data&           operator=(const mat_data&);

            val_type*           ptr()                       { return m_ptr; }
            const val_type*     ptr() const                 { return m_ptr; }

            bool                is_unique() const;
            Integer             refcount() const;
            refcount_str*       get_refstr() const          { return m_refcount; };

            type_info           get_ti() const              { return m_ti; };
            const struct_flag&  get_struct() const          { return m_flag; };
            struct_flag&        get_struct()                { return m_flag; };
            void                reset();
            void                reset(Integer r, Integer c);
            void                destroy_data();

            mat_data(const mat_data&);            
            ~mat_data();

            refcount_str*       m_refcount;
		    Integer				m_rows;
		    Integer				m_cols;
		    Integer				m_max_rows;
		    Integer				m_max_cols;
            Integer				m_ld;
            Integer				m_size;
            val_type*           m_ptr;
            val_type*           m_root_ptr;
            type_info           m_ti;  
            struct_flag         m_flag;

        private:
            void                alloc(Integer s);               

	    private:
            SERIALIZE_MACRO
            void				save(oarchive_impl & ar, const unsigned int version) const;
            void				load(iarchive_impl & ar, const unsigned int version);          
    };
};
template<class value_type, class struct_type>
class MMLIB_EXPORT Matrix
{
	public:
		typedef value_type	    value_type;
		typedef struct_type		struct_type;
};

template <class value_type>
class  MMLIB_EXPORT dense_matrix_base
{
	public:
		typedef value_type		value_type;
		typedef struct_dense	struct_type;

        typedef mmlib::details::refcount_str             refcount_str;

    protected:
        typedef mmlib::details::type_info type_info;

    private:
        SERIALIZE_MACRO
        void				    save(oarchive_impl & ar, const unsigned int version) const;
        void				    load(iarchive_impl & ar, const unsigned int version);    

	public:
		dense_matrix_base(mmlib::details::type_info ti);
		dense_matrix_base(mmlib::details::type_info ti, Integer r, Integer c);
		dense_matrix_base(const dense_matrix_base&);

		~dense_matrix_base(){};

        //matrix must be unique
		dense_matrix_base&		reset_unique();
		dense_matrix_base&		reset_unique(Integer r, Integer c);

        const value_type*		ptr() const                     { return m_data.ptr(); };
		value_type*				ptr()                           { return m_data.ptr(); };

		Integer					refcount() const;  
        bool                    is_unique() const               { return m_data.is_unique(); };
        refcount_str*           get_refstr() const              { return m_data.get_refstr(); };
        const struct_flag&      get_struct() const              { return m_data.m_flag; };
        struct_flag&            get_struct()                    { return m_data.m_flag; };
        void                    set_struct(struct_flag f)       { m_data.m_flag = f; };        
        type_info               get_ti() const;        

        Integer					rows() const                    { return m_data.m_rows; }; 
        Integer					cols() const                    { return m_data.m_cols; };
        Integer                 max_rows() const                { return m_data.m_max_rows; };
        Integer                 max_cols() const                { return m_data.m_max_cols; };
        Integer					ld() const                      { return m_data.m_ld; };
        Integer					size() const                    { return m_data.m_size; };
		Integer					nnz() const;
        void                    read_from(const value_type* arr);

	protected:
        details::mat_data<value_type>   m_data;

        dense_matrix_base&		operator=(const dense_matrix_base&);
};

};};

#include "mmlib/container/raw/mat.inl"
