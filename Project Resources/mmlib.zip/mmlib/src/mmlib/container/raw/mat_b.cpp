/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include <mmlib/container/raw/mat_b.h>
#include <mmlib/container/raw/mat_d.h>
#include "mmlib/object.h"
#include "mmlib/error/error_check.h"
#include "mmlib/utils/utils.h"
#include "mmlib/container/matrix2.inl"
#include "mmlib/base/optim_params.h"
#include "mmlib/container/raw/sp_mat_c.h"
#include "mmlib/container/raw/sp_mat_i.h"
#include "mmlib/container/raw/sp_mat_o.h"
#include "mmlib/container/raw/sp_mat_r.h"
#include "mmlib/func/raw/converter.h"
#include "mmlib/func/raw/raw_manip.h"

namespace mmlib { namespace raw 
{

template <class value_type>
Matrix<value_type,struct_banded>::Matrix(type_info ti) 
: base_type(ti)
{
    m_rows = m_cols = 0;
}

template <class value_type>
Matrix<value_type,struct_banded>::Matrix(type_info ti, Integer r, Integer c, Integer l, Integer u)
: base_type(ti)
{
    l           = std::min(l,r-1);
    u           = std::min(u,c-1);
    l           = std::max(l,0L);
    u           = std::max(u,0L);

	error::check_size_band(r, c, l, u);

    m_rows      = r;
    m_cols      = c;
    m_ldiags    = l;
    m_udiags    = u;

	if (r > 0)
	{
		base_type::reset_unique(l + u + 1, c);
	}
	else
	{
		base_type::reset_unique(0, c);
	};
}


template <class value_type>
Matrix<value_type,struct_banded>::Matrix(const Matrix &m) : base_type(m)
{
    m_rows      = m.m_rows;
    m_cols      = m.m_cols;
    m_ldiags    = m.m_ldiags;
    m_udiags    = m.m_udiags;
}


template <class value_type>
Matrix<value_type,struct_banded>&
Matrix<value_type,struct_banded>::reset_unique()
{
    m_rows = m_cols = 0;
    base_type::reset_unique();

    return *this;
}

template <class value_type>
Matrix<value_type,struct_banded>&
Matrix<value_type,struct_banded>::reset_unique(Integer r, Integer c, Integer l, Integer u)
{
    l           = std::min(l,r-1);
    u           = std::min(u,c-1);
    l           = std::max(l,0L);
    u           = std::max(u,0L);
    error::check_size_band(r, c, l, u);

    m_rows      = r;
    m_cols      = c;
    m_ldiags    = l;
    m_udiags    = u;

	if (r > 0)
	{
		base_type::reset_unique(l + u + 1, c);
	}
	else
	{
		base_type::reset_unique(0, c);
	};

    return *this;
}

template <class value_type>
void Matrix<value_type,struct_banded>::assign(const Matrix &m)
{
    base_type::operator=(m);

    m_rows      = m.m_rows;
    m_cols      = m.m_cols;
    m_ldiags    = m.m_ldiags;
    m_udiags    = m.m_udiags;
}

template <class value_type>
typename Matrix<value_type,struct_banded>::DenseMatrix
Matrix<value_type,struct_banded>::get_diag(Integer d) const
{
    error::check_diag(d, m_rows, m_cols);

    Integer s;
    if (d > 0)
    {
        s = std::min(m_cols - d, m_rows);
    }
    else
    {
        s = std::min(m_rows + d, m_cols);
    }

	if (d > m_udiags || -d > m_ldiags)
	{
        value_type Z = mmlib::details::default_value<value_type>(get_ti());
        return DenseMatrix(get_ti(),Z,s,1);
	};

    Integer st;
    if (d > 0)
    {
        st = imult(d,ld()) + m_udiags - d;
    }
    else
    {
        st = m_udiags - d;
    }

    DenseMatrix res(get_ti(), s, 1);

	if (s == 0)
	{
		return res;
	};

	value_type * ptr           	= res.ptr();
	const value_type * ptr_this = Matrix::ptr() + st;

    for (Integer i = 0; i < s; ++i)
	{
		*(ptr++) = *ptr_this;
		ptr_this += ld();
	};

    return res;
};


template <class value_type>
Integer Matrix<value_type,struct_banded>::nnz() const
{
	Integer out = 0;
	for (Integer i = 1; i <= m_ldiags; ++i)
	{
		out += std::min(m_rows - i, m_cols);
	};
	for (Integer i = 1; i <= m_udiags; ++i)
	{
		out += std::min(m_rows, m_cols - i);
	};
	out += std::min(m_rows, m_cols);
	return out;
};

template <class value_type>
Matrix<value_type,struct_banded> Matrix<value_type,struct_banded>::copy(bool keep_bufor) const
{
    Integer c   = (keep_bufor == true)? max_cols() : cols();
    Integer r   = (keep_bufor == true)? max_rows() : m_data.m_rows;

    Matrix out(get_ti(), r, c, std::max(r-1,0L), 0);

    out.m_data.m_flag   = m_data.m_flag;
    out.m_rows          = rows();
    out.m_cols          = cols();
    out.m_ldiags        = ldiags();
    out.m_udiags        = udiags();
    out.m_data.m_rows   = m_data.m_rows;
    out.m_data.m_cols   = m_data.m_cols;
    out.m_data.m_size   = m_data.m_size;

    if (keep_bufor == true)
    {
        Integer off     = (m_data.m_ptr - m_data.m_root_ptr)%ld();
        out.m_data.m_ptr+= off;
    };

    const value_type* ptr_this = ptr();
    value_type* ptr_out = out.ptr();

    for (Integer j = 0; j < m_cols; ++j)
    {
        Integer fr      = first_row(j);
        Integer lr      = last_row(j);
        Integer pos     = first_elem_pos(j);

        for(Integer i = fr; i <= lr; ++i, ++pos)
        {
            ptr_out[pos] = ptr_this[pos];
        };
        ptr_out         += out.ld();
        ptr_this        += ld();
    };
    return out;
};
template <class val_type>
mmlib::Matrix Matrix<val_type,struct_banded>::fast_optim() const
{
	if (rows() == 1 && cols() == 1)
	{
		return operator()(1,1);
	};
    //struct switch
    switch(get_struct().get())
    {            
        case mmlib::struct_flag::zero:
            return mmlib::Matrix(raw::Matrix<val_type,struct_sparse>(get_ti(),rows(),cols()),false);
        case mmlib::struct_flag::id:
        case mmlib::struct_flag::diag:
            return mmlib::Matrix(get_diag_band(),false);
    };
	if (Real(nnz())/(rows()+1)/(cols()+1) > optim_params::max_sparse_density_max)
	{
        typedef Matrix<val_type,struct_dense> full_matrix;
        full_matrix tmp = raw::converter<full_matrix,Matrix>::eval(get_ti(),*this);
        return mmlib::Matrix(tmp,false);
	}
    return mmlib::Matrix(*this,false);
};
template <class val_type>
Matrix<val_type,struct_banded>
Matrix<val_type,struct_banded>::get_diag_band() const
{
    if (m_ldiags == 0 && m_udiags == 0)
    {
        return *this;
    }
    Matrix out(get_ti(), m_rows, m_cols, 0, 0);
    Integer s = std::min(m_cols, m_rows);

	val_type * ptr              = out.ptr();
	const val_type * ptr_this	= Matrix::ptr() + m_udiags;

    for (Integer i = 0; i < s; ++i)
	{
		*(ptr++) = *ptr_this;
		ptr_this += ld();
	};

    out.get_struct() = this->get_struct();
    return out;
};

template <class val_type>
Matrix<val_type,struct_banded> 
Matrix<val_type,struct_banded>::reserve(Integer r, Integer c, Integer l, Integer u) const
{
    if (c <= m_data.m_max_cols && l <= max_ldiags() && u <= max_udiags())
    {
        return *this;
    };

    Integer m_c = cols();
    Integer m_r = rows();
    Integer rm  = std::max(r,m_r);    
    Integer cm  = std::max(c,max_cols());
    Integer um  = std::max(udiags(),u);
    Integer lm  = std::max(ldiags(), l);    
    um          = std::max(cm-1,0L);
    lm          = std::max(rm-1,0L);

    Matrix out(get_ti(), rm, cm, lm, um);

    out.m_rows          = m_r;
    out.m_cols          = m_c;
    out.m_ldiags        = ldiags();
    out.m_udiags        = udiags();
    out.m_data.m_rows   = ldiags() + udiags() + 1;
    out.m_data.m_size   = imult(out.m_data.m_rows,out.m_data.m_cols);
    out.m_data.m_ptr    = out.m_data.m_ptr + um - udiags();
    out.set_struct(get_struct());

    const value_type* this_ptr = ptr();
    value_type* ptr     = out.ptr();

    Integer m_r_rep     = ldiags() + udiags() + 1;

    if (m_r > 0)
    {
        for (Integer j = 0; j < m_c; ++j)
        {
            for (Integer i = 0; i < m_r_rep; ++i)
            {
                ptr[i]  = this_ptr[i];
            }
            ptr         += out.ld();
            this_ptr    += this->ld();
        }; 
    };

    return out;
};

template <class val_type>
Matrix<val_type,struct_banded> Matrix<val_type,struct_banded>::resize(Integer r, Integer c) const
{
    return resize(r, c, ldiags(), udiags());
};

template <class val_type>
Matrix<val_type,struct_banded> Matrix<val_type,struct_banded>::resize(Integer r, Integer c)
{
    return resize(r, c, ldiags(), udiags());
};

template <class val_type>
Matrix<val_type,struct_banded> 
Matrix<val_type,struct_banded>::resize(Integer r, Integer c, Integer l, Integer u) const
{
    error::check_resize(r,c);

    if (c <= cols() && l <= ldiags() && u <= udiags())
    {
        return make_view(1, r, c, l, u);
    };
    if (c <= m_data.m_max_cols && l <= max_ldiags() && u <= max_udiags())
    {
        Matrix out = copy(true);
        return out.resize(r,c,l,u);
    };

    Matrix out = reserve(r,c,l,u);
    return out.resize(r,c,l,u);
};

template <class val_type>
Matrix<val_type,struct_banded> 
Matrix<val_type,struct_banded>::resize(Integer r, Integer c, Integer l, Integer u)
{
    error::check_resize(r,c);

    l   = std::max(std::min(r-1,l),0L);
    u   = std::max(std::min(c-1,u),0L);

    if (c <= cols() && l <= ldiags() && u <= udiags())
    {
        return make_view(1,r,c,l,u);
    };

    Matrix out      = reserve(r,c,l,u);
    Integer m_c     = cols();
    value_type Z    = mmlib::details::default_value<value_type>(get_ti());

    if (u > udiags())
    {
        Integer du          = u - udiags();
        out.m_data.m_ptr    = out.m_data.m_ptr - du;
        value_type* ptr     = out.ptr();

        for (Integer j = 0; j < c; ++j)
        {
            for (Integer i = 0; i < du; ++i)
            {
                ptr[i]  = Z;
            };
            ptr += out.ld();
        };
    }
    else if (u < udiags())
    {
        Integer du          = udiags() - u;
        out.m_data.m_ptr    = out.m_data.m_ptr + du;
    };
    out.m_udiags            = u;
    out.m_ldiags            = l;
    out.m_rows              = r;
    out.m_cols              = c;
    out.m_data.m_rows       = l + u + 1;
    out.m_data.m_cols       = c;
    out.m_data.m_size       = imult(out.m_data.m_rows,out.m_data.m_cols);

    value_type* ptr         = out.ptr(); 

    for (Integer j = 0; j < m_c; ++j)
    {
        Integer fr          = out.first_row(j);
        Integer pos         = out.first_elem_pos(j) - fr;
        Integer lr1         = pos + this->last_row(j);
        Integer lr2         = pos + out.last_row(j);

        for (Integer i = lr1+1; i <= lr2; ++i)
        {
            ptr[i]          = Z;
        }
        ptr += out.ld();
    };
    
    for (Integer j = m_c; j < c; ++j)
    {
        Integer fr          = out.first_row(j);
        Integer lr          = out.last_row(j);
        Integer pos         = out.first_elem_pos(j);

        for (Integer i = fr; i <= lr; ++i, ++pos)
        {
            ptr[pos]        = Z;
        }
        ptr += out.ld();
    }; 

    bool is_sym = (r == c) && (out.ldiags() == out.udiags());
    out.m_data.get_struct() = out.m_data.get_struct().get_resize(is_sym);

    return out;
};

template <class val_type>
Matrix<val_type,struct_banded>
Matrix<val_type,struct_banded>::make_view(Integer rc0, Integer r, Integer c) const
{
    return make_view(rc0, r,c,ldiags(),udiags());
};
template <class val_type>
Matrix<val_type,struct_banded>
Matrix<val_type,struct_banded>::make_view(Integer rc0, Integer re, Integer ce, Integer l, Integer u) const
{
    Matrix out(*this);    

    Integer  r          = re - rc0 + 1;
    Integer  c          = ce - rc0 + 1;

    l                   = std::max(std::min(r-1,l),0L);
    u                   = std::max(std::min(c-1,u),0L);

    out.m_rows          = r;
    out.m_cols          = c;
    out.m_ldiags        = l;
    out.m_udiags        = u;

    Integer du          = udiags() - u;

    out.m_data.m_rows   = l+u+1;
    out.m_data.m_cols   = c;
    out.m_data.m_size   = imult(out.m_data.m_rows,out.m_data.m_cols);
    out.m_data.m_ptr    = const_cast<value_type*>(ptr()) + du + (rc0-1)*out.ld();

    bool is_sym = (r == c) && (out.ldiags() == out.udiags());
    out.m_data.get_struct() = out.m_data.get_struct().get_rectangle_view(is_sym);

    return out;
};
template<class value_type>
void Matrix<value_type,struct_banded>::check_struct() const
{
    switch (get_struct().get())
    {
        case struct_flag::zero:    goto check_struct_zero;
        case struct_flag::id:      goto check_struct_id;
        case struct_flag::diag:    goto check_struct_diag;
        case struct_flag::tril:    goto check_struct_tril;
        case struct_flag::triu:    goto check_struct_triu;
        case struct_flag::sym:     goto check_struct_sym;
        case struct_flag::her:     goto check_struct_her;
        case struct_flag::unitary: goto check_struct_unitary;
        case struct_flag::qtril:   goto check_struct_qtril;
        case struct_flag::qtriu:   goto check_struct_qtriu;
        case struct_flag::general: return;
        default:
        {
            assertion(0,"unknown case");
            throw;
        }
    };
    check_struct_tril:
    {
        Integer ud = raw::get_ud(*this,0,false);
        if (ud > 0)
        {
            throw error::error_invalid_struct(struct_flag::tril);
        };
        return;
    }

    check_struct_triu:
    {
        Integer ld = raw::get_ld(*this,0,false);
        if (ld > 0)
        {
            throw error::error_invalid_struct(struct_flag::triu);
        };
        return;
    }

    check_struct_diag:
    {
        Integer ud = raw::get_ud(*this,0,false);
        if (ud > 0)
        {
            throw error::error_invalid_struct(struct_flag::diag);
        };
        Integer ld = raw::get_ld(*this,0,false);
        if (ld > 0)
        {
            throw error::error_invalid_struct(struct_flag::diag);
        };
        return;
    }

    check_struct_zero:
    {
        Integer ud = raw::get_ud(*this,0,false);
        if (ud > 0)
        {
            throw error::error_invalid_struct(struct_flag::zero);
        };
        Integer ld = raw::get_ld(*this,0,false);
        if (ld > 0)
        {
            throw error::error_invalid_struct(struct_flag::zero);
        };

        Integer s = std::min(rows(), cols());
        const value_type* ptr = this->ptr() + this->udiags();
        for (Integer i = 0; i < s; ++i)
        {
            value_type val = *ptr;

            if (mmlib::details::is_zero(val) == false)
            {
                throw error::error_invalid_struct(struct_flag::zero);
            };

            ptr += this->ld();
        };
        return;
    }
    check_struct_id:
    {
        if (rows() != cols())
        {
            throw error::error_invalid_struct(struct_flag::id);
        };

        Integer ud = raw::get_ud(*this,0,false);
        if (ud > 0)
        {
            throw error::error_invalid_struct(struct_flag::id);
        };
        Integer ld = raw::get_ld(*this,0,false);
        if (ld > 0)
        {
            throw error::error_invalid_struct(struct_flag::id);
        };

        Integer s = std::min(rows(), cols());
        const value_type* ptr = this->ptr() + this->udiags();
        for (Integer i = 0; i < s; ++i)
        {
            value_type val = *ptr;

            if (mmlib::details::is_one(val) == false)
            {
                throw error::error_invalid_struct(struct_flag::id);
            };

            ptr += this->ld();
        };
        return;
    }

    check_struct_qtril:
    {
        Integer ud = raw::get_ud(*this,1,false);
        if (ud > 1)
        {
            throw error::error_invalid_struct(struct_flag::qtril);
        };
        if (ud == 0)
        {
            return;
        };
        Integer s = std::min(rows(), cols()-1);
        const value_type* ptr = this->ptr() + this->udiags() - 1 + this->ld();
        bool z = false;
        for (Integer i = 0; i < s; ++i)
        {
            value_type val = *ptr;

            if (mmlib::details::is_zero(val) == false)
            {
                if (z)  throw error::error_invalid_struct(struct_flag::qtril);
                else    z = true;
            }
            else
            {
                z = false;
            };

            ptr += this->ld();
        };
        return;
    }

    check_struct_qtriu:
    {
        Integer ld = raw::get_ld(*this,1,false);
        if (ld > 1)
        {
            throw error::error_invalid_struct(struct_flag::qtriu);
        };
        if (ld == 0)
        {
            return;
        };
        Integer s = std::min(rows()-1, cols());
        const value_type* ptr = this->ptr() + this->udiags() + 1;
        bool z = false;
        for (Integer i = 0; i < s; ++i)
        {
            value_type val = *ptr;

            if (mmlib::details::is_zero(val) == false)
            {
                if (z)  throw error::error_invalid_struct(struct_flag::qtriu);
                else    z = true;
            }
            else
            {
                z = false;
            };

            ptr += this->ld();
        };
        return;
    }

    check_struct_sym:
    {
        bool is_sym = raw::is_sym(*this,false);
        if (is_sym == false)
        {
            throw error::error_invalid_struct(struct_flag::sym);
        };
        return;
    }

    check_struct_her:
    {
        bool is_sym = raw::is_her(*this,false);
        if (is_sym == false)
        {
            throw error::error_invalid_struct(struct_flag::her);
        };
        return;
    }

    check_struct_unitary:
        return;
};

};};

template class mmlib::raw::Matrix<mmlib::Integer,mmlib::struct_banded>;
template class mmlib::raw::Matrix<mmlib::Real,mmlib::struct_banded>;
template class mmlib::raw::Matrix<mmlib::Complex,mmlib::struct_banded>;
template class mmlib::raw::Matrix<mmlib::Object,mmlib::struct_banded>;
