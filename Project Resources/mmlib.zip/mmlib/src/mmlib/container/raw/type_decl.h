/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/container/raw/mat.h"
#include "mmlib/container/raw/mat_d.h"
#include "mmlib/container/raw/mat_b.h"
#include "mmlib/container/raw/sp_mat.h"
#include "mmlib/container/raw/sp_mat_c.h"
#include "mmlib/container/raw/sp_mat_r.h"
#include "mmlib/container/raw/sp_mat_i.h"
#include "mmlib/container/raw/sp_mat_o.h"

namespace mmlib { namespace raw
{

typedef Matrix<Integer,struct_dense>			IntegerMatrix;
typedef Matrix<Real,struct_dense>				RealMatrix;
typedef Matrix<Complex,struct_dense>			ComplexMatrix;
typedef Matrix<Object,struct_dense>			    ObjectMatrix;

typedef Matrix<Integer,struct_sparse>			IntegerSparseMatrix;
typedef Matrix<Real,struct_sparse>				RealSparseMatrix;
typedef Matrix<Complex,struct_sparse>			ComplexSparseMatrix;
typedef Matrix<Object,struct_sparse>			ObjectSparseMatrix;

typedef Matrix<Integer,struct_banded>			IntegerBandMatrix;
typedef Matrix<Real,struct_banded>				RealBandMatrix;
typedef Matrix<Complex,struct_banded>			ComplexBandMatrix;
typedef Matrix<Object,struct_banded>			ObjectBandMatrix;


};};