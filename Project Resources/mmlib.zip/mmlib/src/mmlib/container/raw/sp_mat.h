/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/container/raw/spdat.h"
#include "mmlib/container/raw/mat.h"
#include "mmlib/details/enablers.h"


namespace mmlib { namespace raw 
{

template<class value_type>
class MMLIB_EXPORT sparse_matrix_base
{
	public:
		typedef value_type							value_type;
		typedef struct_sparse						struct_type;

		typedef Matrix<value_type,struct_sparse>	SparseMatrix;
		typedef Matrix<value_type,struct_dense>		DenseMatrix;
        typedef Matrix<value_type,struct_banded>    BandMatrix;
		typedef details::spdat<value_type>			spdat;
        typedef mmlib::details::type_info            type_info;
        typedef mmlib::details::refcount_str         refcount_str;

	private:
        SERIALIZE_MACRO
        void			    save(oarchive_impl & ar, const unsigned int version) const;
        void				load(iarchive_impl & ar, const unsigned int version);

	public:
        sparse_matrix_base(type_info ti) : m_data(ti)	{}
		sparse_matrix_base(type_info ti, Integer r, Integer c);
		sparse_matrix_base(type_info ti, Integer r, Integer c, Integer nzmax);
		sparse_matrix_base(type_info ti, const Integer* r_ind, const Integer* c_ind, 
                            const value_type* x_ind, Integer r, Integer c, Integer nnz);

		template<class Real_T>
		sparse_matrix_base(type_info ti, const Integer* ri, const Integer* ci, 
                            const Real_T* xr, const Real_T* xi, Integer r, Integer c, Integer nnz,
							typename mmlib::details::enable_if_val_complex<value_type,Real_T>::type = 0);

		sparse_matrix_base(type_info ti, const Integer* r_ind, const Integer* c_ind, const value_type* x_ind, 
							Integer r,Integer c, Integer nz, Integer nzmax);

		template<class Real_T>
		sparse_matrix_base(type_info ti, const Integer* ri, const Integer* ci, const Real_T* xr, const Real_T* xi, 
							Integer r, Integer c, Integer nnz, Integer nzmax,
							typename mmlib::details::enable_if_val_complex<value_type,Real_T>::type = 0);

		sparse_matrix_base(const sparse_matrix_base&);

        explicit sparse_matrix_base(const spdat &d) : m_data(d) {}

		~sparse_matrix_base() {};

		Integer					refcount() const;
        bool                    is_unique() const           { return m_data.is_unique(); };
        refcount_str*           get_refstr() const          { return m_data.get_refstr(); };

		sparse_matrix_base&		reset();
		sparse_matrix_base&		reset(Integer r, Integer c, Integer nz= 0);		
        void                    destroy_data();

		value_type 				operator()(Integer i, Integer j) const;
		
		SparseMatrix			get_diag(Integer = 0) const;	

		Integer					rows() const;
		Integer					cols() const;
        Integer					max_cols() const;
		Integer					nnz() const;
		Integer					nzmax();

		spdat&					rep()                       { return m_data; }
        const spdat&			rep() const                 { return m_data; }

        type_info               get_ti() const              { return m_data.get_ti(); };
        const struct_flag&      get_struct() const          { return m_data.get_struct(); };
        struct_flag&            get_struct()                { return m_data.get_struct(); };
        void                    set_struct(struct_flag f)   { m_data.get_struct() = f; };
        void                    check_struct() const;

        void                    assign(const sparse_matrix_base&);
        sparse_matrix_base      copy(bool keep_maxcol = false) const;

        sparse_matrix_base      reserve(Integer r, Integer c) const;
        sparse_matrix_base      resize(Integer r, Integer c) const;
        sparse_matrix_base      resize(Integer r, Integer c);
        sparse_matrix_base      make_view(Integer c_start, Integer c_end) const;

	 protected:
		spdat					m_data;
		void                    construct(const Integer* r_ind, const Integer* c_ind, const value_type* x_ind, 
								                Integer r, Integer c, Integer nz, Integer nzmax);

		DenseMatrix				full() const;
        BandMatrix              get_diag_band() const;

	private:
		void                    construct2(const Integer* r_ind, const Integer* c_ind, const Real* xr, 
                                            const Real* xi, Integer r, Integer c, Integer nz, Integer nzmax);		
        sparse_matrix_base&     operator=(const sparse_matrix_base&);
        sparse_matrix_base      resize_remrows(Integer r, Integer c) const;

        template<class val_type>
        friend mmlib::Matrix fast_optim_impl(const val_type& A);
};


};};

#include "mmlib/container/raw/sp_mat.inl"
