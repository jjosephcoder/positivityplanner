/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/fwd_decls.h"
#include "mmlib/container/raw/mat.h"
#include "mmlib/details/enablers.h"


namespace mmlib { namespace raw 
{
	
template<class value_type>
class MMLIB_EXPORT Matrix<value_type,struct_dense> : public dense_matrix_base<value_type>
{
	public:
		typedef struct_dense						struct_type;
		typedef value_type							value_type;
		typedef dense_matrix_base<value_type>		base_type;
        typedef mmlib::details::refcount_str         refcount_str;    
        typedef Matrix<value_type,struct_banded>    BandMatrix;

	private:
        SERIALIZE_MACRO
        void			    save(oarchive_impl & ar, const unsigned int version) const;
        void				load(iarchive_impl & ar, const unsigned int version);

	public:

		Matrix(type_info ti)                        : base_type(ti) {}
		Matrix(type_info ti,Integer r, Integer c)	: base_type(ti, r, c) {}
        Matrix(const base_type &mat)                : base_type(mat) {}
        ~Matrix()                                   {}

		template<class Real_T>
		Matrix(type_info ti,const Real_T* xr, const Real_T* xi, Integer r, Integer c,
			typename mmlib::details::enable_if_val_complex<value_type,Real_T>::type = 0);

		Matrix(type_info ti,const value_type *arr, Integer r, Integer c);
		Matrix(type_info ti,const value_type &val, Integer r, Integer c);


        refcount_str*       get_refstr() const      { return base_type::get_refstr(); };

        const value_type&	operator()(Integer i, Integer j) const;
        Matrix			    get_diag(Integer d = 0) const;
        void                assign(const Matrix&);
        Matrix              reshape(Integer r, Integer c) const;   
        Matrix              make_view(Integer r_start, Integer r_end) const;
        Matrix              make_view(Integer r_start, Integer r_end, Integer c_start, Integer c_end) const;
        mmlib::Matrix        fast_optim() const;
        Matrix              copy(bool keep_bufor = false) const;
        Matrix              make_explicit() const;
        void                destroy_data();   

        void                check_struct() const;

        Matrix              reserve(Integer r, Integer c) const;
        Matrix              resize(Integer r, Integer c) const;
        Matrix              resize(Integer r, Integer c);

        value_type*         ptr()                   { return base_type::ptr(); };
        const value_type*   ptr() const             { return base_type::ptr(); };

    private:
        Matrix&             operator=(const Matrix&);

        BandMatrix          get_diag_band() const;
        mmlib::Matrix        check_change_struct() const;
        Real                estim_density() const;
        void                set_to_all(const value_type& val);               

        using base_type::ptr;
};

};};