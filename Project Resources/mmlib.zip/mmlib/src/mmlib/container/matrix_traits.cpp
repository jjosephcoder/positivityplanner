/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/matrix_traits.h"
#include "mmlib/exception.h"

namespace mmlib
{

enums::value_type matrix_traits::get_value_type(enums::mat_type mt)
{
	switch (mt)
	{
		case enums::integer_dense:
		case enums::integer_sparse:
		case enums::integer_band:
		case enums::integer_scalar:
			return enums::value_integer;

		case enums::real_dense:
		case enums::real_sparse:
		case enums::real_band:
		case enums::real_scalar:
			return enums::value_real;

		case enums::complex_dense:						
		case enums::complex_sparse:						
		case enums::complex_band:
		case enums::complex_scalar:
			return enums::value_complex;

		case enums::object_dense:						
		case enums::object_sparse:						
		case enums::object_band:
		case enums::object_scalar:
			return enums::value_object;

		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};
enums::struct_type matrix_traits::get_struct_type(enums::mat_type mt)
{
	switch (mt)
	{
		case enums::integer_dense:
		case enums::real_dense:
		case enums::complex_dense:
        case enums::object_dense:
		{
			return enums::struct_dense;
		}			
		case enums::integer_scalar:
		case enums::real_scalar:
		case enums::complex_scalar:
        case enums::object_scalar:
		{
			return enums::struct_scalar;
		}			
		case enums::integer_sparse:
		case enums::real_sparse:
		case enums::complex_sparse:
        case enums::object_sparse:
		{
			return enums::struct_sparse;
		}			
		case enums::integer_band:
		case enums::real_band:
		case enums::complex_band:
        case enums::object_band:
		{
			return enums::struct_banded;
		}
		default:			
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};
enums::mat_type matrix_traits::get_matrix_type(enums::value_type vt, enums::struct_type st)
{
	switch (vt)
	{
		case enums::value_integer:
		{
			switch (st)
			{
				case enums::struct_dense:   return enums::integer_dense;
				case enums::struct_sparse:  return enums::integer_sparse;
				case enums::struct_banded:  return enums::integer_band;
				case enums::struct_scalar:  return enums::integer_scalar;
				default:
				{
					assertion(0,"unknown case");
					throw;
				}
			};
		}
		case enums::value_real:
		{
			switch (st)
			{
				case enums::struct_dense:   return enums::real_dense;
				case enums::struct_sparse:  return enums::real_sparse;
				case enums::struct_banded:  return enums::real_band;
				case enums::struct_scalar:  return enums::real_scalar;
				default:
				{
					assertion(0,"unknown case");
					throw;
				}
			};
		}
		case enums::value_complex:
		{
			switch (st)
			{
				case enums::struct_dense:   return enums::complex_dense;
				case enums::struct_sparse:  return enums::complex_sparse;
				case enums::struct_banded:  return enums::complex_band;
				case enums::struct_scalar:  return enums::complex_scalar;
				default:
				{
					assertion(0,"unknown case");
					throw;
				}
			};
		}
		case enums::value_object:
		{
			switch (st)
			{
				case enums::struct_dense:   return enums::object_dense;
				case enums::struct_sparse:  return enums::object_sparse;
				case enums::struct_banded:  return enums::object_band;
				case enums::struct_scalar:  return enums::object_scalar;
				default:
				{
					assertion(0,"unknown case");
					throw;
				}
			};
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};


};