/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/container/matrix2.inl"
#include "mmlib/visitors/assign_visitor.inl" 
#include "mmlib/visitors/assign_visitor_get.inl" 
#include "mmlib/visitors/assign_visitor_mat.inl" 
#include "mmlib/visitors/assign_visitor_del.inl" 
#include "mmlib/manip.h"
#include "mmlib/exception.h"
#include "mmlib/error/error_check.h"
#include "mmlib/container/matrix_container.inl"
#include "mmlib/details/extract_type.h" 
#include "mmlib/visitors/extract_type2_switch.h" 

namespace mmlib
{

namespace details
{

typedef std::pair<const colon*,const colon*> colon2;
typedef std::pair<Integer,Integer> Integer2;

static bool is_tr_view(const colon& c1,const colon& c2)
{
    bool r1, r2;
    int m_s1 = 0, m_s2 = 0;
    switch(c1.m_flag)
    {
        case colon::t_all:      r1 = false; break;
        case colon::t_range:
        case colon::t_end:
        {
            r1 = true;
            m_s1 = c1.m_s;
            if (c1.m_i != 1)
            {
                return false;
            };
            break;        
        }
        default:                return false;
    };
    switch(c2.m_flag)
    {
        case colon::t_all:      r2 = false; break;
        case colon::t_range:
        case colon::t_end:
        {
            r2 = true;
            m_s2 = c2.m_s;
            if (c2.m_i != 1)
            {
                return false;
            };
            break;
        }
        default:                return false;
    };
    if (r1 == true)
    {
        if (r2 == true)
        {
            if (m_s1 == m_s2)   return true;
            else                return false;
        }
        else
        {
            if (m_s1 == 1)      return true;
            else                return false;
        }
    }
    else
    {
        if (r2 == true)
        {
            if (m_s2 == 1)      return true;
            else                return false;
        }
        else
        {
            return true;
        }
    };
};
struct assign_visitor_1: public extract_type2_switch_nc<Matrix&,assign_visitor_1,Integer>
{
    template<class M1, class M2>
    static Matrix& eval_mat_mat(Matrix& handle, M1& A, const M2& B, Integer ind)
    {
	    if (B.rows() == 0 && B.cols() == 0)
	    {
		    handle = delrows(vec(handle),ind);
		    return handle;
	    };
	    error::check_assign(1,1,B.rows(),B.cols());
	    typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;

	    value_type_2 val = B(1,1);
        return assign_functor<M1,value_type_2>::eval(handle,A,val,ind);
    };
    template<class M1, class M2>
    static Matrix& eval_mat_scal(Matrix& handle, M1& A, const M2& B, Integer ind)
    {
	    typedef correct_complex_scalar<M2>::type value_type_2;
        return assign_functor<M1,value_type_2>::eval(handle,A,B,ind);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_mat(Matrix& handle, M1& , const M2& B, Integer ind)
    {
	    if (B.rows() == 0 && B.cols() == 0)
	    {
		    handle = delrows(vec(handle),ind);
		    return handle;
	    };
	    typedef raw::Matrix<M1,struct_dense> FullMatrix;
	    error::check_assign(1,1,B.rows(),B.cols());

        typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;
        value_type_2 val = B(1,1);
        return assign_functor_scal<M1,value_type_2>::eval(handle,val,ind);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_scal(Matrix& handle, M1& , const M2& B, Integer ind)
    {
	    typedef correct_complex_scalar<M2>::type value_type_2;
	    return assign_functor_scal<M1,value_type_2>::eval(handle,B,ind);
    };
};
struct assign_visitor_2: public extract_type2_switch_nc<Matrix&,assign_visitor_2,Integer2>
{
    template<class M1, class M2>
    static Matrix& eval_mat_mat(Matrix& handle, M1& A, const M2& B, Integer2 ind)
    {
	    error::check_assign(1,1,B.rows(),B.cols());
	    typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;

	    value_type_2 val = B(1,1);
        return assign_functor<M1,value_type_2>::eval(handle,A,val,ind.first,ind.second);
    };
    template<class M1, class M2>
    static Matrix& eval_mat_scal(Matrix& handle, M1& A, const M2& B, Integer2 ind)
    {
	    typedef correct_complex_scalar<M2>::type value_type_2;
        return assign_functor<M1,value_type_2>::eval(handle,A,B,ind.first,ind.second);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_mat(Matrix& handle, M1& , const M2& B, Integer2 ind)
    {
	    typedef raw::Matrix<M1,struct_dense> FullMatrix;
	    error::check_assign(1,1,B.rows(),B.cols());
	    typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;

        value_type_2 val = B(1,1);
        return assign_functor_scal<M1,value_type_2>::eval(handle,val,ind.first,ind.second);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_scal(Matrix& handle, M1& , const M2& B, Integer2 ind)
    {
	    typedef correct_complex_scalar<M2>::type value_type_2;
	    return assign_functor_scal<M1,value_type_2>::eval(handle,B,ind.first,ind.second);
    };
};
struct assign_visitor_3: public extract_type2_switch_nc<Matrix&,assign_visitor_3,const colon*>
{
    template<class M1, class M2>
    static Matrix& eval_mat_mat(Matrix& handle, M1& A, const M2& B, const colon* ind)
    {
	    Integer r = B.rows(), c = B.cols();
	    if ( r == 1 && c == 1)
	    {
		    typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;
		    value_type_2 val = B(1,1);
		    return assign_functor<M1,value_type_2>::eval(handle,A,val,*ind);
	    };
	    return assign_functor_mat<M1,M2>::eval(handle,B,*ind);

    };
    template<class M1, class M2>
    static Matrix& eval_mat_scal(Matrix& handle, M1& A, const M2& B, const colon* ind)
    {
	    typedef correct_complex_scalar<M2>::type value_type_2;
        return assign_functor<M1,value_type_2>::eval(handle,A,B,*ind);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_mat(Matrix& handle, M1& , const M2& B, const colon* ind)
    {
	    typedef raw::Matrix<M1,struct_dense> FullMatrix;

	    Integer r = B.rows(), c = B.cols();
	    if ( r == 1 && c == 1)
	    {
		    typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;
		    value_type_2 val = B(1,1);
		    handle = mmlib::full(handle);
            return assign_functor<FullMatrix,value_type_2>
                    ::eval(handle,handle.get_impl_unique<FullMatrix>(),val,*ind);
	    };
	    handle = mmlib::full(handle);
	    return assign_functor_mat<FullMatrix,M2>::eval(handle,B,*ind);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_scal(Matrix& handle, M1& , const M2& B, const colon* ind)
    {
	    typedef correct_complex_scalar<M2>::type value_type_2;
	    return assign_functor_scal<M1,value_type_2>::eval(handle,B,*ind);
    };
};
struct assign_visitor_4: public extract_type2_switch_nc<Matrix&,assign_visitor_4,colon2>
{
    template<class M1, class M2>
    static Matrix& eval_mat_mat(Matrix& handle, M1& A, const M2& B, colon2 ind)
    {
	    Integer r = B.rows(), c = B.cols();
	    if ( r == 1 && c == 1)
	    {
		    typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;
		    value_type_2 val = B(1,1);
            return assign_functor<M1,value_type_2>::eval(handle,A,val,*ind.first,*ind.second);
	    };
	    return assign_functor_mat<M1,M2>::eval(handle,B,*ind.first,*ind.second);
    };
    template<class M1, class M2>
    static Matrix& eval_mat_scal(Matrix& handle, M1& A, const M2& B, colon2 ind)
    {
	    typedef correct_complex_scalar<M2>::type value_type_2;
        return assign_functor<M1,value_type_2>::eval(handle,A,B,*ind.first,*ind.second);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_mat(Matrix& handle, M1& , const M2& B, colon2 ind)
    {
	    typedef raw::Matrix<M1,struct_dense> FullMatrix;

	    Integer r = B.rows(), c = B.cols();
	    if ( r == 1 && c == 1)
	    {
		    typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;
		    value_type_2 val = B(1,1);
		    handle = mmlib::full(handle);
            return assign_functor<FullMatrix,value_type_2>
                ::eval(handle,handle.get_impl_unique<FullMatrix>(),val,*ind.first,*ind.second);
	    };
	    handle = mmlib::full(handle);
	    return assign_functor_mat<FullMatrix,M2>::eval(handle,B,*ind.first,*ind.second);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_scal(Matrix& handle, M1& , const M2& B, colon2 ind)
    {
	    typedef correct_complex_scalar<M2>::type value_type_2;
	    return assign_functor_scal<M1,value_type_2>::eval(handle,B,*ind.first,*ind.second);
    };
};
struct assign_visitor_diag: public extract_type2_switch_nc<Matrix&,assign_visitor_diag,Integer>
{
    template<class M1, class M2>
    static Matrix& eval_mat_mat(Matrix& handle, M1& A, const M2& B, Integer d)
    {
        error::check_diag(d,A.rows(),A.cols());

	    Integer r = B.rows(), c = B.cols();
	    if ( r == 1 && c == 1)
	    {
		    typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;
		    value_type_2 val = B(1,1);
		    return assign_functor<M1,value_type_2>::eval_diag(handle,A,val,d);
	    };
	    return assign_functor_mat<M1,M2>::eval_diag(handle,B,d);

    };
    template<class M1, class M2>
    static Matrix& eval_mat_scal(Matrix& handle, M1& A, const M2& B, Integer d)
    {
        error::check_diag(d,A.rows(),A.cols());

	    typedef correct_complex_scalar<M2>::type value_type_2;
        return assign_functor<M1,value_type_2>::eval_diag(handle,A,B,d);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_mat(Matrix& handle, M1& , const M2& B, Integer d)
    {
	    typedef raw::Matrix<M1,struct_dense> FullMatrix;

        error::check_diag(d,1,1);

	    error::check_assign(1,1,B.rows(),B.cols());
	    typedef correct_complex_scalar<typename M2::value_type>::type value_type_2;
        value_type_2 val = B(1,1);
        return assign_functor_scal<M1,value_type_2>::eval(handle,val,1);
    };
    template<class M1, class M2>
    static Matrix& eval_scal_scal(Matrix& handle, M1& , const M2& B, Integer d)
    {
        error::check_diag(d,1,1);

	    typedef correct_complex_scalar<M2>::type value_type_2;
	    return assign_functor_scal<M1,value_type_2>::eval(handle,B,1);
    };
};

};

Matrix& details::SubMatrix::operator=(const Matrix& mat) const
{
    if (m_colon_2)
    {
        return assign_visitor_4
            ::make(*m_matrix,mat,details::colon2(m_colon_1,m_colon_2));
    }
    else if (m_colon_1)
    {
        return assign_visitor_3::make(*m_matrix,mat,m_colon_1);
    }
    else
    {
        return assign_visitor_diag::make(*m_matrix,mat,m_d);
    };
};
Matrix& details::SubMatrix_1::operator=(const Matrix& mat) const
{
    return assign_visitor_1::make(*m_matrix,mat,m_ind_1);
};
Matrix& details::SubMatrix_2::operator=(const Matrix& mat) const
{
    return assign_visitor_2
        ::make(*m_matrix,mat,details::Integer2(m_ind_1,m_ind_2));
};
Matrix& details::SubMatrix::operator=(const SubMatrix& mat0) const
{
	Matrix mat = mat0;
    return operator=(mat);
};
Matrix& details::SubMatrix::operator=(const SubMatrix_1& mat0) const
{
	Matrix mat = mat0;
    return operator=(mat);
};
Matrix& details::SubMatrix::operator=(const SubMatrix_2& mat0) const
{
	Matrix mat = mat0;
    return operator=(mat);
};
Matrix& details::SubMatrix_1::operator=(const SubMatrix& mat0) const
{
	Matrix mat = mat0;
    return operator=(mat);
};
Matrix& details::SubMatrix_1::operator=(const SubMatrix_1& mat0) const
{
	Matrix mat = mat0;
    return operator=(mat);
};
Matrix& details::SubMatrix_1::operator=(const SubMatrix_2& mat0) const
{
	Matrix mat = mat0;
    return operator=(mat);
};
Matrix& details::SubMatrix_2::operator=(const SubMatrix& mat0) const
{
	Matrix mat = mat0;
    return operator=(mat);
};
Matrix& details::SubMatrix_2::operator=(const SubMatrix_1& mat0) const
{
	Matrix mat = mat0;
    return operator=(mat);
};
Matrix& details::SubMatrix_2::operator=(const SubMatrix_2& mat0) const
{
	Matrix mat = mat0;
    return operator=(mat);
};

Matrix Matrix::operator()(Integer i,Integer j) const
{
	switch(m_type)
	{
		case enums::integer_scalar:
		{
			error::check_index(i,j,1,1);
			return m_value.val_int;
		}
		case enums::real_scalar:
		{
			error::check_index(i,j,1,1);
			return m_value.val_real;
		}
		case enums::complex_scalar:
		{
			error::check_index(i,j,1,1);
			return Complex(m_value.val_complex[0],m_value.val_complex[1]);
		}
		case enums::object_scalar:
		{
			error::check_index(i,j,1,1);
			return get_object();
		}
		case enums::integer_dense:
		{
			typedef details::matrix_container<Integer,struct_dense> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::real_dense:
		{
			typedef details::matrix_container<Real,struct_dense> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::complex_dense:
		{
			typedef details::matrix_container<Complex,struct_dense> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::object_dense:
		{
			typedef details::matrix_container<Object,struct_dense> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::integer_sparse:
		{
			typedef details::matrix_container<Integer,struct_sparse> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::real_sparse:	
		{
			typedef details::matrix_container<Real,struct_sparse> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::complex_sparse:
		{
			typedef details::matrix_container<Complex,struct_sparse> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::object_sparse:
		{
			typedef details::matrix_container<Object,struct_sparse> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::integer_band:	
		{
			typedef details::matrix_container<Integer,struct_banded> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::real_band:	
		{
			typedef details::matrix_container<Real,struct_banded> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::complex_band:
		{
			typedef details::matrix_container<Complex,struct_banded> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		case enums::object_band:
		{
			typedef details::matrix_container<Object,struct_banded> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i,j);
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};	
};
Matrix Matrix::operator()(Integer i) const
{
	switch(m_type)
	{
		case enums::integer_scalar:
		{
			error::check_index(i, 1);
			return m_value.val_int;
		}
		case enums::real_scalar:
		{
			error::check_index(i, 1);
			return m_value.val_real;
		}
		case enums::complex_scalar:
		{
			error::check_index(i, 1);
			return Complex(m_value.val_complex[0],m_value.val_complex[1]);
		}
		case enums::object_scalar:
		{
			error::check_index(i, 1);
			return get_object();
		}
		case enums::integer_dense:
		{
			typedef details::matrix_container<Integer,struct_dense> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::real_dense:
		{
			typedef details::matrix_container<Real,struct_dense> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::complex_dense:
		{
			typedef details::matrix_container<Complex,struct_dense> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::object_dense:
		{
			typedef details::matrix_container<Object,struct_dense> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::integer_sparse:
		{
			typedef details::matrix_container<Integer,struct_sparse> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::real_sparse:	
		{
			typedef details::matrix_container<Real,struct_sparse> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::complex_sparse:
		{
			typedef details::matrix_container<Complex,struct_sparse> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::object_sparse:
		{
			typedef details::matrix_container<Object,struct_sparse> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::integer_band:	
		{
			typedef details::matrix_container<Integer,struct_banded> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::real_band:	
		{
			typedef details::matrix_container<Real,struct_banded> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::complex_band:
		{
			typedef details::matrix_container<Complex,struct_banded> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		case enums::object_band:
		{
			typedef details::matrix_container<Object,struct_banded> cont_type;
			return static_cast<const cont_type*>(m_value.m_mat.mat_ptr)->get_elem(i);
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};	
};
namespace details
{
    struct get_functor_3 : public details::extract_type_1<Matrix,get_functor_3,true>
    {
        template<class T>
        static Matrix eval(const Matrix& handle, const T& mat, const colon& c1)
        {
            return details::get_sub_functor<T>::eval(handle,mat,c1);
        };
        template<class T>
        static Matrix eval_scalar(const Matrix& handle, const T& mat, const colon& c1)
        {
            return details::get_sub_functor_scal<T>::eval(handle,mat,c1);
        };
    };
    struct get_functor_4 : public details::extract_type_2<Matrix,get_functor_4,true>
    {
        template<class T>
        static Matrix eval(const Matrix& handle, const T& mat, const colon& c1, const colon& c2)
        {
            return details::get_sub_functor<T>::eval(handle,mat,c1,c2);
        };
        template<class T>
        static Matrix eval_scalar(const Matrix& handle, const T& mat, const colon& c1, const colon& c2)
        {
            return details::get_sub_functor_scal<T>::eval(handle,mat,c1,c2);
        };
    };
};

Matrix Matrix::operator()(const colon& c1) const
{
    return details::get_functor_3::make<const Matrix&,const colon&>(*this,c1);
}
Matrix Matrix::operator()(const colon& c1,const colon& c2) const
{
    Matrix ret = details::get_functor_4::make<const Matrix&,const colon&,const colon&>(*this,c1,c2);

    if (details::is_tr_view(c1,c2))
    {
        ret.set_struct(this->get_struct().get_rectangle_view(ret.is_square()));
    }
    return ret;
};

namespace details
{
    struct delrows_functor : public details::extract_type_1<Matrix,delrows_functor,true>
    {
        template<class T>
        static Matrix eval(const Matrix& handle, const T& mat, const colon& c1)
        {
            return details::del_rows_functor<T>::eval(handle,mat,c1);
        };
        template<class T>
        static Matrix eval_scalar(const Matrix& handle, const T& mat, const colon& c1)
        {
            return details::del_functor_scal<T>::eval(handle,mat,c1,true);
        };
    };
    struct delcols_functor : public details::extract_type_1<Matrix,delcols_functor,true>
    {
        template<class T>
        static Matrix eval(const Matrix& handle, const T& mat, const colon& c1)
        {
            return details::del_cols_functor<T>::eval(handle,mat,c1);
        };
        template<class T>
        static Matrix eval_scalar(const Matrix& handle, const T& mat, const colon& c1)
        {
            return details::del_functor_scal<T>::eval(handle,mat,c1,false);
        };
    };
};

Matrix Matrix::delrows(const colon& c) const
{
    return details::delrows_functor::make<const Matrix&,const colon&>(*this,c);
};
Matrix Matrix::delcols(const colon& c) const
{
    return details::delcols_functor::make<const Matrix&,const colon&>(*this,c);
};

Matrix details::SubMatrix::to_matrix() const
{
    const Matrix& tmp = *m_matrix;
    if (m_colon_2)
    {
        return tmp(*m_colon_1,*m_colon_2);
    }
    else if(m_colon_1)
    {
        return tmp(*m_colon_1);
    }
    else
    {
        return get_diag(tmp,m_d);
    };
};
Matrix details::SubMatrix_1::to_matrix() const
{
    const Matrix& tmp = *m_matrix;
	return tmp(m_ind_1);
};
Matrix details::SubMatrix_2::to_matrix() const
{
	const Matrix& tmp = *m_matrix;
    return tmp(m_ind_1,m_ind_2);
};

template MMLIB_EXPORT Matrix& details::SubMatrix::assign_scalar<Integer>(Integer val) const;
template MMLIB_EXPORT Matrix& details::SubMatrix::assign_scalar<Real>(Real val) const;
template MMLIB_EXPORT Matrix& details::SubMatrix::assign_scalar<Complex>(Complex val) const;
template MMLIB_EXPORT Matrix& details::SubMatrix::assign_scalar<Object>(Object val) const;

template MMLIB_EXPORT Matrix& details::SubMatrix_1::assign_scalar<Integer>(Integer val) const;
template MMLIB_EXPORT Matrix& details::SubMatrix_1::assign_scalar<Real>(Real val) const;
template MMLIB_EXPORT Matrix& details::SubMatrix_1::assign_scalar<Complex>(Complex val) const;
template MMLIB_EXPORT Matrix& details::SubMatrix_1::assign_scalar<Object>(Object val) const;

template MMLIB_EXPORT Matrix& details::SubMatrix_2::assign_scalar<Integer>(Integer val) const;
template MMLIB_EXPORT Matrix& details::SubMatrix_2::assign_scalar<Real>(Real val) const;
template MMLIB_EXPORT Matrix& details::SubMatrix_2::assign_scalar<Complex>(Complex val) const;
template MMLIB_EXPORT Matrix& details::SubMatrix_2::assign_scalar<Object>(Object val) const;
};