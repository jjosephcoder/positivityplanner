/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/type_decls.h"

namespace mmlib { namespace details
{

class MMLIB_EXPORT2 pool
{
    private:
        class pool_impl*    m_pool;

    public:
        pool(size_t size);
        ~pool();

        void*   malloc();
        void    free(void* ptr);
};

class MMLIB_EXPORT2 container_pool
{
    private:
        typedef pool table_type[enums::last_code];
        static table_type* m_pools;

    public:
        template<int code>
        static pool& get()
        {
            return (*m_pools)[code];
        };
        static pool& get(int code)
        {
            return (*m_pools)[code];
        };

        static void close();

    private:
        static table_type* init();
};

void MMLIB_EXPORT2 close_container_pool();

};};