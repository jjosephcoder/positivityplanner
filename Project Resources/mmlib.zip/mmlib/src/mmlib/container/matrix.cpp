/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/container/matrix2.inl"
#include "mmlib/container/matrix_container.inl"
#include "mmlib/matrix_concat.h"
#include "mmlib/exception.h"
#include "mmlib/matrix_traits.h"
#include "mmlib/matrix_gen.h"
#include "mmlib/matrix_func_unary.h"
#include "mmlib/colon.h"
#include "mmlib/constants.h"

namespace mmlib
{

Matrix::Matrix()
{
	details::constructor_helper<double>::eval(0.,true,*this);
};
void Matrix::increase_refcount() const
{
    if (m_type < enums::integer_dense)
        return;

    m_value.m_mat.m_ref->increase();
    m_value.m_mat.mat_ptr->increase();
};
void Matrix::decrease_refcount() const
{
    if (m_type < enums::integer_dense)
        return;

	if(m_value.m_mat.m_ref->decrease())
    {        
        m_value.m_mat.m_ref->destroy();
        destroy_container(m_value.m_mat.mat_ptr);
    }
    else if (m_value.m_mat.mat_ptr->decrease())
    {   
        free_container(m_value.m_mat.mat_ptr);
    };
};
Matrix::Matrix(const Matrix& mat)
{
	m_type = mat.m_type;
	m_value = mat.m_value;
	increase_refcount();
};
Matrix::Matrix(const mat_row& mr)
{
	Matrix tmp = mr.to_matrix();
	m_type	= tmp.m_type;
	m_value = tmp.m_value;
	increase_refcount();
};
Matrix::Matrix(const mat_col& mc)
{
	const Matrix& tmp = mc.to_matrix();
	m_type	= tmp.m_type;
	m_value = tmp.m_value;
	increase_refcount();
};
Matrix::~Matrix()
{
	decrease_refcount();
};
Integer Matrix::rows() const
{
    if (m_type < enums::integer_dense)
        return 1;

	return m_value.m_mat.mat_ptr->rows();
}; 
Integer	Matrix::cols() const
{
    if (m_type < enums::integer_dense)
        return 1;

	return m_value.m_mat.mat_ptr->cols();
}; 

Integer	Matrix::nnz() const
{
	switch(m_type)
	{
		case enums::integer_scalar:
		{
			return (m_value.val_int == 0)? 0 : 1;
		}
		case enums::real_scalar:
		{
			return (m_value.val_real == 0.)? 0 : 1;
		}
		case enums::complex_scalar:
		{
			return (m_value.val_complex[0] == 0. && m_value.val_complex[1] == 0.)? 0 : 1;
		}
        case enums::object_scalar:
		{
			return (get_object().is_zero() == true)? 0 : 1;
		}
		default:
		{
			return m_value.m_mat.mat_ptr->nnz();
		}
	};
}; 
Integer	Matrix::ldiags() const
{
    if (m_type < enums::integer_dense)
        return 0;

	return m_value.m_mat.mat_ptr->ldiags();
};
Integer Matrix::udiags() const
{
    if (m_type < enums::integer_dense)
        return 0;

	return m_value.m_mat.mat_ptr->udiags();
};
int_tup_2 Matrix::size() const
{
    if (m_type < enums::integer_dense)
        return int_tup_2(1,1);

	return m_value.m_mat.mat_ptr->size();
}; 
Integer	Matrix::length() const
{
	Integer m,n;
	tie(m,n) = size();
    
    if (m == 0 || n == 0)   return 0;

    return (m > n ? m : n);
};
Real Matrix::numel() const
{
	Integer m,n;
	tie(m,n) = size();
    return Real(m)*Real(n);
};
bool Matrix::is_empty() const
{
	Integer m,n;
	tie(m,n) = size();
	return (m == 0 || n == 0);
};
bool Matrix::is_scalar() const
{
	Integer m,n;
	tie(m,n) = size();
	return (m == 1 && n == 1);
};
bool Matrix::is_matrix_type() const
{
    if (m_type < enums::integer_dense)
        return false;

	return true;
};
bool Matrix::is_scalar_type() const
{
    if (m_type < enums::integer_dense)
        return true;

	return false;
};

bool Matrix::is_square() const
{
	Integer m,n;
	tie(m,n) = size();
	return (m == n);
};
bool Matrix::is_vector() const
{
	Integer m,n;
	tie(m,n) = size();
	return (m == 1 || n == 1);
};
bool Matrix::is_unique() const
{
    if (m_type < enums::integer_dense)
        return true;

	return m_value.m_mat.m_ref->is_unique();
};

enums::value_type Matrix::value_type() const
{
	return matrix_traits::get_value_type(m_type);
};
enums::struct_type Matrix::struct_type() const
{
	return matrix_traits::get_struct_type(m_type);
};
Matrix& Matrix::operator=(const details::SubMatrix& mat)
{
	return operator=(mat.to_matrix());
}
Matrix& Matrix::operator=(const details::SubMatrix_1& mat)
{
	return operator=(mat.to_matrix());
}
Matrix& Matrix::operator=(const details::SubMatrix_2& mat)
{
	return operator=(mat.to_matrix());
}
Matrix& Matrix::operator=(const Matrix& mat)
{
	mat.increase_refcount();
	decrease_refcount();

    matrix_base::operator =(mat);
	return *this;
};
const struct_flag Matrix::get_struct() const
{
    if (m_type < enums::integer_dense)
        return struct_flag();

	return m_value.m_mat.mat_ptr->get_struct();
};
void Matrix::set_struct(const struct_flag& fl)
{
    if (m_type < enums::integer_dense)
        return;

    //this is probably thread safe
    //struct is always proper
    //if different thread does not see the change, then all operations are still valid
    //unless struct is checked many times during one operation
    //struct change must be atomic at least from persepctive of given thread
	m_value.m_mat.mat_ptr->set_struct(fl);
};
const details::matrix_container_base* Matrix::get_mat_ptr_prv() const
{
	switch(m_type)
	{
		case enums::integer_scalar:
		case enums::real_scalar:
		case enums::complex_scalar:
        case enums::object_scalar:
		{
			throw error::error_invalid_return_type();
		}
		default:
		{
			return m_value.m_mat.mat_ptr;
		}
	};
};
bool Matrix::is_scalar_true() const
{
	switch(m_type)
	{
		case enums::integer_scalar:
		{
			return (m_value.val_int != 0);
		}
		case enums::real_scalar:
		{
			return (m_value.val_real != 0.);
		}
		case enums::complex_scalar:
		{
			return (m_value.val_complex[0] != 0. || m_value.val_complex[1] != 0.);
		}
        case enums::object_scalar:
        {
            return get_object().is_true();
        }
		default:
		{
			return m_value.m_mat.mat_ptr->is_scalar_true();
		}
	};
};
Matrix::Matrix(const details::SubMatrix& sm)
{
	Matrix tmp = sm.to_matrix();
	m_type	= tmp.m_type;
	m_value = tmp.m_value;
	increase_refcount();
};
Matrix::Matrix(const details::SubMatrix_1& sm)
{
	Matrix tmp = sm.to_matrix();
	m_type	= tmp.m_type;
	m_value = tmp.m_value;
	increase_refcount();
};
Matrix::Matrix(const details::SubMatrix_2& sm)
{
	Matrix tmp = sm.to_matrix();
	m_type	= tmp.m_type;
	m_value = tmp.m_value;
	increase_refcount();
};
inline details::type_info Matrix::get_ti() const
{
    if (m_type < enums::integer_dense)
        return details::get_raw_ti();

    return m_value.m_mat.mat_ptr->get_ti();
};
details::SubMatrix Matrix::diag(Integer d)
{
	details::SubMatrix ret = details::SubMatrix(d,this);
    return ret;
};
Matrix Matrix::diag(Integer d) const
{
    return get_diag(*this,d);
};

details::SubMatrix* details::SubMatrix::clone()
{
    details::SubMatrix* ret = new details::SubMatrix();
    ret->m_matrix = m_matrix;

    const colon* ptr1_c = this->m_colon_1;
    const colon* ptr2_c = this->m_colon_2;

    colon* ptr1 = NULL;        
    colon* ptr2 = NULL;
    if (ptr1_c)   
        ptr1 = new colon(*ptr1_c);
    if (ptr2_c)   
        ptr2 = new colon(*ptr2_c);

    ret->m_colon_1 = ptr1;
    ret->m_colon_2 = ptr2;
    ret->m_d = this->m_d;
    return ret;
};
details::SubMatrix_1* details::SubMatrix_1::clone()
{
    details::SubMatrix_1* ret = new details::SubMatrix_1();
    ret->m_matrix = m_matrix;
    ret->m_ind_1 = this->m_ind_1;
    return ret;
};
details::SubMatrix_2* details::SubMatrix_2::clone()
{
    details::SubMatrix_2* ret = new details::SubMatrix_2(*this);
    ret->m_matrix = m_matrix;
    ret->m_ind_1 = this->m_ind_1;
    ret->m_ind_2 = this->m_ind_2;
    return ret;
};
void details::SubMatrix::destroy()
{
    delete this->m_colon_1;
    delete this->m_colon_2;
    delete this;
};
void details::SubMatrix_1::destroy()
{
    delete this;
};
void details::SubMatrix_2::destroy()
{
    delete this;
};

void Matrix::resize(Integer r, Integer c)
{
    if (m_type < enums::integer_dense)
    {
        *this = full(*this);
        *this = m_value.m_mat.mat_ptr->resize(r,c);
        return;
    };
    *this = m_value.m_mat.mat_ptr->resize(r,c);
};
void Matrix::reserve(Integer r, Integer c)
{
    if (m_type < enums::integer_dense)
    {
        *this = full(*this);
        *this = m_value.m_mat.mat_ptr->reserve(r,c);
        return;
    };
    *this = m_value.m_mat.mat_ptr->reserve(r,c);
};
void Matrix::resize_band(Integer r, Integer c, Integer ld, Integer ud)
{
    if (m_type < enums::integer_dense)
    {
        *this = full(*this);
        *this = m_value.m_mat.mat_ptr->resize_band(r,c,ld,ud);
        return;
    };
    *this = m_value.m_mat.mat_ptr->resize_band(r,c,ld,ud);
};
void Matrix::reserve_band(Integer r, Integer c, Integer ld, Integer ud)
{
    if (m_type < enums::integer_dense)
    {
        *this = full(*this);
        *this = m_value.m_mat.mat_ptr->reserve_band(r,c,ld,ud);
        return;
    };
    *this = m_value.m_mat.mat_ptr->reserve_band(r,c,ld,ud);
};
void Matrix::check_struct() const
{
    if (m_type < enums::integer_dense)
    {
        return;
    };

    if (get_struct().get() == struct_flag::unitary)
    {
        if (rows() != cols())
        {
            throw error::error_invalid_struct(struct_flag::unitary);
        };

        Matrix tmp = (*this)*ctrans(*this) - speye(rows());
        tmp = max_abs_d(max_abs_d(tmp,1),2);

        if ((tmp > 100 * constants::Eps).is_scalar_true())
        {
            throw error::error_invalid_struct(struct_flag::unitary);
        }
        else
        {
            return;
        };
    };
    return m_value.m_mat.mat_ptr->check_struct();
};

};
