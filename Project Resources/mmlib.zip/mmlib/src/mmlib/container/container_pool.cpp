/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/container/container_pool.h"
#include "mmlib/container/matrix_container.h"

#include "boost/pool/pool.hpp"
#include "boost/smart_ptr/detail/spinlock.hpp"

namespace mmlib { namespace details
{

class pool_impl : private boost::pool<boost::default_user_allocator_malloc_free>
{
    private:
        typedef boost::pool<boost::default_user_allocator_malloc_free> base_type;
        typedef boost::detail::spinlock::scoped_lock scoped_lock;
        boost::detail::spinlock m_mutex;
        long n_item;

    public:
        pool_impl(size_t size)
            :base_type(size)
        {
            m_mutex.v_ = 0;
            n_item = 0;
        };
        void* malloc()
        {
            scoped_lock lock(m_mutex);
            ++n_item;
            return base_type::malloc();
        };
        void free(void* ptr)
        {
            scoped_lock lock(m_mutex);
            --n_item;
            base_type::free(ptr);
        };
};

pool::pool(size_t size)
{
    m_pool = new pool_impl(size);
};
pool::~pool()
{
    delete m_pool;
};
void* pool::malloc()
{
    return m_pool->malloc();
};
void  pool::free(void* ptr)
{
    return m_pool->free(ptr);
};

container_pool::table_type* container_pool::m_pools = container_pool::init();

template<class T>
struct pool_size_impl
{
    static const size_t value = 4;
};
template<class V, class S>
struct pool_size_impl<raw::Matrix<V,S>>
{
    typedef matrix_container<V,S> container_type;
    static const size_t value = sizeof(container_type);
};
template<int code>
struct pool_size
{
    typedef typename code_to_type<(enums::mat_type)code>::type		matrix_type;
    static const size_t value = pool_size_impl<matrix_type>::value;
};
template<typename table_type, int code>
struct init_impl
{
    static void eval(table_type* ptr)
    {
        new(&ptr[code]) pool(pool_size<code>::value);
        init_impl<table_type,code-1>::eval(ptr);
    };
};
template<typename table_type>
struct init_impl<table_type,0>
{
    static void eval(table_type* ptr)
    {
        new(ptr) pool(pool_size<0>::value);
    };
};
struct pool_type_size
{
    char member[sizeof(pool)];
};
container_pool::table_type* container_pool::init()
{
    static pool_type_size m_table[enums::last_code];
    pool* ptr = reinterpret_cast<pool*>(m_table);
    init_impl<pool,enums::last_code-1>::eval(ptr);
    return reinterpret_cast<table_type*>(&m_table);
};

void container_pool::close()
{
    for (int i = 0; i < enums::last_code; ++i)
    {
        (*m_pools)[i].~pool();
    };    
};

void close_container_pool()
{
    container_pool::close();
};

};};