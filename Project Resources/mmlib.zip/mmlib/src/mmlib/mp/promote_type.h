/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/isa.h"
#include "mmlib/details/mpl.h"
#include "mmlib/func/raw/converter.h"
#include "mmlib/details/type_info_utils.h"

namespace mmlib { namespace raw
{

namespace details
{

template <class T> struct lazy_value_type	{ typedef typename T::value_type type; };
template <class T> struct lazy_struct_type	{ typedef typename T::struct_type type; };

template<class T>	struct get_val_type
{
	static const bool is_sc		= mmlib::details::is_scalar<T>::value;

	typedef typename mmlib::details::lazy_select_if
		<
			is_sc,
			mmlib::details::promote_scalar<T>,
			lazy_value_type<T>
		>::type type;
};
template<class T>
struct get_struct_type
{
	static const bool is_sc		= mmlib::details::is_scalar<T>::value;

	typedef typename mmlib::details::lazy_select_if
		<
			is_sc,
			mmlib::details::lazy_type<struct_dense>,
			lazy_struct_type<T>
		>::type type;
};

template<class T, class T_pr, bool is_mat, bool is_scal>
struct promote_arg
{
    static T_pr eval(mmlib::details::type_info ti, const T& arg)
	{
		return converter<T_pr,T>::eval(ti,arg);
	};
};
template<class T, class T_pr>
struct promote_arg<T,T_pr,false,true>
{
	static T_pr eval(mmlib::details::type_info ti, const T& arg)
	{
		typedef typename T_pr value_type;
		return converter<T_pr,value_type>::eval(ti, value_type(arg));
	};
};

template<class T>
struct promote_type_impl
{
	typedef typename get_val_type<T>::type		value_type;
	typedef typename get_struct_type<T>::type	struct_type;

	typedef Matrix<value_type,struct_type>		type;
};
};
template<class T>
struct promote_type
{
	typedef typename details::promote_type_impl<T>::type type;

	static type eval(const T& arg)
	{
		static const bool ism = mmlib::details::is_matrix<T>::value;
		static const bool iss = mmlib::details::is_scalar<type>::value;
        mmlib::details::type_info ti = mmlib::details::get_ti(arg);
		return details::promote_arg<T,type,ism,iss>::eval(ti,arg);
	};
};

template<class T>   struct get_value_type   {   typedef typename T::value_type type; };
template<> struct get_value_type<Integer>   {   typedef Integer type; };
template<> struct get_value_type<Real>      {   typedef Real type; };
template<> struct get_value_type<Complex>   {   typedef Complex type; };
template<> struct get_value_type<Object>    {   typedef Object type; };

template<class T>   struct get_struct_type   {   typedef typename T::struct_type type; };
template<> struct get_struct_type<Integer>   {   typedef struct_scalar type; };
template<> struct get_struct_type<Real>      {   typedef struct_scalar type; };
template<> struct get_struct_type<Complex>   {   typedef struct_scalar type; };
template<> struct get_struct_type<Object>    {   typedef struct_scalar type; };

template<class V1, class V2>
struct ret_value_type
{
	typedef typename mmlib::details::select_if
	<
        mmlib::details::is_equal<V1,Object>::value 
            || mmlib::details::is_equal<V2,Object>::value,
		Object,
	    typedef typename mmlib::details::select_if
	    <
		    mmlib::details::is_equal<V1,Integer>::value,
		    V2,
		    V1
	    >::type
	>::type type;
};
template<class V, class S>
struct ret_matrix_type
{
    typedef mmlib::raw::Matrix<V,S>  type;
};
template<class V>
struct ret_matrix_type<V,struct_scalar>
{
    typedef V  type;
};

template<class T1, class T2>
struct val_type_corrector
{
    typedef typename get_value_type<T1>::type               val_1;
    typedef typename get_value_type<T2>::type               val_2;
    typedef typename get_struct_type<T1>::type              str_1;
    typedef typename get_struct_type<T2>::type              str_2;
    typedef typename ret_value_type<val_1,val_2>::type      val_ret_1;
    typedef typename ret_value_type<val_2,val_1>::type      val_ret_2;

    typedef typename ret_matrix_type<val_ret_1,str_1>::type type_1;
    typedef typename ret_matrix_type<val_ret_2,str_2>::type type_2;

    static type_1  convert_1(mmlib::details::type_info ti, const T1& mat)
    {
        return mmlib::raw::converter<type_1,T1>::eval(ti,mat);
    };
    static type_2  convert_2(mmlib::details::type_info ti, const T2& mat)
    {
        return mmlib::raw::converter<type_2,T2>::eval(ti,mat);
    };
};

};};
