/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once 

#include "mmlib/container/raw/type_decl.h"

namespace mmlib { namespace raw
{
	using mmlib::Integer;
	using mmlib::Real;
	using mmlib::Complex;
    using mmlib::Object;
};};

#define MACRO_EVAL_SCALAR_TYPES(macro,arg,arg2)		\
macro(Integer,arg,arg2)								\
macro(Real,arg,arg2)								\
macro(Complex,arg,arg2)								\
macro(Object,arg,arg2)								\

#define MACRO_EVAL_SCALAR_TYPES_2(macro,arg,arg2)	\
macro(Integer,arg,arg2)								\
macro(Real,arg,arg2)								\
macro(Complex,arg,arg2)								\
macro(Object,arg,arg2)								\

#define MACRO_EVAL_GEN_TYPES(macro,arg,arg2)		\
macro(IntegerMatrix,arg,arg2)						\
macro(RealMatrix,arg,arg2)							\
macro(ComplexMatrix,arg,arg2)						\
macro(ObjectMatrix,arg,arg2)						\
macro(IntegerSparseMatrix,arg,arg2)					\
macro(RealSparseMatrix,arg,arg2)					\
macro(ComplexSparseMatrix,arg,arg2)					\
macro(ObjectSparseMatrix,arg,arg2)					

#define MACRO_EVAL_GEN_TYPES_2(macro,arg,arg2)		\
macro(IntegerMatrix,arg,arg2)						\
macro(RealMatrix,arg,arg2)							\
macro(ComplexMatrix,arg,arg2)						\
macro(ObjectMatrix,arg,arg2)						\
macro(IntegerSparseMatrix,arg,arg2)					\
macro(RealSparseMatrix,arg,arg2)					\
macro(ComplexSparseMatrix,arg,arg2)					\
macro(ObjectSparseMatrix,arg,arg2)					

#define MACRO_EVAL_VEC_TYPES_2(macro,arg,arg2)		\
macro(IntegerMatrix,arg,arg2)						\
macro(RealMatrix,arg,arg2)							\
macro(ComplexMatrix,arg,arg2)						\
macro(ObjectMatrix,arg,arg2)						\
macro(IntegerSparseMatrix,arg,arg2)					\
macro(RealSparseMatrix,arg,arg2)					\
macro(ComplexSparseMatrix,arg,arg2)					\
macro(ObjectSparseMatrix,arg,arg2)					

#define MACRO_EVAL_STR_TYPES(macro,arg,arg2)		\
macro(IntegerBandMatrix,arg,arg2)					\
macro(RealBandMatrix,arg,arg2)						\
macro(ComplexBandMatrix,arg,arg2)                   \
macro(ObjectBandMatrix,arg,arg2)

#define MACRO_EVAL_STR_TYPES_2(macro,arg,arg2)		\
macro(IntegerBandMatrix,arg,arg2)					\
macro(RealBandMatrix,arg,arg2)						\
macro(ComplexBandMatrix,arg,arg2)                   \
macro(ObjectBandMatrix,arg,arg2)                   

#define MACRO_EVAL_STRUCT_TYPES(macro,arg,arg2)		\
macro(struct_banded,arg,arg2)


#define MACRO_INSTANTIATE_21_IMPL(type_name2,type_name1,cl_name)	\
	template struct cl_name<mmlib::raw::type_name1,mmlib::raw::type_name2>;

#define MACRO_INSTANTIATE_1_IMPL(type_name,cl_name,arg2)			\
	template struct cl_name<mmlib::raw::type_name>;


#define MACRO_INSTANTIATE_2_G_IMPL(type_name,cl_name,arg2)			\
	MACRO_EVAL_GEN_TYPES_2(MACRO_INSTANTIATE_21_IMPL,type_name,cl_name)

#define MACRO_INSTANTIATE_2_S_IMPL(type_name,cl_name,arg2)			\
	MACRO_EVAL_SCALAR_TYPES_2(MACRO_INSTANTIATE_21_IMPL,type_name,cl_name)

#define MACRO_INSTANTIATE_2_ST_IMPL(type_name,cl_name,arg2)			\
	MACRO_EVAL_STR_TYPES_2(MACRO_INSTANTIATE_21_IMPL,type_name,cl_name)


#define MACRO_INSTANTIATE_SCAL_1(cl_name)							\
MACRO_EVAL_SCALAR_TYPES(MACRO_INSTANTIATE_1_IMPL,cl_name,)				

#define MACRO_INSTANTIATE_G_1(cl_name)								\
MACRO_EVAL_GEN_TYPES(MACRO_INSTANTIATE_1_IMPL,cl_name,)				

#define MACRO_INSTANTIATE_S_1(cl_name)								\
MACRO_EVAL_STR_TYPES(MACRO_INSTANTIATE_1_IMPL,cl_name,)

#define MACRO_INSTANTIATE_SS_2(cl_name)							\
MACRO_INSTANTIATE_21_IMPL(Integer,Integer,cl_name)				\
MACRO_INSTANTIATE_21_IMPL(Real,Real,cl_name)					\
MACRO_INSTANTIATE_21_IMPL(Complex,Real,cl_name)					\
MACRO_INSTANTIATE_21_IMPL(Complex,Real,cl_name)					\
MACRO_INSTANTIATE_21_IMPL(Object,Object,cl_name)				\

#define MACRO_INSTANTIATE_SS_2_F(cl_name)						\
MACRO_EVAL_SCALAR_TYPES(MACRO_INSTANTIATE_2_S_IMPL,cl_name,)

#define MACRO_INSTANTIATE_GS_2(cl_name)							\
MACRO_INSTANTIATE_21_IMPL(Integer,IntegerMatrix,cl_name)		\
MACRO_INSTANTIATE_21_IMPL(Integer,IntegerSparseMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(Real,RealMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(Real,RealSparseMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(Real,ComplexMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(Real,ComplexSparseMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(Complex,RealMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(Complex,RealSparseMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(Complex,ComplexMatrix,cl_name)		\
MACRO_INSTANTIATE_21_IMPL(Complex,ComplexSparseMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(Object,ObjectMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(Object,ObjectSparseMatrix,cl_name)	\

#define MACRO_INSTANTIATE_SG_2_F(cl_name)						\
MACRO_EVAL_SCALAR_TYPES(MACRO_INSTANTIATE_2_G_IMPL,cl_name,)

#define MACRO_INSTANTIATE_STS_2(cl_name)						\
MACRO_INSTANTIATE_21_IMPL(Integer,IntegerBandMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(Real,RealBandMatrix,cl_name)	        \
MACRO_INSTANTIATE_21_IMPL(Real,ComplexBandMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(Complex,RealBandMatrix,cl_name)		\
MACRO_INSTANTIATE_21_IMPL(Complex,ComplexBandMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(Object,ObjectBandMatrix,cl_name)		\

#define MACRO_INSTANTIATE_SST_2_F(cl_name)						\
MACRO_EVAL_SCALAR_TYPES(MACRO_INSTANTIATE_2_ST_IMPL,cl_name,)

#define MACRO_INSTANTIATE_SG_2(cl_name)							\
MACRO_INSTANTIATE_21_IMPL(IntegerMatrix,Integer,cl_name)		\
MACRO_INSTANTIATE_21_IMPL(IntegerSparseMatrix,Integer,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(RealMatrix,Real,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(RealSparseMatrix,Real,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(ComplexMatrix,Real,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(ComplexSparseMatrix,Real,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(RealMatrix,Complex,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(RealSparseMatrix,Complex,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(ComplexMatrix,Complex,cl_name)		\
MACRO_INSTANTIATE_21_IMPL(ComplexSparseMatrix,Complex,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(ObjectMatrix,Object,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(ObjectSparseMatrix,Object,cl_name)	\

#define MACRO_INSTANTIATE_GS_2_F(cl_name)						\
MACRO_EVAL_GEN_TYPES(MACRO_INSTANTIATE_2_S_IMPL,cl_name,)

#define MACRO_INSTANTIATE_GG_2(cl_name)							            \
MACRO_INSTANTIATE_21_IMPL(IntegerMatrix,IntegerMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(IntegerMatrix,IntegerSparseMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(IntegerSparseMatrix,IntegerMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(IntegerSparseMatrix,IntegerSparseMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(RealMatrix,RealMatrix,cl_name)		            \
MACRO_INSTANTIATE_21_IMPL(RealMatrix,RealSparseMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(RealSparseMatrix,RealMatrix,cl_name)	            \
MACRO_INSTANTIATE_21_IMPL(RealSparseMatrix,RealSparseMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(ComplexMatrix,RealMatrix,cl_name)		            \
MACRO_INSTANTIATE_21_IMPL(ComplexMatrix,RealSparseMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(ComplexSparseMatrix,RealMatrix,cl_name)	        \
MACRO_INSTANTIATE_21_IMPL(ComplexSparseMatrix,RealSparseMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(RealMatrix,ComplexMatrix,cl_name)		            \
MACRO_INSTANTIATE_21_IMPL(RealMatrix,ComplexSparseMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(RealSparseMatrix,ComplexMatrix,cl_name)	        \
MACRO_INSTANTIATE_21_IMPL(RealSparseMatrix,ComplexSparseMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(ComplexMatrix,ComplexMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(ComplexMatrix,ComplexSparseMatrix,cl_name)		\
MACRO_INSTANTIATE_21_IMPL(ComplexSparseMatrix,ComplexMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(ComplexSparseMatrix,ComplexSparseMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(ObjectMatrix,ObjectMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(ObjectMatrix,ObjectSparseMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(ObjectSparseMatrix,ObjectMatrix,cl_name)	        \
MACRO_INSTANTIATE_21_IMPL(ObjectSparseMatrix,ObjectSparseMatrix,cl_name)	\

#define MACRO_INSTANTIATE_GG_2_F(cl_name)								\
MACRO_EVAL_GEN_TYPES(MACRO_INSTANTIATE_2_G_IMPL,cl_name,)

#define MACRO_INSTANTIATE_STG_2(cl_name)							        \
MACRO_INSTANTIATE_21_IMPL(IntegerMatrix,IntegerBandMatrix,cl_name)	        \
MACRO_INSTANTIATE_21_IMPL(IntegerSparseMatrix,IntegerBandMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(RealMatrix,RealBandMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(RealSparseMatrix,RealBandMatrix,cl_name)	        \
MACRO_INSTANTIATE_21_IMPL(ComplexMatrix,RealBandMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(ComplexSparseMatrix,RealBandMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(RealMatrix,ComplexBandMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(RealSparseMatrix,ComplexBandMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(ComplexMatrix,ComplexBandMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(ComplexSparseMatrix,ComplexBandMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(ObjectMatrix,ObjectBandMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(ObjectSparseMatrix,ObjectBandMatrix,cl_name)	    \

#define MACRO_INSTANTIATE_GST_2_F(cl_name)							\
MACRO_EVAL_GEN_TYPES(MACRO_INSTANTIATE_2_ST_IMPL,cl_name,)

#define MACRO_INSTANTIATE_SST_2(cl_name)						\
MACRO_INSTANTIATE_21_IMPL(IntegerBandMatrix,Integer,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(RealBandMatrix,Real,cl_name)	        \
MACRO_INSTANTIATE_21_IMPL(ComplexBandMatrix,Real,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(RealBandMatrix,Complex,cl_name)		\
MACRO_INSTANTIATE_21_IMPL(ComplexBandMatrix,Complex,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(ObjectBandMatrix,Object,cl_name)		\

#define MACRO_INSTANTIATE_STS_2_F(cl_name)						\
MACRO_EVAL_STR_TYPES(MACRO_INSTANTIATE_2_S_IMPL,cl_name,)

#define MACRO_INSTANTIATE_GST_2(cl_name)							        \
MACRO_INSTANTIATE_21_IMPL(IntegerBandMatrix,IntegerMatrix,cl_name)	        \
MACRO_INSTANTIATE_21_IMPL(IntegerBandMatrix,IntegerSparseMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(RealBandMatrix,RealMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(RealBandMatrix,RealSparseMatrix,cl_name)	        \
MACRO_INSTANTIATE_21_IMPL(RealBandMatrix,ComplexMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(RealBandMatrix,ComplexSparseMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(ComplexBandMatrix,RealMatrix,cl_name)		        \
MACRO_INSTANTIATE_21_IMPL(ComplexBandMatrix,RealSparseMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(ComplexBandMatrix,ComplexMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(ComplexBandMatrix,ComplexSparseMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(ObjectBandMatrix,ObjectMatrix,cl_name)		    \
MACRO_INSTANTIATE_21_IMPL(ObjectBandMatrix,ObjectSparseMatrix,cl_name)	    \

#define MACRO_INSTANTIATE_STG_2_F(cl_name)							\
MACRO_EVAL_STR_TYPES(MACRO_INSTANTIATE_2_G_IMPL,cl_name,)

#define MACRO_INSTANTIATE_STST_2(cl_name)							    \
MACRO_INSTANTIATE_21_IMPL(IntegerBandMatrix,IntegerBandMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(RealBandMatrix,RealBandMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(RealBandMatrix,ComplexBandMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(ComplexBandMatrix,RealBandMatrix,cl_name)	    \
MACRO_INSTANTIATE_21_IMPL(ComplexBandMatrix,ComplexBandMatrix,cl_name)	\
MACRO_INSTANTIATE_21_IMPL(ObjectBandMatrix,ObjectBandMatrix,cl_name)	\

#define MACRO_INSTANTIATE_STST_2_F(cl_name)							\
MACRO_EVAL_STR_TYPES(MACRO_INSTANTIATE_2_ST_IMPL,cl_name,)