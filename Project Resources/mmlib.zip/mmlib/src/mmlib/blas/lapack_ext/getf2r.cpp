/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/blas/blas.h"
#include "mmlib/blas/lapack.h"
#include "mmlib/blas/lapack_ext/lapack_ext.h"

namespace mmlib { namespace lapack
{

template<class T>
void lapack::getf2r(i_type M, i_type* Nptr, i_type JB, i_type J0, T *A, i_type LDA, i_type* IPIV, i_type* IQIV, 
            typename lapack::details::real_type<T>::type TOLC,
            typename lapack::details::real_type<T>::type TOLR, 
            typename lapack::details::real_type<T>::type TOLV,
            void* WORK, i_type *INFO )
{
// Purpose
// =======
//
// GETF2R computes an LU factorization of a general m-by-n matrix A
// using rook pivoting with row and column interchanges.
//
// The factorization has the form
//    A = P * L * U * Q
// where P, Q are permutation matrices, L is lower triangular with unit
// diagonal elements (lower trapezoidal if m > n), and U is upper
// triangular (upper trapezoidal if m < n).
//
// This is the Level 2 BLAS version of the algorithm.
//
// Arguments
// =========
//
// M       (input) INTEGER
//         The number of rows of the matrix A.  M >= 0.
//
// N       (input/output) INTEGER
//         The number of columns of the matrix A.  N >= 0.
//         On exit, number of nonzero columns
//
// JB      (input) INTEGER
//         The number of columns of the matrix A in the working block.  
//         JB >= 0.
//
// J0      (input) INTEGER
//         Position of the current block in the large matrix.
//
// A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
//         On entry, the m by n matrix to be factored.
//         On exit, the factors L and U from the factorization
//         A = P*L*U; the unit diagonal elements of L are not stored.
//
// LDA     (input) INTEGER
//         The leading dimension of the array A.  LDA >= max(1,M).
//
// IPIV    (output) INTEGER array, dimension (min(M,N))
//         The pivot indices; for 1 <= i <= min(M,N), row i of the
//         matrix was interchanged with row IPIV(i).
//
// IQIV    (input/output) INTEGER array, dimension (N)
//         The column permutation vector; for 1 <= i <= N, column i 
//         is given by IQIV(i) column of the matrix A, on input IQIV
//         gives starting permutation vector, for example 1:N
//
// TOLC    (input) DOUBLE PRECISION
//         tolerace, given column is selected as a pivot if element 
//         is greater than 1/TOLC * max element if given row, 
//         0 <= TOLC <= 1
//
// TOLC    (input) DOUBLE PRECISION
//         tolerace, given row is selected as a pivot if element 
//         is greater than 1/TOLR * max element if given column, 
//         0 <= TOLR <= 1
//
// TOLV    (input) DOUBLE PRECISION
//         tolerace, if absolute value of pivot is less than TOLV,
//         then all elements in given column are changed to zero, column 
//         is moved to the right end of the matrix and marked as singular
//
// WORK    (input/output) working array of size in bytes WORK_SIZE
//         WORK_SIZE is returned by this routine is is called with 
//         INFO[0] = -1
//
// INFO    (output) INTEGER
//         = 0: successful exit
//         < 0: if INFO = -k, the k-th argument had an illegal value
//          if this routine is called in query mode (INFO[0] == -1),
//          then on return INFO[0] is minimal WORK_SIZE (if INFO[0] >= 0)
//
// =====================================================================

    T  ONE     = 1.;
    T  ZERO    = 0.;    
    i_type     J, JP, JQ, JC, JP0, JP2, N = *Nptr;

    typedef typename lapack::details::real_type<T>::type TR;

    --A;
    --IPIV;
    --IQIV;

    bool test = (*INFO == -1);
    //  Test the input parameters.
    *INFO = 0;
    if ( M < 0 )
        *INFO = -1;
    else if ( N < 0 )
        * INFO = -2;
    else if ( JB < 0 )
        * INFO = -3;
    else if ( J0 < 0 )
        * INFO = -4;
    else if( LDA < lapack::maximum(1,M) )
        *INFO = -6;
    else if (TOLC > 1 || TOLC < 0)
        *INFO = -9;
    else if (TOLR > 1 || TOLR < 0)
        *INFO = -10;

    if( *INFO != 0 )
        return;

    if (test)
    {
        i_type work_size = (M+JB*N)*sizeof(T) + M*sizeof(i_type);
        *INFO = work_size;
        return;
    };

    // Quick return if possible
    if( M == 0 || N == 0 || JB == 0)
    {
        *Nptr = 0;
        return;   
    };

    i_type Jmax, Nold = N, LDR = N;
    Jmax = lapack::minimum( M, N );
    Jmax = lapack::minimum( Jmax, JB );

    i_type* work_I   = (i_type*)WORK;
    T*      work_C   = (T*)(work_I+M);
    T*      work_R   = work_C + M;

    --work_I;
    --work_C;
    --work_R;

    for (J = 1; J <= M; ++J)
    {
        work_I[J] = J;
    };

    for(J = 1; J <= Jmax; ++J)
    {
        //compute J column
        lapack::copy(M,A+1+(J-1)*LDA,1,work_C+1,1);
        if (J > 1)
        {
            //apply deferred interchanges
            lapack::laswp( 1, work_C+1, M, 1, J-1, IPIV+1, 1 );

            lapack::gemv( "No transpose", M-J+1, J-1, -ONE, A+J, LDA, work_R + J, LDR, 
                ONE, work_C+J, 1 );
        };

        // Find pivot
        JC = J;
        JP = J + lapack::amax( M-J+1, work_C+J, 1 ) - 1;

        for(;;)
        {
            //compute JP row
            JP0 = work_I[JP];

            lapack::copy(Nold-J+1,A+JP0+(J-1)*LDA,LDA,work_R+J + (J-1)*LDR,1);
            lapack::gemv( "No Trans", N-J+1, J-1, -ONE, work_R + J, LDR, A+JP, LDA, 
                    ONE, work_R+J + (J-1)*LDR, 1);

            //column pivot candidate
            JQ = J + lapack::amax( N-J+1, work_R+J + (J-1)*LDR, 1 ) - 1;

            if (lapack::abs(work_R[JC+ (J-1)*LDR]) < TOLC * lapack::abs(work_R[JQ+ (J-1)*LDR]))
            {
                // column test failed, check column JQ

                //compute JQ column
                lapack::copy(M,A+1+(JQ-1)*LDA,1,work_C+1,1);

                if (J > 1)
                {
                    //apply deferred interchanges
                    lapack::laswp( 1, work_C+1, M, 1, J-1, IPIV+1, 1 );

                    lapack::gemv( "No transpose", M-J+1, J-1, -ONE, A+J, LDA, work_R + JQ, LDR, 
                                ONE, work_C+J, 1 );
                };

                //row pivot candidate
                JP2 = J + lapack::amax( M-J+1, work_C+J, 1 ) - 1;
                if (lapack::abs(work_C[JP]) < TOLR * lapack::abs(work_C[JP2]))
                {
                    // row test failed, check row JP2
                    JP = JP2;
                    JC = JQ;
                    continue;
                }
                else
                {
                    //pivot (JP, JQ) is acceptable
                    break;
                };
            }
            else
            {
                //pivot (JP, JC) is acceptable
                JQ = JC;
                break;
            };
        };

        //value test
        if (lapack::abs(work_C[JP]) <= TOLV)
        {            
            if (JQ != N)
            {
                //permute upper block
                lapack::swap( J0-1, A+1-(J0-1)+(JQ-1)*LDA, 1, A+1-(J0-1)+(N-1)*LDA, 1 );                

                //permute current block
                lapack::swap( J-1, work_R + JQ, LDR, work_R + N, LDR );
                lapack::swap( M, A+1+(JQ-1)*LDA, 1, A+1+(N-1)*LDA, 1 );                 

                { i_type tmp = IQIV[JQ]; IQIV[JQ] = IQIV[N]; IQIV[N] = tmp; };
            };            
            
            if (J != JQ)
            {
                //permute upper block
                lapack::swap( J0-1, A+1-(J0-1)+(J-1)*LDA, 1, A+1-(J0-1)+(JQ-1)*LDA, 1 );                

                //permute current block
                lapack::swap( J-1, work_R + J, LDR, work_R + JQ, LDR );
                lapack::swap( M, A+1+(J-1)*LDA, 1, A+1+(JQ-1)*LDA, 1 );

                { i_type tmp = IQIV[J]; IQIV[J] = IQIV[JQ]; IQIV[JQ] = tmp; };
            };

            memset(A+1+(N-1)*LDA,0,M*sizeof(T));

            //remove current column
            --J;            
            --N;
            Jmax = lapack::minimum( Jmax, N );
            continue;
        };

        IPIV[J] = JP;
        {
            i_type tmp  = IQIV[J]; 
            IQIV[J]     = IQIV[JQ]; 
            IQIV[JQ]    = tmp;
        };

        i_type tmp  = work_I[J];
        work_I[J]   = work_I[JP];
        work_I[JP]  = tmp;

        // Apply the interchange to rows 1:M.
        if( JQ != J )
        {       
            //update upper block
            lapack::swap( J0-1, A+1-(J0-1)+(J-1)*LDA, 1, A+1-(J0-1)+(JQ-1)*LDA, 1 );

            lapack::swap( J, work_R + J, LDR, work_R + JQ, LDR );
            lapack::copy(M,A+1+(J-1)*LDA,1,A+1+(JQ-1)*LDA,1);
        }
        if (J > 1 || JQ != J)
        {
            lapack::copy(M-J+1,work_C+J,1,A+J+(J-1)*LDA,1);
        };

        if( A[JP+(J-1)*LDA] != ZERO )
        {
            // Apply the interchange to columns 1:J.
            if( JP != J )
            {
                lapack::swap( J, A+J, LDA, A+JP, LDA );
            }

            // Compute elements J+1:M of J-th column.
            if( J < M )
            {
                lapack::scal( M-J, ONE / A[J+(J-1)*LDA], A+J+1+(J-1)*LDA, 1 );
            };
        };
        
        // update A(1:J-1,J)
        lapack::copy(J-1,work_R+J,LDR,A+1 + (J-1)*LDA,1);
    };

    for (; J <= lapack::minimum( M, Nold ); ++J)
    {
        IPIV[J] = J;
    };

    // Apply interchanges to columns Jmax+1:N.
    lapack::laswp( Nold-Jmax, A+1+(Jmax)*LDA, LDA, 1, Jmax, IPIV+1, 1 );

    //update A(1:Jmax,Jmax+1:N)
    for (J = Jmax + 1; J <= Nold; ++J)
    {
        lapack::copy(Jmax,work_R+J,LDR,A+1+(J-1)*LDA,1);
    };
    *Nptr = N;
    return;
};

template void BLAS_EXPORT
getf2r<d_type>(i_type M, i_type* N, i_type JB, i_type J0, d_type *A, i_type LDA, i_type* IPIV, 
                                     i_type* IQIV, d_type TOLC, d_type TOLR, d_type TOLV,  
                                     void* WORK, i_type *INFO );

template void BLAS_EXPORT
getf2r<z_type>(i_type M, i_type* N, i_type JB, i_type J0, z_type *A, i_type LDA, i_type* IPIV, 
                                     i_type* IQIV, d_type TOLC, d_type TOLR, d_type TOLV,  
                                     void* WORK, i_type *INFO );

};};