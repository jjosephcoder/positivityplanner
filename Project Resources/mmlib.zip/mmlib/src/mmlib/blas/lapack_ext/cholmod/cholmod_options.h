/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/blas/blas_utils.h"

namespace mmlib { namespace lapack
{

class BLAS_EXPORT cholmod_options
{
	public:
		enum correction_alg
		{
			E_NONE, E_GMW, E_SE
		};
		enum correction_type
		{
			TYPE_I,TYPE_II
		};
		enum pivot_type
		{
			PIV_NONE,PIV_DIAG,PIV_ABS_DIAG,PIV_GERSHGORIN
		};

	private:
		typedef cholmod_options	self_type;

	private:

		d_type				    m_tol;
		d_type				    m_mu;
		correction_alg			m_corr_alg;
		correction_type			m_corr_type;		
		bool				    m_nondecreasing_strategy;
		pivot_type				m_piv_type;

	public:

		cholmod_options();

		d_type				    tol() const						{ return m_tol; };
		d_type				    mu() const						{ return m_mu; };
		correction_type			corr_type() const				{ return m_corr_type; };
		correction_alg			corr_alg() const				{ return m_corr_alg; };		
		bool					nondecreasing_strategy() const	{ return m_nondecreasing_strategy; };
		pivot_type				piv_type() const				{ return m_piv_type; };

		void					tol(d_type val)				    { m_tol = val; };
		void					mu(d_type val);
		void					corr_type(correction_type val)	{ m_corr_type = val; };
		void					corr_alg(correction_alg val)	{ m_corr_alg = val; };
		void					nondecreasing_strategy(bool v)	{ m_nondecreasing_strategy = v; };
		void					piv_type(pivot_type piv) 		{ m_piv_type = piv; };

		void					check() const;
};


};};