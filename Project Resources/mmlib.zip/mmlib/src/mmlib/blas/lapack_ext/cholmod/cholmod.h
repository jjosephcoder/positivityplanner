/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "cholmod_options.h"
#include "mmlib/blas/lapack_ext/cholmod/matrix.h"
#include <boost/shared_array.hpp>
#include "mmlib/blas/blas_utils.h"

#pragma warning(push)
#pragma warning(disable:4251)       //warning C4251: 'mmlib::lapack::cholmod<T>::m_piv' : class 'boost::shared_array<T>' needs to have dll-interface to be used by clients of class 'mmlib::lapack::cholmod<T>'

namespace mmlib { namespace lapack
{


template<class T>
class BLAS_EXPORT cholmod
{
    public:
        typedef boost::shared_array<i_type>                 int_array;

	private:
		typedef typename details::real_type<T>::type	    real_type;
		typedef cholmod										self_type;        

	private:
        void			make_factorization(Matrix<T>& mat,const cholmod_options& opt);
		void			clear();
		void			init();	

		int_array		m_piv;
		i_type		    m_rank;
		real_type		m_norm_E;

	public:
                        cholmod(Matrix<T>& mat,const cholmod_options& opt);
						~cholmod();

		i_type		    rank() const				{ return m_rank; };
		int_array		permutation() const			{ return m_piv;	};
		real_type		norm_correction() const		{ return m_norm_E; };
};

};};

#pragma warning(pop)