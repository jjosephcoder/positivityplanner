/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/blas/blas_utils.h"

namespace mmlib { namespace lapack 
{

struct triang_part
{
    enum type    { UPPER, LOWER };
};

template<class T> class Matrix
{
	public:
		typedef T			data_type;
		typedef Matrix		self_type;

	private:
		i_type              m_M;
		i_type              m_N;
		i_type              m_LD;
		T*                  m_data;
        triang_part::type   m_tr_type;

	public:

        Matrix(T* data,i_type M,i_type N,i_type LD,triang_part::type tr_type)
			:m_data(data),m_M(M),m_N(N),m_LD(LD),m_tr_type(tr_type)
		{
			if (M<0 || N<0 || LD < 1)
			{
				throw std::runtime_error("invalid matrix");
			};
		};

		T&					operator()(i_type i,i_type j)			    { return m_data[i+j*m_LD]; };
		const T&			operator()(i_type i,i_type j) const		    { return m_data[i+j*m_LD]; };

		i_type			    rows() const								{ return m_M; };
		i_type			    cols() const								{ return m_N; };
		i_type			    ld() const									{ return m_LD; };
        triang_part::type   triang_type() const							{ return m_tr_type; };

};

};};