/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "cholmod_options.h"
#include "mmlib/blas/lapack_ext/cholmod/matrix.h"
#include <boost/shared_array.hpp>

namespace mmlib { namespace lapack
{

template<class T>
struct pstrf_output
{
	typedef typename details::real_type<T>::type	real_type;
    typedef boost::shared_array<i_type> int_array;

	int_array						    m_piv;
	real_type							tol_used;
	i_type							    step_phase_I;
	i_type							    step_phase_II;
	i_type							    exit_block_size;
	real_type							norm_E;
};
template<class T>
struct corr_alg_data
{
	typedef typename details::real_type<T>::type	real_type;

	real_type							beta;
	real_type							delta;
	real_type							tau;
	real_type							tau_bar;

	corr_alg_data()
	{
		beta							= 0;
		delta							= 0;
		tau								= 0;
		tau_bar							= 0;
	};
};

template<class T>
class pstrf
{
	private:
		typedef typename details::real_type<T>::type	real_type;

		lapack::Matrix<T>				A;
		void*							workspace;
		const cholmod_options&			opt;
		pstrf_output<T>&				out;

		bool    						upper;
		i_type  						n;
		i_type						    lda;

		real_type *						work;
		T *								work_sav;

		real_type						max_diag;		
		real_type						min_diag;
		real_type						max_diag_abs;
		i_type						    pvt;
		real_type						stop_value;
		corr_alg_data<T>				m_corr_alg_data;
		i_type						    j;

		void							init_local_vars();
		void							init_output();
		void							check_arg() const;
		void							compute_stopping_value();
		i_type						    get_block_size(bool upper);
		void							correct_max_diag_GMW();
		void							correct_max_diag_SE();
		real_type						get_delta_SE();
		real_type						get_delta_SE_block22();
		void							init_correction_alg_GMW();
		void							init_correction_alg_SE();
		i_type						    find_pivot(bool phase_I);
		void							init_gershgorin_bounds();
		void							update_gerschgorin_bounds();
		real_type						get_c_norm_inf();
		real_type						get_c_norm_1();

		void							make(bool phase_I, i_type* piv);

	public:
		pstrf(lapack::Matrix<T>& A, void* workspace, const cholmod_options& opt, pstrf_output<T>& out);

		void make();

    private:
        pstrf& operator=(const pstrf&);
};

};};