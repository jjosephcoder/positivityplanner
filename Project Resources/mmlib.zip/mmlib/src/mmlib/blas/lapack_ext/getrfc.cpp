/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/blas/blas.h"
#include "mmlib/blas/lapack.h"
#include "mmlib/blas/lapack_ext/lapack_ext.h"

namespace mmlib { namespace lapack
{

template<class T>
void lapack::getrfc(i_type M, i_type N, T *A, i_type LDA, i_type *IPIV, i_type *IQIV, 
                    typename lapack::details::real_type<T>::type TOLV, i_type *INFO)
{
// Purpose
// =======
//
// DGETRFC computes an LU factorization of a general M-by-N matrix A
// using complete pivoting
//
// The factorization has the form
//    A = P * L * U * Q
// where P, Q are permutation matrices, L is lower triangular with unit
// diagonal elements (lower trapezoidal if m > n), and U is upper
// triangular (upper trapezoidal if m < n).
//
// Arguments
// =========
//
// M       (input) INTEGER
//         The number of rows of the matrix A.  M >= 0.
//
// N       (input) INTEGER
//         The number of columns of the matrix A.  N >= 0.
//
// A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
//         On entry, the M-by-N matrix to be factored.
//         On exit, the factors L and U from the factorization
//         A = P*L*U; the unit diagonal elements of L are not stored.
//
// LDA     (input) INTEGER
//         The leading dimension of the array A.  LDA >= max(1,M).
//
// IPIV    (output) INTEGER array, dimension (min(M,N))
//         The row pivot indices; for 1 <= i <= min(M,N), row i of the
//         matrix was interchanged with row IPIV(i).
//
// IQIV    (input/output) INTEGER array, dimension (N)
//         The column permutation vector; for 1 <= i <= N, column i 
//         is given by IQIV(i) column of the matrix A. On entry IQIV gives
//         initial column permutation, for example 1:N.
//
// TOLV    (input) DOUBLE PRECISION
//         tolerace, if absolute value of pivot is less than TOLV,
//         then all elements in given column are changed to zero, column 
//         is moved to the right end of the matrix and marked as singular
//
// INFO    (output) INTEGER
//         >= 0: successful exit
//         < 0:  if INFO = -i, the i-th argument had an illegal value
//         >=0:  INFO is estimated rank.
//
// =====================================================================
    --A;
    --IPIV;
    --IQIV;

    typedef typename lapack::details::real_type<T>::type TR;

    //  Test the input parameters.
    *INFO = 0;

    if ( M < 0 )
        *INFO = -1;
    else if ( N < 0 )
        * INFO = -2;
    else if( LDA < lapack::maximum(1,M) )
        *INFO = -4;

    if( *INFO != 0 )
        return;

    // Quick return if possible
    if( M == 0 || N == 0)
    {
        *INFO = 0;
        return;   
    };

    i_type  I, J, K, L, LAST, IMAX, JMAX, JLAST, JNEW, IDA1, IDA2, RANK;
    T       V;
    TR      AIJMAX, AJMAX;

    bool is_sing;
    LAST = N;
    RANK = 0;

    //-----------------------------------------------------------------
    //    Start of elimination loop.
    //-----------------------------------------------------------------
    for(K = 1; K <= N; K++) 
    {
        // Find the biggest aij in row imax and column jmax.
        AIJMAX  = 0;
        IMAX    = K;
        JMAX    = K;
        JLAST   = LAST;
        is_sing = true;

        for(J = K; J <= JLAST; J++) 
        {
            L       = amax(M-K+1,A+K+(J-1)*LDA,1)+K-1;
            AJMAX   = abs(A[L+(J-1)*LDA]);

            if(AJMAX <= TOLV) 
            {
                //========================================================
                //    Do column interchange, changing old column to zero.
                //    Reduce  "last"  and try again with same j.
                //========================================================
                JNEW        = IQIV[LAST];
                IQIV[LAST]  = IQIV[J];
                IQIV[J]     = JNEW;

                if (J != LAST)
                {
                    for(I = 1; I <= K-1; I++) 
                    {
                        IDA1    = I+(LAST-1)*LDA;
                        IDA2    = I+(J-1)*LDA;
                        V       = A[IDA1];
                        A[IDA1] = A[IDA2];
                        A[IDA2] = V;
                    }
                    for(I = K; I <= M; I++) 
                    {
                        IDA1            = I+(LAST-1)*LDA;
                        V               = A[IDA1];
                        A[IDA1]         = 0;
                        A[I+(J-1)*LDA]  = V;
                    }
                }
                else
                {
                    for(I = K; I <= M; I++) 
                    {
                        IDA1            = I+(LAST-1)*LDA;
                        A[IDA1]         = 0;
                    }
                };
                --LAST;

                if(J<=LAST)
                {
                    --J;
                    continue;
                };

                break;
            };
            is_sing = false;
            //  Check if this column has biggest aij so far.
            if(AIJMAX < AJMAX) 
            {
                AIJMAX  = AJMAX;
                IMAX    = L;
                JMAX    = J;
            }
            if(J >= LAST)
                break;
        };

        if (is_sing == true)
        {
            goto exit_label;
        };

        ++RANK;
        IPIV[K] = IMAX;

        if(JMAX != K) 
        {
            //==========================================================
            //    Do column interchange (k and jmax).
            //==========================================================
            JNEW        = IQIV[JMAX];
            IQIV[JMAX]  = IQIV[K];
            IQIV[K]     = JNEW;

            IDA1        = 1+(JMAX-1)*LDA;
            IDA2        = 1+(K-1)*LDA;
            for(I = 1; I <= M; ++I,++IDA1,++IDA2) 
            {
                V       = A[IDA1];
                A[IDA1] = A[IDA2];
                A[IDA2] = V;
            }
        }
        if(M>K) 
        {
            //===========================================================
            //       Do row interchange if necessary.
            //===========================================================
            if(IMAX!=K) 
            {
                IDA1        = IMAX;
                IDA2        = K;
                for (I = 1; I <= K; ++I,IDA1+=LDA,IDA2+=LDA)
                {
                    V       = A[IDA1];
                    A[IDA1] = A[IDA2];
                    A[IDA2] = V;
                };
            }
            //===========================================================
            //    Compute multipliers.
            //    Do row elimination with column indexing.
            //===========================================================
            V = 1./A[K+(K-1)*LDA];
            scal(M-K,V,A+K+1+(K-1)*LDA,1);

            for(J = K+1; J <= LAST; J++) 
            {
                IDA1    = IMAX+(J-1)*LDA;
                V       = A[IDA1];
                if(IMAX!=K) 
                {
                    IDA2    = K+(J-1)*LDA;
                    A[IDA1] = A[IDA2];
                    A[IDA2] = V;
                }
                axpy(M-K,-V,A+K+1+(K-1)*LDA,1, A+K+1+(J-1)*LDA,1);
            }
        }
        else
            break;

        if(K>=LAST)
            break;
    }

  exit_label:

    *INFO = RANK;
    // Set ipvt(*) for singular rows.
    for(K = LAST+1; K <= M; K++)
    {
        IPIV[K] = K;
    };
    return;
};

template void BLAS_EXPORT
lapack::getrfc<d_type>(i_type M, i_type N, d_type *A, i_type LDA, i_type* IPIV, i_type* IQIV, 
                       d_type TOLV, i_type *INFO );
template void BLAS_EXPORT
lapack::getrfc<z_type>(i_type M, i_type N, z_type *A, i_type LDA, i_type* IPIV, i_type* IQIV, 
                       d_type TOLV, i_type *INFO );

};};