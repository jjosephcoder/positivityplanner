/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/blas/blas.h"
#include "mmlib/blas/lapack.h"

namespace mmlib { namespace lapack
{

//================================================================================
//                      UTILS
//================================================================================
//  transforms permutation vector IPIV to series of interchanges
BLAS_EXPORT void perm2int(i_type M,i_type *IPIV, i_type* WORK);

//  transforms series of interchanges to permutation vector IPIV 
template<class T> BLAS_EXPORT
void int2perm(T M,T *IPIV, T* WORK);

//================================================================================
//                      FACTORIZATION
//================================================================================

// GETF2R computes an LU factorization of a general m-by-n matrix A
// using rook pivoting with row and column interchanges. Level 2 algorithm
template<class T> 
void getf2r(i_type M, i_type* N, i_type JB, i_type J, T *A, i_type LDA, i_type* IPIV, i_type* IQIV, 
            typename lapack::details::real_type<T>::type TOLC,
            typename lapack::details::real_type<T>::type TOLR, 
            typename lapack::details::real_type<T>::type TOLV,
            void* WORK, i_type *INFO );

// getrfr computes an LU factorization of a general M-by-N matrix A
// using rook pivoting. Level 3 right-looking algorithm
template<class T> BLAS_EXPORT
void getrfr(i_type M, i_type N, T *A, i_type LDA, i_type *IPIV, i_type *IQIV, 
            typename lapack::details::real_type<T>::type TOLC,
            typename lapack::details::real_type<T>::type TOLR, 
            typename lapack::details::real_type<T>::type TOLV,
            i_type *INFO);

// getrfr computes an LU factorization of a general M-by-N matrix A
// using complete pivoting.
template<class T> BLAS_EXPORT
void getrfc(i_type M, i_type N, T *A, i_type LDA, i_type *IPIV, i_type *IQIV, 
            typename lapack::details::real_type<T>::type TOLV,
            i_type *INFO);

// GETF2 computes an LU factorization of a general m-by-n matrix A
// using partial pivoting with row interchanges. Level 2 algorithm
template<class T> BLAS_EXPORT
void getf2(i_type M, i_type N, T *A, i_type LDA, i_type* IPIV, i_type *INFO );


// getrf_rl computes an LU factorization of a general M-by-N matrix A
// using partial pivoting with row interchanges. Level 3 right-looking
// algorithm
template<class T> BLAS_EXPORT
void getrf_rl(i_type M, i_type N, T *A, i_type LDA, i_type *IPIV, i_type *INFO);

// getrf_rl computes an LU factorization of a general M-by-N matrix A
// using partial pivoting with row interchanges. Level 3 left-looking
// algorithm
template<class T> BLAS_EXPORT
void getrf_ll(i_type M,i_type N, T* A,i_type LDA,i_type* IPIV,i_type* INFO);

// getrf_rl computes an LU factorization of a general M-by-N matrix A
// using partial pivoting with row interchanges. Level 3 Crout algorithm
template<class T> BLAS_EXPORT
void getrf_cr(i_type M, i_type N, T* A,i_type LDA,i_type* IPIV,i_type* INFO);

// getrf_rl computes an LU factorization of a general M-by-N matrix A
// using partial pivoting with row interchanges. Level 3 recursive algorithm
template<class T> BLAS_EXPORT
void getrf_rec(i_type M, i_type N, T* A,i_type LDA,i_type* IPIV,i_type* INFO );

};};