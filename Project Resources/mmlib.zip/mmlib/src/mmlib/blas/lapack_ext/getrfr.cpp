/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/blas/blas.h"
#include "mmlib/blas/lapack.h"
#include "mmlib/blas/lapack_ext/lapack_ext.h"

namespace mmlib { namespace lapack
{

template<class T>
void lapack::getrfr(i_type M, i_type N, T *A, i_type LDA, i_type *IPIV, i_type *IQIV, 
            typename lapack::details::real_type<T>::type TOLC,
            typename lapack::details::real_type<T>::type TOLR, 
            typename lapack::details::real_type<T>::type TOLV,
            i_type *INFO)
{
// Purpose
// =======
//
// DGETRFR computes an LU factorization of a general M-by-N matrix A
// using rook pivoting
//
// The factorization has the form
//    A = P * L * U * Q
// where P, Q are permutation matrices, L is lower triangular with unit
// diagonal elements (lower trapezoidal if m > n), and U is upper
// triangular (upper trapezoidal if m < n).
//
// This is the right-looking Level 3 BLAS version of the algorithm.
//
// Arguments
// =========
//
// M       (input) INTEGER
//         The number of rows of the matrix A.  M >= 0.
//
// N       (input) INTEGER
//         The number of columns of the matrix A.  N >= 0.
//
// A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
//         On entry, the M-by-N matrix to be factored.
//         On exit, the factors L and U from the factorization
//         A = P*L*U; the unit diagonal elements of L are not stored.
//
// LDA     (input) INTEGER
//         The leading dimension of the array A.  LDA >= max(1,M).
//
// IPIV    (output) INTEGER array, dimension (min(M,N))
//         The row pivot indices; for 1 <= i <= min(M,N), row i of the
//         matrix was interchanged with row IPIV(i).
//
// IQIV    (input/output) INTEGER array, dimension (N)
//         The column permutation vector; for 1 <= i <= N, column i 
//         is given by IQIV(i) column of the matrix A. On entry IQIV gives
//         initial column permutation, for example 1:N.
//
// TOLC    (input) DOUBLE PRECISION
//         tolerace, given column is selected as a pivot if element 
//         is greater than 1/TOLC * max element if given row, 
//         0 <= TOLC <= 1
//
// TOLR    (input) DOUBLE PRECISION
//         tolerace, given row is selected as a pivot if element 
//         is greater than 1/TOLR * max element if given column, 
//         0 <= TOLR <= 1
//
// TOLV    (input) DOUBLE PRECISION
//         tolerace, if absolute value of pivot is less than TOLV,
//         then all elements in given column are changed to zero, column 
//         is moved to the right end of the matrix and marked as singular
//
// INFO    (output) INTEGER
//         >= 0: successful exit
//         < 0:  if INFO = -i, the i-th argument had an illegal value
//         -100: not enough memory
//         >=0:  INFO is estimated rank.
//
// =====================================================================
    --A;
    --IPIV;
    --IQIV;

    typedef typename typename lapack::details::real_type<T>::type TR;

    i_type NB, J, JB, IINFO, I, MN = lapack::minimum( M, N );

    T  ONE = 1.;

    // query work size
    INFO[0] = -1;
    
    lapack::getf2r(M, &N, N, 1, A+1, LDA, IPIV + 1, IQIV + 1, TOLC, TOLR, TOLV, NULL, INFO );

    if (*INFO < 0)
    {
        return;
    };    

    if( M == 0 || N == 0 )
    {
        *INFO = 0;
        return;
    };

    void * WORK = malloc(*INFO);
    if (*INFO != 0 && WORK == NULL)
    {
        *INFO = -100;
        return;
    };
    *INFO = 0;

    // Determine the block size for this environment.
    //NB = lapack::ilaenv( 2, "DGETRF", " ", M, N, -1, -1 );
    NB = 48;

    if( NB <= 1 || NB >= lapack::minimum( M, N ) )
    {
        // Use unblocked code.
         lapack::getf2r(M, &N, N, 1, A+1, LDA, IPIV + 1, IQIV + 1, TOLC, TOLR, TOLV, WORK, INFO );
         INFO[0] = lapack::minimum( M, N );
         free(WORK);
         return;
    }    

    // Use blocked code.
    for(J = 1; J <= lapack::minimum( M, N ); J += NB)
    {
        JB = lapack::minimum( lapack::minimum( M, N )-J+1, NB );

        // Factor diagonal, subdiagonal and block row of U
        IINFO = 0;
        i_type Nptr = N - J + 1;
        lapack::getf2r(M - J + 1, &Nptr, JB, J, A+J+(J-1)*LDA, LDA, IPIV + J, IQIV + J, 
                    TOLC, TOLR, TOLV, WORK, &IINFO );

        N = N + Nptr - (N - J + 1);

        // Adjust pivot indices.

        for(I = J; I <= lapack::minimum( M, J+JB-1 ); ++I)
        {
            IPIV[I] = J - 1 + IPIV[I];
        };

        // Apply interchanges to columns 1:J-1.
        lapack::laswp( J-1, A+1, LDA, J, J+JB-1, IPIV+1, 1 );

        if( J+JB <= N && J+JB <= M)
        {
            // Update trailing submatrix.
            lapack::gemm( "No transpose", "No transpose", M-J-JB+1,
                      N-J-JB+1, JB, -ONE, A+J+JB+(J-1)*LDA, LDA,
                      A+J+(J+JB-1)*LDA, LDA, ONE, A+J+JB+(J+JB-1)*LDA, LDA );
        };
    };
    for (I = J; I < MN; ++I)
    {
        IPIV[I] = I;
    };

    INFO[0] = lapack::minimum( M, N );
    free(WORK);

    return;
};

template void BLAS_EXPORT
lapack::getrfr<d_type>(i_type M, i_type N, d_type *A, i_type LDA, i_type* IPIV, i_type* IQIV, 
                       d_type TOLC, d_type TOLR, d_type TOLV, i_type *INFO );
template void BLAS_EXPORT
lapack::getrfr<z_type>(i_type M, i_type N, z_type *A, i_type LDA, i_type* IPIV, i_type* IQIV, 
                       d_type TOLC, d_type TOLR, d_type TOLV, i_type *INFO );

};};