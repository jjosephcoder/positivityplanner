/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/blas/blas.h"
#include "mmlib/blas/lapack.h"
#include "mmlib/blas/lapack_ext/lapack_ext.h"

namespace mmlib { namespace lapack
{
//  SYNTAX:
//
//      void int2perm(int_type M,int_type *IPIV, int_type *WORK)
//
//  PURPOSE:
//  -----------------------------------------------------------------------
//
//  transforms series of interchanges to permutation vector IPIV 
//
//  ARGUMENTS:
//  -----------------------------------------------------------------------
//  M       (input) INTEGER
//          The number of rows of the vector IPIV.  M >= 0.
//
//  IPIV    (input/output) INTEGER array, dimension M
//          On entry IPIV is a vector of interchanges of vector 0:1:M-1
//          On exit IPIV is a vector of permutations of numbers 0:1:M-1
//
//  WORK    (input) INTEGER array, dimension at least M
void int2perm(i_type M,i_type *IPIV, i_type* WORK)
{
    if (M<=0)
    {
        return;
    };
    
    for(i_type i=0; i<M;i++)
    {
        WORK[i]			= IPIV[i];
		IPIV[i]			= i;
    };
    for (i_type i=0;i<M;i++)
    {
		i_type tmp		= IPIV[i];
		IPIV[i]			= IPIV[WORK[i]];
		IPIV[WORK[i]]	= tmp;
    };
};

};};