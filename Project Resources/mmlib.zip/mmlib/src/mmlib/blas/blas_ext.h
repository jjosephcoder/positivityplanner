/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/blas/blas.h"

namespace mmlib { namespace lapack
{

// BLAS Level1
//=======================   SET    =====================================================
// Compute Y(1:n) = alpha

template<class V> BLAS_EXPORT
typename details::enable_if_valid<void,V>::type
set(i_type n, V alpha, V* y, i_type incy);

BLAS_EXPORT void sset(const i_type* n, const s_type* alpha,s_type* y, const i_type* incy );
BLAS_EXPORT void dset(const i_type* n, const d_type* alpha,d_type* y, const i_type* incy );
BLAS_EXPORT void cset(const i_type* n, const c_type* alpha,c_type* y, const i_type* incy );
BLAS_EXPORT void zset(const i_type* n, const z_type* alpha,z_type* y, const i_type* incy );


//=======================   YAX    =====================================================
// Compute Y = alpha * X

template<class V> BLAS_EXPORT
typename details::enable_if_valid<void,V>::type
yax(i_type n, V alpha, const V* x,i_type incx, V* y, i_type incy);

BLAS_EXPORT void syax(const i_type* n, const s_type* alpha,const s_type* x,const i_type* incx, 
                             s_type* y, const i_type* incy );
BLAS_EXPORT void dyax(const i_type* n, const d_type* alpha,const d_type* x,const i_type* incx, 
                             d_type* y, const i_type* incy );
BLAS_EXPORT void cyax(const i_type* n, const c_type* alpha,const c_type* x,const i_type* incx, 
                             c_type* y, const i_type* incy );
BLAS_EXPORT void zyax(const i_type* n, const z_type* alpha,const z_type* x,const i_type* incx, 
                             z_type* y, const i_type* incy );

};};