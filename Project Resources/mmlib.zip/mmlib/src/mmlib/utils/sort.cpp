/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/utils/sort.h"
#include <algorithm>
#include <stack>
#include "mmlib/object.h"
#include "mmlib/utils/utils.h"
#include "mmlib/details/type_info_utils.h"

namespace mmlib { namespace utils
{

static const Integer SORT_MAX  = 50;

template <class Ttype>
inline void sort_ins(Ttype * const ptr, const Integer n)
{
    for(Integer j = 1; j < n; ++j)
    {
        Ttype x = ptr[j];
		Integer i;
        for (i = j - 1; ((i >= 0) && (ptr[i] > x)); --i)
		{
			ptr[i + 1] = ptr[i];
		};
        ptr[i + 1] = x;
    };
};

template <class Ttype1, class Ttype2>
void sort_ins(Ttype1 * const ptr1, Ttype2 * const ptr2,const Integer n)
{
    for(Integer j = 1; j < n; ++j)
    {
        Ttype1 x1 = ptr1[j];
        Ttype2 x2 = ptr2[j];
		Integer i;
        for (i = j - 1; ((i >= 0) && (ptr1[i] > x1)); --i)
        {
            ptr1[i + 1] = ptr1[i];
            ptr2[i + 1] = ptr2[i];
        }
        ptr1[i + 1] = x1;
        ptr2[i + 1] = x2;
    };
};
template <class Ttype1, class Ttype2, class Ttype3>
void sort_ins(Ttype1 * const ptr1, Ttype2 * const ptr2, Ttype3 * const ptr3,const Integer n)
{
    for(Integer j = 1; j < n; ++j)
    {
        Ttype1 x1 = ptr1[j];
        Ttype2 x2 = ptr2[j];
		Ttype3 x3 = ptr3[j];
		Integer i;
        for (i = j - 1; ((i >= 0) && (ptr1[i] > x1)); --i)
        {
            ptr1[i + 1] = ptr1[i];
            ptr2[i + 1] = ptr2[i];
			ptr3[i + 1] = ptr3[i];
        }
        ptr1[i + 1] = x1;
        ptr2[i + 1] = x2;
		ptr3[i + 1] = x3;
    };
};

template <class Type> 
inline Type * Partition(Type *pF, Type *pL, const Type pivot)
{
	for (pF--; ;) 
	{
		while (*(++pF) < pivot);
		while (*(--pL) > pivot);
		if (pF>=pL) { return pF; }
		std::iter_swap(pF, pL);
	}
}

template <typename Type> 
inline const Type& GetPivot(const Type *pF, Integer n)
{	
	return GetMedian(pF[0], pF[n/2], pF[n-1]);	// using first, mid and last
}
template <typename Type> 
inline const Type& GetMedian(const Type& x, const Type& y, const Type& z)
{
	if (x < y)	{ return (y < z ? y : x < z ? z : x); }
	else		{ return (x < z ? x : y < z ? z : y); }
}

template <typename Type> 
inline void sort_q(Type *pF, Type *pL)
{
	const Integer& n = pL-pF;
	if (n <= 1) 
	{
		return;
	};
	if (n <= SORT_MAX) 
	{
		sort_ins(pF, n);
	} 
	else 
	{
		Type *pM = Partition(pF, pL, GetPivot(pF, n));
		sort_q(pF, pM);
		sort_q(pM, pL);
	};
};

template <class Ttype>
void sort_q(Ttype *ptr, Integer n)
{
	if (n <= 1)
	{
		return;
	};
	if (n <= SORT_MAX) 
	{
		sort_ins(ptr, n);
		return;
	};

	return sort_q(ptr,ptr+n);
}


template <class Ttype1, class Ttype2>
void sort_q(Ttype1 *ptr1, Ttype2 *ptr2, Integer n)
{
	if (n <= 1) 
	{
		return;
	};
	if (n <= SORT_MAX) 
	{
		sort_ins(ptr1,ptr2, n);
	};

    Ttype1 x1 = GetPivot(ptr1, n);
	Integer i,j;

    mmlib::details::type_info ti_1 = mmlib::details::get_ti(ptr1[0]);
    mmlib::details::type_info ti_2 = mmlib::details::get_ti(ptr2[0]);
    Ttype1 sw1 = mmlib::details::default_value<Ttype1>(ti_1);
	Ttype2 sw2 = mmlib::details::default_value<Ttype2>(ti_2);

    for (i = 0, j = n - 1; i <= j;)
    {
        while (ptr1[i] < x1) ++i;
        while (ptr1[j] > x1) --j;
        if (i <= j)
        {
            sw1 = ptr1[i]; ptr1[i] = ptr1[j]; ptr1[j] = sw1;
            sw2 = ptr2[i]; ptr2[i] = ptr2[j]; ptr2[j] = sw2;
            ++i;
            --j;
        }
    }
    if (j > 0)		sort_q(ptr1, ptr2, j + 1);
    if (i < n - 1)	sort_q(ptr1 + i, ptr2 + i, n - i);
}
template <class Ttype1, class Ttype2, class Ttype3>
void sort_q(Ttype1 *ptr1, Ttype2 *ptr2, Ttype3 *ptr3, Integer n)
{
	if (n <= 1) 
	{
		return;
	};
	if (n <= SORT_MAX) 
	{
		sort_ins(ptr1,ptr2, ptr3, n);
	};

    Ttype1 x1 = GetPivot(ptr1, n);
	Integer i,j;

	Ttype1 sw1;
	Ttype2 sw2;
	Ttype3 sw3;

    for (i = 0, j = n - 1; i <= j;)
    {
        while (ptr1[i] < x1) ++i;
        while (ptr1[j] > x1) --j;
        if (i <= j)
        {
            sw1 = ptr1[i]; ptr1[i] = ptr1[j]; ptr1[j] = sw1;
            sw2 = ptr2[i]; ptr2[i] = ptr2[j]; ptr2[j] = sw2;
			sw3 = ptr3[i]; ptr3[i] = ptr3[j]; ptr3[j] = sw3;
            ++i;
            --j;
        }
    }
    if (j > 0)		sort_q(ptr1, ptr2,ptr3, j + 1);
    if (i < n - 1)	sort_q(ptr1 + i, ptr2 + i, ptr3 + i, n - i);
}

};};


template void mmlib::utils::sort_ins(Integer* const, const Integer);
template void mmlib::utils::sort_ins(Real* const, const Integer);

template void mmlib::utils::sort_q(Integer*, Integer);
template void mmlib::utils::sort_q(Real*, Integer);

template void mmlib::utils::sort_ins(Integer*, Integer*, Integer);
template void mmlib::utils::sort_ins(Real*, Integer*, Integer);
template void mmlib::utils::sort_ins(Integer*, Real*, Integer);
template void mmlib::utils::sort_ins(Integer*, Complex*, Integer);

template void mmlib::utils::sort_q(Integer*, Integer*, Integer);
template void mmlib::utils::sort_q(Real*, Integer*, Integer);
template void mmlib::utils::sort_q(Integer*, Real*, Integer);
template void mmlib::utils::sort_q(Integer*, Complex*, Integer);
template void mmlib::utils::sort_q(Integer*, Object*, Integer);

template void mmlib::utils::sort_q(Integer*, Integer*, Integer*, Integer);
