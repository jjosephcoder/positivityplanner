/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/fwd_decls.h"
#include "mmlib/utils/vector.h"
#include <vector>

namespace mmlib { namespace raw { namespace details
{
    template<class V> class spptr_helper;
    template<class V> struct array_helper;
};};};

namespace mmlib { namespace details
{

//indices are 1-based
inline void pos2ind(Integer pos, Integer s, Integer& i, Integer& j)
{
	--pos;
	i = (pos%s);
	j = (pos/s);
};

template<class val_type,class struct_type>
struct zero_matrix
{
	typedef raw::Matrix<val_type,struct_type> matrix_type;
	static matrix_type eval(Integer m,Integer n)
	{};
};
template<class val_type>
struct zero_matrix<val_type,struct_dense>
{
	typedef raw::Matrix<val_type,struct_dense> matrix_type;

	static matrix_type eval(type_info ret_ti, Integer m,Integer n)
	{
        val_type Z = default_value<val_type>(ret_ti);
		matrix_type out(ret_ti,Z,m,n);
        out.get_struct().set_zero_matrix();
        return out;
	};
};
template<class val_type>
struct zero_matrix<val_type,struct_sparse>
{
	typedef raw::Matrix<val_type,struct_sparse> matrix_type;

	static matrix_type eval(type_info ret_ti, Integer m,Integer n)
	{
		return matrix_type(ret_ti, m,n);
	};
};
template<class val_type>
struct zero_matrix<val_type,struct_banded>
{
	typedef raw::Matrix<val_type,struct_banded> matrix_type;

	static matrix_type eval(type_info ret_ti,Integer m,Integer n)
	{
		matrix_type out(ret_ti,m,n);
        val_type Z = default_value<val_type>(ret_ti);

        Integer out_size = out.size();
        val_type* ptr_out = out.rep_ptr();

		for  (Integer i = 0; i < out_size; ++i)
		{
			ptr_out[i] = Z;
		}
        out.get_struct().set_zero_matrix();
		return out;
	};
};
template<class T> inline bool is_zero(const T& val)        { return val == T(); };
template<> inline bool is_zero<Object>(const Object& val)  { return val.is_zero(); };
template<> inline bool is_zero<Complex>(const Complex& val){ return real(val) == 0 && imag(val) == 0; };

template<class T> inline bool is_one(const T& val)         { return val == T(1.); };
template<> inline bool is_one<Complex>(const Complex& val) { return real(val) == 1 && imag(val) == 0; };
template<> inline bool is_one<Object>(const Object& val)   { return val.is_one(); };

template<class T>
struct default_value_impl
{
    static T eval(type_info )
    {
        return T();
    };
};
template<class T>
struct default_value_impl<mmlib::raw::details::array_helper<T>>
{
    typedef mmlib::raw::details::array_helper<T> value_type;
    static value_type eval(type_info ti)
    {
        return value_type(ti);
    };
};

template<class V, class S>
struct default_value_impl<mmlib::raw::Matrix<V,S>>
{
    static mmlib::raw::Matrix<V,S> eval(type_info ti)
    {
        return mmlib::raw::Matrix<V,S>(ti);
    };
};
template<class V>
struct default_value_impl<mmlib::raw::details::spptr_helper<V>>
{
    typedef mmlib::raw::details::spptr_helper<V> value_type;

    static value_type eval(type_info ti)
    {
        return value_type(ti);
    };
};
template<>
struct default_value_impl<Object>
{
    static Object eval(type_info ti)
    {
        return Object(ti);
    };
};
template<class T> 
inline T default_value(type_info ti)
{
    return default_value_impl<T>::eval(ti);
};

struct ti_initializer
{
    private:
        type_info       m_ti;

    public:
        ti_initializer(type_info ti)
            :m_ti(ti)
        {};

        template<class T>
        void initialize(T* ptr) const
        {
            new(ptr) T(m_ti);
        };
};
template<class T>
class vector : public ::data_struct::vector<T,ti_initializer>
{
    private:
        typedef ::data_struct::vector<T,ti_initializer> base_type;
    public:
        vector(type_info ti)  
            : base_type(ti_initializer(ti))
        {};
        vector(type_info ti,size_t size)
            : base_type(ti_initializer(ti),size)
        {};
};

template<>
class vector<Integer> : public std::vector<Integer>
{
    private:
        typedef std::vector<Integer>  base_type;

    public:
        vector(type_info )  
            : base_type() 
        {};
        vector(type_info ,size_t size)     
            : base_type(size) 
        {};
};
template<>
class vector<Real> : public std::vector<Real>
{
    private:
        typedef std::vector<Real>  base_type;

    public:
        vector(type_info ) 
            : base_type() 
        {};
        vector(type_info , size_t size)     
            : base_type(size) 
        {};
};
template<>
class vector<Complex> : public std::vector<Complex>
{
    private:
        typedef std::vector<Complex>  base_type;

    public:
        vector(type_info )
            : base_type() 
        {};
        vector(type_info , size_t size)     
            : base_type(size) 
        {};
};

};};