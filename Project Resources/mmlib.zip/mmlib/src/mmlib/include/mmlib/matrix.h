/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/matrix_details.h"
#include "mmlib/details/enablers.h"
#include "mmlib/details/isa.h"
#include "mmlib/details/struct_flag.h"

namespace mmlib
{

//given instance cannot be shared between threads unless all accesses are read only
class MMLIB_EXPORT Matrix : private details::matrix_base
{
	private:
		typedef details::matrix_container_base mat_ptr;

		const mat_ptr*              get_mat_ptr_prv() const;

		friend  details::matrix_data_accesser;
		friend  details::SubMatrix;
        friend  details::SubMatrix_1;
        friend  details::SubMatrix_2;
		typedef details::matrix_base    base_type;

		template<class derived_type,class ret_type>
        friend class details::bin_visitor;

	public:
		Matrix();

		template<class T>			
		Matrix(const T& val,bool allow_conversions = true,
			typename details::enable_if_is_conv_to_mat<T>::type = 0);

		Matrix(const Matrix&);
		Matrix(const details::SubMatrix&);
        Matrix(const details::SubMatrix_1&);
        Matrix(const details::SubMatrix_2&);
		Matrix(const mat_row&);
		Matrix(const mat_col&);

		~Matrix();

		Matrix&                     operator=(const Matrix&);
		Matrix&                     operator=(const details::SubMatrix&);
        Matrix&                     operator=(const details::SubMatrix_1&);
        Matrix&                     operator=(const details::SubMatrix_2&);

		details::SubMatrix_1        operator()(Integer );		
		details::SubMatrix_2        operator()(Integer,Integer);
		details::SubMatrix          operator()(const colon& );
		details::SubMatrix          operator()(const colon&,const colon&);

		Matrix                      operator()(Integer ) const;
		Matrix                      operator()(Integer,Integer) const;
		Matrix                      operator()(const colon& ) const;		
		Matrix  	                operator()(const colon&,const colon&) const;

        details::SubMatrix          diag(Integer d = 0);
        Matrix                      diag(Integer d = 0) const;

		void                        make_unique();
		Matrix                      clone() const;
		void                        increase_refcount() const;
		void                        decrease_refcount() const;			

		Matrix                      delrows(const colon&) const;
		Matrix                      delcols(const colon&) const;

		Integer                     rows() const;
		Integer                     cols() const;
		Integer                     ldiags() const;
		Integer                     udiags() const;
		Integer                     nnz() const;
        Integer                     length() const;
        Real                        numel() const;
		int_tup_2                   size() const; 	

		bool                        is_empty() const;
		bool                        is_scalar() const;
		bool                        is_square() const;
		bool                        is_vector() const;
		bool                        is_matrix_type() const;
		bool                        is_scalar_type() const;
		bool                        is_unique() const;

		enums::value_type           value_type() const;
		enums::struct_type          struct_type() const;
		enums::mat_type             matrix_type() const;
        details::type_info          get_ti() const;

        const struct_flag           get_struct() const;
        void                        set_struct(const struct_flag&);
        void                        check_struct() const;
				
		bool                        is_scalar_true() const;

		template<class M> const M&  get_impl() const;           //exact rep
		template<class M>       M&  get_impl_unique();			//makes matrix unique
        template<class M> M	        impl() const;               //allow conversions, slower

        template<class V> V	        get_scalar() const;
        template<class V> V&	    get_scalar_unique();
		template<class T> const T*  get_array() const;          //matrix must be dense
		template<class T> T*        get_array_unique();	        //makes matrix unique

        void                        resize(Integer r, Integer c);
        void                        reserve(Integer r, Integer c);
        void                        resize_band(Integer r, Integer c, Integer ld, Integer ud);
        void                        reserve_band(Integer r, Integer c, Integer ld, Integer ud);
};

};