/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <exception>
#include <string>
#include "mmlib/scalar_types.h"
#include "mmlib/exception_message.h"
#include "mmlib/config.h"
#include "mmlib/type_decls.h"
#include "mmlib/details/struct_flag.h"

namespace mmlib { namespace error
{

class MMLIB_EXPORT assert_exception
{
    private:
		std::string file;
        int line;
        std::string message;

    public:
		assert_exception(const std::string& file_, int line_, const std::string& message_);
        virtual std::string what() const;
};
inline void _assert(const char* txt, const char* description, const char* file, int line)
{
    std::string message = "assertion failed: ";
	message				+= txt;
	if (description)
	{
		message			+= ": ";
		message			+= description;
	};
    throw assert_exception(file,line,message);
}

class MMLIB_EXPORT mmlib_exception : public std::exception
{
	private:
		mutable std::string m_message;

	public:
	    virtual const char* what() const;
		virtual const char* what(exception_message& em) const = 0;
};
class MMLIB_EXPORT error_general : public mmlib_exception
{
	public:
		std::string msg;

	public:
		error_general(const std::string& msg)	: msg(msg) {};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_alloc : public mmlib_exception
{
	public:
		Integer m_size;

	public:
		error_alloc(Integer size)	: m_size(size) {};
		error_alloc()				: m_size(0) {};			//unknown memory error or unknown size

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_size : public mmlib_exception
{
	public:
		Integer m_rows;
		Integer m_cols;

	public:
		error_size(Integer r, Integer c)	: m_rows(r), m_cols(c) {};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_resize : public mmlib_exception
{
	public:
		Integer m_rows;
		Integer m_cols;

	public:
		error_resize(Integer r, Integer c)	: m_rows(r), m_cols(c) {};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_int_mult : public mmlib_exception
{
	public:
		Integer m_rows;
		Integer m_cols;

	public:
		error_int_mult(Integer r, Integer c)	: m_rows(r), m_cols(c) {};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_int_cast : public mmlib_exception
{
	public:		
        Real m_val;

	public:
		error_int_cast(Real val)	: m_val(val){};

		virtual const char* what(exception_message& em) const;
};


class MMLIB_EXPORT error_single_index : public mmlib_exception
{
	public:
		Integer m_pos;
		Integer m_size;

	public:
		error_single_index(Integer i, Integer size)	: m_pos(i), m_size(size) {};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_double_index : public mmlib_exception
{
	public:
		Integer m_i;
		Integer m_j;
		Integer m_r;
		Integer m_c;

	public:
		error_double_index(Integer i, Integer j, Integer r, Integer c)	
			: m_i(i), m_j(j), m_r(r), m_c(c)
		{};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_diag : public mmlib_exception
{
	public:
		Integer m_d;
		Integer m_r;
		Integer m_c;

	public:
		error_diag(Integer d, Integer r, Integer c)		: m_d(d), m_r(r), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_index_band : public mmlib_exception
{
	public:
		Integer m_i;
		Integer m_j;
		Integer m_r;
		Integer m_c;
		Integer m_l;
		Integer m_u;

	public:
		error_index_band(Integer i,Integer j, Integer r, Integer c, Integer l, Integer u)
			: m_i(i),m_j(j),m_r(r),m_c(c),m_l(l),m_u(u)	{};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_size_band : public mmlib_exception
{
	public:
		Integer m_r;
		Integer m_c;
		Integer m_l;
		Integer m_u;

	public:
		error_size_band(Integer r, Integer c, Integer l, Integer u)
			: m_r(r),m_c(c),m_l(l),m_u(u)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_size_sp : public mmlib_exception
{
	public:
		Integer m_r;
		Integer m_c;

	public:
		error_size_sp(Integer r, Integer c)
			: m_r(r),m_c(c){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_invalid_return_type : public mmlib_exception
{
	public:
		error_invalid_return_type()	{};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_horzcat : public mmlib_exception
{
	public:
		Integer m_r1;
		Integer m_c1;
		Integer m_r2;
		Integer m_c2;

	public:
		error_horzcat(Integer r1, Integer c1, Integer r2, Integer c2)
			: m_r1(r1),m_c1(c1),m_r2(r2),m_c2(c2)	{};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_vertcat : public mmlib_exception
{
	public:
		Integer m_r1;
		Integer m_c1;
		Integer m_r2;
		Integer m_c2;

	public:
		error_vertcat(Integer r1, Integer c1, Integer r2, Integer c2)
			: m_r1(r1),m_c1(c1),m_r2(r2),m_c2(c2)	{};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_index : public mmlib_exception
{
	public:
		Integer m_i;
		Integer m_j;
		Integer m_r;
		Integer m_c;

	public:
		error_index(Integer i, Integer j, Integer r, Integer c)
			: m_i(i),m_j(j),m_r(r),m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_assign : public mmlib_exception
{
	public:
		Integer m_r1;
		Integer m_c1;
		Integer m_r2;
		Integer m_c2;

	public:
		error_assign(Integer r1, Integer c1, Integer r2, Integer c2)
			: m_r1(r1),m_c1(c1),m_r2(r2),m_c2(c2)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_row : public mmlib_exception
{
	public:
		Integer m_i;
		Integer m_r;
		Integer m_c;

	public:
		error_row(Integer i, Integer r, Integer c)		: m_i(i), m_r(r), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_col : public mmlib_exception
{
	public:
		Integer m_j;
		Integer m_r;
		Integer m_c;

	public:
		error_col(Integer j, Integer r, Integer c)		: m_j(j), m_r(r), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_reshape : public mmlib_exception
{
	public:
		Integer m_r1;
		Integer m_c1;
		Integer m_r2;
		Integer m_c2;

	public:
		error_reshape(Integer r1, Integer c1, Integer r2, Integer c2)		
			: m_r1(r1), m_c1(c1), m_r2(r2), m_c2(c2)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_eeop : public mmlib_exception
{
	public:
		Integer m_r1;
		Integer m_c1;
		Integer m_r2;
		Integer m_c2;

	public:
		error_eeop(Integer r1, Integer c1, Integer r2, Integer c2)		
			: m_r1(r1), m_c1(c1), m_r2(r2), m_c2(c2)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_mul : public mmlib_exception
{
	public:
		Integer m_r1;
		Integer m_c1;
		Integer m_r2;
		Integer m_c2;

	public:
		error_mul(Integer r1, Integer c1, Integer r2, Integer c2)		
			: m_r1(r1), m_c1(c1), m_r2(r2), m_c2(c2)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_atan2_on_complex : public mmlib_exception
{
	public:
		error_atan2_on_complex() {};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_dim : public mmlib_exception
{
	public:
		Integer m_i;
		Integer m_d;

	public:
		error_dim(Integer i, Integer d)		
			: m_i(i), m_d(d)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_bspdiags_nonconf : public mmlib_exception
{
	public:
		error_bspdiags_nonconf() {};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_randperm_arg_neg : public mmlib_exception
{
	public:
		Integer m_n;

	public:
		error_randperm_arg_neg(Integer n)
			: m_n(n)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_bspdiag_1starg_not_vec : public mmlib_exception
{
	public:
		Integer m_r;
		Integer m_c;

	public:
		error_bspdiag_1starg_not_vec(Integer r, Integer c)
			: m_r(r), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_bspdiags_2ndarg_not_vec : public mmlib_exception
{
	public:
		Integer m_r;
		Integer m_c;

	public:
		error_bspdiags_2ndarg_not_vec(Integer r, Integer c)
			: m_r(r), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_diag_arg_not_vec : public mmlib_exception
{
	public:
		Integer m_r;
		Integer m_c;

	public:
		error_diag_arg_not_vec(Integer r, Integer c)
			: m_r(r), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_linear_index_too_large : public mmlib_exception
{
	public:
		Integer m_r;
		Integer m_c;
		Integer m_rows;

	public:
		error_linear_index_too_large(Integer r, Integer c, Integer rows)
			: m_r(r), m_c(c),m_rows(rows)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_alloc_ext : public mmlib_exception
{
	public:
		error_alloc_ext() {};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_scalar_required : public mmlib_exception
{
	public:
		Integer m_r;
		Integer m_c;

	public:
		error_scalar_required(Integer r, Integer c)
			: m_r(r), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_type_get : public mmlib_exception
{
	public:
		enums::mat_type m_ret;
		enums::mat_type m_in;

	public:
		error_type_get(enums::mat_type ret, enums::mat_type in)
			: m_ret(ret), m_in(in)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_type_get_rep : public mmlib_exception
{
	public:
		enums::mat_type m_ret;
		enums::mat_type m_in;

	public:
		error_type_get_rep(enums::mat_type ret, enums::mat_type in)
			: m_ret(ret), m_in(in)	{};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_unable_to_convert : public mmlib_exception
{
	public:
		enums::mat_type m_ret;
		enums::mat_type m_in;

	public:
		error_unable_to_convert(enums::mat_type ret, enums::mat_type in)
			: m_ret(ret), m_in(in)	{};

		virtual const char* what(exception_message& em) const;
};

class MMLIB_EXPORT error_unable_to_read_matrix : public mmlib_exception
{
	public:
		error_unable_to_read_matrix(){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_not_vec : public mmlib_exception
{
	public:
		Integer m_r;
		Integer m_c;

	public:
		error_not_vec(Integer r, Integer c)
			: m_r(r), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_invalid_vectors_spmat : public mmlib_exception
{
	public:
		Integer m_sr;
		Integer m_sc;
		Integer m_sx;

	public:
		error_invalid_vectors_spmat(Integer sr, Integer sc, Integer sx)
			: m_sr(sr), m_sc(sc), m_sx(sx)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_unable_to_convert_invalid_code : public mmlib_exception
{
	public:
		error_unable_to_convert_invalid_code() {};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_row_indices_sortcols : public mmlib_exception
{
	public:
		Integer m_s;
		Integer m_c;

	public:
		error_row_indices_sortcols(Integer s, Integer c)
			: m_s(s), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_cols_indices_sortrows : public mmlib_exception
{
	public:
		Integer m_s;
		Integer m_c;

	public:
		error_cols_indices_sortrows(Integer s, Integer c)
			: m_s(s), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_row_indices_elem_sortcols : public mmlib_exception
{
	public:
		Integer m_elem;
		Integer m_c;

	public:
		error_row_indices_elem_sortcols(Integer elem, Integer c)
			: m_elem(elem), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_col_indices_elem_sortrows : public mmlib_exception
{
	public:
		Integer m_elem;
		Integer m_c;

	public:
		error_col_indices_elem_sortrows(Integer elem, Integer c)
			: m_elem(elem), m_c(c)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_open_mmlibfile : public mmlib_exception
{
	public:
		std::string file_name;
		std::string msg;

	public:
		error_open_mmlibfile(const std::string& file, const std::string& msg = "")
			: file_name(file), msg(msg)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_open_matfile : public mmlib_exception
{
	public:
		std::string file_name;
		std::string msg;

	public:
		error_open_matfile(const std::string& file, const std::string& msg = "")
			: file_name(file), msg(msg)	{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_matfile_not_opened : public mmlib_exception
{
	public:
		error_matfile_not_opened(){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_read_matfile : public mmlib_exception
{
	public:
		error_read_matfile(){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_read_matfile_var : public mmlib_exception
{
	public:
		std::string var_name;
	public:
		error_read_matfile_var(const std::string& var_name)
			:var_name(var_name)
		{};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_write_matfile : public mmlib_exception
{
	public:
		error_write_matfile(){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_mmlibfile_locked : public mmlib_exception
{
	public:
		error_mmlibfile_locked(){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_create_mmlibfile : public mmlib_exception
{
	public:
		std::string msg;
	public:
		error_create_mmlibfile(const std::string& msg) : msg(msg){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_read_mmlibfile : public mmlib_exception
{
	public:
		std::string msg;
	public:
		error_read_mmlibfile(const std::string& msg) : msg(msg){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_read_mmlibfile_mat_not_exist : public mmlib_exception
{
	public:
		std::string mat_name;
	public:
		error_read_mmlibfile_mat_not_exist(const std::string& msg) : mat_name(msg){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_write_mmlibfile_mat_already_exist : public mmlib_exception
{
	public:
		std::string mat_name;
	public:
		error_write_mmlibfile_mat_already_exist(const std::string& msg) : mat_name(msg){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_unable_to_load_library : public mmlib_exception
{
	public:
		std::string path;
	public:
		error_unable_to_load_library(const std::string& path) : path(path){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_while_loading_library : public mmlib_exception
{
	public:
		std::string path;
	public:
		error_while_loading_library(const std::string& path) : path(path){};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_object_value_type_not_allowed : public mmlib_exception
{
	public:
		error_object_value_type_not_allowed() {};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_integer_value_type_not_allowed : public mmlib_exception
{
	public:
		error_integer_value_type_not_allowed() {};

		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_square_matrix_required: public mmlib_exception
{
	public:
        error_square_matrix_required(){};
		virtual const char* what(exception_message& em) const;
};
class MMLIB_EXPORT error_invalid_struct: public mmlib_exception
{
    private:
        struct_flag::struct_type st;
	public:
        error_invalid_struct(struct_flag::struct_type fl) : st(fl){};
		virtual const char* what(exception_message& em) const;
};

};};


#define assertion(cond,description)		\
	((cond) ? (void)0 : ::mmlib::error::_assert(#cond,description, __FILE__, __LINE__))
