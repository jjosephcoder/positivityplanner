/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/matrix.h"
#include "boost/shared_ptr.hpp"

namespace mmlib
{

MMLIB_EXPORT Matrix		randperm(Integer n);
MMLIB_EXPORT Matrix		range(Real s, Real i, Real e);
MMLIB_EXPORT Matrix		range(Real s, Real e);
MMLIB_EXPORT Matrix		range(Real s, Real i, Real e, enums::value_type vt);
MMLIB_EXPORT Matrix		range(Real s, Real e, enums::value_type vt);
MMLIB_EXPORT Matrix		irange(Integer s, Integer i, Integer e);
MMLIB_EXPORT Matrix		irange(Integer s, Integer e);
MMLIB_EXPORT Matrix		linspace(Real s, Real e, Integer n);
MMLIB_EXPORT Matrix		logspace(Real s, Real e, Integer n);

MMLIB_EXPORT Matrix		zeros(Integer r, Integer c);
MMLIB_EXPORT Matrix		zeros(Integer r, Integer c, enums::value_type vt);
MMLIB_EXPORT Matrix		zeros(details::type_info ti,Integer r, Integer c);
MMLIB_EXPORT Matrix		spzeros(Integer r, Integer c,Integer nnz = 0);
MMLIB_EXPORT Matrix		spzeros(Integer r, Integer c,Integer nnz, enums::value_type);
MMLIB_EXPORT Matrix		spzeros(details::type_info ti,Integer r, Integer c,Integer nnz = 0);
MMLIB_EXPORT Matrix		bzeros(Integer r, Integer c,Integer ld, Integer ud);
MMLIB_EXPORT Matrix		bzeros(Integer r, Integer c,Integer ld, Integer ud, enums::value_type);
MMLIB_EXPORT Matrix		bzeros(details::type_info ti,Integer r, Integer c,Integer ld, Integer ud);
MMLIB_EXPORT Matrix		izeros(Integer r, Integer c);
MMLIB_EXPORT Matrix		ispzeros(Integer r, Integer c,Integer nnz = 0);
MMLIB_EXPORT Matrix		ibzeros(Integer r, Integer c,Integer ld, Integer ud);
MMLIB_EXPORT Matrix		czeros(Integer r, Integer c);
MMLIB_EXPORT Matrix		cspzeros(Integer r, Integer c,Integer nnz = 0);
MMLIB_EXPORT Matrix		cbzeros(Integer r, Integer c,Integer ld, Integer ud);

MMLIB_EXPORT Matrix		ones(Integer r, Integer c);
MMLIB_EXPORT Matrix		ones(Integer r, Integer c, enums::value_type vt);
MMLIB_EXPORT Matrix		ones(details::type_info ti,Integer r, Integer c);
MMLIB_EXPORT Matrix		spones(Integer r, Integer c);
MMLIB_EXPORT Matrix		spones(Integer r, Integer c, enums::value_type vt);
MMLIB_EXPORT Matrix		spones(details::type_info ti,Integer r, Integer c);
MMLIB_EXPORT Matrix		bones(Integer r, Integer c);
MMLIB_EXPORT Matrix		bones(Integer r, Integer c, enums::value_type vt);
MMLIB_EXPORT Matrix		bones(details::type_info ti,Integer r, Integer c);
MMLIB_EXPORT Matrix		iones(Integer r, Integer c);
MMLIB_EXPORT Matrix		ispones(Integer r, Integer c);
MMLIB_EXPORT Matrix		ibones(Integer r, Integer c);
MMLIB_EXPORT Matrix		cones(Integer r, Integer c);
MMLIB_EXPORT Matrix		cspones(Integer r, Integer c);
MMLIB_EXPORT Matrix		cbones(Integer r, Integer c);

MMLIB_EXPORT Matrix		eye(Integer m, Integer n);
MMLIB_EXPORT Matrix		eye(Integer m);
MMLIB_EXPORT Matrix		eye(Integer m, Integer n, enums::value_type vt);
MMLIB_EXPORT Matrix		eye(Integer m, enums::value_type vt);
MMLIB_EXPORT Matrix		eye(details::type_info ti,Integer m, Integer n);
MMLIB_EXPORT Matrix		eye(details::type_info ti,Integer m);
MMLIB_EXPORT Matrix		speye(Integer m, Integer n);
MMLIB_EXPORT Matrix		speye(Integer m);
MMLIB_EXPORT Matrix		speye(Integer m, Integer n, enums::value_type vt);
MMLIB_EXPORT Matrix		speye(Integer m, enums::value_type vt);
MMLIB_EXPORT Matrix		speye(details::type_info ti,Integer m, Integer n);
MMLIB_EXPORT Matrix		speye(details::type_info ti,Integer m);
MMLIB_EXPORT Matrix		beye(Integer m, Integer n, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		beye(Integer m, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		beye(Integer m, Integer n, Integer ld, Integer ud, enums::value_type vt);
MMLIB_EXPORT Matrix		beye(Integer m, Integer ld, Integer ud, enums::value_type vt);
MMLIB_EXPORT Matrix		beye(details::type_info ti,Integer m, Integer n, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		beye(details::type_info ti,Integer m, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		ieye(Integer m, Integer n);
MMLIB_EXPORT Matrix		ieye(Integer m);
MMLIB_EXPORT Matrix		ispeye(Integer m, Integer n);
MMLIB_EXPORT Matrix		ispeye(Integer m);
MMLIB_EXPORT Matrix		ibeye(Integer m, Integer n, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		ibeye(Integer m, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		ceye(Integer m, Integer n);
MMLIB_EXPORT Matrix		ceye(Integer m);
MMLIB_EXPORT Matrix		cspeye(Integer m, Integer n);
MMLIB_EXPORT Matrix		cspeye(Integer m);
MMLIB_EXPORT Matrix		cbeye(Integer m, Integer n, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		cbeye(Integer m, Integer ld, Integer ud);

MMLIB_EXPORT Matrix		diag(const Matrix& v, Integer d= 0);
MMLIB_EXPORT Matrix		bdiag(const Matrix &v, Integer d = 0);
MMLIB_EXPORT Matrix		spdiag(const Matrix &v, Integer d = 0);
MMLIB_EXPORT Matrix		diags(const Matrix &A, const Matrix &d, Integer m, Integer n);
MMLIB_EXPORT Matrix		bdiags(const Matrix &A, const Matrix &d, Integer m, Integer n);
MMLIB_EXPORT Matrix		spdiags(const Matrix &A, const Matrix &d, Integer m, Integer n);

MMLIB_EXPORT Real		rand();
MMLIB_EXPORT Real		randn();
MMLIB_EXPORT Complex	    crand();
MMLIB_EXPORT Complex	    crandn();
MMLIB_EXPORT Integer	    irand();
MMLIB_EXPORT void		init_genrand(unsigned long s);

struct rand_state
{
    unsigned long   mt[624];
    int             mti;
};
typedef boost::shared_ptr<rand_state> rand_state_ptr;

MMLIB_EXPORT rand_state_ptr  get_rand_state();
MMLIB_EXPORT void            set_rand_state(rand_state_ptr st);

MMLIB_EXPORT Matrix		rand(Integer m, Integer n);
MMLIB_EXPORT Matrix		rand(Integer m, Integer n,enums::value_type vt);
MMLIB_EXPORT Matrix		irand(Integer m, Integer n);
MMLIB_EXPORT Matrix		crand(Integer m, Integer n);

MMLIB_EXPORT Matrix		randn(Integer m, Integer n);
MMLIB_EXPORT Matrix		randn(Integer m, Integer n,enums::value_type vt);
MMLIB_EXPORT Matrix		crandn(Integer m, Integer n);

MMLIB_EXPORT Matrix		sprand(Integer m, Integer n, Real d);
MMLIB_EXPORT Matrix		sprand(Integer m, Integer n, Real d,enums::value_type vt);
MMLIB_EXPORT Matrix		isprand(Integer m, Integer n, Real d);
MMLIB_EXPORT Matrix		csprand(Integer m, Integer n, Real d);
MMLIB_EXPORT Matrix		sprandn(Integer m, Integer n, Real d);
MMLIB_EXPORT Matrix		sprandn(Integer m, Integer n, Real d,enums::value_type vt);
MMLIB_EXPORT Matrix		csprandn(Integer m, Integer n, Real d);

MMLIB_EXPORT Matrix		rand_band(Integer m, Integer n, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		rand_band(Integer m, Integer n, Integer ld, Integer ud,enums::value_type vt);
MMLIB_EXPORT Matrix		randn_band(Integer m, Integer n, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		randn_band(Integer m, Integer n, Integer ld, Integer ud,enums::value_type vt);
MMLIB_EXPORT Matrix		irand_band(Integer m, Integer n, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		crand_band(Integer m, Integer n, Integer ld, Integer ud);
MMLIB_EXPORT Matrix		crandn_band(Integer m, Integer n, Integer ld, Integer ud);

MMLIB_EXPORT Matrix		IntegerMatrix(Integer rows,Integer cols);
MMLIB_EXPORT Matrix		RealMatrix(Integer rows,Integer cols);
MMLIB_EXPORT Matrix		ComplexMatrix(Integer rows,Integer cols);
MMLIB_EXPORT Matrix		ObjectMatrix(details::type_info,Integer rows,Integer cols);

MMLIB_EXPORT Matrix		IntegerMatrix(Integer rows,Integer cols,const Integer *arr);
MMLIB_EXPORT Matrix		RealMatrix(Integer rows,Integer cols,const Real *arr);
MMLIB_EXPORT Matrix		ComplexMatrix(Integer rows,Integer cols,const Complex *arr);
MMLIB_EXPORT Matrix		ComplexMatrix(Integer rows,Integer cols,const Real *ar_r,const Real *ar_i);
MMLIB_EXPORT Matrix		ObjectMatrix(details::type_info,Integer rows,Integer cols,const Object *arr);

MMLIB_EXPORT Matrix		IntegerMatrix(Integer val,Integer rows,Integer cols);
MMLIB_EXPORT Matrix		RealMatrix(Real val,Integer rows,Integer cols);
MMLIB_EXPORT Matrix		ComplexMatrix(Complex val,Integer rows,Integer cols);
MMLIB_EXPORT Matrix		ObjectMatrix(details::type_info,Object val,Integer rows,Integer cols);

MMLIB_EXPORT Matrix		IntegerBandMatrix2(Integer val,Integer rows,Integer cols, Integer ldiags = 0, 
                                           Integer udiags = 0);
MMLIB_EXPORT Matrix		RealBandMatrix2(Real val,Integer rows,Integer cols, Integer ldiags = 0, 
                                        Integer udiags = 0);
MMLIB_EXPORT Matrix		ComplexBandMatrix2(Complex val,Integer rows,Integer cols, Integer ldiags = 0, 
                                           Integer udiags = 0);

MMLIB_EXPORT Matrix		IntegerBandMatrix(Integer rows,Integer cols, Integer ldiags = 0, Integer udiags = 0);
MMLIB_EXPORT Matrix		RealBandMatrix(Integer rows,Integer cols, Integer ldiags = 0, Integer udiags = 0);
MMLIB_EXPORT Matrix		ComplexBandMatrix(Integer rows,Integer cols, Integer ldiags = 0, Integer udiags = 0);
MMLIB_EXPORT Matrix		ObjectBandMatrix(details::type_info,Integer rows,Integer cols, Integer ldiags = 0, 
                                         Integer udiags = 0);

MMLIB_EXPORT Matrix		IntegerSparseMatrix(Integer rows,Integer cols, Integer nzmax = 0);
MMLIB_EXPORT Matrix		RealSparseMatrix(Integer rows,Integer cols, Integer nzmax = 0);
MMLIB_EXPORT Matrix		ComplexSparseMatrix(Integer rows,Integer cols, Integer nzmax = 0);
MMLIB_EXPORT Matrix		ObjectSparseMatrix(details::type_info,Integer rows,Integer cols, Integer nzmax = 0);

MMLIB_EXPORT Matrix		IntegerSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Integer *trip_x,
										Integer r, Integer c, Integer nnz);
MMLIB_EXPORT Matrix		RealSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Real *trip_x,
										Integer r, Integer c, Integer nnz);
MMLIB_EXPORT Matrix		ComplexSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Complex *trip_x,
										Integer r, Integer c, Integer nnz);
MMLIB_EXPORT Matrix		ComplexSparseMatrix(const Integer *trip_r, const Integer *trip_c, 
										const Real *trip_re, const Real *trip_im,
										Integer r, Integer c, Integer nnz);

MMLIB_EXPORT Matrix		IntegerSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Integer *trip_x,
										Integer r, Integer c, Integer nnz, Integer nzmax);
MMLIB_EXPORT Matrix		RealSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Real *trip_x,
										Integer r, Integer c, Integer nnz, Integer nzmax);
MMLIB_EXPORT Matrix		ComplexSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Complex *trip_x,
										Integer r, Integer c, Integer nnz, Integer nzmax);
MMLIB_EXPORT Matrix		ComplexSparseMatrix(const Integer *trip_r, const Integer *trip_c, 
										const Real *trip_re, const Real *trip_im,
										Integer r, Integer c, Integer nnz, Integer nzmax);

MMLIB_EXPORT Matrix      SparseMatrix(const Matrix& trip_r, const Matrix& trip_c, const Matrix& trip_x,
										Integer r, Integer c);
MMLIB_EXPORT Matrix      SparseMatrix(const Matrix& trip_r, const Matrix& trip_c, const Matrix& trip_x,
										Integer r, Integer c, Integer nzmax);

MMLIB_EXPORT Matrix		UninitializedIntegerMatrix(Integer rows,Integer cols);
MMLIB_EXPORT Matrix		UninitializedRealMatrix(Integer rows,Integer cols);
MMLIB_EXPORT Matrix		UninitializedComplexMatrix(Integer rows,Integer cols);
MMLIB_EXPORT Matrix		UninitializedObjectMatrix(details::type_info,Integer rows,Integer cols);

MMLIB_EXPORT Matrix		UninitializedIntegerBandMatrix(Integer rows,Integer cols, Integer ldiags = 0, 
                                                       Integer udiags = 0);
MMLIB_EXPORT Matrix		UninitializedRealBandMatrix(Integer rows,Integer cols, Integer ldiags = 0, 
                                                    Integer udiags = 0);
MMLIB_EXPORT Matrix		UninitializedComplexBandMatrix(Integer rows,Integer cols, Integer ldiags = 0, 
                                                       Integer udiags = 0);
MMLIB_EXPORT Matrix		UninitializedObjectBandMatrix(details::type_info,Integer rows,Integer cols, 
                                                      Integer ldiags = 0, Integer udiags = 0);

MMLIB_EXPORT Matrix		UninitializedIntegerSparseMatrix(Integer rows,Integer cols, Integer nzmax = 0);
MMLIB_EXPORT Matrix		UninitializedRealSparseMatrix(Integer rows,Integer cols, Integer nzmax = 0);
MMLIB_EXPORT Matrix		UninitializedComplexSparseMatrix(Integer rows,Integer cols, Integer nzmax = 0);
MMLIB_EXPORT Matrix		UninitializedObjectSparseMatrix(details::type_info, Integer rows,Integer cols, 
                                                        Integer nzmax = 0);

MMLIB_EXPORT Matrix		DenseMatrix(Integer rows,Integer cols, enums::value_type);
MMLIB_EXPORT Matrix		BandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags, enums::value_type);
MMLIB_EXPORT Matrix		SparseMatrix(Integer rows,Integer cols, Integer nzmax, enums::value_type);
MMLIB_EXPORT Matrix		UninitializedDenseMatrix(Integer rows,Integer cols, enums::value_type);
MMLIB_EXPORT Matrix		UninitializedBandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags, 
                                                enums::value_type);
MMLIB_EXPORT Matrix		UninitializedSparseMatrix(Integer rows,Integer cols, Integer nzmax, enums::value_type);
};