/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once
#include "mmlib/details/type_codes.h"
#include "mmlib/config.h"
#include "mmlib/details/isa.h"

namespace mmlib
{

struct MMLIB_EXPORT matrix_traits
{
	private:
		template<class mat_type,bool is_scal>
		struct mat_type_info_type_impl
		{
			typedef mat_type										matrix_type;
			typedef typename matrix_type::value_type				value_type;
			typedef typename matrix_type::struct_type				struct_type;

			static const enums::mat_type    matrix_code		= details::type_to_code<mat_type>::value;
			static const enums::value_type	value_code		= details::value_to_code<value_type>::value;
			static const enums::struct_type struct_code		= details::struct_to_code<struct_type>::value;
		};
		template<class mat_type>
		struct mat_type_info_type_impl<mat_type,true>
		{
			typedef mat_type										matrix_type;
			typedef mat_type										value_type;
			typedef struct_scalar									struct_type;

			static const enums::mat_type    matrix_code		= details::type_to_code<mat_type>::value;
			static const enums::value_type	value_code		= details::value_to_code<value_type>::value;
			static const enums::struct_type struct_code		= details::struct_to_code<struct_type>::value;
		};

	public:

		static enums::value_type	get_value_type(enums::mat_type mt);
		static enums::struct_type	get_struct_type(enums::mat_type mt);
		static enums::mat_type		get_matrix_type(enums::value_type vt, enums::struct_type st);

		template<enum enums::mat_type mt>
		struct mat_type_info_code
		{
			typedef typename details::code_to_type<mt>::type		matrix_type;
			typedef typename matrix_type::value_type				value_type;
			typedef typename matrix_type::struct_type				struct_type;

			static const enums::mat_type    matrix_code		= mt;
			static const enums::value_type	value_code		= details::value_to_code<value_type>::value;
			static const enums::struct_type struct_code		= details::struct_to_code<struct_type>::value;
		};

		template<class mat_type>
		struct mat_type_info_type : public mat_type_info_type_impl<mat_type,details::is_scalar<mat_type>::value>
		{};


		template<enum enums::value_type vt, enum enums::struct_type st>
		struct mat_type_info_code_2
		{
			typedef typename details::code_to_value<vt>::type		value_type;
			typedef typename details::code_to_struct<st>::type		struct_type;
			typedef raw::Matrix<value_type,struct_type>				matrix_type;

			static const enums::mat_type    matrix_code		= details::type_to_code<matrix_type>::value;
			static const enums::value_type	value_code		= vt;
			static const enums::struct_type struct_code		= st;
		};
		template<class vt, class st>
		struct mat_type_info_type_2 : public mat_type_info_type<raw::Matrix<vt,st>>
		{};

        template<class V>
        struct value_code
        {
            static const enums::value_type value	        = details::value_to_code<V>::value;
        };
};

};