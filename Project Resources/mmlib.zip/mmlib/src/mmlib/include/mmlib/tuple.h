/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once 

namespace mmlib
{

namespace details
{
template<class T> struct add_const_ref		{ typedef const T&	type; };
template<class T> struct add_const_ref<T&>	{ typedef const T&	type; };

template<class T> struct param_type			{ typedef const T&	type; };
template<class T> struct param_type<T&>		{ typedef		T&	type; };
};

template <class T>
struct tuple_default_initializer			{ static T eval() { return T();};  };

template<class T, size_t N>
class tuple: public tuple<T,N-1>
{
	public:
		typedef tuple<T,N-1>								base_type;		
		typedef typename details::add_const_ref<T>::type	const_ref;		

		static const size_t	 size			= N;

	private:
		typedef typename details::param_type<T>::type		R;

	private:
		T		m_data;

	public:
		tuple()								:m_data(tuple_default_initializer<T>::eval()){};
		tuple(R a1)							:m_data(a1){};
		tuple(R a1,R a2)					:m_data(a1),base_type(a2){};
		tuple(R a1,R a2,R a3)				:m_data(a1),base_type(a2,a3){};
		tuple(R a1,R a2,R a3,R a4)		    :m_data(a1),base_type(a2,a3,a4){};
		tuple(R a1,R a2,R a3,R a4,R a5)	    :m_data(a1),base_type(a2,a3,a4,a5){};
        tuple(R a1,R a2,R a3,R a4,R a5,R a6):m_data(a1),base_type(a2,a3,a4,a5,a6){};

		tuple(const tuple& tup)				:m_data(tup.m_data),base_type(static_cast<const tuple<T,N-1>&>(tup)){};
		template<size_t M>
		tuple(const tuple<T,M>& tup)		:m_data(tup.m_data),base_type(static_cast<const tuple<T,M-1>&>(tup)){};
		template<>
		tuple(const tuple<T,0>& tup)		:m_data(tuple_default_initializer<T>::eval()){};

		template<class S,size_t M>
		tuple(const tuple<S,M>& tup)		:m_data(tup.m_data),base_type(static_cast<const tuple<S,M-1>&>(tup)){};
		template<class S>
		tuple(const tuple<S,0>& tup)		:m_data(tuple_default_initializer<T>::eval()){};

		tuple& operator=(const tuple& t)
		{
			m_data = t.m_data;
			base_type::operator=(static_cast<const tuple<T,N-1>&>(t));
			return *this;
		};

		template<class S, size_t M>
		tuple& operator=(const tuple<S,M>& t)
		{
			m_data = t.m_data;
			base_type::operator=(static_cast<const tuple<S,M-1>&>(t));
			return *this;
		};
		template<class S>
		tuple& operator=(const tuple<S,0>& t)
		{
			m_data = tuple_default_initializer<T>::eval();
			base_type::operator=(t);
			return *this;
		};

		~tuple()							{};

		operator R() const					{ return m_data;};

		template<size_t N> 
		const_ref get() const				{ return base_type::get<N-1>();};
		template<>	
		const_ref get<1>() const			{ return m_data;};

		template<class T, size_t N> friend class tuple;
};

template<class T>
class tuple<T,0>
{
	public:
		typedef typename details::add_const_ref<T>::type	const_ref;
		typedef typename details::param_type<T>::type		param_type;

	public:
		tuple()								{};
		tuple(param_type val,...)						
		{
			TOO_MANY_INITIALIZERS();			
		};

		tuple(const tuple& )				{};
		template<size_t M>
		tuple(const tuple<T,M>& )           {};
		template<class S,size_t M>
		tuple(const tuple<S,M>& )           :{};

		template<class S,size_t M>
		tuple& operator=(const tuple<S,M>& )
		{
			return *this;
		};

		template<size_t N> const_ref get()	const
		{ 
			INDEX_EXCEEDED_TUPLE_SIZE();
		};
};


template<class T> 
inline tuple<T&,1> tie(T& t1)									{  return tuple<T&> (t1);	};
template<class T>
inline tuple<T&, 2> tie(T& t1,T& t2)							{  return tuple<T&, 2> (t1, t2); };
template<class T>
inline tuple<T&, 3> tie(T& t1,T& t2,T& t3)					    {  return tuple<T&, 3> (t1, t2, t3); };
template<class T>
inline tuple<T&, 4> tie(T& t1,T& t2,T& t3,T& t4)				{  return tuple<T&, 4> (t1, t2, t3, t4); };
template<class T>
inline tuple<T&, 5> tie(T& t1,T& t2,T& t3,T& t4,T& t5)		    {  return tuple<T&, 5> (t1, t2, t3, t4, t5); };
template<class T>
inline tuple<T&, 6> tie(T& t1,T& t2,T& t3,T& t4,T& t5,T& t6)	{  return tuple<T&, 6> (t1, t2, t3, t4, t5, t6); };

};