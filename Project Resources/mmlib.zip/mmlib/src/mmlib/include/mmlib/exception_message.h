/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <string>
#include "mmlib/scalar_types.h"
#include "mmlib/config.h"
#include "mmlib/type_decls.h"
#include <boost/shared_ptr.hpp>
#include "mmlib/details/struct_flag.h"

#pragma warning(push)
#pragma warning(disable:4251)   //'mmlib::error::exception_message::m_linalg' : class 'boost::shared_ptr<T>' needs to have dll-interface to be used by clients of class 'mmlib::error::exception_message'

namespace mmlib { namespace error
{
class exception_message;
class exception_message_linalg;

typedef boost::shared_ptr<exception_message>        exception_message_ptr;
typedef boost::shared_ptr<exception_message_linalg> exception_message_linalg_ptr;

class MMLIB_EXPORT exception_message
{
    private:
        exception_message_linalg_ptr    m_linalg;

	public:
        exception_message_linalg_ptr get_linalg_message()           { return m_linalg; };
        void set_linalg_message(exception_message_linalg_ptr ptr)   { m_linalg = ptr; };

		virtual ~exception_message(){};
		virtual const char* error_general(const std::string& msg) = 0;
		
		virtual const char* error_alloc(Integer size) = 0;
        virtual const char* error_resize(Integer r, Integer c) = 0;
		virtual const char* error_size(Integer r, Integer c) = 0;
		virtual const char* error_int_mult(Integer r, Integer c) = 0;
        virtual const char* error_int_cast(Real val) = 0;
		virtual const char* error_single_index(Integer pos,Integer size) = 0;
		virtual const char* error_double_index(Integer i,Integer j,Integer r,Integer c) = 0;
		virtual const char* error_diag(Integer d,Integer r,Integer c) = 0;
		virtual const char* error_index_band(Integer i,Integer j, Integer r, Integer c, 
											 Integer l, Integer u) = 0;
		virtual const char* error_size_band(Integer r, Integer c, Integer l, Integer u) = 0;
		virtual const char* error_size_sp(Integer r, Integer c) = 0;
		virtual const char* error_invalid_return_type() = 0;
		virtual const char* error_horzcat(Integer r1, Integer c1, Integer r2, Integer c2) = 0;
		virtual const char* error_vertcat(Integer r1, Integer c1, Integer r2, Integer c2) = 0;
		virtual const char* error_index(Integer i, Integer j, Integer r, Integer c) = 0;
		virtual const char* error_assign(Integer r1, Integer c1, Integer r2, Integer c2) = 0;
		virtual const char* error_row(Integer i, Integer r, Integer c) = 0;
		virtual const char* error_col(Integer j, Integer r, Integer c) = 0;
		virtual const char* error_reshape(Integer r1, Integer c1, Integer r2, Integer c2) = 0;
		virtual const char* error_eeop(Integer r1, Integer c1, Integer r2, Integer c2) = 0;
		virtual const char* error_mul(Integer r1, Integer c1, Integer r2, Integer c2) = 0;
		virtual const char* error_dim(Integer i, Integer d)	= 0;
		virtual const char* error_atan2_on_complex() = 0;
		virtual const char* error_bspdiags_nonconf() = 0;
		virtual const char* error_randperm_arg_neg(Integer n) = 0;
		virtual const char* error_bspdiag_1starg_not_vec(Integer r, Integer c) = 0;
		virtual const char* error_bspdiags_2ndarg_not_vec(Integer r, Integer c) = 0;
		virtual const char* error_diag_arg_not_vec(Integer r, Integer c) = 0;
		virtual const char* error_linear_index_too_large(Integer r, Integer c, Integer rows) = 0;
		virtual const char* error_alloc_ext() = 0;
		virtual const char* error_scalar_required(Integer r, Integer c) = 0;
		virtual const char* error_type_get(enums::mat_type ret, enums::mat_type in)= 0;
		virtual const char* error_type_get_rep(enums::mat_type ret, enums::mat_type in)= 0;
		virtual const char* error_unable_to_convert(enums::mat_type ret, enums::mat_type in)= 0;
		virtual const char* error_unable_to_read_matrix()= 0;
		virtual const char* error_not_vec(Integer r, Integer c)= 0;
		virtual const char* error_invalid_vectors_spmat(Integer sr, Integer sc, Integer sx)= 0;
		virtual const char* error_unable_to_convert_invalid_code()= 0;
		virtual const char* error_row_indices_sortcols(Integer s, Integer c)= 0;
		virtual const char* error_cols_indices_sortrows(Integer s, Integer c)= 0;
		virtual const char* error_row_indices_elem_sortcols(Integer elem, Integer c)= 0;
		virtual const char* error_col_indices_elem_sortrows(Integer elem, Integer c)= 0;
		virtual const char* error_open_mmlibfile(const std::string& file, const std::string& msg)= 0;
		virtual const char* error_open_matfile(const std::string& file, const std::string& msg)= 0;
		virtual const char* error_matfile_not_opened() = 0;
		virtual const char* error_mmlibfile_locked()= 0;
		virtual const char* error_create_mmlibfile(const std::string& msg)= 0;
		virtual const char* error_read_mmlibfile(const std::string& msg)= 0;
		virtual const char* error_read_mmlibfile_mat_not_exist(const std::string& mat)= 0;
		virtual const char* error_write_mmlibfile_mat_already_exist(const std::string& mat)= 0;
		virtual const char* error_read_matfile() = 0;
		virtual const char* error_read_matfile_var(const std::string& var_name) = 0;
		virtual const char* error_write_matfile() = 0;

		virtual const char* error_unable_to_load_library(const std::string& path) = 0;
		virtual const char* error_while_loading_library(const std::string& path) = 0;

        virtual const char* error_object_value_type_not_allowed() = 0;
        virtual const char* error_integer_value_type_not_allowed() = 0;
        virtual const char* error_square_matrix_required() = 0;
        virtual const char* error_invalid_struct(struct_flag::struct_type fl) = 0;

        virtual void        warning_precision_lost_real_to_int(Real val) = 0;
        virtual void        warning_precision_lost_compl_to_real(Complex val) = 0;
};

class MMLIB_EXPORT default_exception_message : public exception_message
{
	private:
		std::string current_message;

	public:
		virtual const char* error_general(const std::string& msg);

		virtual const char* error_alloc(Integer size);
        virtual const char* error_resize(Integer r, Integer c);
		virtual const char* error_size(Integer r, Integer c);
		virtual const char* error_int_mult(Integer r, Integer c);
        virtual const char* error_int_cast(Real val);
		virtual const char* error_single_index(Integer pos,Integer size);
		virtual const char* error_double_index(Integer i,Integer j,Integer r,Integer c);
		virtual const char* error_diag(Integer d,Integer r,Integer c);
		virtual const char* error_index_band(Integer i,Integer j, Integer r, Integer c, 
											 Integer l, Integer u);
		virtual const char* error_size_band(Integer r, Integer c, Integer l, Integer u);
		virtual const char* error_size_sp(Integer r, Integer c);
		virtual const char* error_invalid_return_type();
		virtual const char* error_horzcat(Integer r1, Integer c1, Integer r2, Integer c2);
		virtual const char* error_vertcat(Integer r1, Integer c1, Integer r2, Integer c2);
		virtual const char* error_index(Integer i, Integer j, Integer r, Integer c);
		virtual const char* error_assign(Integer r1, Integer c1, Integer r2, Integer c2);
		virtual const char* error_row(Integer i, Integer r, Integer c);
		virtual const char* error_col(Integer j, Integer r, Integer c);
		virtual const char* error_reshape(Integer r1, Integer c1, Integer r2, Integer c2);
		virtual const char* error_eeop(Integer r1, Integer c1, Integer r2, Integer c2);
		virtual const char* error_mul(Integer r1, Integer c1, Integer r2, Integer c2);
		virtual const char* error_dim(Integer i, Integer d);
		virtual const char* error_atan2_on_complex();
		virtual const char* error_bspdiags_nonconf();
		virtual const char* error_randperm_arg_neg(Integer n);
		virtual const char* error_bspdiag_1starg_not_vec(Integer r, Integer c);
		virtual const char* error_bspdiags_2ndarg_not_vec(Integer r, Integer c);
		virtual const char* error_diag_arg_not_vec(Integer r, Integer c);
		virtual const char* error_linear_index_too_large(Integer r, Integer c, Integer rows);
		virtual const char* error_alloc_ext();
		virtual const char* error_scalar_required(Integer r, Integer c);
		virtual const char* error_type_get(enums::mat_type ret, enums::mat_type in);
		virtual const char* error_type_get_rep(enums::mat_type ret, enums::mat_type in);
		virtual const char* error_unable_to_convert(enums::mat_type ret, enums::mat_type in);
		virtual const char* error_unable_to_read_matrix();
		virtual const char* error_not_vec(Integer r, Integer c);
		virtual const char* error_invalid_vectors_spmat(Integer sr, Integer sc, Integer sx);
		virtual const char* error_unable_to_convert_invalid_code();
		virtual const char* error_row_indices_sortcols(Integer s, Integer c);
		virtual const char* error_cols_indices_sortrows(Integer s, Integer c);
		virtual const char* error_row_indices_elem_sortcols(Integer elem, Integer c);
		virtual const char* error_col_indices_elem_sortrows(Integer elem, Integer c);
		virtual const char* error_open_mmlibfile(const std::string& file, const std::string& msg);
		virtual const char* error_open_matfile(const std::string& file, const std::string& msg);
		virtual const char* error_matfile_not_opened();
		virtual const char* error_mmlibfile_locked();
		virtual const char* error_create_mmlibfile(const std::string& msg);
		virtual const char* error_read_mmlibfile(const std::string& msg);
		virtual const char* error_read_mmlibfile_mat_not_exist(const std::string& mat);
		virtual const char* error_write_mmlibfile_mat_already_exist(const std::string& mat);
		virtual const char* error_read_matfile();
		virtual const char* error_read_matfile_var(const std::string& var_name);
		virtual const char* error_write_matfile();
		virtual const char* error_unable_to_load_library(const std::string& path);
		virtual const char* error_while_loading_library(const std::string& path);
        virtual const char* error_object_value_type_not_allowed();
        virtual const char* error_integer_value_type_not_allowed();
        virtual const char* error_square_matrix_required();
        virtual const char* error_invalid_struct(struct_flag::struct_type fl);

        virtual void        warning(const std::string& msg);
        virtual void        warning_precision_lost_real_to_int(Real val);
        virtual void        warning_precision_lost_compl_to_real(Complex val);
};

MMLIB_EXPORT void set_global_messanger(exception_message_ptr msg);
MMLIB_EXPORT exception_message& get_global_messanger();

};};

#pragma warning(pop)