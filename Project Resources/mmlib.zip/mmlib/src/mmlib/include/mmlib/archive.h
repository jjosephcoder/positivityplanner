/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <iosfwd>
#include "mmlib/details/fwd_decls.h"

namespace eos 
{

class portable_iarchive;
class portable_oarchive;
};

namespace mmlib 
{

class MMLIB_EXPORT iarchive
{
    private:
        typedef eos::portable_iarchive  archive_type;

        archive_type*   m_impl;

        iarchive(const iarchive&);
        iarchive& operator=(const iarchive&);

    public:
        iarchive(std::istream& is, unsigned int v = 0);
        ~iarchive();

        archive_type&   get()       { return *m_impl; };

        iarchive&       operator>>(Matrix& mat);
        iarchive&       operator>>(Integer& v);
        iarchive&       operator>>(Real& v);
        iarchive&       operator>>(Complex& v);
};

class MMLIB_EXPORT oarchive
{
    private:
        typedef eos::portable_oarchive  archive_type;

        archive_type*   m_impl;

        oarchive(const oarchive&);
        oarchive& operator=(const oarchive&);

    public:
        oarchive(std::ostream& os, unsigned int v = 0);

        archive_type&   get()       { return *m_impl; };

        oarchive&       operator<<(const Matrix& mat);
        oarchive&       operator<<(Integer v);
        oarchive&       operator<<(Real v);
        oarchive&       operator<<(const Complex& v);
};

};