/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/scalar_types.h"
#include "mmlib/details/type_info.h"
#include <iosfwd>

namespace mmlib 
{

namespace details
{
    template<class val_type> 
    val_type* aligned_realloc(type_info ti, val_type* old_ptr, size_t old_size, size_t n_elem);
};

class Object
{
    private:
        typedef details::type_info type_info;

    public:        
        ~Object()                                   {};

        explicit Object(type_info)                  {};
        explicit Object(type_info, const Object&)   {};
        explicit Object(type_info,Integer )         {};
        explicit Object(type_info,Real )            {};
        explicit Object(type_info,Complex )         {};

        Object& operator+=(const Object& )      { return *this; };
        Object& operator*=(const Object& )      { return *this; };

        bool    is_zero() const                 { return false; };
        bool    is_one() const                  { return false; };
        bool    is_true() const                 { return true; };
        Integer to_integer() const              { return 0; };
        Real    to_real() const                 { return 0.;};
        Complex to_complex() const              { return Complex();};
        Object  convert(type_info ) const       { return *this; };

        std::string to_string() const           { return "object"; };
        type_info get_ti() const                { return details::get_empty_ti(); };

        friend std::ostream&	operator<<(std::ostream& os, const Object& ) {return os; };
        friend std::istream&	operator>>(std::istream& is, Object& )       {return is; };

    private:
        void location_changed(Object* , Object* )
        {};

        friend Object* details::aligned_realloc<Object>(type_info ti, Object* old_ptr, 
                                                        size_t old_size, size_t n_elem);
};

namespace details
{
    template<class T1,class T2> struct object_enabler {};
    template<class T2> struct object_enabler<Integer,T2>        { typedef T2 type; };
    template<class T2> struct object_enabler<Real,T2>           { typedef T2 type; };
    template<class T2> struct object_enabler<Complex,T2>        { typedef T2 type; };
};

inline  Object  operator-(const Object& A)                      { return A; };
inline  Object  operator+(const Object& A, const Object& )      { return A; };

template<class T> 
inline typename details::object_enabler<T,Object>::type
        operator+(const Object& A, T )                          { return A; };

template<class T> 
inline typename details::object_enabler<T,Object>::type
        operator+(T , const Object& B)                          { return B; };

inline Object  operator-(const Object& A, const Object& )       { return A; };

template<class T> 
inline typename details::object_enabler<T,Object>::type
        operator-(const Object& A, T )                          { return A; };

template<class T> 
inline typename details::object_enabler<T,Object>::type
        operator-(T , const Object& B)                          { return B; };

inline Object  operator*(const Object& A, const Object& )       { return A; };

template<class T> 
inline typename details::object_enabler<T,Object>::type
        operator*(const Object& A, T )                          { return A; };

template<class T> 
inline typename details::object_enabler<T,Object>::type
        operator*(T , const Object& B)                          { return B; };

inline Object  operator/(const Object& A, const Object& )       { return A; };

template<class T>
inline typename details::object_enabler<T,Object>::type
        operator/(const Object& A, T )                          { return A; };

template<class T> 
inline typename details::object_enabler<T,Object>::type
        operator/(T , const Object& B)                          { return B; };

inline bool    operator==(const Object& , const Object& )       { return true;};

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator==(const Object& , T )                          { return true; };

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator==(T A, const Object& )                         { return true; };

inline bool    operator!=(const Object& , const Object& )       { return true;};

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator!=(const Object& , T )                          { return true; };

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator!=(T A, const Object& B)                        { return true; };

inline bool    operator<(const Object& , const Object& )        { return true;};

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator<(const Object& , T )                           { return true; };

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator<(T A, const Object& B)                         { return true; };

inline bool    operator<=(const Object& , const Object& )       { return true;};

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator<=(const Object& , T )                          { return true; };

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator<=(T A, const Object& B)                        { return true; };

inline bool    operator>=(const Object& , const Object& )       { return true;};

template<class T> 
inline typename details::object_enabler<T,bool>::type
        operator>=(const Object& , T )                          { return true; };

template<class T> 
inline typename details::object_enabler<T,bool>::type
        operator>=(T A, const Object& )                         { return true; };

inline bool    operator>(const Object& , const Object& )        { return true;};

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator>(const Object& , T )                           { return true; };

template<class T>
inline typename details::object_enabler<T,bool>::type
        operator>(T A, const Object& B)                         { return true; };

namespace object_func
{
inline Object  real(const Object& obj) { return obj; };
inline Object  imag(const Object& obj) { return obj; };


inline Object  atan2(const Object& A, const Object& )          { return A; };
inline Object  pow(const Object& A, const Object& )            { return A; };
inline Object  sqrt(const Object& A)                           { return A; };
inline Object  abs(const Object& A)                            { return A; };
inline Object  angle(const Object& A)                          { return A; };
inline Object  arg(const Object& A)                            { return A; };
inline Object  conj(const Object& A)                           { return A; };
inline Object  exp(const Object& A)                            { return A; };
inline Object  log(const Object& A)                            { return A; };
inline Object  log10(const Object& A)                          { return A; };
inline Object  log2(const Object& A)                           { return A; };
inline Object  pow2(const Object& A)                           { return A; };
inline Object  sin(const Object& A)                            { return A; };
inline Object  cos(const Object& A)                            { return A; };
inline Object  tan(const Object& A)                            { return A; };
inline Object  cot(const Object& A)                            { return A; };
inline Object  sec(const Object& A)                            { return A; };
inline Object  csc(const Object& A)                            { return A; };
inline Object  asin(const Object& A)                           { return A; };
inline Object  acos(const Object& A)                           { return A; };
inline Object  atan(const Object& A)                           { return A; };
inline Object  acot(const Object& A)                           { return A; };
inline Object  asec(const Object& A)                           { return A; };
inline Object  acsc(const Object& A)                           { return A; };
inline Object  sinh(const Object& A)                           { return A; };
inline Object  cosh(const Object& A)                           { return A; };
inline Object  tanh(const Object& A)                           { return A; };
inline Object  coth(const Object& A)                           { return A; };
inline Object  sech(const Object& A)                           { return A; };
inline Object  csch(const Object& A)                           { return A; };
inline Object  asinh(const Object& A)                          { return A; };
inline Object  acosh(const Object& A)                          { return A; };
inline Object  atanh(const Object& A)                          { return A; };
inline Object  acoth(const Object& A)                          { return A; };
inline Object  asech(const Object& A)                          { return A; };
inline Object  acsch(const Object& A)                          { return A; };
inline bool    isnan(const Object& )                           { return false; };
inline bool    isinf(const Object&  )                          { return false; };
inline bool    finite(const Object& )                          { return false; };
inline bool    isfinite(const Object& )                        { return false; };
inline Object  ceil(const Object& A)                           { return A; };
inline Object  fix(const Object& A)                            { return A; };
inline Object  floor(const Object& A)                          { return A; };
inline Object  round(const Object& A)                          { return A; };
inline Object  trunc(const Object& A)                          { return A; };
inline Object  sign(const Object& A)                           { return A; };
inline Integer iceil(const Object& )                           { return 0; };
inline Integer ifix(const Object& )                            { return 0; };
inline Integer ifloor(const Object& )                          { return 0; };
inline Integer iround(const Object& )                          { return 0; };
inline Integer itrunc(const Object& )                          { return 0; };
inline Integer isign(const Object& )                           { return 0; };
};

};
