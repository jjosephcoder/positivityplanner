/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <complex>

namespace mmlib
{
    class Object;
};

namespace mmlib { namespace complex
{

//some functions with the same name as in std namespace must be changed
//in order to satisfy the embedness property: f_(R)(x) = f_(C)(Complex(x)) for x in R
//this makes some problems with ADL
template<class T>
struct complex
{
    typedef T           type;

    std::complex<T>     value;

    complex()                   : value(T(),T()){};
    complex(T re)               : value(re,T()) {};
    complex(T re, T im)         : value(re,im)  {};

    explicit complex(const std::complex<T>& value)
                                :value(value)   {};
};

template<class T>
inline T imag(const complex<T>& val)            { return std::imag(val.value); };
template<class T>
inline T real(const complex<T>& val)            { return std::real(val.value); };

namespace details
{

template<class T>   struct base_scalar						{ };
template<>			struct base_scalar<bool>				{	typedef signed long		type;   };
template<>			struct base_scalar<signed char>			{	typedef signed long		type;   };
template<>			struct base_scalar<unsigned char>		{	typedef signed long		type;   };
template<>			struct base_scalar<signed short>		{	typedef signed long		type;   };
template<>			struct base_scalar<unsigned short>		{	typedef signed long		type;   };
template<>			struct base_scalar<signed int>			{	typedef signed long		type;   };
template<>			struct base_scalar<unsigned int>		{	typedef signed long		type;   };
template<>			struct base_scalar<signed long>			{	typedef signed long		type;   };
template<>			struct base_scalar<unsigned long>		{	typedef signed long		type;   };
template<>			struct base_scalar<signed long long>	{	typedef signed long		type;   };
template<>			struct base_scalar<unsigned long long>	{	typedef signed long		type;   };
template<>			struct base_scalar<double>				{	typedef double		    type;   };
template<>			struct base_scalar<float>				{	typedef double		    type;   };
template<>			struct base_scalar<long double>			{	typedef double		    type;   };
template<>			struct base_scalar<Object>			    {	typedef Object		    type;   };

template<class T>   struct base_scalar_code                 {};
template<>          struct base_scalar_code<signed long>    { static const int code = 0;        };
template<>          struct base_scalar_code<double>         { static const int code = 1;        };
template<>          struct base_scalar_code<Object>         { static const int code = 2;        };

template<int code>  struct code_base_scalar                 {};
template<>          struct code_base_scalar<0>              { typedef signed long type;         };
template<>          struct code_base_scalar<1>              { typedef double type;              };
template<>          struct code_base_scalar<2>              { typedef Object type;              };

template<class T, class S>
struct max_type_base 
{
    static const int T_code = base_scalar_code<base_scalar<T>::type>::code;
    static const int S_code = base_scalar_code<base_scalar<S>::type>::code;
    static const int M_code = (T_code > S_code)? T_code: S_code;

    typedef typename code_base_scalar<M_code>::type type;
};

template<class T>
struct uminus_helper
{};
template<class T>
struct uminus_helper<complex<T>>
{
    typedef complex<T> return_type;

    static return_type eval(const complex<T>& a)
    {
        return complex<T>(std::operator-(a.value));
    };
};

template<class T>
struct inv_helper
{};
template<class T>
struct inv_helper<complex<T>>
{
    typedef complex<T> return_type;

    static return_type eval(const complex<T>& a)
    {
        return complex<T>(std::operator/(1.,a.value));
    };
};


template<class T, class S>
struct plus_helper
{};
template<class T, class S>
struct plus_helper<complex<T>,complex<S>>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const complex<T>& a, const complex<S>& b)
    {
        return return_type(std::operator+(a.value,b.value));
    };
};
template<class T, class S>
struct plus_helper<complex<T>,S>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const complex<T>& a, const S& b)
    {
        return return_type(std::operator+(a.value,b));
    };
};
template<class T, class S>
struct plus_helper<T,complex<S>>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const T& a, const complex<S>& b)
    {
        return return_type(std::operator+(a,b.value));
    };
};

template<class T, class S>
struct minus_helper
{};
template<class T, class S>
struct minus_helper<complex<T>,complex<S>>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const complex<T>& a, const complex<S>& b)
    {
        return return_type(std::operator-(a.value,b.value));
    };
};
template<class T, class S>
struct minus_helper<complex<T>,S>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const complex<T>& a, const S& b)
    {
        return return_type(std::operator-(a.value,b));
    };
};
template<class T, class S>
struct minus_helper<T,complex<S>>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const T& a, const complex<S>& b)
    {
        return return_type(a-real(b),-imag(b));
    };
};

template<class T, class S>
struct mul_helper
{};
template<class T, class S>
struct mul_helper<complex<T>,complex<S>>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const complex<T>& a, const complex<S>& b)
    {
        return return_type(std::operator*(a.value,b.value));
    };
};
template<class T, class S>
struct mul_helper<complex<T>,S>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const complex<T>& a, const S& b)
    {
        return return_type(std::operator*(a.value,b));
    };
};
template<class T, class S>
struct mul_helper<T,complex<S>>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const T& a, const complex<S>& b)
    {
        return return_type(std::operator*(a,b.value));
    };
};

template<class T, class S>
struct div_helper
{};
template<class T, class S>
struct div_helper<complex<T>,complex<S>>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const complex<T>& a, const complex<S>& b)
    {
        return return_type(std::operator/(a.value,b.value));
    };
};
template<class T, class S>
struct div_helper<complex<T>,S>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const complex<T>& a, const S& b)
    {
        return return_type(std::operator/(a.value,b));
    };
};
template<class T, class S>
struct div_helper<T,complex<S>>
{
    typedef complex<typename max_type_base<T,S>::type> return_type;

    static return_type eval(const T& a, const complex<S>& b)
    {
        return return_type(std::operator/(a,b.value));
    };
};


template<class T, class S>
struct lt_helper
{};
template<class T, class S>
struct lt_helper<complex<T>,complex<S>>
{
    static bool eval(const complex<T>& a, const complex<S>& b)
    {
	    if (mmlib::complex::real(a) < mmlib::complex::real(b))
	    {
		    return true;
	    }
	    else if (mmlib::complex::real(a) == mmlib::complex::real(b))
	    {
		    return mmlib::complex::imag(a) < mmlib::complex::imag(b);
	    };
	    return false;
    };
};
template<class T, class S>
struct lt_helper<complex<T>,S>
{
    static bool eval(const complex<T>& a, const S& b)
    {
	    if (mmlib::complex::real(a) < b)
	    {
		    return true;
	    }
	    else if (mmlib::complex::real(a) == b)
	    {
		    return mmlib::complex::imag(a) < T();
	    };
	    return false;
    };
};
template<class T, class S>
struct lt_helper<T,complex<S>>
{
    static bool eval(const T& a, const complex<S>& b)
    {
	    if (a < mmlib::complex::real(b))
	    {
		    return true;
	    }
	    else if (a == mmlib::complex::real(b))
	    {
		    return S() < mmlib::complex::imag(b);
	    };
	    return false;
    };
};

template<class T, class S>
struct gt_helper
{};
template<class T, class S>
struct gt_helper<complex<T>,complex<S>>
{
    static bool eval(const complex<T>& a, const complex<S>& b)
    {
	    if (mmlib::complex::real(a) > mmlib::complex::real(b))
	    {
		    return true;
	    }
	    else if (mmlib::complex::real(a) == mmlib::complex::real(b))
	    {
		    return mmlib::complex::imag(a) > mmlib::complex::imag(b);
	    };
	    return false;
    };
};
template<class T, class S>
struct gt_helper<complex<T>,S>
{
    static bool eval(const complex<T>& a, const S& b)
    {
	    if (mmlib::complex::real(a) > b)
	    {
		    return true;
	    }
	    else if (mmlib::complex::real(a) == b)
	    {
		    return mmlib::complex::imag(a) > T();
	    };
	    return false;
    };
};
template<class T, class S>
struct gt_helper<T,complex<S>>
{
    static bool eval(const T& a, const complex<S>& b)
    {
	    if (a > mmlib::complex::real(b))
	    {
		    return true;
	    }
	    else if (a == mmlib::complex::real(b))
	    {
		    return S() > mmlib::complex::imag(b);
	    };
	    return false;
    };
};

template<class T, class S>
struct leq_helper
{};
template<class T, class S>
struct leq_helper<complex<T>,complex<S>>
{   
    static bool eval(const complex<T>& a, const complex<S>& b)
    {
	    if (mmlib::complex::real(a) < mmlib::complex::real(b))
	    {
		    return true;
	    }
	    else if (mmlib::complex::real(a) == mmlib::complex::real(b))
	    {
		    return mmlib::complex::imag(a) <= mmlib::complex::imag(b);
	    };
	    return false;
    };
};
template<class T, class S>
struct leq_helper<complex<T>,S>
{
    static bool eval(const complex<T>& a, const S& b)
    {
	    if (mmlib::complex::real(a) < b)
	    {
		    return true;
	    }
	    else if (mmlib::complex::real(a) == b)
	    {
		    return mmlib::complex::imag(a) <= T();
	    };
	    return false;
    };
};
template<class T, class S>
struct leq_helper<T,complex<S>>
{
    static bool eval(const T& a, const complex<S>& b)
    {
	    if (a < mmlib::complex::real(b))
	    {
		    return true;
	    }
	    else if (a == mmlib::complex::real(b))
	    {
		    return S() <= mmlib::complex::imag(b);
	    };
	    return false;
    };
};

template<class T, class S>
struct geq_helper
{};
template<class T, class S>
struct geq_helper<complex<T>,complex<S>>
{
    static bool eval(const complex<T>& a, const complex<S>& b)
    {
	    if (mmlib::complex::real(a) > mmlib::complex::real(b))
	    {
		    return true;
	    }
	    else if (mmlib::complex::real(a) == mmlib::complex::real(b))
	    {
		    return mmlib::complex::imag(a) >= mmlib::complex::imag(b);
	    };
	    return false;
    };
};
template<class T, class S>
struct geq_helper<complex<T>,S>
{
    static bool eval(const complex<T>& a, const S& b)
    {
	    if (mmlib::complex::real(a) > b)
	    {
		    return true;
	    }
	    else if (mmlib::complex::real(a) == b)
	    {
		    return mmlib::complex::imag(a) >= T();
	    };
	    return false;
    };
};
template<class T, class S>
struct geq_helper<T,complex<S>>
{
    static bool eval(const T& a, const complex<S>& b)
    {
	    if (a > mmlib::complex::real(b))
	    {
		    return true;
	    }
	    else if (a == mmlib::complex::real(b))
	    {
		    return S() >= mmlib::complex::imag(b);
	    };
	    return false;
    };
};


template<class T, class S>
struct eeq_helper
{};
template<class T, class S>
struct eeq_helper<complex<T>,complex<S>>
{
    static bool eval(const complex<T>& a, const complex<S>& b)
    {
        return (mmlib::complex::real(a) == mmlib::complex::real(b)) 
            && (mmlib::complex::imag(a) == mmlib::complex::imag(b));
    };
};
template<class T, class S>
struct eeq_helper<complex<T>,S>
{
    static bool eval(const complex<T>& a, const S& b)
    {
        return (mmlib::complex::real(a) == b) && (mmlib::complex::imag(a) == T());
    };
};
template<class T, class S>
struct eeq_helper<T,complex<S>>
{
    static bool eval(const T& a, const complex<S>& b)
    {
        return (a == mmlib::complex::real(b)) && (S() == mmlib::complex::imag(b));
    };
};

template<class T, class S>
struct neq_helper
{};
template<class T, class S>
struct neq_helper<complex<T>,complex<S>>
{
    static bool eval(const complex<T>& a, const complex<S>& b)
    {
        return (mmlib::complex::real(a) != mmlib::complex::real(b)) 
                    || (mmlib::complex::imag(a) != mmlib::complex::imag(b));
    };
};
template<class T, class S>
struct neq_helper<complex<T>,S>
{
    static bool eval(const complex<T>& a, const S& b)
    {
        return (mmlib::complex::real(a) != b) || (mmlib::complex::imag(a) != T());
    };
};
template<class T, class S>
struct neq_helper<T,complex<S>>
{
    static bool eval(const T& a, const complex<S>& b)
    {
        return (a != mmlib::complex::real(b)) || (S() != mmlib::complex::imag(b));
    };
};

};

template<class T>
inline typename details::uminus_helper<T>::return_type
uminus_c(const T& a)
{
    return details::uminus_helper<T>::eval(a);
};
template<class T>
inline typename details::inv_helper<T>::return_type
inv_c(const T& a)
{
    return details::inv_helper<T>::eval(a);
};

template<class T, class S>
inline typename details::plus_helper<T,S>::return_type
plus_c(const T& a, const S& b)
{
    return details::plus_helper<T,S>::eval(a,b);
};
template<class T, class S>
inline typename details::minus_helper<T,S>::return_type
minus_c(const T& a, const S& b)
{
    return details::minus_helper<T,S>::eval(a,b);
};
template<class T, class S>
inline typename details::mul_helper<T,S>::return_type
mul_c(const T& a, const S& b)
{
    return details::mul_helper<T,S>::eval(a,b);
};
template<class T, class S>
inline typename details::div_helper<T,S>::return_type
div_c(const T& a, const S& b)
{
    return details::div_helper<T,S>::eval(a,b);
};

template<class T, class S>
inline bool lt_c(const T& a, const S& b)
{
    return details::lt_helper<T,S>::eval(a,b);
};
template<class T, class S>
inline bool gt_c(const T& a, const S& b)
{
    return details::gt_helper<T,S>::eval(a,b);
};
template<class T, class S>
inline bool leq_c(const T& a, const S& b)
{
    return details::leq_helper<T,S>::eval(a,b);
};
template<class T, class S>
inline bool geq_c(const T& a, const S& b)
{
    return details::geq_helper<T,S>::eval(a,b);
};
template<class T, class S>
inline bool eeq_c(const T& a, const S& b)
{
    return details::eeq_helper<T,S>::eval(a,b);
};
template<class T, class S>
inline bool neq_c(const T& a, const S& b)
{
    return details::neq_helper<T,S>::eval(a,b);
};

template<class T>
inline complex<T>& operator+=(complex<T>& arg, const complex<T>& val)
{
    arg = details::plus_helper<complex<T>,complex<T>>::eval(arg,val);
    return arg;
};
template<class T>
inline complex<T>& operator-=(complex<T>& arg, const complex<T>& val)
{
    arg = details::minus_helper<complex<T>,complex<T>>::eval(arg,val);
    return arg;
};
template<class T>
inline complex<T>& operator*=(complex<T>& arg, const complex<T>& val)
{
    arg = details::mul_helper<complex<T>,complex<T>>::eval(arg,val);
    return arg;
};
template<class T>
inline complex<T>& operator/=(complex<T>& arg, const complex<T>& val)
{
    arg = details::div_helper<complex<T>,complex<T>>::eval(arg,val);
    return arg;
};

};};
