/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/matrix_fwd.h"
#include "mmlib/matrix.h"

namespace mmlib
{

namespace details
{
	struct MMLIB_EXPORT colonend 
	{ 
		Integer offset;		

		colonend() : offset(0) {};

		Integer apply(Integer s) const
		{
			return s + offset;
		};
	};

	inline colonend operator+(colonend old, Integer val)
	{
		colonend out;
		out.offset = old.offset + val;
		return out;
	};
	inline colonend operator+(Integer val, colonend old)
	{
		colonend out;
		out.offset = old.offset + val;
		return out;
	};

	inline colonend operator-(colonend old, Integer val)
	{
		colonend out;
		out.offset = old.offset - val;
		return out;
	};
	inline colonend operator-(Integer val, colonend old)
	{
		colonend out;
		out.offset = val - old.offset;
		return out;
	};
};


namespace 
{
	details::colonend end;
};

class MMLIB_EXPORT colon
{
	public:    
		typedef details::colonend cend;

		enum colon_type { t_all, t_range, t_end, t_rev_end, t_end_end, t_last, t_matrix };

		colon_type				m_flag;
		Integer					m_s;
		Integer					m_i;
		Integer					m_e;
		cend					m_end1;
		cend					m_end2;
		Matrix					m_mat;

	public:
		colon()									:m_s(0),m_i(0),m_e(0),m_flag(t_all){};
		colon(Integer s)						:m_s(s),m_i(1),m_e(s),m_flag(t_range){};
		colon(details::colonend e)				:m_s(0),m_i(0),m_e(0),m_flag(t_last),m_end1(e){};
        colon::colon(const Matrix& mat);

		colon(Integer s, Integer e)				:m_s(s),m_i(1),m_e(e),m_flag(t_range){};
		colon(Integer s, details::colonend e)	:m_s(s),m_i(1),m_e(0),m_flag(t_end),m_end1(e){};

		colon(Integer s, Integer i, Integer e)	:m_s(s),m_i(i),m_e(e),m_flag(t_range){};
		colon(Integer s, Integer i, cend e)		:m_s(s),m_i(i),m_e(0),m_flag(t_end),m_end1(e){};
		colon(cend en, Integer i, Integer e)	:m_s(0),m_i(i),m_e(e),m_flag(t_rev_end),m_end1(en){};
		colon(cend en, Integer e)				:m_s(0),m_i(1),m_e(e),m_flag(t_rev_end),m_end1(en){};

		colon(cend en1, Integer i,cend en2)		:m_s(0),m_i(i),m_e(0),m_end1(en1),m_end2(en2)
                                                ,m_flag(t_end_end){};
		colon(cend en1, cend en2)				:m_s(0),m_i(1),m_e(0),m_end1(en1),m_end2(en2)
                                                ,m_flag(t_end_end){};
};


};
