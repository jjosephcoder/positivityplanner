/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/matrix.h"
#include "mmlib/disp_stream.h"

namespace mmlib
{

namespace details
{
	MMLIB_EXPORT void			disp_impl(disp_stream& os, Integer);
	MMLIB_EXPORT void			disp_impl(disp_stream& os, const Real&);
	MMLIB_EXPORT void			disp_impl(disp_stream& os, const Complex&);

	MMLIB_EXPORT void			disp_impl(Integer);
	MMLIB_EXPORT void			disp_impl(const Real&);
	MMLIB_EXPORT void			disp_impl(const Complex&);
};

MMLIB_EXPORT void			disp(const Matrix& m);
MMLIB_EXPORT void			disp(disp_stream& os, const Matrix& m);
MMLIB_EXPORT void			disp(char*);
MMLIB_EXPORT void			disp(const std::string& );

template<class S> MMLIB_EXPORT
inline typename details::enable_if_scal_ret_void<S>::type
disp(S A)
{
	typedef typename details::promote_scalar<S>::type SP;
	return details::disp_impl(SP(A));
};

template<class S> MMLIB_EXPORT
inline typename details::enable_if_scal_ret_void<S>::type
disp(disp_stream& os,S A)
{
	typedef typename details::promote_scalar<S>::type SP;
	return details::disp_impl(os,SP(A));
};

MMLIB_EXPORT void			disp(disp_stream& os, char*);
MMLIB_EXPORT void			disp(disp_stream& os, const std::string& );

MMLIB_EXPORT std::ostream&	operator<<(std::ostream&, const Matrix&);
MMLIB_EXPORT std::istream&	operator>>(std::istream&, Matrix&);

MMLIB_EXPORT void            load(iarchive& ar,Matrix& mat);
MMLIB_EXPORT void            save(oarchive& ar,const Matrix& mat);


};