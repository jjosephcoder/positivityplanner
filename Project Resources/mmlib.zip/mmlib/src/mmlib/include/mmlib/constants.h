/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/config.h"
#include "mmlib/scalar_types.h"

namespace mmlib { namespace constants
{

namespace details
{
MMLIB_EXPORT Real Eps();
MMLIB_EXPORT Real MinReal();
MMLIB_EXPORT Real MaxReal();
MMLIB_EXPORT Real Inf();
MMLIB_EXPORT Real NaN();
MMLIB_EXPORT Integer MaxInt();
MMLIB_EXPORT Integer MinInt();
MMLIB_EXPORT Complex I();
MMLIB_EXPORT Real e();
MMLIB_EXPORT Real pi();
MMLIB_EXPORT Real pi_2();
MMLIB_EXPORT Real log2e();
MMLIB_EXPORT Real log10pi();
MMLIB_EXPORT Real sqrt2();
};

namespace 
{
const Real Eps			= details::Eps();
const Real MinReal		= details::MinReal();
const Real MaxReal		= details::MaxReal();
const Real Inf			= details::Inf();
const Real NaN			= details::NaN();
const Integer MaxInt	= details::MaxInt();
const Integer MinInt	= details::MinInt();
const Complex I			= details::I();
const Real e			= details::e();
const Real pi			= details::pi();
const Real pi_2			= details::pi_2();
const Real log2e		= details::log2e();
const Real log10pi		= details::log10pi();
const Real sqrt2		= details::sqrt2();
};

};};