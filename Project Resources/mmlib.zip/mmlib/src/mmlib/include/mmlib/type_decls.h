/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/scalar_types.h"

namespace mmlib
{

namespace enums
{
	enum value_type	
	{ 
		value_integer = 1, value_real = 2, value_complex = 3, value_object = 4
	};
	enum struct_type
	{ 
		struct_dense = 0, struct_sparse, struct_banded, struct_scalar
	};
	enum mat_type
	{
        integer_scalar = 0,	real_scalar,	complex_scalar,     object_scalar,
		integer_dense,	    real_dense,		complex_dense,      object_dense,
		integer_sparse,     real_sparse,	complex_sparse,     object_sparse,
		integer_band,	    real_band,		complex_band,       object_band,		
        last_code
	};

	enum open_mode
	{
		readonly, readwrite, readwrite_create, update
	};
	enum thread_mode
	{
		single_thread, multi_thread, serialized
	};
};

struct struct_dense{};
struct struct_sparse{};
struct struct_banded{};
struct struct_scalar{};


};
