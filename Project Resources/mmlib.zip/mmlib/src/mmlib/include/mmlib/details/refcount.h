/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/config.h"
#include "mmlib/details/fwd_decls.h"

namespace mmlib { namespace details
{

class matrix_container_base;

struct MMLIB_EXPORT refcount_str
{
    public:
        refcount_str(long val = 0);
        ~refcount_str(){};

        long                    get_count() const;
        refcount_str*           increase();
        bool                    decrease();
        bool                    is_unique() const;
        void                    destroy();

        static refcount_str*    create(long val);

    protected:
        long                    m_refcount;

    private:
        refcount_str(const refcount_str&);
        refcount_str& operator=(const refcount_str&);

    private:
/*
        SERIALIZE_MACRO
        void save(oarchive & , const unsigned int ) const {};
        void load(iarchive & , const unsigned int )
        {
            m_refcount = 0;
        }; 
*/
};

//not thread safe
long MMLIB_EXPORT no_existing_objects();

//not thread safe
void MMLIB_EXPORT close_refcount();

};};

#include "mmlib/details/refcount.inl"
