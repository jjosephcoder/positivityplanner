/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/config.h"

namespace mmlib { namespace details
{

class MMLIB_EXPORT type_info
{
    private:
        type_info(){};
    public:
        static type_info    get_ti_other()                          { return type_info(); };

        static type_info    ti_assign(type_info , type_info )       { return type_info(); };

        template<class T>
        static type_info    ti_assign_obj_raw(type_info t)          { return t; };

        template<class T>
        static type_info    ti_assign_raw_obj(type_info t)          { return t; };

        bool operator==(const type_info& ) const                    { return true;};
        bool operator<=(const type_info& ) const                    { return true;};
        bool operator>=(const type_info& ) const                    { return true;};
};

inline MMLIB_EXPORT std::ostream& operator<<(std::ostream& os, const type_info&)
{
    return os;
};
inline MMLIB_EXPORT std::istream& operator>>(std::istream& is, type_info&)
{
    return is;
};

inline type_info get_raw_ti()
{
    return type_info::get_ti_other();
};
inline type_info get_empty_ti()
{
    return type_info::get_ti_other();
};

struct ti_func
{
    enum func
    {
        func_sqrt,  func_log,   func_log2,  func_log10, func_asin,
        func_acos,  func_asec,  func_acsc,  func_acosh, func_atanh,
        func_acoth, func_asech, func_istrue,func_uminus,func_op_neg,
        func_ctrans,func_pow2,  func_exp,   func_acot,  func_atan,
        func_cos,   func_cosh,  func_cot,   func_csc,   func_sec,
        func_sin,   func_sinh,  func_tan,   func_tanh,  func_acsch,
        func_asinh, func_coth,  func_csch,  func_abs,   func_arg,
        func_imag,  func_isfinite,func_isinf,func_isnan,func_real,
        func_conj,  func_ceil,  func_fix,   func_floor, func_iceil,
        func_ifix,  func_ifloor,func_iround,func_itrunc,func_round,
        func_sign,  func_trunc, 
    };
};

class binfunc_mult{};   class binfunc_minus{};  class binfunc_plus{};
class binfunc_xor{};    class binfunc_mod{};    class binfunc_idiv{};
class binfunc_min{};    class binfunc_max{};    class binfunc_rem{};
class binfunc_and{};    class binfunc_or{};     class binfunc_atan2{};
class binfunc_eeq{};    class binfunc_geq{};    class binfunc_leq{};
class binfunc_neq{};    class binfunc_lt{};     class binfunc_gt{};
class binfunc_div{};    class binfunc_pow{};    class binfunc_pow_nc{};
class binfunc_kron{};

class unfunc_uminus{};  class unfunc_pow{};     class unfunc_pow_nc{};
class unfunc_abs{};     class unfunc_conj{};    class unfunc_isnan{};
class unfunc_sqrt_nc{}; class unfunc_real{};    class unfunc_angle{};
class unfunc_arg{};     class unfunc_exp{};     class unfunc_imag{};
class unfunc_log{};     class unfunc_pow2{};    class unfunc_sqrt{};
class unfunc_ceil{};    class unfunc_fix{};     class unfunc_floor{};
class unfunc_log10{};   class unfunc_log2{};    class unfunc_round{};
class unfunc_trunc{};   class unfunc_iceil{};   class unfunc_ifix{};
class unfunc_ifloor{};  class unfunc_iround{};  class unfunc_isfinite{};
class unfunc_isinf{};   class unfunc_itrunc{};  
class unfunc_sin{};     class unfunc_cos{};     class unfunc_tan{};
class unfunc_cot{};     class unfunc_sec{};     class unfunc_csc{};
class unfunc_asin{};    class unfunc_acos{};    class unfunc_atan{};
class unfunc_acot{};    class unfunc_asec{};    class unfunc_acsc{};
class unfunc_sinh{};    class unfunc_cosh{};    class unfunc_tanh{};
class unfunc_coth{};    class unfunc_sech{};    class unfunc_csch{};
class unfunc_asinh{};   class unfunc_acosh{};   class unfunc_atanh{};
class unfunc_acoth{};   class unfunc_asech{};   class unfunc_acsch{};
class unfunc_sign{};    class unfunc_cumprod{}; class unfunc_isscalar_false{};                  
class unfunc_min{};     class unfunc_prod{};    class unfunc_isscalar_true{};
class unfunc_sum{};     class unfunc_sumsq{};   class unfunc_cumsum{};
class unfunc_isfalse{}; class unfunc_istrue{};  class unfunc_max{};
class unfunc_mean{};    class unfunc_std{};     class unfunc_all{};
class unfunc_any{};     class unfunc_neg{};

template<class T> struct raw_type_info{};
template<> struct raw_type_info<Integer>
{
    static type_info    eval()    { return get_raw_ti(); };
};
template<> struct raw_type_info<Real>
{
    static type_info    eval()    { return get_raw_ti(); };
};
template<> struct raw_type_info<Complex>
{
    static type_info    eval()    { return get_raw_ti(); };
};

inline type_info get_concat_ti(type_info t1, type_info )
{
    return t1;
};
inline type_info get_concat_ti_int(type_info t1)
{
    return t1;
};
inline type_info get_concat_ti_real(type_info t1)
{
    return t1;
};
inline type_info get_concat_ti_compl(type_info t1)
{
    return t1;
};
template<class T1, class T2>
struct return_ti
{
    static type_info eval(const T1& , const T2& )
    { 
        return get_raw_ti(); 
    };
};
template<class T, ti_func::func func>
struct return_scal
{
    static type_info eval(const T& )
    { 
        return get_raw_ti(); 
    };
};

template<class T1, class T2>
struct return_kron_ti
{
    static type_info eval(const T1& , const T2& )
    { 
        return get_raw_ti(); 
    };
};
inline type_info return_mult_ti2(type_info , type_info )
{ 
    return get_raw_ti(); 
};
inline type_info return_plus_ti2(type_info , type_info )
{ 
    return get_raw_ti(); 
};

template<class T1, class T2>
struct return_pow_ti
{
    static type_info eval(const T1& mat1, const T2& mat2)
    { 
        return get_raw_ti(); 
    };
};
template<class T1, class T2>
struct return_mult_ti
{
    static type_info eval(const T1& , const T2& )
    { 
        return get_raw_ti(); 
    };
};
template<class T1, class T2>
struct return_div_ti
{
    static type_info eval(const T1& , const T2& )
    { 
        return get_raw_ti(); 
    };
};
template<class F, class T1, class T2 = void>
struct return_func_ti
{
    static type_info eval(const T1& , const T2& )
    { 
        return get_raw_ti(); 
    };
};
template<class F, class T1>
struct return_func_ti<F,T1,void>
{
    static type_info eval(const T1& )
    { 
        return get_raw_ti(); 
    };
};
template<class M1,class M2,class T>
struct return_plus_ti
{
    static type_info eval(const M1& ,const M2& , T /*scal1*/,T /*scal2*/)
    { 
        return get_raw_ti(); 
    };
};

inline type_info get_ti_real(type_info)
{ 
    return get_raw_ti(); 
};

};};