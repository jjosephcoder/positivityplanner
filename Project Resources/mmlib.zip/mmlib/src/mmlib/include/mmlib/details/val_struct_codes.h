/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/matrix_fwd.h"

namespace mmlib { namespace details
{

template<class T>	struct value_to_code							{};
template<>			struct value_to_code<Integer>					{static const enums::value_type value = enums::value_integer;};
template<>			struct value_to_code<Real>						{static const enums::value_type value = enums::value_real;};
template<>			struct value_to_code<Complex>					{static const enums::value_type value = enums::value_complex;};
template<>			struct value_to_code<Object>					{static const enums::value_type value = enums::value_object;};

template<class T>	struct struct_to_code							{};
template<>			struct struct_to_code<struct_dense>				{static const enums::struct_type value = enums::struct_dense;};
template<>			struct struct_to_code<struct_sparse>			{static const enums::struct_type value = enums::struct_sparse;};
template<>			struct struct_to_code<struct_banded>			{static const enums::struct_type value = enums::struct_banded;};
template<>			struct struct_to_code<struct_scalar>			{static const enums::struct_type value = enums::struct_scalar;};

template<enum enums::value_type>	struct code_to_value			{};
template<>			struct code_to_value<enums::value_integer>		{typedef Integer type;};
template<>			struct code_to_value<enums::value_real>			{typedef Real type;};
template<>			struct code_to_value<enums::value_complex>		{typedef Complex type;};
template<>			struct code_to_value<enums::value_object>		{typedef Object type;};

template<enum enums::struct_type>	struct code_to_struct			{};
template<>			struct code_to_struct<enums::struct_dense>		{typedef struct_dense type;};
template<>			struct code_to_struct<enums::struct_sparse>		{typedef struct_sparse type;};
template<>			struct code_to_struct<enums::struct_banded>		{typedef struct_banded type;};
template<>			struct code_to_struct<enums::struct_scalar>		{typedef struct_scalar type;};

};};