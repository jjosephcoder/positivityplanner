/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/matrix_fwd.h"
#include "mmlib/details/refcount.h"

namespace mmlib { namespace details
{
	class matrix_container_base;
	class SubMatrix;
    class SubMatrix_1;
    class SubMatrix_2;
	class matrix_base;

	template<class derived_type,class ret_type>
    class bin_visitor;

	template<class M>
	struct get_functor
	{
		static MMLIB_EXPORT const M& eval(const matrix_base& mat);
		static MMLIB_EXPORT M& eval(matrix_base& mat);
	};
	template<class M>
	struct get_scalar_functor
	{
		static MMLIB_EXPORT M  eval(const matrix_base& mat);
        static MMLIB_EXPORT M& eval(matrix_base& mat);
	};
	template<class T>
	struct constructor_helper
	{
		static MMLIB_EXPORT 
		typename bool eval(const T& val,bool allow_conversions,matrix_base& mat);

	};

	class MMLIB_EXPORT matrix_base
	{
		public:
			typedef details::matrix_container_base	matrix_container;
			union value
			{
                struct mat_info
                {
				    matrix_container*   mat_ptr;					
                    refcount_str*       m_ref;
                }                       m_mat;
				Integer				    val_int;
				Real				    val_real;
				Real				    val_complex[2];
                char                    val_object[sizeof(Object)];
			};
			
			value		    m_value;
			enums::mat_type	m_type;

        public:
            Object& get_object()        
            { 
                return *reinterpret_cast<Object*>(m_value.val_object);
            };
            const Object& get_object() const  
            { 
                return *reinterpret_cast<const Object*>(m_value.val_object);
            };
            
            matrix_base()
            {
            }
            matrix_base(const matrix_base& other)
                :m_type(other.m_type),m_value(other.m_value)
            {
                if (m_type == enums::object_scalar)
                {
                    new (m_value.val_object) Object(other.get_object());
                };
            };
            matrix_base& operator=(const matrix_base& other)
            {
                if (m_type == enums::object_scalar || other.m_type == enums::object_scalar)
                {
                    if (m_type == enums::object_scalar && other.m_type == enums::object_scalar)
                    {
                        get_object() = other.get_object();
                        return *this;
                    };
                    if (m_type == enums::object_scalar)
                    {
                        get_object().~Object();
                        m_type = other.m_type;
                        m_value = other.m_value;
                        return *this;
                    }
                    get_object() = other.get_object();
                    m_type = other.m_type;
                    return *this;
                };

                m_type = other.m_type;
                m_value = other.m_value;
                return *this;
            };
            ~matrix_base()
            {
                if (m_type == enums::object_scalar)
                {
                    get_object().~Object();
                }
            }
            void reset(matrix_base& other)
            {
                m_value = other.m_value;
                m_type = other.m_type;
                other.m_type = enums::integer_scalar;
            };
	};
};


};