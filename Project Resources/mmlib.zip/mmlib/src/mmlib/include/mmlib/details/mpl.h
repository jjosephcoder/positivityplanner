/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/scalar_types.h"

namespace mmlib { namespace details
{

template<bool val>
struct bool_type												{	static const bool value = val;	};

template<bool cond,class T1,class T2> struct select_if			{	typedef T1 type;				};
template<class T1,class T2> struct select_if<false,T1,T2>		{	typedef T2 type;				};

template<bool cond,class T1,class T2> struct lazy_select_if		{	typedef typename T1::type type;	};
template<class T1,class T2> struct lazy_select_if<false,T1,T2>	{	typedef typename T2::type type; };

template<bool cond,class T> struct enable_if					{	typedef T type;					};
template<class T>			struct enable_if<false,T>			{};

template<bool cond,class T>	struct lazy_enable_if				{	typedef typename T::type type;	};
template<class T>			struct lazy_enable_if<false,T>		{};

template<class T1,class T2> struct is_equal						{	static const bool value = false;};
template<class T1>			struct is_equal<T1,T1>				{	static const bool value = true;	};

template<class T>			struct lazy_type					{	typedef T type;					};
template<int val>			struct integer_type					{	static const int value = val;	};

template<class T>	struct promote_scalar						{ };
template<>			struct promote_scalar<bool>					{	typedef Integer		type;		};
template<>			struct promote_scalar<signed char>			{	typedef Integer		type;		};
template<>			struct promote_scalar<unsigned char>		{	typedef Integer		type;		};
template<>			struct promote_scalar<signed short>			{	typedef Integer		type;		};
template<>			struct promote_scalar<unsigned short>		{	typedef Integer		type;		};
template<>			struct promote_scalar<signed int>			{	typedef Integer		type;		};
template<>			struct promote_scalar<unsigned int>			{	typedef Integer		type;		};
template<>			struct promote_scalar<signed long>			{	typedef Integer		type;		};
template<>			struct promote_scalar<unsigned long>		{	typedef Integer		type;		};
template<>			struct promote_scalar<signed long long>		{	typedef Integer		type;		};
template<>			struct promote_scalar<unsigned long long>	{	typedef Integer		type;		};
template<>			struct promote_scalar<Real>					{	typedef Real		type;		};
template<>			struct promote_scalar<float>				{	typedef Real		type;		};
template<>			struct promote_scalar<long double>			{	typedef Real		type;		};
template<>			struct promote_scalar<Complex>				{	typedef Complex		type;		};
template<>			struct promote_scalar<Object>				{	typedef Object		type;		};

template<class T>   struct remove_const                         {   typedef T           type;       };
template<class T>   struct remove_const<const T>                {   typedef T           type;       };

//disable type deduction
template<class T>   struct hide_type                            {   typedef T           type;       };
};};