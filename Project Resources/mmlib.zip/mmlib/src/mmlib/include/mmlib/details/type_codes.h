/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/val_struct_codes.h"
#include "mmlib/details/raw_fwd.h"

namespace mmlib { namespace details
{

namespace utils
{
    typedef mmlib::raw::Matrix<Integer,struct_scalar>    IntegerScalar;
    typedef mmlib::raw::Matrix<Real,struct_scalar>       RealScalar;
    typedef mmlib::raw::Matrix<Complex,struct_scalar>    ComplexScalar;
    typedef mmlib::raw::Matrix<Object,struct_scalar>     ObjectScalar;
};

template<class T>	struct type_to_code								{};
template<>			struct type_to_code<raw::IntegerMatrix>			{static const enums::mat_type value = enums::integer_dense;};
template<>			struct type_to_code<raw::RealMatrix>			{static const enums::mat_type value = enums::real_dense;};
template<>			struct type_to_code<raw::ComplexMatrix>			{static const enums::mat_type value = enums::complex_dense;};
template<>			struct type_to_code<raw::ObjectMatrix>			{static const enums::mat_type value = enums::object_dense;};
template<>			struct type_to_code<raw::IntegerSparseMatrix>	{static const enums::mat_type value = enums::integer_sparse;};
template<>			struct type_to_code<raw::RealSparseMatrix>		{static const enums::mat_type value = enums::real_sparse;};
template<>			struct type_to_code<raw::ComplexSparseMatrix>	{static const enums::mat_type value = enums::complex_sparse;};
template<>			struct type_to_code<raw::ObjectSparseMatrix>	{static const enums::mat_type value = enums::object_sparse;};
template<>			struct type_to_code<raw::IntegerBandMatrix>		{static const enums::mat_type value = enums::integer_band;};
template<>			struct type_to_code<raw::RealBandMatrix>		{static const enums::mat_type value = enums::real_band;};
template<>			struct type_to_code<raw::ComplexBandMatrix>		{static const enums::mat_type value = enums::complex_band;};
template<>			struct type_to_code<raw::ObjectBandMatrix>		{static const enums::mat_type value = enums::object_band;};
template<>			struct type_to_code<utils::IntegerScalar>		{static const enums::mat_type value = enums::integer_scalar;};
template<>			struct type_to_code<utils::RealScalar>			{static const enums::mat_type value = enums::real_scalar;};
template<>			struct type_to_code<utils::ComplexScalar>		{static const enums::mat_type value = enums::complex_scalar;};
template<>			struct type_to_code<utils::ObjectScalar>		{static const enums::mat_type value = enums::object_scalar;};
template<>			struct type_to_code<Integer>					{static const enums::mat_type value = enums::integer_scalar;};
template<>			struct type_to_code<Real>						{static const enums::mat_type value = enums::real_scalar;};
template<>			struct type_to_code<Complex>					{static const enums::mat_type value = enums::complex_scalar;};
template<>			struct type_to_code<Object>					    {static const enums::mat_type value = enums::object_scalar;};

template<enum enums::mat_type>	struct code_to_type					{};
template<>			struct code_to_type<enums::integer_dense>		{typedef raw::IntegerMatrix type;};
template<>			struct code_to_type<enums::real_dense>			{typedef raw::RealMatrix type;};
template<>			struct code_to_type<enums::complex_dense>		{typedef raw::ComplexMatrix type;};
template<>			struct code_to_type<enums::object_dense>		{typedef raw::ObjectMatrix type;};
template<>			struct code_to_type<enums::integer_sparse>		{typedef raw::IntegerSparseMatrix type;};
template<>			struct code_to_type<enums::real_sparse>			{typedef raw::RealSparseMatrix type;};
template<>			struct code_to_type<enums::complex_sparse>		{typedef raw::ComplexSparseMatrix type;};
template<>			struct code_to_type<enums::object_sparse>		{typedef raw::ObjectSparseMatrix type;};
template<>			struct code_to_type<enums::integer_band>		{typedef raw::IntegerBandMatrix type;};
template<>			struct code_to_type<enums::real_band>			{typedef raw::RealBandMatrix type;};
template<>			struct code_to_type<enums::complex_band>		{typedef raw::ComplexBandMatrix type;};
template<>			struct code_to_type<enums::object_band>		    {typedef raw::ObjectBandMatrix type;};
template<>			struct code_to_type<enums::integer_scalar>		{typedef Integer type;};
template<>			struct code_to_type<enums::real_scalar>			{typedef Real type;};
template<>			struct code_to_type<enums::complex_scalar>		{typedef Complex type;};
template<>			struct code_to_type<enums::object_scalar>		{typedef Object type;};

};};

#define macro_first_matrix_type_code enums::integer_dense
#define macro_last_matrix_type_code  enums::object_band

#define macro_first_scalar_type_code enums::integer_scalar
#define macro_last_scalar_type_code  enums::object_scalar

#define MACRO_FOREACH_CODE(macro,arg1,arg2)																	\
	macro(::mmlib::details::code_to_type<::mmlib::enums::integer_dense>::type,arg1,arg2)	\
	macro(::mmlib::details::code_to_type<::mmlib::enums::real_dense>::type,arg1,arg2)		\
	macro(::mmlib::details::code_to_type<::mmlib::enums::complex_dense>::type,arg1,arg2)	\
    macro(::mmlib::details::code_to_type<::mmlib::enums::object_dense>::type,arg1,arg2)	\
	macro(::mmlib::details::code_to_type<::mmlib::enums::integer_sparse>::type,arg1,arg2)	\
	macro(::mmlib::details::code_to_type<::mmlib::enums::real_sparse>::type,arg1,arg2)	\
	macro(::mmlib::details::code_to_type<::mmlib::enums::complex_sparse>::type,arg1,arg2)	\
    macro(::mmlib::details::code_to_type<::mmlib::enums::object_sparse>::type,arg1,arg2)	\
	macro(::mmlib::details::code_to_type<::mmlib::enums::integer_band>::type,arg1,arg2)	\
	macro(::mmlib::details::code_to_type<::mmlib::enums::real_band>::type,arg1,arg2)		\
	macro(::mmlib::details::code_to_type<::mmlib::enums::complex_band>::type,arg1,arg2)   \
    macro(::mmlib::details::code_to_type<::mmlib::enums::object_band>::type,arg1,arg2)
