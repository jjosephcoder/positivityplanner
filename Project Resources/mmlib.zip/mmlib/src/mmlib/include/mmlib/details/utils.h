/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/mpl.h"
#include "mmlib/details/type_codes.h"

namespace mmlib { namespace details
{

template<class S1,class S2,class T>
struct object_or_type
{
	typedef typename details::select_if
		<
			is_equal<S1,Object>::value || is_equal<S2,Object>::value,
			Object,
			T
		>:: type type;
};
template<class S1,class S2,class T>
struct lazy_object_or_type
{
	typedef typename details::select_if
		<
			is_equal<S1,Object>::value || is_equal<S2,Object>::value,
			Object,
            typename T::type
		>:: type type;
};
template<class T1, class T2>
struct max_type
{
	typedef typename select_if
		<
			value_to_code<T1>::value >= value_to_code<T2>::value,
			T1,
			T2
		>:: type type;
};
template<class T1, class T2>
struct min_type
{
	typedef typename select_if
		<
			value_to_code<T1>::value <= value_to_code<T2>::value,
			T1,
			T2
		>:: type type;
};

template<class T1, class T2, class T3>
struct max_type2
{
	typedef typename max_type<typename max_type<T1,T2>::type,T3>::type type;
};
template<class T1, class T2, class T3>
struct min_type2
{
	typedef typename min_type<typename min_type<T1,T2>::type,T3>::type type;
};

template<class T> struct real_type				{};
template<> struct real_type<Integer>			{ typedef Integer type;			};
template<> struct real_type<Real>				{ typedef Real type;			};
template<> struct real_type<Complex>			{ typedef Real type;			};
template<> struct real_type<Object>			    { typedef Object type;			};

};};