/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/config.h"
#include "mmlib/scalar_types.h"
#include <boost/detail/interlocked.hpp>

namespace mmlib 
{

namespace details
{
    struct MMLIB_EXPORT struct_flag_impl
    {
        public:
            enum struct_type
            {
                zero = 0,       id,     diag,       tril,           
                triu,           sym,    her,        unitary,
                qtril,          qtriu,  general
            };

            struct_flag_impl(struct_type t)
                :m_flag(t)
            {};

            struct_type     get() const         { return (struct_type)m_flag; };
            void            set(struct_type t)  { BOOST_INTERLOCKED_EXCHANGE(&m_flag,t); };

        private:
            long            m_flag;
    };
};

class MMLIB_EXPORT struct_flag : public details::struct_flag_impl
{
    private:
        typedef details::struct_flag_impl   base_type;

    public:
        enum value_type
        {
            v_general = 0,  v_zero, v_one,  v_real
        };

    public:
        struct_flag(struct_type type)           :base_type(type) {};
        struct_flag()                           :base_type(general) {};

        struct_type     get() const             { return base_type::get(); };
        void            set(struct_type t)      { base_type::set(t); };
        void            reset(bool z)           { if (!z || !is_zero()) base_type::set(general); };

        void            set_zero_matrix()       { base_type::set(zero);};
        void            set_id_matrix()         { base_type::set(id);  };
        void            set_diag_matrix()       { base_type::set(diag);};
        void            set_tril_matrix()       { base_type::set(tril);};
        void            set_triu_matrix()       { base_type::set(triu);};
        struct_flag&    set_warnings();
        struct_flag&    link_struct(struct_flag other);

        bool            is_general() const      { return base_type::get() == general;};
        bool            is_zero() const         { return base_type::get() == zero;};
        bool            is_id() const           { return base_type::get() == id;};
        bool            is_diag() const;
        bool            is_tril() const         { return base_type::get() == tril;};
        bool            is_triu() const         { return base_type::get() == triu;};
        bool            is_triangular() const   { return is_tril() || is_triu();};
        bool            is_sym() const          { return base_type::get() == sym; };
        bool            is_her() const          { return base_type::get() == her; };

        struct_flag     get_trans() const;
        struct_flag     get_ctrans() const;
        struct_flag     get_tril(Integer d) const;
        struct_flag     get_triu(Integer d) const;
        struct_flag     get_rectangle_view(bool is_square) const;
        struct_flag     get_qtril() const;
        struct_flag     get_qtriu() const;
        struct_flag     get_set_diag(Integer d, value_type vt) const;
        struct_flag     get_scal_mult(value_type vt) const;
        struct_flag     get_unitary() const;
        struct_flag     get_abs() const;
        struct_flag     get_real() const;
        struct_flag     get_conj() const;
        struct_flag     get_resize(bool is_sym) const;

        bool            is_trans_id() const;
        bool            is_ctrans_id() const;
        bool            is_tril_id() const;
        bool            is_triu_id() const;        

        static value_type   get_value_type(Integer val);
        static value_type   get_value_type(Real val);
        static value_type   get_value_type(Complex val);
        static value_type   get_value_type(Object val);        
        static struct_flag  mult_struct(struct_flag f1, struct_flag f2);        
        static struct_flag  dmult_struct(struct_flag f1, struct_flag f2);
        static struct_flag  plus_struct(struct_flag f1, struct_flag f2);
        static struct_flag  minus_struct(struct_flag f1, struct_flag f2);
        static struct_flag  eval_struct(struct_flag f1, bool is_zero_id);

    private:   
        enum op_type { op_mult, op_plus, op_dmult };

        static struct_flag  op_struct(struct_flag f1, struct_flag f2, op_type op);
        static struct_flag  op_struct_zero(struct_flag f2, op_type op);
        static struct_flag  op_struct_id(struct_flag f2, op_type op);
        static struct_flag  op_struct_gen(struct_flag f2, op_type op);
        static struct_flag  op_struct_diag(struct_flag f2, op_type op);
        static struct_flag  op_struct_tril(struct_flag f2, op_type op);
        static struct_flag  op_struct_triu(struct_flag f2, op_type op);
        static struct_flag  op_struct_sym(struct_flag f2, op_type op);
        static struct_flag  op_struct_her(struct_flag f2, op_type op);
        static struct_flag  op_struct_unitary(struct_flag f2, op_type op);
        static struct_flag  op_struct_qtriu(struct_flag f2, op_type op);
        static struct_flag  op_struct_qtril(struct_flag f2, op_type op);
};

};