/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <cfloat>
#include "mmlib/constants.h"

#pragma warning(push)
#pragma warning(disable:4127)   //conditional expression is constant
#include <boost/math/complex/asin.hpp>
#include <boost/math/complex/acos.hpp>
#include <boost/math/complex/atan.hpp>
#include <boost/math/complex/asinh.hpp>
#include <boost/math/complex/acosh.hpp>
#include <boost/math/complex/atanh.hpp>
#include <boost/math/tr1.hpp>
#pragma warning(pop)

namespace mmlib { namespace raw { namespace details
{

namespace gd = mmlib::details;

namespace scal_func
{
	inline bool isnan(double x)
	{
		return (::_isnan(x)) ? 1 : 0;
	};
	inline bool isnan(const Complex &x)
	{
		return scal_func::isnan(real(x)) || scal_func::isnan(imag(x));
	}
	inline bool isnan(const Object &x)
	{
        return mmlib::object_func::isnan(x);
	}
	inline bool finite(double x)
	{
		return (::_finite(x)) ? 1 : 0;
	};
	inline bool finite(const Complex &x)
	{
		return scal_func::finite(real(x)) && scal_func::finite(imag(x));
	};
	inline bool finite(const Object &x)
	{
        return mmlib::object_func::finite(x);
	}

	inline bool isinf(double x)
	{
	    return (scal_func::isnan(x) || scal_func::finite(x)) ? 0 : 1;
	};
	inline bool isinf(const Complex &x)
	{
		return (scal_func::isinf(real(x)) || scal_func::isinf(imag(x))) ? 1 : 0;
	};
	inline bool isinf(const Object &x)
	{
        return mmlib::object_func::isinf(x);
	}

	inline double sign(double a)
	{
		if (scal_func::isnan(a)) return a;
		if (a > 0) return 1.;
		if (a < 0) return -1.;
		return 0;
	};
	inline long int sign(long int a)
	{
		if (a > 0) return 1;
		if (a < 0) return -1;
		return 0;
	};
    inline Real abs(const Complex& arg)		
	{	
	    //std::abs(Inf+i*NaN) = Inf 
	    if (scal_func::isnan(arg))
	    {
		    return constants::NaN;
	    };
	    return std::abs(arg.value);	
    };
	inline Complex sign(const Complex &a) 
	{
        return mmlib::complex::eeq_c(a , 0.) ? 0 
            : mmlib::complex::div_c(a , scal_func::abs(a));
	};


	inline double arg(double a)
	{
		if (scal_func::isnan(a)) return a;
		return (a >= 0.) ? 0. : constants::pi;
	}
	inline double arg(const Complex &a) 
	{ 
		return std::arg(a.value); 
	};
	inline double angle(double a) 
	{ 
		return scal_func::arg(a); 
	}
	inline double angle(const Complex &a) 
	{ 
		return scal_func::arg(a); 
	};

	inline double pow2(double a) 
	{ 
		return std::pow(2., a); 
	};
	inline Complex pow2(const Complex &a) 
	{ 
		return Complex(std::pow(2., a.value)); 
	};
    inline Complex log(const Complex& arg)		
    {	
        return Complex(std::log(arg.value));
    };
	inline double log2(double a) 
	{ 
		return std::log(a) * constants::log2e; 
	};
	inline Complex log2(const Complex &a)
	{
        return mmlib::complex::mul_c(scal_func::log(a) , constants::log2e);
	};
    inline double log1p(const double& arg)		
    {	
        return boost::math::tr1::log1p(arg);
    };
    inline Complex log1p(const Complex& arg)		
    {	
        return scal_func::log(mmlib::complex::plus_c(1.,arg));
    };
    inline Complex tan(const Complex& arg)		
    {	
        return Complex(std::tan(arg.value));
    };
	inline double cot(double x)
	{
		return 1. / ::tan(x);
	};
	inline Complex cot(const Complex &x) 
	{ 
        return mmlib::complex::inv_c(scal_func::tan(x)); 
	};
    inline Complex cos(const Complex& arg)		
    {	
        return Complex(std::cos(arg.value));
    };
	inline double sec(double x) 
	{ 
		return 1. / ::cos(x); 
	};
	inline Complex sec(const Complex &x) 
	{ 
        return mmlib::complex::inv_c(scal_func::cos(x));
	};
    inline Complex sin(const Complex& arg)		
    {	
        return Complex(std::sin(arg.value));
    };
	inline double csc(double x) 
	{ 
		return 1. / ::sin(x); 
	};
	inline Complex csc(const Complex &x) 
	{ 
        return mmlib::complex::inv_c(scal_func::sin(x));
	};
	inline double asin(double cm)
	{
		return std::asin(cm);
	};
    inline Complex sqrt(const Complex& arg)		
    {	
        return Complex(std::sqrt(arg.value));
    };
	inline Complex asin(const Complex &cm)
	{     
        std::complex<double> tmp(real(cm),imag(cm));
        std::complex<double> ret = boost::math::asin(tmp);
        return Complex(real(ret),imag(ret));
	};
	inline double acosh(double x)
	{
        return boost::math::tr1::acosh(x);
	};
	inline Complex acosh(const Complex &cm)
	{
        std::complex<double> tmp(real(cm),imag(cm));
        std::complex<double> ret = boost::math::acosh(tmp);
        return Complex(real(ret),imag(ret));
	};

	inline double acos(double cm)
	{
		return std::acos(cm);
	};
	inline Complex acos(const Complex &cm)
	{
        std::complex<double> tmp(real(cm),imag(cm));
        std::complex<double> ret = boost::math::acos(tmp);
        return Complex(real(ret),imag(ret));
	};
	inline double atan(double x)
	{
		return ::atan(x);
	};

	inline Complex atan(const Complex &cm)
	{
        std::complex<double> tmp(real(cm),imag(cm));
        std::complex<double> ret = boost::math::atan(tmp);
        return Complex(real(ret),imag(ret));
	};
	inline double acot(double x) 
	{ 
        return scal_func::atan(1./x);
	};
	inline Complex acot(const Complex &x)
	{
        Complex tmp = mmlib::complex::div_c(1.,x);
        return scal_func::atan(tmp);
	};
	inline double asec(double x) 
	{ 
		return ::acos(1./x); 
	};
	inline Complex asec(const Complex &x) 
	{ 
        return scal_func::acos(mmlib::complex::inv_c(x)); 
	};
	inline double acsc(double x) 
	{ 
		return ::asin(1./x); 
	};
	inline Complex acsc(const Complex &x) 
	{ 
        return scal_func::asin(mmlib::complex::inv_c(x)); 
	};
    inline Complex tanh(const Complex& arg)		
    {	
        return Complex(std::tanh(arg.value));
    };
	inline double coth(double x) 
	{ 
		return 1./::tanh(x); 
	};
	inline Complex coth(const Complex &x) 
	{ 
        return mmlib::complex::inv_c(scal_func::tanh(x)); 
	};
    inline Complex cosh(const Complex& arg)		
    {	
        if (imag(arg) == 0.)
        {
            return std::cosh(real(arg));
        };
        return Complex(std::cosh(arg.value));
    };
	inline double sech(double x) 
	{ 
		return 1. / ::cosh(x); 
	};
	inline Complex sech(const Complex &x) 
	{ 
        return mmlib::complex::inv_c(scal_func::cosh(x)); 
	}
    inline Complex sinh(const Complex& arg)		
    {	
        return Complex(std::sinh(arg.value));
    };
	inline double csch(double x) 
	{ 
		return 1./::sinh(x); 
	}
	inline Complex csch(const Complex &x) 
	{ 
        return mmlib::complex::inv_c(scal_func::sinh(x)); 
	}
	inline double asinh(double x)
	{
        return boost::math::tr1::asinh(x);
	}
	inline Complex asinh(const Complex &cm)
	{
        std::complex<double> tmp(real(cm),imag(cm));
        std::complex<double> ret = boost::math::asinh(tmp);
        return Complex(real(ret),imag(ret));
	}
	inline double atanh(double x)
	{
        return boost::math::tr1::atanh(x);
	}
	inline Complex atanh(const Complex &cm)
	{
        std::complex<double> tmp(real(cm),imag(cm));
        std::complex<double> ret = boost::math::atanh(tmp);
        return Complex(real(ret),imag(ret));
	}
	inline double acoth(double x)
	{
        return scal_func::atanh(1./x);
	}
	inline Complex acoth(const Complex &x)
	{
        Complex tmp1 = mmlib::complex::div_c(1.,x);
        return scal_func::atanh(tmp1);        
	}
	inline double asech(double x) 
	{ 
		return scal_func::acosh(1. / x); 
	}
	inline Complex asech(const Complex &x)
	{
        return scal_func::acosh(mmlib::complex::inv_c(x));
	}
	inline double acsch(double x) 
	{ 
		return scal_func::asinh(1. / x); 
	}
	inline Complex acsch(const Complex &x)
	{
        return scal_func::asinh(mmlib::complex::inv_c(x));
	}

	inline double floor(double a) 
	{
		return ::floor(a);
	}

	inline Complex floor(const Complex &a)
	{
        return Complex(::floor(mmlib::complex::real(a)), ::floor(mmlib::complex::imag(a)));
	}

	inline double ceil(double a) 
	{
		return ::ceil(a);
	}
	inline Complex ceil(const Complex &a)
	{
		return Complex(scal_func::ceil(mmlib::complex::real(a)),scal_func::ceil(mmlib::complex::imag(a)));
	}

	inline double trunc(double a) 
	{
		if (!scal_func::finite(a)) return a;
		return (a >= 0) ? scal_func::floor(a) : ::ceil(a);
	}
	inline Complex trunc(const Complex &a)
	{
		return Complex(scal_func::trunc(mmlib::complex::real(a)),scal_func::trunc(mmlib::complex::imag(a)));
	}

	inline double round(double a) 
	{ 
		return (scal_func::floor(a) + .5 >= a) ? scal_func::floor(a) : ::ceil(a);
	}
	inline Complex round(const Complex &a)
	{
		return Complex(scal_func::round(mmlib::complex::real(a)), scal_func::round(mmlib::complex::imag(a)));
	}
	inline double fix(double a) 
	{
		return scal_func::trunc(a);
	}
	inline Complex fix(const Complex &a)
	{
		return scal_func::trunc(a);
	}

};

template<class T>
struct isinf_helper
{
	static bool eval(gd::type_info ,T arg)	
    { 
        return scal_func::isinf(arg);		
    };
};
template<>
struct isinf_helper<Integer>					
{
	static bool eval(gd::type_info ,Integer)	
    { 
        return false; 
    };
};

template<class T>
struct isnan_helper
{
    static bool eval(gd::type_info ,T arg)	
    { 
        return scal_func::isnan(arg); 
    };
};
template<>
struct isnan_helper<Integer>					
{
	static bool eval(gd::type_info ,Integer )	
    { 
        return false; 
    };
};


template<class T>
struct real_helper	
{
	static T eval(gd::type_info ,T arg)		
    {	
        return arg;	
    };
};
template<>
struct real_helper<Complex>
{
	static Real eval(gd::type_info ,const Complex& arg)		
    {	
        return mmlib::complex::real(arg);	
    };
};
template<>
struct real_helper<Object>
{
	static Object eval(gd::type_info ,const Object& arg)		
    {	
        return object_func::real(arg);	
    };
};

template<class T>
struct imag_helper
{
	static T eval(gd::type_info ,T )							
    {	
        return T();	
    };
};
template<>
struct imag_helper<Complex>
{
	static Real eval(gd::type_info ,const Complex& arg)		
    {	
        return mmlib::complex::imag(arg);	
    };
};
template<>
struct imag_helper<Object>
{
	static Object eval(gd::type_info ,const Object& arg)		
    {	
        return object_func::imag(arg);	
    };
};
template<class T>
struct conj_helper
{
	static T eval(gd::type_info ,T arg)						
    {	
        return arg;	
    };
};
template<>
struct conj_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)		
    {	
        return Complex(std::conj(arg.value));
    };
};
template<>
struct conj_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)		
    {	
        return object_func::conj(arg);
    };
};

template<class T>
struct arg_helper
{
	static Real eval(gd::type_info ,T arg)	
    {	
        return scal_func::arg(arg);		
    };
};
template<>
struct arg_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::arg(arg);
    };
};


template<class T>
struct abs_helper
{
	static T eval(gd::type_info ,T arg)	
    {	
        return ::abs(arg);	
    };
};
template<>
struct abs_helper<Complex>
{
    static Real eval(gd::type_info ,const Complex& arg)
    {  
        return	scal_func::abs(arg); 
    };
};
template<>
struct abs_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::abs(arg);
    };
};

template<class T>
struct angle_helper
{
	static Real eval(gd::type_info ,T arg)	
    {	
        return scal_func::angle(arg);	
    };
};
template<>
struct angle_helper<Complex>
{
	static Real eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::angle(arg);	
    };
};
template<>
struct angle_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::angle(arg);
    };
};

template<class T>
struct isfinite_helper
{
	static bool eval(gd::type_info ,T arg)	
    { 
        return scal_func::finite(arg); 
    };
};
template<>
struct isfinite_helper<Integer>		
{
	static bool eval(gd::type_info ,Integer)	
    { 
        return true; 
    };
};
template<>
struct isfinite_helper<Object>
{
    static bool eval(gd::type_info ,const Object& arg)
    {	
        return object_func::isfinite(arg);
    };
};

template<class T>
struct sqrt_helper
{
	static Real eval(gd::type_info ,Real arg)		
    {  
        return std::sqrt(arg);	
    };
};
template<>
struct sqrt_helper<Complex>
{
    static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::sqrt(arg);
    };
};
template<>
struct sqrt_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::sqrt(arg);
    };
};

template<class T>
struct pow2_helper
{
	static Real eval(gd::type_info ,Real arg)			
    {	
        return scal_func::pow2(arg);	
    };
};
template<>
struct pow2_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::pow2(arg);	
    };
};
template<>
struct pow2_helper<Object>
{
	static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::pow2(arg);	
    };
};

template<class T>
struct log_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return ::log(arg);	
    };
};
template<>
struct log_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)	
    {	
        return scal_func::log(arg);
    };
};
template<>
struct log_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::log(arg);
    };
};

template<class T>
struct cos_helper
{
	static Real eval(gd::type_info ,Real arg)	
    {	
        return ::cos(arg);	
    };
};
template<>
struct cos_helper<Complex>
{
    static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::cos(arg);
    };
};
template<>
struct cos_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)	
    {	
        return object_func::cos(arg);
    };
};

template<class T>
struct sin_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return ::sin(arg);	
    };
};
template<>
struct sin_helper<Complex>
{
    static Complex eval(gd::type_info ,const Complex& arg)		
    {	
        return scal_func::sin(arg);
    };
};
template<>
struct sin_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::sin(arg);
    };
};

template<class T>
struct exp_helper
{
	static Real eval(gd::type_info ,Real arg)		
    {	
        return ::exp(arg);	
    };
};
template<>
struct exp_helper<Complex>
{
	static Complex eval(gd::type_info ti,const Complex& arg)		
    {	
	    Real re         = real(arg);
        Real im         = imag(arg);
        re              = exp(re);
        Real out_re     = re*cos_helper<Real>::eval(ti,im);
        Real out_im     = re*sin_helper<Real>::eval(ti,im);
        return Complex(out_re,out_im);
    };
};
template<>
struct exp_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)	
    {	
        return object_func::exp(arg);
    };
};

template<class T>
struct log2_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::log2(arg);	
    };
};
template<>
struct log2_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::log2(arg);	
    };
};
template<>
struct log2_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::log2(arg);
    };
};

template<class T>
struct log10_helper	
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return ::log10(arg);	
    };
};
template<>
struct log10_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return Complex(std::log10(arg.value));
    };
};
template<>
struct log10_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::log10(arg);
    };
};

template<class T>
struct tan_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return ::tan(arg);	
    };
};
template<>
struct tan_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::tan(arg);
    };
};
template<>
struct tan_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)	
    {	
        return object_func::tan(arg);
    };
};

template<class T>
struct cot_helper
{
	static Real eval(gd::type_info ,Real arg)	
    {	
        return scal_func::cot(arg);	
    };
};
template<>
struct cot_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::cot(arg);	
    };
};
template<>
struct cot_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::cot(arg);
    };
};

template<class T>
struct sec_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::sec(arg);	
    };
};
template<>
struct sec_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::sec(arg);	
    };
};
template<>
struct sec_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::sec(arg);
    };
};

template<class T>
struct csc_helper
{
	static Real eval(gd::type_info ,Real arg)	
    {	
        return scal_func::csc(arg);	
    };
};
template<>
struct csc_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::csc(arg);	
    };
};
template<>
struct csc_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::csc(arg);
    };
};

template<class T>
struct asin_helper
{
	static Real eval(gd::type_info ,Real arg)	
    {	
        return scal_func::asin(arg);	
    };
};
template<>
struct asin_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::asin(arg);	
    };
};
template<>
struct asin_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::asin(arg);
    };
};

template<class T>
struct acos_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::acos(arg);	
    };
};
template<>
struct acos_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)	
    {	
        return scal_func::acos(arg);	
    };
};
template<>
struct acos_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::acos(arg);
    };
};
template<class T>
struct atan_helper
{
	static Real eval(gd::type_info ,Real arg)	
    {	
        return scal_func::atan(arg);	
    };
};
template<>
struct atan_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::atan(arg);	
    };
};
template<>
struct atan_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::atan(arg);
    };
};
template<class T>
struct acot_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::acot(arg);	
    };
};
template<>
struct acot_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)	
    {	
        return scal_func::acot(arg);	
    };
};
template<>
struct acot_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)	
    {	
        return object_func::acot(arg);
    };
};
template<class T>
struct asec_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::asec(arg);	
    };
};
template<>
struct asec_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::asec(arg);	
    };
};
template<>
struct asec_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::asec(arg);
    };
};
template<class T>
struct acsc_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::acsc(arg);	
    };
};
template<>
struct acsc_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::acsc(arg);	
    };
};
template<>
struct acsc_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::acsc(arg);
    };
};
template<class T>
struct sinh_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return std::sinh(arg);	
    };
};
template<>
struct sinh_helper<Complex>
{
    static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::sinh(arg);
    };
};
template<>
struct sinh_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::sinh(arg);
    };
};
template<class T>
struct cosh_helper
{
	static Real eval(gd::type_info ,Real arg)		
    {	
        return std::cosh(arg);	
    };
};
template<>
struct cosh_helper<Complex>
{
    static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::cosh(arg);
    };
};
template<>
struct cosh_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::cosh(arg);
    };
};
template<class T>
struct tanh_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return std::tanh(arg);	
    };
};
template<>
struct tanh_helper<Complex>
{
    static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::tanh(arg);
    };
};
template<>
struct tanh_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::tanh(arg);
    };
};
template<class T>
struct coth_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::coth(arg);	
    };
};
template<>
struct coth_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::coth(arg);	
    };
};
template<>
struct coth_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::coth(arg);
    };
};
template<class T>
struct sech_helper
{
	static Real eval(gd::type_info ,Real arg)	
    {	
        return scal_func::sech(arg);	
    };
};
template<>
struct sech_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::sech(arg);	
    };
};
template<>
struct sech_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::sech(arg);
    };
};
template<class T>
struct csch_helper
{
	static Real eval(gd::type_info ,Real arg)	
    {	
        return scal_func::csch(arg);	
    };
};
template<>
struct csch_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)	
    {	
        return scal_func::csch(arg);	
    };
};
template<>
struct csch_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)	
    {	
        return object_func::csch(arg);
    };
};
template<class T>
struct asinh_helper
{
	static Real eval(gd::type_info ,Real arg)		
    {	
        return scal_func::asinh(arg);	
    };
};
template<>
struct asinh_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)	
    {	
        return scal_func::asinh(arg);	
    };
};
template<>
struct asinh_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::asinh(arg);
    };
};
template<class T>
struct acosh_helper
{
	static Real eval(gd::type_info ,Real arg)	
    {	
        return scal_func::acosh(arg);	
    };
};
template<>
struct acosh_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::acosh(arg);	
    };
};
template<>
struct acosh_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::acosh(arg);
    };
};
template<class T>
struct atanh_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::atanh(arg);	
    };
};
template<>
struct atanh_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::atanh(arg);	
    };
};
template<>
struct atanh_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)	
    {	
        return object_func::atanh(arg);
    };
};
template<class T>
struct acoth_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::acoth(arg);	
    };
};
template<>
struct acoth_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::acoth(arg);	
    };
};
template<>
struct acoth_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::acoth(arg);
    };
};
template<class T>
struct asech_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::asech(arg);	
    };
};
template<>
struct asech_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)	
    {	
        return scal_func::asech(arg);	
    };
};
template<>
struct asech_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::asech(arg);
    };
};
template<class T>
struct acsch_helper
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::acsch(arg);	
    };
};
template<>
struct acsch_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::acsch(arg);	
    };
};
template<>
struct acsch_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::acsch(arg);
    };
};

template<class T> 
struct floor_helper	 {};
template<> 
struct floor_helper<Integer>
{
	static Integer eval(gd::type_info ,Integer arg)
    {	
        return arg;	
    };
};
template<> 
struct floor_helper<Real>
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::floor(arg);	
    };
};
template<> 
struct floor_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::floor(arg);	
    };
};
template<> 
struct floor_helper<Object>
{
	static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::floor(arg);	
    };
};

template<class T> 
struct ceil_helper	 {};
template<> 
struct ceil_helper<Integer>
{
	static Integer eval(gd::type_info ,Integer arg)
    {	
        return arg;	
    };
};
template<> 
struct ceil_helper<Real>
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::ceil(arg);	
    };
};
template<> 
struct ceil_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::ceil(arg);	
    };
};
template<>
struct ceil_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::ceil(arg);
    };
};
template<class T> 
struct round_helper	 {};
template<> 
struct round_helper<Integer>
{
	static Integer eval(gd::type_info ,Integer arg)
    {	
        return arg;	
    };
};
template<> 
struct round_helper<Real>
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::round(arg);	
    };
};
template<> 
struct round_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::round(arg);	
    };
};
template<>
struct round_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)	
    {	
        return object_func::round(arg);
    };
};
template<class T> 
struct fix_helper	 {};
template<> struct fix_helper<Integer>
{
	static Integer eval(gd::type_info ,Integer arg)	
    {	
        return arg;	
    };
};
template<> struct fix_helper<Real>
{
	static Real eval(gd::type_info ,Real arg)	
    {	
        return scal_func::fix(arg);	
    };
};
template<> struct fix_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::fix(arg);	
    };
};
template<> struct fix_helper<Object>
{
	static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::fix(arg);	
    };
};

template<class T> 
struct trunc_helper	 {};
template<> 
struct trunc_helper<Integer>
{
	static Integer eval(gd::type_info ,Integer arg)
    {	
        return arg;	
    };
};
template<> 
struct trunc_helper<Real>
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::trunc(arg);	
    };
};
template<> 
struct trunc_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::trunc(arg);	
    };
};
template<>
struct trunc_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::trunc(arg);
    };
};
template<class T> 
struct sign_helper	 {};
template<> 
struct sign_helper<Integer>
{
	static Integer eval(gd::type_info ,Integer arg)
    {	
        return scal_func::sign(arg);	
    };
};
template<> 
struct sign_helper<Real>
{
	static Real eval(gd::type_info ,Real arg)
    {	
        return scal_func::sign(arg);	
    };
};
template<> 
struct sign_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& arg)
    {	
        return scal_func::sign(arg);	
    };
};
template<>
struct sign_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    {	
        return object_func::sign(arg);
    };
};
template<class T>
struct ifloor_helper
{
	static Integer eval(gd::type_info ti,T arg)	
    {	
        return (Integer)floor_helper<T>::eval(ti,arg);	
    };
};
template<>
struct ifloor_helper<Complex>
{
	static Integer eval(gd::type_info ti,const Complex& arg)		
    {	
        return (Integer)mmlib::complex::real(floor_helper<Complex>::eval(ti,arg));	
    };
};
template<>
struct ifloor_helper<Object>
{
    static Integer eval(gd::type_info ,const Object& arg)		
    {	
        return object_func::ifloor(arg);
    };
};
template<class T>
struct iceil_helper
{
	static Integer eval(gd::type_info ti,T arg)
    {	
        return (Integer)ceil_helper<T>::eval(ti,arg);	
    };
};
template<>
struct iceil_helper<Complex>
{
	static Integer eval(gd::type_info ti,const Complex& arg)	
    {	
        return (Integer)mmlib::complex::real(ceil_helper<Complex>::eval(ti,arg));	
    };
};
template<>
struct iceil_helper<Object>
{
    static Integer eval(gd::type_info ,const Object& arg)
    {	
        return object_func::iceil(arg);
    };
};
template<class T>
struct iround_helper
{
	static Integer eval(gd::type_info ti,T arg)		
    {	
        return (Integer)round_helper<T>::eval(ti,arg);	
    };
};
template<>
struct iround_helper<Complex>
{
	static Integer eval(gd::type_info ti,const Complex& arg)	
    {	
        return (Integer)mmlib::complex::real(round_helper<Complex>::eval(ti,arg));	
    };
};
template<>
struct iround_helper<Object>
{
    static Integer eval(gd::type_info ,const Object& arg)
    {	
        return object_func::iround(arg);
    };
};
template<class T>
struct ifix_helper
{
	static Integer eval(gd::type_info ti,T arg)	
    {	
        return (Integer)fix_helper<T>::eval(ti,arg);	
    };
};
template<>
struct ifix_helper<Complex>
{
	static Integer eval(gd::type_info ti,const Complex& arg)	
    {	
        return (Integer)mmlib::complex::real(fix_helper<Complex>::eval(ti,arg));	
    };
};
template<>
struct ifix_helper<Object>
{
    static Integer eval(gd::type_info ,const Object& arg)
    {	
        return object_func::ifix(arg);
    };
};
template<class T>
struct itrunc_helper
{
	static Integer eval(gd::type_info ti,T arg)
    {	
        return (Integer)trunc_helper<T>::eval(ti,arg);	
    };
};
template<>
struct itrunc_helper<Complex>
{
	static Integer eval(gd::type_info ti,const Complex& arg)
    {	
        return (Integer)mmlib::complex::real(trunc_helper<Complex>::eval(ti,arg));	
    };
};
template<>
struct itrunc_helper<Object>
{
    static Integer eval(gd::type_info ,const Object& arg)
    {	
        return object_func::itrunc(arg);
    };
};
template<class T>
struct isign_helper
{
	static Integer eval(gd::type_info ti,T arg)	
    {	
        return (Integer)sign_helper<T>::eval(ti,arg);	
    };
};
template<>
struct isign_helper<Complex>
{
	static Integer eval(gd::type_info ti,const Complex& arg)
    {	
        return (Integer)mmlib::complex::real(sign_helper<Complex>::eval(ti,arg));	
    };
};
template<>
struct isign_helper<Object>
{
    static Integer eval(gd::type_info ,const Object& arg)
    {	
        return object_func::isign(arg);
    };
};
template<class T>
struct uminus_helper
{
	static T eval(gd::type_info ,T val)
    { 
        return -val; 
    };
};
template<>
struct uminus_helper<Complex>
{
	static Complex eval(gd::type_info ,const Complex& val)
    { 
        return mmlib::complex::uminus_c(val); 
    };
};
template<>
struct uminus_helper<Object>
{
    static Object eval(gd::type_info ,const Object& arg)
    { 
        return -arg; 
    };
};
template<class T>
struct op_neg_helper
{
	static bool eval(gd::type_info ,T val)
    { 
        return (val == T())? true : false; 
    };
};
template<>
struct op_neg_helper<Complex>
{
    static bool eval(gd::type_info ti,const Complex& val)		
    { 
        return op_neg_helper<Real>::eval(ti,mmlib::complex::real(val)) 
		                && op_neg_helper<Real>::eval(ti,mmlib::complex::imag(val)); 
    };
};
template<>
struct op_neg_helper<Object>
{
    static bool eval(gd::type_info ,const Object& val)
    {
        return !val.is_true(); 
    };
};
template<class T>
struct is_true_helper
{
	static bool eval(gd::type_info ,T val)		
    { 
        return (val == T())? false : true; 
    };
};
template<>
struct is_true_helper<Complex>
{
	static bool eval(gd::type_info ti,const Complex& val)	
    {
        return is_true_helper<Real>::eval(ti,mmlib::complex::real(val)) 
                    || is_true_helper<Real>::eval(ti,mmlib::complex::imag(val)); 
    };
};
template<>
struct is_true_helper<Object>
{
    static bool eval(gd::type_info ,const Object& val)	
    { 
        return val.is_true(); 
    };
};
template<class T>
struct is_false_helper
{
	static bool eval(gd::type_info ,T val)	
    { 
        return (val == T())? true : false; 
    };
};
template<>
struct is_false_helper<Complex>
{
	static bool eval(gd::type_info ti,const Complex& val)		
    {
        return is_false_helper<Real>::eval(ti,mmlib::complex::real(val)) 
		                && is_false_helper<Real>::eval(ti,mmlib::complex::imag(val)); 
    };
};
template<>
struct is_false_helper<Object>
{
    static bool eval(gd::type_info ,const Object& val)		  
    {
        return !val.is_true(); 
    };
};

}}}