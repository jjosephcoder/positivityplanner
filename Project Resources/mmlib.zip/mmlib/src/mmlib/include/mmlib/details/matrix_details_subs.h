/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/matrix.h"
#include "mmlib/details/isa.h"
#include "mmlib/details/extract_type.h" 
#include "mmlib/details/assign_visitor.h" 

namespace mmlib { namespace details
{
    class implementation_access;

	class MMLIB_EXPORT SubMatrix
	{
		private:
			Matrix*					m_matrix;
			const colon*	        m_colon_1;
			const colon*	        m_colon_2;
            Integer                 m_d;

		private:
			SubMatrix(Matrix* m, const colon& c1);
			SubMatrix(Matrix* m, const colon& c1, const colon& c2);
            SubMatrix(Integer diag, Matrix* m);

			template<class S>
			Matrix& assign_scalar(S val) const;

		public:		
			Matrix to_matrix() const;

			template<class S>
			typename details::enable_if<details::is_scalar<S>::value,Matrix&>::type
			operator=(S) const;

			Matrix& operator=(const Matrix&) const;
			Matrix& operator=(const SubMatrix&) const;
            Matrix& operator=(const SubMatrix_1&) const;
            Matrix& operator=(const SubMatrix_2&) const;

		private:
            SubMatrix(){};
            SubMatrix*  clone();
            void        destroy();

            SubMatrix(const SubMatrix& m);

			friend Matrix;
            friend mmlib::details::implementation_access;
	};
	class MMLIB_EXPORT SubMatrix_1
	{
		private:
			Matrix*					m_matrix;
			Integer			        m_ind_1;

		private:
			SubMatrix_1(Matrix* m, Integer i);

			template<class S>
			Matrix& assign_scalar(S val) const;

		public:		
			Matrix to_matrix() const;

			template<class S>
			typename details::enable_if<details::is_scalar<S>::value,Matrix&>::type
			operator=(S) const  throw();

			Matrix& operator=(const Matrix&) const;
			Matrix& operator=(const SubMatrix&) const  throw();
            Matrix& operator=(const SubMatrix_1&) const  throw();
            Matrix& operator=(const SubMatrix_2&) const  throw();

		private:
            SubMatrix_1(){} ;
            SubMatrix_1*    clone();
            void            destroy();

            SubMatrix_1(const SubMatrix_1& m) throw();

			friend Matrix;
            friend mmlib::details::implementation_access;
	};
	class MMLIB_EXPORT SubMatrix_2
	{
		private:
			Matrix*					m_matrix;
			Integer			        m_ind_1;
            Integer			        m_ind_2;

		private:
			SubMatrix_2(Matrix* m, Integer i, Integer j);

			template<class S>
			Matrix& assign_scalar(S val) const;

		public:		
			Matrix to_matrix() const;

			template<class S>
			typename details::enable_if<details::is_scalar<S>::value,Matrix&>::type
			operator=(S) const;

			Matrix& operator=(const Matrix&) const;
			Matrix& operator=(const SubMatrix&) const;
            Matrix& operator=(const SubMatrix_1&) const;
            Matrix& operator=(const SubMatrix_2&) const;

		private:
            SubMatrix_2*    clone();
            void            destroy();

            SubMatrix_2(const SubMatrix_2& m);

			friend Matrix;
            friend mmlib::details::implementation_access;
	};
};

inline mmlib::details::SubMatrix::SubMatrix(const SubMatrix& m)
:m_matrix(m.m_matrix),m_colon_1(m.m_colon_1),m_colon_2(m.m_colon_2),m_d(m.m_d)
{
};
inline mmlib::details::SubMatrix_1::SubMatrix_1(const SubMatrix_1& m)
:m_matrix(m.m_matrix),m_ind_1(m.m_ind_1)
{
};
inline mmlib::details::SubMatrix_2::SubMatrix_2(const SubMatrix_2& m)
:m_matrix(m.m_matrix),m_ind_1(m.m_ind_1),m_ind_2(m.m_ind_2)
{
};
inline mmlib::details::SubMatrix_1::SubMatrix_1(Matrix* m, Integer i)						
	:m_matrix(m),m_ind_1(i)
{
};
inline mmlib::details::SubMatrix_2::SubMatrix_2(Matrix* m, Integer i, Integer j)			
	:m_matrix(m),m_ind_1(i),m_ind_2(j)
{
};
inline mmlib::details::SubMatrix::SubMatrix(Matrix* m, const colon& c1)				
	:m_matrix(m), m_colon_1(&c1),m_colon_2(NULL),m_d(0)
{
};
inline mmlib::details::SubMatrix::SubMatrix(Matrix* m, const colon& c1, const colon& c2)
	:m_matrix(m), m_colon_1(&c1),m_colon_2(&c2),m_d(0)
{
};
inline mmlib::details::SubMatrix::SubMatrix(Integer d, Matrix* m)
	:m_matrix(m), m_colon_1(NULL),m_colon_2(NULL),m_d(d)
{
};

namespace details
{
struct assign_scal_1_functor : public details::extract_type_2<Matrix&,assign_scal_1_functor,false>
{
    template<class T, class S>
    static Matrix& eval(Matrix& handle, T& mat,Integer ind, S val)
    {
        return details::assign_functor<T,S>::eval(handle,mat,val,ind);
    };
    template<class T, class S>
    static Matrix& eval_scalar(Matrix& handle, T& ,Integer ind, S val)
    {
        return details::assign_functor_scal<T,S>::eval(handle,val,ind);
    };
};

struct assign_scal_2_functor : public details::extract_type_3<Matrix&,assign_scal_2_functor,false>
{
    template<class T, class S>
    static Matrix& eval(Matrix& handle, T& mat,Integer ind1, Integer ind2, S val)
    {
        return details::assign_functor<T,S>::eval(handle,mat,val,ind1,ind2);
    };
    template<class T, class S>
    static Matrix& eval_scalar(Matrix& handle, T& ,Integer ind1,Integer ind2, S val)
    {
        return details::assign_functor_scal<T,S>::eval(handle,val,ind1,ind2);
    };
};

struct assign_scal_3_functor : public details::extract_type_2<Matrix&,assign_scal_3_functor,false>
{
    template<class T, class S>
    static Matrix& eval(Matrix& handle, T& mat,const colon& c1, S val)
    {
        return details::assign_functor<T,S>::eval(handle,mat,val,c1);
    };

    template<class T, class S>
    static Matrix& eval_scalar(Matrix& handle, T& , const colon& c1, S val)
    {
        return details::assign_functor_scal<T,S>::eval(handle,val,c1);
    };
};
struct assign_scal_4_functor : public details::extract_type_3<Matrix&,assign_scal_4_functor,false>
{
    template<class T, class S>
    static Matrix& eval(Matrix& handle, T& mat,const colon& c1,const colon& c2, S val)
    {
        return details::assign_functor<T,S>::eval(handle,mat,val,c1,c2);
    };
    template<class T, class S>
    static Matrix& eval_scalar(Matrix& handle, T& , const colon& c1, const colon& c2, S val)
    {
        return details::assign_functor_scal<T,S>::eval(handle,val,c1,c2);
    };
};
struct assign_diag_functor : public details::extract_type_2<Matrix&,assign_diag_functor,false>
{
    template<class T, class S>
    static Matrix& eval(Matrix& handle, T& mat,Integer d, S val)
    {
        return details::assign_functor<T,S>::eval_diag(handle,mat,val,d);
    };
    template<class T, class S>
    static Matrix& eval_scalar(Matrix& handle, T&, Integer d, S val)
    {
        if (d != 0)
        {
            throw error::error_diag(d, 1, 1);
        };
        handle = val;
        return handle;
    };
};
};

template<class S>
inline Matrix& details::SubMatrix_1::assign_scalar(S val) const
{
    return assign_scal_1_functor::make<Matrix&,Integer,S>(*m_matrix,m_ind_1,val);
};
template<class S>
inline Matrix& details::SubMatrix_2::assign_scalar(S val) const
{
    return assign_scal_2_functor::make<Matrix&,Integer,Integer,S>(*m_matrix,m_ind_1,m_ind_2,val);
};
template<class S>
inline Matrix& details::SubMatrix::assign_scalar(S val) const
{
    if (m_colon_2)
    {
        return assign_scal_4_functor::make<Matrix&,const colon&,const colon&,S>
                    (*m_matrix,*m_colon_1,*m_colon_2,val);
    }
    else if(m_colon_1)
    {
        return assign_scal_3_functor::make<Matrix&,const colon&,S>(*m_matrix,*m_colon_1,val);
    }
    else
    {
        return assign_diag_functor::make<Matrix&,Integer,S>(*m_matrix,m_d,val);
    };
};


template<class S>
typename details::enable_if<details::is_scalar<S>::value,Matrix&>::type
inline details::SubMatrix::operator=(S val) const
{
	typedef typename mmlib::details::promote_scalar<S>::type val_type;
	return assign_scalar<val_type>(val);
};
template<class S>
typename details::enable_if<details::is_scalar<S>::value,Matrix&>::type
inline details::SubMatrix_1::operator=(S val) const
{
	typedef typename mmlib::details::promote_scalar<S>::type val_type;
	return assign_scalar<val_type>(val);
};
template<class S>
typename details::enable_if<details::is_scalar<S>::value,Matrix&>::type
inline details::SubMatrix_2::operator=(S val) const
{
	typedef typename mmlib::details::promote_scalar<S>::type val_type;
	return assign_scalar<val_type>(val);
};

};