/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/blas/blas.h"

namespace mmlib { namespace details
{

template<class T> struct lusol_value_type             { typedef T type;} ;
template<>        struct lusol_value_type<Complex>    { typedef std::complex<double> type;} ;

template<class T> struct lapack_value_type            { typedef T type;} ;
template<>        struct lapack_value_type<Complex>   { typedef std::complex<double> type;} ;

template<bool cond> struct check_size_impl            {};
template<>          struct check_size_impl<true>      { static void eval(){}; };

template<class T1, class T2>
struct check_size : public check_size_impl<sizeof(T1) == sizeof(T2)> {};

inline lapack::i_type* lap(Integer* ptr)
{
    check_size<lapack::i_type,Integer>::eval();
    return reinterpret_cast<lapack::i_type*>(ptr);
};
inline lapack::d_type* lap(Real* ptr)
{
    return reinterpret_cast<lapack::d_type*>(ptr);
};
inline lapack::z_type* lap(Complex* ptr)
{
    return reinterpret_cast<lapack::z_type*>(ptr);
};

inline const lapack::i_type* lap(const Integer* ptr)
{
    check_size<lapack::i_type,Integer>::eval();
    return reinterpret_cast<const lapack::i_type*>(ptr);
};
inline const lapack::d_type* lap(const Real* ptr)
{
    return reinterpret_cast<const lapack::d_type*>(ptr);
};
inline const lapack::z_type* lap(const Complex* ptr)
{
    return reinterpret_cast<const lapack::z_type*>(ptr);
};

};};