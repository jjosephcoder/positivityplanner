/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/scalar_types.h"
#include "mmlib/details/mpl.h"
#include "mmlib/details/isa.h"
#include "mmlib/details/utils.h"
#include "mmlib/details/val_struct_codes.h"

namespace mmlib { namespace details
{
template<class T1, class T2>
struct max_type_scal_impl
{
	typedef typename details::select_if
		<
			details::value_to_code<T1>::value >= details::value_to_code<T2>::value,
			T1,
			T2
		>:: type type;
};
template<class T1, class T2>
struct min_type_scal_impl
{
	typedef typename details::select_if
		<
			value_to_code<T1>::value <= value_to_code<T2>::value,
			T1,
			T2
		>:: type type;
};

template<class S1,class S2,class S3 = void>
struct max_type_scal
{
	typedef typename details::promote_scalar<S1>::type SP1;
	typedef typename details::promote_scalar<S2>::type SP2;
	typedef typename max_type_scal_impl<SP1,SP2>::type type_0;
	typedef typename max_type_scal<type_0,S3>::type type;
};
template<class S1,class S2>
struct pow_ret_type
{
	typedef typename details::promote_scalar<S1>::type SP1;
	typedef typename details::promote_scalar<S2>::type SP2;
	typedef typename details::select_if
		<
            details::is_equal<SP1,Integer>::value && details::is_equal<SP2,Integer>::value,
			Real,
	        typename details::select_if
		    <
                details::is_equal<SP1,Object>::value || details::is_equal<SP2,Object>::value,
			    Object,
			    Complex
		    >:: type
		>:: type type;
};
template<class S1>
struct max_type_scal<S1,void>
{
	typedef S1 type;
};
template<class S1,class S2,class S3 = void>
struct min_type_scal
{
	typedef typename details::promote_scalar<S1>::type SP1;
	typedef typename details::promote_scalar<S2>::type SP2;
	typedef typename min_type_scal_impl<SP1,SP2>::type type_0;
	typedef typename min_type_scal<type_0,S3>::type type;
};
template<class S1>
struct min_type_scal<S1,void>
{
	typedef S1 type;
};
template<class T, class Real_T>
struct enable_if_val_complex : 
	public enable_if
			<	is_equal<Real_T,Real>::value && is_equal<T,Complex>::value,
				const void*
			>
{};

template<class T>
struct enable_if_is_conv_to_mat :
	public enable_if
			<
				is_scalar<T>::value || is_matrix<T>::value,
				const void*
			>
{};

template<class ret_type,bool>
struct enable_if_matrix_impl
{};
template<class ret_type>
struct enable_if_matrix_impl<ret_type,true>
{
	typedef typename ret_type::type type;
};
template<class M,class ret_type>
struct enable_if_matrix:public enable_if_matrix_impl<ret_type,is_matrix<M>::value>
{};

template<class M, class ret_type,bool>
struct enable_if_scalar_impl
{};
template<class M, class ret_type>
struct enable_if_scalar_impl<M,ret_type,true>
{
	typedef typename ret_type::type type;
};
template<class M, class ret_type>
struct enable_if_scalar : public enable_if_scalar_impl<M,ret_type,is_scalar<M>::value>
{};

template<class S1, class S2>
struct enable_if_scal2_ret_max_op:
	public details::lazy_enable_if
	<
		is_scalar<S1>::value && is_scalar<S2>::value
		&& (details::is_equal<S1,Complex>::value || details::is_equal<S2,Complex>::value),
		max_type_scal<S1,S2>
	>
{};
template<class S1, class S2>
struct enable_if_scal2_ret_max:
	public details::lazy_enable_if
	<
		is_scalar<S1>::value && is_scalar<S2>::value,
		max_type_scal<S1,S2>
	>
{};
template<class S1, class S2>
struct enable_if_scal2_ret_max_real:
	public details::lazy_enable_if
	<
		is_scalar<S1>::value && is_scalar<S2>::value,
		max_type_scal<S1,S2,Real>
	>
{};
template<class S1, class S2>
struct enable_if_scal2_ret_pow:
	public details::lazy_enable_if
	<
		is_scalar<S1>::value && is_scalar<S2>::value,
		pow_ret_type<S1,S2>
	>
{};
template<class S1, class S2>
struct enable_if_scal2_ret_bool:
	public details::lazy_enable_if
	<
		is_scalar<S1>::value && is_scalar<S2>::value,
		details::lazy_type<bool>
	>
{};
template<class S1, class S2>
struct enable_if_scal2_ret_real:
	public details::lazy_enable_if
	<
		is_scalar<S1>::value && is_scalar<S2>::value,
		object_or_type<S1,S2,Real>
	>
{};
template<class S1, class S2>
struct enable_if_scal2_ret_matrix:
	public details::lazy_enable_if
	<
		is_scalar<S1>::value && is_scalar<S2>::value,
		details::lazy_type<Matrix>
	>
{};
template<class S1, class S2>
struct enable_if_scal2_ret_bool_op:
	public details::lazy_enable_if
	<
		is_scalar<S1>::value && is_scalar<S2>::value
		&& (details::is_equal<S1,Complex>::value || details::is_equal<S2,Complex>::value
            ||details::is_equal<S1,Object>::value || details::is_equal<S2,Object>::value),
		details::lazy_type<bool>
	>
{};

template<class S>
struct enable_if_scal_ret_the_same : public details::enable_if<is_scalar<S>::value,S>
{};
template<class S>
struct enable_if_scal_ret_the_same_op 
	: public details::enable_if<is_scalar<S>::value && details::is_equal<S,Complex>::value,S>
{};
template<class S>
struct enable_if_scal_ret_bool_op 
	: public details::enable_if<is_scalar<S>::value && details::is_equal<S,Complex>::value,bool>
{};


template<class S>
struct enable_if_scal_ret_bool : public details::enable_if<is_scalar<S>::value,bool>
{};
template<class S>
struct enable_if_scal_ret_int : public details::enable_if<is_scalar<S>::value,Integer>
{};
template<class S>
struct enable_if_scal_ret_void : public details::enable_if<is_scalar<S>::value,void>
{};
template<class S>
struct enable_if_scal_ret_matrix : public details::enable_if<is_scalar<S>::value,Matrix>
{};

template<class S>
struct enable_if_scal_ret_real : public details::enable_if<is_scalar<S>::value,Real>
{};
template<class S>
struct enable_if_scal_ret_max_with_real 
	: public details::lazy_enable_if<is_scalar<S>::value,max_type_scal<S,Real>>
{};
template<class S>
struct enable_if_scal_ret_min_with_real 
	: public details::lazy_enable_if<
                                        is_scalar<S>::value,
                                        lazy_object_or_type<S,void,min_type_scal<S,Real>>
                                    >
{};

template<class M,class ret_type>
struct enable_if_matrix_or_scalar 
	: public enable_if_matrix_impl<ret_type,is_matrix<M>::value || is_scalar<M>::value>
{};


template<class M1,class M2, class ret_type>
struct enable_if_mat_mat
	: public enable_if_matrix_impl
			<	ret_type,
				is_matrix<M1>::value && is_matrix<M2>::value
			>
{};
template<class M1,class M2, class ret_type>
struct enable_if_matscal_matscal
	: public enable_if_matrix_impl
			<	ret_type,
				(is_matrix<M1>::value || is_scalar<M1>::value) 
					&& (is_matrix<M2>::value || is_scalar<M1>::value)
			>
{};

template<class M1,class M2, class ret_type>
struct enable_if_scal_mat
	: public enable_if_matrix_impl
			<	ret_type,
				(is_scalar<M1>::value) && (is_matrix<M2>::value)
			>
{};

template<class M1,class M2, class ret_type>
struct enable_if_mat_scal
	: public enable_if_matrix_impl
			<	ret_type,
				(is_matrix<M1>::value) 	&& (is_scalar<M2>::value)
			>
{};
template<class M1,class M2, class ret_type>
struct enable_if_scal_scal
	: public enable_if_matrix_impl
			<	ret_type,
				is_scalar<M1>::value && is_scalar<M2>::value
			>
{};
template<class M1,class M2, class ret_type>
struct enable_if_scal_scal_op
	: public enable_if_matrix_impl
			<	ret_type,
				is_scalar<M1>::value && is_scalar<M2>::value
				&& (is_equal<M1,Complex>::value || is_equal<M2,Complex>::value)
			>
{};

};};

