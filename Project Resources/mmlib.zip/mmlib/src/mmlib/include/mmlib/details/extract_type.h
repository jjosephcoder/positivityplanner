/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

namespace mmlib { namespace details
{

template<class ret,class owner,class c_type,class Arg1>
struct vtable_1
{
    typedef ret (*function_type)(c_type handle,Arg1);
    typedef function_type table_type[macro_last_matrix_type_code+1];
    static table_type* table;
    static function_type get(size_t code)
    {
        return (*table)[code];
    };
    static table_type* init_table()
    {
        static table_type table;
        {
            typedef raw::Matrix<Integer,struct_dense> type;
            table[enums::integer_dense] = owner::make_impl<c_type,type,Arg1>;
        };
        {
            typedef raw::Matrix<Real,struct_dense> type;
            table[enums::real_dense] = owner::make_impl<c_type,type,Arg1>;
        };
        {
            typedef raw::Matrix<Complex,struct_dense> type;
            table[enums::complex_dense] = owner::make_impl<c_type,type,Arg1>;
        };
        {
            typedef raw::Matrix<Object,struct_dense> type;
            table[enums::object_dense] = owner::make_impl<c_type,type,Arg1>;
        };

        {
            typedef raw::Matrix<Integer,struct_sparse> type;
            table[enums::integer_sparse] = owner::make_impl<c_type,type,Arg1>;
        };
        {
            typedef raw::Matrix<Real,struct_sparse> type;
            table[enums::real_sparse] = owner::make_impl<c_type,type,Arg1>;
        };
        {
            typedef raw::Matrix<Complex,struct_sparse> type;
            table[enums::complex_sparse] = owner::make_impl<c_type,type,Arg1>;
        };
        {
            typedef raw::Matrix<Object,struct_sparse> type;
            table[enums::object_sparse] = owner::make_impl<c_type,type,Arg1>;
        };

        {
            typedef raw::Matrix<Integer,struct_banded> type;
            table[enums::integer_band] = owner::make_impl<c_type,type,Arg1>;
        };
        {
            typedef raw::Matrix<Real,struct_banded> type;
            table[enums::real_band] = owner::make_impl<c_type,type,Arg1>;
        };
        {
            typedef raw::Matrix<Complex,struct_banded> type;
            table[enums::complex_band] = owner::make_impl<c_type,type,Arg1>;
        };
        {
            typedef raw::Matrix<Object,struct_banded> type;
            table[enums::object_band] = owner::make_impl<c_type,type,Arg1>;
        };

        {
            typedef Integer type;
            table[enums::integer_scalar] = owner::make_impl_scalar<c_type,type,Arg1>;
        };
        {
            typedef Real type;
            table[enums::real_scalar] = owner::make_impl_scalar<c_type,type,Arg1>;
        };
        {
            typedef Complex type;
            table[enums::complex_scalar] = owner::make_impl_scalar<c_type,type,Arg1>;
        };
        {
            typedef Object type;
            table[enums::object_scalar] = owner::make_impl_scalar<c_type,type,Arg1>;
        };

        return &table;
    };
};
template<class ret,class owner,class c_type,class Arg1>
typename vtable_1<ret,owner,c_type,Arg1>::table_type* 
vtable_1<ret,owner,c_type,Arg1>::table = vtable_1<ret,owner,c_type,Arg1>::init_table();

template<class ret,class owner,class c_type,class Arg1,class Arg2>
struct vtable_2
{
    typedef ret (*function_type)(c_type handle,Arg1,Arg2);
    typedef function_type table_type[macro_last_matrix_type_code+1];
    static table_type* table;
    static function_type get(size_t code)
    {
        return (*table)[code];
    };
    static table_type* init_table()
    {
        static table_type table;
        {
            typedef raw::Matrix<Integer,struct_dense> type;
            table[enums::integer_dense] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };
        {
            typedef raw::Matrix<Real,struct_dense> type;
            table[enums::real_dense] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };
        {
            typedef raw::Matrix<Complex,struct_dense> type;
            table[enums::complex_dense] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };
        {
            typedef raw::Matrix<Object,struct_dense> type;
            table[enums::object_dense] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };

        {
            typedef raw::Matrix<Integer,struct_sparse> type;
            table[enums::integer_sparse] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };
        {
            typedef raw::Matrix<Real,struct_sparse> type;
            table[enums::real_sparse] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };
        {
            typedef raw::Matrix<Complex,struct_sparse> type;
            table[enums::complex_sparse] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };
        {
            typedef raw::Matrix<Object,struct_sparse> type;
            table[enums::object_sparse] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };

        {
            typedef raw::Matrix<Integer,struct_banded> type;
            table[enums::integer_band] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };
        {
            typedef raw::Matrix<Real,struct_banded> type;
            table[enums::real_band] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };
        {
            typedef raw::Matrix<Complex,struct_banded> type;
            table[enums::complex_band] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };
        {
            typedef raw::Matrix<Object,struct_banded> type;
            table[enums::object_band] = owner::make_impl<c_type,type,Arg1,Arg2>;
        };

        {
            typedef Integer type;
            table[enums::integer_scalar] = owner::make_impl_scalar<c_type,type,Arg1,Arg2>;
        };
        {
            typedef Real type;
            table[enums::real_scalar] = owner::make_impl_scalar<c_type,type,Arg1,Arg2>;
        };
        {
            typedef Complex type;
            table[enums::complex_scalar] = owner::make_impl_scalar<c_type,type,Arg1,Arg2>;
        };
        {
            typedef Object type;
            table[enums::object_scalar] = owner::make_impl_scalar<c_type,type,Arg1,Arg2>;
        };

        return &table;
    };
};

template<class ret,class owner,class c_type,class Arg1,class Arg2>
typename vtable_2<ret,owner,c_type,Arg1,Arg2>::table_type* 
vtable_2<ret,owner,c_type,Arg1,Arg2>::table
        = vtable_2<ret,owner,c_type,Arg1,Arg2>::init_table();


template<class ret,class owner,class c_type,class Arg1,class Arg2, class Arg3>
struct vtable_3
{
    typedef ret (*function_type)(c_type handle,Arg1,Arg2,Arg3);
    typedef function_type table_type[macro_last_matrix_type_code+1];
    static table_type* table;
    static function_type get(size_t code)
    {
        return (*table)[code];
    };
    static table_type* init_table()
    {
        static table_type table;
        {
            typedef raw::Matrix<Integer,struct_dense> type;
            table[enums::integer_dense] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef raw::Matrix<Real,struct_dense> type;
            table[enums::real_dense] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef raw::Matrix<Complex,struct_dense> type;
            table[enums::complex_dense] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef raw::Matrix<Object,struct_dense> type;
            table[enums::object_dense] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };

        {
            typedef raw::Matrix<Integer,struct_sparse> type;
            table[enums::integer_sparse] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef raw::Matrix<Real,struct_sparse> type;
            table[enums::real_sparse] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef raw::Matrix<Complex,struct_sparse> type;
            table[enums::complex_sparse] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef raw::Matrix<Object,struct_sparse> type;
            table[enums::object_sparse] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };

        {
            typedef raw::Matrix<Integer,struct_banded> type;
            table[enums::integer_band] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef raw::Matrix<Real,struct_banded> type;
            table[enums::real_band] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef raw::Matrix<Complex,struct_banded> type;
            table[enums::complex_band] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef raw::Matrix<Object,struct_banded> type;
            table[enums::object_band] = owner::make_impl<c_type,type,Arg1,Arg2,Arg3>;
        };

        {
            typedef Integer type;
            table[enums::integer_scalar] = owner::make_impl_scalar<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef Real type;
            table[enums::real_scalar] = owner::make_impl_scalar<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef Complex type;
            table[enums::complex_scalar] = owner::make_impl_scalar<c_type,type,Arg1,Arg2,Arg3>;
        };
        {
            typedef Object type;
            table[enums::object_scalar] = owner::make_impl_scalar<c_type,type,Arg1,Arg2,Arg3>;
        };

        return &table;
    };
};

template<class ret,class owner,class c_type,class Arg1,class Arg2,class Arg3>
typename vtable_3<ret,owner,c_type,Arg1,Arg2,Arg3>::table_type* 
vtable_3<ret,owner,c_type,Arg1,Arg2,Arg3>::table
        = vtable_3<ret,owner,c_type,Arg1,Arg2,Arg3>::init_table();

template<class ret, class derived, bool cost_access>
struct extract_type_1
{
    template<class c_type, class Arg1>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1)
    {
        typedef vtable_1<ret,extract_type_2,c_type,Arg1> vtable_type;
        typedef typename vtable_type::function_type Func;
        Func f = vtable_type::get(ptr.matrix_type());
        return f(ptr,arg1);
    };		
    template<class c_type, class T, class Arg1>
    static ret make_impl(typename hide_type<c_type>::type ptr, Arg1 arg1)
    {
        return derived::eval(ptr,ptr.get_impl_unique<T>(),arg1);
    };
    template<class c_type, class T, class Arg1>
    static ret make_impl_scalar(typename hide_type<c_type>::type ptr, Arg1 arg1)
    {
        return derived::eval_scalar(ptr,ptr.get_scalar<T>(),arg1);
    };
};
template<class ret, class derived>
struct extract_type_1<ret,derived,true>
{
    template<class c_type, class Arg1>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1)
    {
        typedef vtable_1<ret,extract_type_1,c_type,Arg1> vtable_type;
        typedef typename vtable_type::function_type Func;
        Func f = vtable_type::get(ptr.matrix_type());
        return f(ptr,arg1);
    };		
    template<class c_type, class T, class Arg1>
    static ret make_impl(typename hide_type<c_type>::type ptr, Arg1 arg1)
    {
        return derived::eval(ptr,ptr.get_impl<T>(),arg1);
    };
    template<class c_type, class T, class Arg1>
    static ret make_impl_scalar(typename hide_type<c_type>::type ptr, Arg1 arg1)
    {
        return derived::eval_scalar(ptr,ptr.get_scalar<T>(),arg1);
    };
};


template<class ret, class derived, bool cost_access>
struct extract_type_2
{
    template<class c_type, class Arg1, class Arg2>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2)
    {
        typedef vtable_2<ret,extract_type_2,c_type,Arg1,Arg2> vtable_type;
        typedef typename vtable_type::function_type Func;
        Func f = vtable_type::get(ptr.matrix_type());
        return f(ptr,arg1,arg2);
    };		
    template<class c_type, class T, class Arg1, class Arg2>
    static ret make_impl(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2)
    {
        return derived::eval(ptr,ptr.get_impl_unique<T>(),arg1,arg2);
    };
    template<class c_type, class T, class Arg1, class Arg2>
    static ret make_impl_scalar(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2)
    {
        return derived::eval_scalar(ptr,ptr.get_scalar_unique<T>(),arg1,arg2);
    };
};
template<class ret, class derived>
struct extract_type_2<ret,derived,true>
{
    template<class c_type, class Arg1, class Arg2>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2)
    {
        typedef vtable_2<ret,extract_type_2,c_type,Arg1,Arg2> vtable_type;
        typedef typename vtable_type::function_type Func;
        Func f = vtable_type::get(ptr.matrix_type());
        return f(ptr,arg1,arg2);       
    };		
    template<class c_type, class T, class Arg1, class Arg2>
    static ret make_impl(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2)
    {
        return derived::eval(ptr,ptr.get_impl<T>(),arg1,arg2);
    };
    template<class c_type, class T, class Arg1, class Arg2>
    static ret make_impl_scalar(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2)
    {
        return derived::eval_scalar(ptr,ptr.get_scalar<T>(),arg1,arg2);
    };
};

template<class ret, class derived, bool cost_access>
struct extract_type_3
{
    template<class c_type, class Arg1, class Arg2, class Arg3>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2, Arg3 arg3)
    {
        typedef vtable_3<ret,extract_type_3,c_type,Arg1,Arg2,Arg3> vtable_type;
        typedef typename vtable_type::function_type Func;
        Func f = vtable_type::get(ptr.matrix_type());
        return f(ptr,arg1,arg2,arg3);
    };		
    template<class c_type, class T, class Arg1, class Arg2, class Arg3>
    static ret make_impl(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2, Arg3 arg3)
    {
        return derived::eval(ptr,ptr.get_impl_unique<T>(),arg1,arg2,arg3);
    };
    template<class c_type, class T, class Arg1, class Arg2,class Arg3>
    static ret make_impl_scalar(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2, Arg3 arg3)
    {
        return derived::eval_scalar(ptr,ptr.get_scalar_unique<T>(),arg1,arg2,arg3);
    };
};
template<class ret, class derived>
struct extract_type_3<ret,derived,true>
{
    template<class c_type, class Arg1, class Arg2, class Arg3>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2, Arg3 arg3)
    {
        typedef vtable_3<ret,extract_type_3,c_type,Arg1,Arg2,Arg3> vtable_type;
        typedef typename vtable_type::function_type Func;
        Func f = vtable_type::get(ptr.matrix_type());
        return f(ptr,arg1,arg2,arg3);
    };		
    template<class c_type, class T, class Arg1, class Arg2, class Arg3>
    static ret make_impl(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2, Arg3 arg3)
    {
        return derived::eval(ptr,ptr.get_impl<T>(),arg1,arg2,arg3);
    };
    template<class c_type, class T, class Arg1, class Arg2, class Arg3>
    static ret make_impl_scalar(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2, Arg3 arg3)
    {
        return derived::eval_scalar(ptr,ptr.get_scalar<T>(),arg1,arg2,arg3);
    };
};
};};