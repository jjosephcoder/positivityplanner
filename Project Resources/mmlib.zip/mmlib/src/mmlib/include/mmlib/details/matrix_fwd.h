/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/config.h"
#include "mmlib/type_decls.h"
#include "mmlib/tuple.h"

namespace mmlib
{

class Matrix;
class colon;
class mat_row;
class mat_col;

class test_function;
class scalar_function;
class disp_stream;

template<class derived> class scalar_function_templ;
template<class derived> class test_function_templ;

typedef tuple<Matrix,2>			mat_tup_2;
typedef tuple<Matrix,3>			mat_tup_3;
typedef tuple<Matrix,4>			mat_tup_4;
typedef tuple<Matrix,5>			mat_tup_5;
typedef tuple<Matrix,6>			mat_tup_6;
typedef tuple<Integer,2>		int_tup_2;

namespace details
{
	class mat_cons_data;
	struct matrix_data_accesser;	

	template<class M> struct sparse_matrix_constructor_row;
	template<class M> struct dense_matrix_constructor_row;

	template<class M> struct sparse_matrix_constructor_col;
	template<class M> struct dense_matrix_constructor_col;
};

};