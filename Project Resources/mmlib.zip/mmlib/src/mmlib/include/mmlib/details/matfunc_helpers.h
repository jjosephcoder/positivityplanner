/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once 

#include "mmlib/details/utils.h"
#include "mmlib/details/isa.h"
#include "mmlib/exception.h"
#include "mmlib/details/type_info_utils.h"

namespace mmlib { namespace raw { namespace details
{ 

namespace gd = mmlib::details;
namespace gc = mmlib::complex;

inline Integer gl_mult(Integer a, Integer b)   { return a*b; };
inline Real    gl_mult(Real a, Real b)         { return a*b; };
inline Object  gl_mult(Object a, Object b)     { return operator*(a,b); };

inline Integer gl_plus(Integer a, Integer b)   { return a+b; };
inline Real    gl_plus(Real a, Real b)         { return a+b; };
inline Object  gl_plus(Object a, Object b)     { return operator+(a,b); };

inline Integer gl_minus(Integer a, Integer b)  { return a-b; };
inline Real    gl_minus(Real a, Real b)        { return a-b; };
inline Object  gl_minus(Object a, Object b)    { return operator-(a,b); };

inline Integer gl_minus(Integer a)             { return -a; };
inline Real    gl_minus(Real a)                { return -a; };
inline Object  gl_minus(Object a)              { return operator-(a); };

inline Integer gl_div(Integer a, Integer b)    { return a/b; };
inline Real    gl_div(Real a, Real b)          { return a/b; };
inline Object  gl_div(Object a, Object b)      { return operator/(a,b); };

namespace bin_func
{
	inline Complex min(const Complex &a, const Complex &b) 
	{
        return gc::lt_c(a,b) ? a : b;
	}

	inline Complex max(const Complex &a, const Complex &b)
	{
		return gc::gt_c(a,b) ? a : b; 
	}
};

template<class T> struct promote_int						{ typedef T    type;};
template<>		  struct promote_int<Integer>				{ typedef Real type;};

template<class ret,bool isc,bool iso,class S1,class S2>
struct mul_helper_impl
{
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)
	{
        return gl_mult(arg1,arg2);
	};
};
template<class ret,class S1,class S2>
struct mul_helper_impl<ret,true,false,S1,S2>
{
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)
	{
        return gc::mul_c(arg1,arg2);
	};
};
template<class ret,bool isc,class S1,class S2>
struct mul_helper_impl<ret,isc,true,S1,S2>
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
        return gl_mult(Object(ti,arg1),Object(ti,arg2));
	};
};

template<class ret,bool isc,bool iso, class S1,class S2>
struct plus_helper_impl
{
    static ret eval(gd::type_info ,S1 arg1, S2 arg2)
	{
        return gl_plus(arg1,arg2);
	};
};
template<class ret,class S1,class S2>
struct plus_helper_impl<ret,true,false,S1,S2>
{
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)
	{
        return gc::plus_c(arg1,arg2);
	};
};
template<class ret,bool isc, class S1,class S2>
struct plus_helper_impl<ret,isc,true,S1,S2>
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
        return gl_plus(Object(ti,arg1),Object(ti,arg2));
	};
};
template<class ret,bool isc,bool iso,class S1,class S2>
struct minus_helper_impl
{
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)
	{
        return gl_minus(arg1,arg2);
	};
};
template<class ret,class S1,class S2>
struct minus_helper_impl<ret,true,false,S1,S2>
{
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)
	{
        return gc::minus_c(arg1,arg2);
	};
};
template<class ret,bool isc, class S1,class S2>
struct minus_helper_impl<ret,isc,true,S1,S2>
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
        return gl_minus(Object(ti,arg1),Object(ti,arg2));
	};
};
template<class ret,bool isc,bool iso, class S1,class S2>
struct div_helper_impl
{
    static ret eval(gd::type_info , S1 arg1, S2 arg2)
	{
        return gl_div(arg1,arg2);
	};
};
template<class ret,class S1,class S2>
struct div_helper_impl<ret,true,false,S1,S2>
{
	static ret eval(gd::type_info , S1 arg1, S2 arg2)
	{
        return gc::div_c(arg1,arg2);
	};
};
template<class ret,bool isc, class S1,class S2>
struct div_helper_impl<ret,isc,true,S1,S2>
{
	static ret eval(gd::type_info ti, S1 arg1, S2 arg2)
	{
        return gl_div(Object(ti,arg1),Object(ti,arg2));
	};
};
template<class ret,bool isc,class S1,class S2>
struct min_helper_impl
{
    static ret eval(gd::type_info ti, S1 arg1, S2 arg2)
	{
		if (isnan_helper<S1>::eval(ti,arg1))
		{
            return ret(arg2);
		};
		if (isnan_helper<S2>::eval(ti,arg2))
		{
            return ret(arg1);
		};
        return (arg1<arg2)? ret(arg1) : ret(arg2); 
	};
};
template<class ret,class S1,class S2>
struct min_helper_impl<ret,true,S1,S2>
{
	static ret eval(gd::type_info ti, S1 arg1, S2 arg2)
	{
		if (isnan_helper<S1>::eval(ti,arg1))
		{
			return arg2;
		};
		if (isnan_helper<S2>::eval(ti,arg2))
		{
			return arg1;
		};
        return gc::lt_c(arg1,arg2)? arg1 : arg2; 
	};
};
template<class ret,bool isc,bool iso,class S1,class S2>
struct max_helper_impl
{
	static ret eval(gd::type_info ti, S1 arg1, S2 arg2)
	{
		if (isnan_helper<S1>::eval(ti,arg1))
		{
			return ret(arg2);
		};
		if (isnan_helper<S2>::eval(ti,arg2))
		{
			return ret(arg1);
		};
		return (arg1>arg2)? ret(arg1) : ret(arg2); 
	};
};
template<class ret,class S1,class S2>
struct max_helper_impl<ret,true,false,S1,S2>
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
		if (isnan_helper<S1>::eval(ti,arg1))
		{
			return ret(arg2);
		};
		if (isnan_helper<S2>::eval(ti,arg2))
		{
			return ret(arg1);
		};
        return gc::gt_c(arg1,arg2)? ret(arg1) : ret(arg2); 
	};
};
template<class ret,bool isc,class S1,class S2>
struct max_helper_impl<ret,isc,true,S1,S2>
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
		if (isnan_helper<S1>::eval(ti,arg1))
		{
			return ret(ti,arg2);
		};
		if (isnan_helper<S2>::eval(ti,arg2))
		{
			return ret(ti,arg1);
		};
		return (arg1>arg2)? ret(ti,arg1) : ret(ti,arg2); 
	};
};
template<class ret,bool isc,class S1,class S2>
struct eeq_helper_impl
{
	static ret eval(S1 arg1, S2 arg2)
	{
		return (arg1 == arg2); 
	};
};
template<class ret,class S1,class S2>
struct eeq_helper_impl<ret,true,S1,S2>
{
	static ret eval(S1 arg1, S2 arg2)
	{
        return gc::eeq_c(arg1,arg2);
	};
};
template<class ret,bool isc,class S1,class S2>
struct neq_helper_impl
{
	static ret eval(S1 arg1, S2 arg2)
	{
		return (arg1 != arg2); 
	};
};
template<class ret,class S1,class S2>
struct neq_helper_impl<ret,true,S1,S2>
{
	static ret eval(S1 arg1, S2 arg2)
	{
        return gc::neq_c(arg1,arg2);
	};
};

template<class ret,bool isc,class S1,class S2>
struct leq_helper_impl
{
	static ret eval(S1 arg1, S2 arg2)
	{
		return (arg1 <= arg2); 
	};
};
template<class ret,class S1,class S2>
struct leq_helper_impl<ret,true,S1,S2>
{
	static ret eval(S1 arg1, S2 arg2)
	{
        return gc::leq_c(arg1,arg2);
	};
};
template<class ret,bool isc,class S1,class S2>
struct geq_helper_impl
{
	static ret eval(S1 arg1, S2 arg2)
	{
		return (arg1 >= arg2); 
	};
};
template<class ret,class S1,class S2>
struct geq_helper_impl<ret,true,S1,S2>
{
	static ret eval(S1 arg1, S2 arg2)
	{
        return gc::geq_c(arg1,arg2);
	};
};
template<class ret,bool isc,class S1,class S2>
struct lt_helper_impl
{
	static ret eval(S1 arg1, S2 arg2)
	{
		return (arg1 < arg2); 
	};
};
template<class ret,class S1,class S2>
struct lt_helper_impl<ret,true,S1,S2>
{
	static ret eval(S1 arg1, S2 arg2)
	{
        return gc::lt_c(arg1,arg2);
	};
};
template<class ret,bool isc,class S1,class S2>
struct gt_helper_impl
{
	static ret eval(S1 arg1, S2 arg2)
	{
		return (arg1 > arg2); 
	};
};
template<class ret,class S1,class S2>
struct gt_helper_impl<ret,true,S1,S2>
{
	static ret eval(S1 arg1, S2 arg2)
	{
        return gc::gt_c(arg1,arg2);
	};
};


template<class ret,bool isc,bool iso,class S1,class S2>
struct mod_helper_impl
{
    static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
        return (arg2==S2())? ret() 
            : gl_minus(arg1, gl_mult(floor_helper<ret>::eval(ti,gl_div(arg1,arg2)),arg2)); 
	};
};
template<class ret,class S1,class S2>
struct mod_helper_impl<ret,true,false,S1,S2>
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
        return eeq_helper<S2,S2>::eval(ti,arg2,0)? 0 
            : gc::minus_c(arg1,gc::mul_c(floor_helper<ret>::eval(ti,gc::div_c(arg1,arg2)),arg2)); 
	};
};
template<class ret,bool isc,class S1,class S2>
struct mod_helper_impl<ret,isc,true,S1,S2>
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
        S2 zero_2 = gd::default_value<S2>(gd::get_ti(arg2));
        ret zero_r = gd::default_value<ret>(gd::get_ti(arg1));
        return (arg2==zero_2)? zero_r 
            : gl_minus(arg1, gl_mult(floor_helper<ret>::eval(ti,gl_div(arg1,arg2)),arg2)); 
	};
};

template<class ret,bool isc,bool iso,class S1,class S2>
struct rem_helper_impl
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
        S2 zero_2 = 0;
        ret zero_r = 0;
        return (arg2==zero_2)? zero_r 
            : gl_minus(arg1, gl_mult(fix_helper<ret>::eval(ti,gl_div(arg1,arg2)),arg2)); 
	};
};
template<class ret,class S1,class S2>
struct rem_helper_impl<ret,true,false,S1,S2>
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
        return eeq_helper<S2,S2>::eval(ti,arg2,0)? 0 
            : gc::minus_c(arg1,gc::mul_c(fix_helper<ret>::eval(ti,gc::div_c(arg1,arg2)),arg2)); 
	};
};
template<class ret,bool isc,class S1,class S2>
struct rem_helper_impl<ret,isc,true,S1,S2>
{
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
	{
        return (arg2.is_zero())? Object(ti) 
            : gl_minus(arg1, gl_mult(fix_helper<ret>::eval(ti,gl_div(arg1,arg2)),arg2)); 
	};
};

template<class T1, class T2>
struct mul_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;

	static const bool isc = gd::is_equal<S1,Complex>::value 
							||gd::is_equal<S2,Complex>::value;
	static const bool iso = gd::is_equal<S1,Object>::value 
							||gd::is_equal<S2,Object>::value;

    static ret eval(gd::type_info ti, S1 arg1, S2 arg2)						
	{	
		return mul_helper_impl<ret,isc,iso,S1,S2>::eval(ti,arg1,arg2);	
	};
};
template<>
struct mul_helper<Integer,Integer>
{
	typedef Integer T1;
	typedef Integer T2;
	typedef Integer ret;
	static ret eval(gd::type_info , T1 arg1, T2 arg2)						
	{	
        return gl_mult(arg1,arg2);
	};
};
template<class T1, class T2>
struct plus_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;
	static const bool isc = gd::is_equal<S1,Complex>::value 
							||gd::is_equal<S2,Complex>::value;
	static const bool iso = gd::is_equal<S1,Object>::value 
							||gd::is_equal<S2,Object>::value;
    static ret eval(gd::type_info ti,S1 arg1, S2 arg2)						
	{	
		return plus_helper_impl<ret,isc,iso,S1,S2>::eval(ti,arg1,arg2);	
	};
};
template<>
struct plus_helper<Integer,Integer>
{
	typedef Integer T1;
	typedef Integer T2;
	typedef Integer ret;
	static ret eval(gd::type_info ,T1 arg1, T2 arg2)						
	{	
        return gl_plus(arg1,arg2);
	};
};
template<class T1, class T2>
struct minus_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;
	static const bool isc = gd::is_equal<S1,Complex>::value 
							||gd::is_equal<S2,Complex>::value;
	static const bool iso = gd::is_equal<S1,Object>::value 
							||gd::is_equal<S2,Object>::value;
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)						
	{	
		return minus_helper_impl<ret,isc,iso,S1,S2>::eval(ti,arg1,arg2);	
	};
};
template<>
struct minus_helper<Integer,Integer>
{
	typedef Integer T1;
	typedef Integer T2;
	typedef Integer ret;
	static ret eval(gd::type_info ,T1 arg1, T2 arg2)
	{	
        return gl_minus(arg1,arg2);
	};
};

template<class T1, class T2>
struct min_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;
    static ret eval(gd::type_info ti, S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		static const bool iso = gd::is_equal<S1,Object>::value 
								||gd::is_equal<S2,Object>::value;
		return min_helper_impl<ret,isc && (iso == false),S1,S2>::eval(ti,arg1,arg2);	
	};
};
template<>
struct min_helper<Integer,Integer>
{
	typedef Integer T1;
	typedef Integer T2;
	typedef Integer ret;
	static ret eval(gd::type_info , T1 arg1, T2 arg2)						
	{	
		return (arg1<arg2)? arg1 : arg2; 
	};
};

template<class T1, class T2>
struct max_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;
	static ret eval(gd::type_info ti, S1 arg1, S2 arg2)					
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		static const bool iso = gd::is_equal<S1,Object>::value 
								||gd::is_equal<S2,Object>::value;
		return max_helper_impl<ret,isc,iso,S1,S2>::eval(ti,arg1,arg2);	
	};
};
template<>
struct max_helper<Integer,Integer>
{
	typedef Integer T1;
	typedef Integer T2;
	typedef Integer ret;
	static ret eval(gd::type_info , T1 arg1, T2 arg2)						
	{	
		return (arg1>arg2)? arg1 : arg2; 
	};
};

template<class T1, class T2>
struct idiv_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;
	static ret eval(gd::type_info ti, S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		static const bool iso = gd::is_equal<S1,Object>::value 
								||gd::is_equal<S2,Object>::value;
		return div_helper_impl<ret,isc,iso,S1,S2>::eval(ti,arg1,arg2);	
	};
};
template<>
struct idiv_helper<Integer,Integer>
{
	typedef Integer T1;
	typedef Integer T2;
	typedef Integer ret;
	static ret eval(gd::type_info , T1 arg1, T2 arg2)						
	{	
		//avoids unhandled exceptions -> integer overflow
		return	(arg2 == 0)? 0 
                : (arg2 == -1)? gl_mult(arg1,arg2) : gl_div(arg1,arg2); 
	};
};
template<class T1, class T2>
struct div_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;
	static ret eval(gd::type_info ti, S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		static const bool iso = gd::is_equal<S1,Object>::value 
								||gd::is_equal<S2,Object>::value;
		return div_helper_impl<ret,isc,iso,S1,S2>::eval(ti,arg1,arg2);	
	};
};
template<>
struct div_helper<Integer,Integer>
{
	typedef Real T1;
	typedef Real T2;
	typedef Real ret;
	static ret eval(gd::type_info , T1 arg1, T2 arg2)						
	{	
		return gl_div(arg1,arg2); 
	};
};
template<class T1, class T2>
struct pow_complex
{
    static Complex eval(const T1& arg1, const T2& arg2);
};

template<class T1, class T2>
struct pow_helper
{
	typedef typename promote_int<T1> :: type    S1;
	typedef T2                                  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;

	static const bool isc = gd::is_equal<S1,Complex>::value 
							||gd::is_equal<S2,Complex>::value;
	static const bool iso = gd::is_equal<S1,Object>::value 
							||gd::is_equal<S2,Object>::value;

    static ret eval(gd::type_info ti,S1 arg1, S2 arg2)						
	{	
		return eval_impl<isc,iso>::eval(ti,arg1,arg2); 
	};

	template<bool isc,bool iso>
	struct eval_impl
	{	
		static ret eval(gd::type_info ,S1 arg1, S2 arg2)
		{
			return std::pow(arg1,arg2); 
		};
	};
	template<>
	struct eval_impl<true,false>
	{	
		static ret eval(gd::type_info ,S1 arg1, S2 arg2)
        {
            return pow_complex<S1,S2>::eval(arg1,arg2);
        };
	};
	template<bool isc>
	struct eval_impl<isc,true>
	{	
		static ret eval(gd::type_info ti,S1 arg1, S2 arg2)
        {
            Object obj1 = converter<Object,S1>::eval(ti,arg1);
            Object obj2 = converter<Object,S2>::eval(ti,arg2);
            return object_func::pow(obj1,obj2);
        };
	};
};

template<class T1, class T2>
struct mod_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		static const bool iso = gd::is_equal<S1,Object>::value 
								||gd::is_equal<S2,Object>::value;
		return mod_helper_impl<ret,isc,iso,S1,S2>::eval(ti,arg1,arg2);			
	};
};
template<>
struct mod_helper<Integer,Integer>
{
	typedef Integer T1;
	typedef Integer T2;
	typedef Integer ret;
	static ret eval(gd::type_info ,T1 arg1, T2 arg2)						
	{	
		return (arg2==0 || arg2 == -1)? 0 : arg1 % arg2; 
	};
};

template<class T1, class T2>
struct rem_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	typedef typename gd::max_type<S1,S2>::type	  ret;
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		static const bool iso = gd::is_equal<S1,Object>::value 
								||gd::is_equal<S2,Object>::value;
		return rem_helper_impl<ret,isc,iso,S1,S2>::eval(ti,arg1,arg2);			
	};
};
template<>
struct rem_helper<Integer,Integer>
{
	typedef Integer T1;
	typedef Integer T2;
	typedef Integer ret;
	static ret eval(gd::type_info ,T1 arg1, T2 arg2)	
	{	
		if (arg2==0 || arg2 == -1)
		{
			return 0;
		};

		Integer tmp = arg1 % arg2;
		if (tmp < 0)
		{
            tmp += ( (arg2 < 0)? gl_minus(arg2) : arg2 );
		};
		return tmp; 
	};
};
template<class S1, class S2>
struct eeq_helper
{
	typedef bool ret;
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		return eeq_helper_impl<ret,isc,S1,S2>::eval(arg1,arg2);	
	};
};
template<class S1, class S2>
struct neq_helper
{
	typedef bool ret;
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		return neq_helper_impl<ret,isc,S1,S2>::eval(arg1,arg2);	
	};
};
template<class S1, class S2>
struct leq_helper
{
	typedef bool ret;
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		return leq_helper_impl<ret,isc,S1,S2>::eval(arg1,arg2);	
	};
};
template<class S1, class S2>
struct geq_helper
{
	typedef bool ret;
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		return geq_helper_impl<ret,isc,S1,S2>::eval(arg1,arg2);	
	};
};
template<class S1, class S2>
struct lt_helper
{
	typedef bool ret;
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)						
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		return lt_helper_impl<ret,isc,S1,S2>::eval(arg1,arg2);	
	};
};
template<class S1, class S2>
struct gt_helper
{
	typedef bool ret;
	static ret eval(gd::type_info ,S1 arg1, S2 arg2)	
	{	
		static const bool isc = gd::is_equal<S1,Complex>::value 
								||gd::is_equal<S2,Complex>::value;
		return gt_helper_impl<ret,isc,S1,S2>::eval(arg1,arg2);	
	};
};

template<class T1, class T2,bool iso>
struct atan2_helper_impl
{
	typedef Real							  ret;
    static ret eval(gd::type_info , T1 arg1, T2 arg2)						
	{	
        return std::atan2(arg1,arg2);
	};
};
template<class T2>
struct atan2_helper_impl<Complex,T2,false>
{
	typedef Real							  ret;
	static ret eval(gd::type_info ti, const Complex& arg1, T2 arg2)	
	{	
		if (imag(arg1) == 0.)
		{
			return atan2_helper<Real,T2>::eval(ti,real(arg1),arg2); 
		}
		else
		{
			throw error::error_atan2_on_complex();
		};
	};
};
template<class T1>
struct atan2_helper_impl<T1,Complex,false>
{
	typedef Real							  ret;
	static ret eval(gd::type_info ti, T1 arg1,const Complex& arg2)	
	{	
		if (imag(arg2) == 0.)
		{
			return atan2_helper<T1,Real>::eval(ti,arg1,real(arg2)); 
		}
		else
		{
			throw error::error_atan2_on_complex();
		};
	};
};
template<>
struct atan2_helper_impl<Complex,Complex,false>
{
	typedef Real ret;
	static ret eval(gd::type_info ti, const Complex& arg1,const Complex& arg2)	
	{	
		if (imag(arg1) == 0. && imag(arg2) == 0.)
		{
			return atan2_helper_impl<Real,Real,false>::eval(ti,real(arg1),real(arg2)); 
		}
		else
		{
			throw error::error_atan2_on_complex();
		};
	};
};
template<class T>
struct atan2_helper_impl<T,Object,true>
{
	typedef Object ret;
	static ret eval(gd::type_info ti, const T& arg1,const Object& arg2)	
	{	
        return object_func::atan2(Object(ti,arg1),Object(ti,arg2));
	};
};
template<class T>
struct atan2_helper_impl<Object,T,true>
{
	typedef Object ret;
	static ret eval(gd::type_info ti, const Object& arg1,const T& arg2)	
	{	
        return object_func::atan2(Object(ti,arg1),Object(ti,arg2));
	};
};
template<>
struct atan2_helper_impl<Object,Object,true>
{
	typedef Object ret;
	static ret eval(gd::type_info ti, const Object& arg1,const Object& arg2)	
	{	
        return object_func::atan2(Object(ti,arg1),Object(ti,arg2));
	};
};
template<class T1, class T2>
struct atan2_helper
{
	typedef typename promote_int<T1> :: type  S1;
	typedef typename promote_int<T2> :: type  S2;
	static const bool iso = gd::is_equal<S1,Object>::value 
					        ||gd::is_equal<S2,Object>::value;
    typedef typename atan2_helper_impl<S1,S2,iso>::ret  ret;
	static ret eval(gd::type_info ti,S1 arg1, S2 arg2)						
	{	
        return atan2_helper_impl<S1,S2,iso>::eval(ti,arg1,arg2);
	};
};
template<class T1, class T2>
struct or_helper
{
	typedef bool ret;
	static ret eval(gd::type_info ti,T1 arg1, T2 arg2)	
	{	
		return is_true_helper<T1>::eval(ti,arg1) || is_true_helper<T2>::eval(ti,arg2); 
	};
};
template<class T1, class T2>
struct and_helper
{
	typedef bool ret;
	static ret eval(gd::type_info ti,T1 arg1, T2 arg2)	
	{	
		return is_true_helper<T1>::eval(ti,arg1) && is_true_helper<T2>::eval(ti,arg2); 
	};
};
template<class T1, class T2>
struct xor_helper
{
	typedef bool ret;
	static ret eval(gd::type_info ti,T1 arg1, T2 arg2)	
	{	
		return is_true_helper<T1>::eval(ti,arg1) ^ is_true_helper<T2>::eval(ti,arg2); 
	};
};

};};};