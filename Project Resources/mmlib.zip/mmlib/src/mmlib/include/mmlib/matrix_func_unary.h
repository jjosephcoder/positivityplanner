/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/matrix.h"

namespace mmlib
{

MMLIB_EXPORT Matrix		    uminus(const Matrix& A);
MMLIB_EXPORT Matrix			neg(const Matrix& A);

inline Matrix			    operator-(const Matrix& A)					{ return uminus(A); };
inline Matrix				operator~(const Matrix& A)					{ return neg(A); };

MMLIB_EXPORT Matrix			is_true(const Matrix& A);
inline Matrix				is_false(const Matrix& A)					{ return neg(A);};
inline bool					is_scalar_true(const Matrix& A)				{ return A.is_scalar_true(); };
inline bool					is_scalar_false(const Matrix& A)			{ return !A.is_scalar_true(); };

MMLIB_EXPORT Matrix			sum(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			cumsum(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			prod(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			cumprod(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			sumsq(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			min_d(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			max_d(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			min_abs_d(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			max_abs_d(const Matrix& v, int dim = 1);
inline Matrix				min(const Matrix& v)						{ return min_d(v,1); };
inline Matrix				max(const Matrix& v)						{ return max_d(v,1); };
inline Matrix				min_abs(const Matrix& v)				    { return min_abs_d(v,1); };
inline Matrix				max_abs(const Matrix& v)					{ return max_abs_d(v,1); };
MMLIB_EXPORT mat_tup_2		min2(const Matrix& v, int dim = 1);
MMLIB_EXPORT mat_tup_2		max2(const Matrix& v, int dim = 1);
MMLIB_EXPORT mat_tup_2		min_abs2(const Matrix& v, int dim = 1);
MMLIB_EXPORT mat_tup_2		max_abs2(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			mean(const Matrix& v, int dim = 1);
MMLIB_EXPORT Matrix			std(const Matrix& v,int dim = 1);
MMLIB_EXPORT Matrix			all(const Matrix& v,int dim = 1);
MMLIB_EXPORT Matrix			any(const Matrix& v,int dim = 1);
MMLIB_EXPORT Matrix			all(const Matrix& v,const test_function& t,int dim = 1);
MMLIB_EXPORT Matrix			any(const Matrix& v,const test_function& t,int dim = 1);

MMLIB_EXPORT Matrix			find(const Matrix& v);
MMLIB_EXPORT Matrix			find(const Matrix& v,const test_function& t);
MMLIB_EXPORT mat_tup_2		find2(const Matrix& v);
MMLIB_EXPORT mat_tup_2		find2(const Matrix& v,const test_function& t);
MMLIB_EXPORT mat_tup_3		find3(const Matrix& v);
MMLIB_EXPORT mat_tup_3		find3(const Matrix& v,const test_function& t);

MMLIB_EXPORT Matrix			sort(const Matrix& v,int dim = 1, bool asceding = true);
MMLIB_EXPORT mat_tup_2		sort2(const Matrix& v,int dim = 1, bool asceding = true);
MMLIB_EXPORT Matrix			sortrows(const Matrix& v);
MMLIB_EXPORT mat_tup_2		sortrows2(const Matrix& v);
MMLIB_EXPORT Matrix			sortrows(const Matrix& v,const Matrix& dims);
MMLIB_EXPORT mat_tup_2		sortrows2(const Matrix& v, const Matrix& dims);
MMLIB_EXPORT Matrix			sortcols(const Matrix& v);
MMLIB_EXPORT mat_tup_2		sortcols2(const Matrix& v);
MMLIB_EXPORT Matrix			sortcols(const Matrix& v,const Matrix& dims);
MMLIB_EXPORT mat_tup_2		sortcols2(const Matrix& v, const Matrix& dims);

MMLIB_EXPORT Matrix			issorted(const Matrix& v,int dim = 1, bool asceding = true);
MMLIB_EXPORT bool			issorted_rows(const Matrix& v);
MMLIB_EXPORT bool			issorted_cols(const Matrix& v);

MMLIB_EXPORT Matrix			real(const Matrix &m);
MMLIB_EXPORT Matrix			imag(const Matrix &m);
MMLIB_EXPORT Matrix			abs(const Matrix &m);
MMLIB_EXPORT Matrix			arg(const Matrix &m);
MMLIB_EXPORT Matrix			angle(const Matrix &m);
MMLIB_EXPORT Matrix			conj(const Matrix &m);

MMLIB_EXPORT Matrix			is_inf(const Matrix &m);
MMLIB_EXPORT Matrix			is_nan(const Matrix &m);
MMLIB_EXPORT Matrix			is_finite(const Matrix &m);

MMLIB_EXPORT Matrix			floor(const Matrix &m);
MMLIB_EXPORT Matrix			ceil(const Matrix &m);
MMLIB_EXPORT Matrix			round(const Matrix &m);
MMLIB_EXPORT Matrix			fix(const Matrix &m);
MMLIB_EXPORT Matrix			trunc(const Matrix &m);
MMLIB_EXPORT Matrix			ifloor(const Matrix &m);
MMLIB_EXPORT Matrix			iceil(const Matrix &m);
MMLIB_EXPORT Matrix			iround(const Matrix &m);
MMLIB_EXPORT Matrix			ifix(const Matrix &m);
MMLIB_EXPORT Matrix			itrunc(const Matrix &m);
MMLIB_EXPORT Matrix			sign(const Matrix &m);
MMLIB_EXPORT Matrix			isign(const Matrix &m);

MMLIB_EXPORT Matrix			pow2(const Matrix &m);
MMLIB_EXPORT Matrix			exp(const Matrix &m);
MMLIB_EXPORT Matrix			sin(const Matrix &m);
MMLIB_EXPORT Matrix			cos(const Matrix &m);
MMLIB_EXPORT Matrix			tan(const Matrix &m);
MMLIB_EXPORT Matrix			cot(const Matrix &m);
MMLIB_EXPORT Matrix			sec(const Matrix &m);
MMLIB_EXPORT Matrix			csc(const Matrix &m);
MMLIB_EXPORT Matrix			atan(const Matrix &m);
MMLIB_EXPORT Matrix			acot(const Matrix &m);
MMLIB_EXPORT Matrix			sinh(const Matrix &m);
MMLIB_EXPORT Matrix			cosh(const Matrix &m);
MMLIB_EXPORT Matrix			tanh(const Matrix &m);
MMLIB_EXPORT Matrix			coth(const Matrix &m);
MMLIB_EXPORT Matrix			sech(const Matrix &m);
MMLIB_EXPORT Matrix			csch(const Matrix &m);
MMLIB_EXPORT Matrix			asinh(const Matrix &m);
MMLIB_EXPORT Matrix			acsch(const Matrix &m);
MMLIB_EXPORT Matrix			atan2(const Matrix &m1,const Matrix &m2);

MMLIB_EXPORT Matrix			sqrt(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			log(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			log2(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			log10(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			asin(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			acos(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			asec(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			acsc(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			acosh(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			atanh(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			acoth(const Matrix &m, bool allow_convert_to_complex = true);
MMLIB_EXPORT Matrix			asech(const Matrix &m, bool allow_convert_to_complex = true);

inline Matrix				sqrt_nc(const Matrix &m)	{ return sqrt(m,false); };
inline Matrix				log_nc(const Matrix &m)		{ return log(m,false); };
inline Matrix				log2_nc(const Matrix &m)	{ return log2(m,false); };
inline Matrix				log10_nc(const Matrix &m)	{ return log10(m,false); };
inline Matrix				asin_nc(const Matrix &m)	{ return asin(m,false); };
inline Matrix				acos_nc(const Matrix &m)	{ return acos(m,false); };
inline Matrix				asec_nc(const Matrix &m)	{ return asec(m,false); };
inline Matrix				acsc_nc(const Matrix &m)	{ return acsc(m,false); };
inline Matrix				acosh_nc(const Matrix &m)	{ return acosh(m,false); };
inline Matrix				atanh_nc(const Matrix &m)	{ return atanh(m,false); };
inline Matrix				acoth_nc(const Matrix &m)	{ return acoth(m,false); };
inline Matrix				asech_nc(const Matrix &m)	{ return asech(m,false); };

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
uminus(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
neg(S A);

template<class S> inline
typename details::enable_if_scal_ret_the_same_op<S>::type
operator-(S A)			{ return uminus(A); };

template<class S> inline
typename details::enable_if_scal_ret_bool_op<S>::type
operator~(S A)			{ return neg(A); };

template<class S> inline
typename details::enable_if_scal_ret_bool_op<S>::type
operator!(S A)			{ return neg(A); };

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
is_true(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
is_false(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
is_scalar_true(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
is_scalar_false(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
sum(S v, int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
cumsum(S v, int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
prod(S v, int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
cumprod(S v, int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
sumsq(S v, int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
min_d(S v, int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_min_with_real<S>::type
min_abs_d(S v, int dim = 1);

template<class S> inline
typename details::enable_if_scal_ret_the_same<S>::type
min(S v) 
{ 
	return min_d(v,1);
};

template<class S> inline
typename details::enable_if_scal_ret_min_with_real<S>::type
min_abs(S v) 
{ 
	return min_abs_d(v,1);
};

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
max_d(S v, int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_min_with_real<S>::type
max_abs_d(S v, int dim = 1);

template<class S> inline
typename details::enable_if_scal_ret_the_same<S>::type
max(S v)
{
	return max_d(v,1);
};
template<class S> inline
typename details::enable_if_scal_ret_min_with_real<S>::type
max_abs(S v)
{
	return max_abs_d(v,1);
};

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
mean(S v, int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
std(S v,int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
all(S v,int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
any(S v,int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
all(S v,const test_function& t,int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
any(S v,const test_function& t,int dim = 1);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
is_inf(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
is_nan(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_bool<S>::type
is_finite(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_min_with_real<S>::type
real(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_min_with_real<S>::type
imag(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_min_with_real<S>::type
abs(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_real<S>::type
arg(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_real<S>::type
angle(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
conj(S m);


template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
floor(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
ceil(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
round(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
fix(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
trunc(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_the_same<S>::type
sign(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_int<S>::type
ifloor(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_int<S>::type
iceil(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_int<S>::type
iround(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_int<S>::type
ifix(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_int<S>::type
itrunc(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_int<S>::type
isign(S A);


template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
pow2(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
exp(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
sin(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
cos(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
tan(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
cot(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
sec(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
csc(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
atan(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
acot(S m);


template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
sinh(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
cosh(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
tanh(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
coth(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
sech(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
csch(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
asinh(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
acsch(S A);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_real<S1,S2>::type
atan2(S1 A,S2 B);


template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
sqrt(S m, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
log(S m, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
log2(S m, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
log10(S m, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
asin(S m, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
acos(S m, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
asec(S A, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
acsc(S A, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
acosh(S A, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
atanh(S A, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
acoth(S A, bool allow_convert_to_complex = true);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_matrix<S>::type
asech(S A, bool allow_convert_to_complex = true);


template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
sqrt_nc(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
log_nc(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
log2_nc(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
log10_nc(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
asin_nc(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
acos_nc(S m);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
asec_nc(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
acsc_nc(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
acosh_nc(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
atanh_nc(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
acoth_nc(S A);

template<class S> MMLIB_EXPORT
typename details::enable_if_scal_ret_max_with_real<S>::type
asech_nc(S A);

};