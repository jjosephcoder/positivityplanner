/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <iostream>
#include <vector>
#include "mmlib/details/matrix_fwd.h"
#include "mmlib/details/struct_flag.h"

namespace boost
{
    class mutex;
};

namespace mmlib 
{

class output_stream
{
    private:
        boost::mutex*   m_mutex;

    private:
        std::ostream& stream;

    private:
        output_stream(const output_stream& os);
        output_stream& operator=(const output_stream& os);

    public:
        output_stream(std::ostream& of);
        ~output_stream();

        void    disp(std::stringstream& of);
};

#pragma warning(push)
#pragma warning(disable:4251)   //warning C4251: 'mmlib::disp_stream::m_width' : class 'std::vector<_Ty>' needs to have dll-interface to be used by clients of class 'mmlib::disp_stream'

//all indices are 0-based except new_line and end_line which are 1-base (0 - column headers)
class MMLIB_EXPORT disp_stream
{
	private:
		output_stream&	        m_stream;
        std::vector<Integer>    m_width;
        enums::value_type       m_vt;
        std::stringstream       m_buf;

	public:
		disp_stream(output_stream& os);
		virtual ~disp_stream() {};

		virtual void	    displaying_string();
		virtual void	    displaying_scalar(enums::value_type vt);
        virtual void	    displaying_dense_matrix(Integer r, Integer c, enums::value_type vt, 
                                                    details::struct_flag_impl::struct_type t);
		virtual void	    displaying_sparse_matrix(Integer r, Integer c, Integer nz, enums::value_type vt,
                                                    details::struct_flag_impl::struct_type t);

		virtual void	    start_display();
		virtual void	    end_display();

        virtual void	    new_line(Integer line);
		virtual void	    end_line(Integer line);
        virtual Integer     new_line_width() const;
        virtual Integer     end_line_width() const;

        virtual void        disp_elem(Integer width, const std::string& s);
        virtual void        disp_elem(Integer width, Integer r);
        virtual void        disp_elem(Integer width, Real r);
        virtual void        disp_elem(Integer width, const Complex& r);
        virtual void        disp_elem(Integer width, const Object& r);        
        virtual void        disp_row_header(Integer r, Integer w);
        virtual void        disp_first_col_separator(Integer w);
        virtual void        disp_col_separator(Integer w, Integer c);
        virtual void        disp_col_header_row(Integer w);
        virtual void        disp_col_header_1sep(Integer w);
        virtual void        disp_col_header_col(Integer c, Integer w);
        virtual void        disp_col_header_col_separator(Integer c, Integer w);
        virtual bool        do_disp_first_row_separator() const;
        virtual void        disp_first_row_separator(Integer w);
        virtual void        disp_sparse_separator(Integer w);

        virtual Integer     get_min_width(Integer v) const;
        virtual Integer     get_min_width(Real v) const;
        virtual Integer     get_min_width(const Complex& v) const;
        virtual Integer     get_min_width(const Object& v) const;
        virtual Integer     get_preffered_width(enums::value_type vt) const;
        virtual void        set_column_min_width(Integer c, Integer width);
        virtual Integer     get_column_width(Integer c) const;
        virtual Integer	    get_column_label_width(Integer c) const;
        virtual Integer	    get_col_separator_width() const;        
        virtual Integer	    get_sparse_separator_width() const;

        virtual Integer     get_row_headers_width() const;
        virtual Integer	    get_first_col_separator_width() const;        
        virtual Integer	    get_ternimal_width() const;                

		virtual Integer	    max_matrix_cols() const;
        virtual Integer	    max_matrix_rows() const;
		
        //if row or col == -1, then insert continuation mark
		virtual void	    sparse_row(Integer row,Integer col, Integer width_r, Integer width_c);

		virtual void	    display_empty_matrix(Integer r, Integer c);	

		std::ostream&	    get_stream()	{ return m_buf; };
        std::string         get_struct_name(details::struct_flag_impl::struct_type) const;
        std::string         get_value_name(enums::value_type vt) const;

	private:
		disp_stream(const disp_stream&);
		disp_stream& operator=(const disp_stream&);
};

#pragma warning(pop)
}