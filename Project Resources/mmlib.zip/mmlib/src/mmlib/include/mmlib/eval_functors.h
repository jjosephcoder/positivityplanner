/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/matrix_fwd.h"

namespace mmlib
{

class MMLIB_EXPORT scalar_function
{
    protected:
        typedef details::type_info type_info;
	public:
		virtual ~scalar_function(){};

		virtual enums::value_type return_value(enums::value_type,type_info in, type_info& ret) const = 0;

		virtual void eval(Integer v, Integer& ret) const = 0;
		virtual void eval(Integer v, Real& ret) const = 0;
		virtual void eval(Integer v, Complex& ret) const = 0;
        virtual void eval(Integer v, Object& ret) const = 0;

		virtual void eval(Real v, Integer& ret) const = 0;
		virtual void eval(Real v, Real& ret) const = 0;
		virtual void eval(Real v, Complex& ret) const = 0;
        virtual void eval(Real v, Object& ret) const = 0;

		virtual void eval(const Complex& v, Integer& ret) const = 0;
		virtual void eval(const Complex& v, Real& ret) const = 0;
		virtual void eval(const Complex& v, Complex& ret) const = 0;
        virtual void eval(const Complex& v, Object& ret) const = 0;

		virtual void eval(const Object& v, Integer& ret) const = 0;
		virtual void eval(const Object& v, Real& ret) const = 0;
		virtual void eval(const Object& v, Complex& ret) const = 0;
        virtual void eval(const Object& v, Object& ret) const = 0;
};

template<class derived>
class scalar_function_templ : public scalar_function
{
	public:
		virtual enums::value_type return_value(enums::value_type,type_info in, type_info& ret) const;

		virtual void eval(Integer v, Integer& ret) const;
		virtual void eval(Integer v, Real& ret) const;
		virtual void eval(Integer v, Complex& ret) const;
        virtual void eval(Integer v, Object& ret) const;

		virtual void eval(Real v, Integer& ret) const;
		virtual void eval(Real v, Real& ret) const;
		virtual void eval(Real v, Complex& ret) const;
        virtual void eval(Real v, Object& ret) const;

		virtual void eval(const Complex& v, Integer& ret) const;
		virtual void eval(const Complex& v, Real& ret) const;
		virtual void eval(const Complex& v, Complex& ret) const;
        virtual void eval(const Complex& v, Object& ret) const;

		virtual void eval(const Object& v, Integer& ret) const;
		virtual void eval(const Object& v, Real& ret) const;
		virtual void eval(const Object& v, Complex& ret) const;
        virtual void eval(const Object& v, Object& ret) const;
};

class MMLIB_EXPORT test_function
{
	public:
		virtual ~test_function() {};
		virtual bool eval(Integer) const = 0;
		virtual bool eval(Real) const = 0;
		virtual bool eval(const Complex&) const = 0;
        virtual bool eval(const Object&) const = 0;
};

template<class derived>
class test_function_templ : public test_function
{
	public:
		virtual bool eval(Integer val) const;
		virtual bool eval(Real val) const;
		virtual bool eval(const Complex& val) const;
        virtual bool eval(const Object&) const;
};

};

#include "mmlib/details/eval_functors.inl"
