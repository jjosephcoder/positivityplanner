/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/matrix.h"
#include "mmlib/details/enablers.h"

namespace mmlib
{

MMLIB_EXPORT Matrix		    plus(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix		    minus(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix		    mmul(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix		    mdiv(const Matrix& A, const Matrix& B);

inline Matrix               chain_mult(const Matrix& A1, const Matrix& A2)          {return mmul(A1,A2);};
MMLIB_EXPORT Matrix          chain_mult(const Matrix& A1, const Matrix& A2, const Matrix& A3);
MMLIB_EXPORT Matrix          chain_mult(const Matrix& A1, const Matrix& A2, const Matrix& A3,
                                       const Matrix& A4);
MMLIB_EXPORT Matrix          chain_mult(const Matrix& A1, const Matrix& A2, const Matrix& A3,
                                       const Matrix& A4, const Matrix& A5);
MMLIB_EXPORT Matrix          chain_mult(const Matrix& A1, const Matrix& A2, const Matrix& A3,
                                       const Matrix& A4, const Matrix& A5, const Matrix& A6);

inline Matrix			    operator+(const Matrix& A, const Matrix& B)				{return plus(A,B); };
inline Matrix			    operator-(const Matrix& A, const Matrix& B)				{return minus(A,B);};
inline Matrix			    operator*(const Matrix& A, const Matrix& B)				{return mmul(A,B); };
inline Matrix			    operator/(const Matrix& A, const Matrix& B)				{return mdiv(A,B); };

MMLIB_EXPORT Matrix			mul(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			div(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			idiv(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			pow(const Matrix& A, const Matrix& B, bool allow_convert_to_complex = true);
inline Matrix				pow_nc(const Matrix& A, const Matrix& B)                { return pow(A,B,false); };
MMLIB_EXPORT Matrix			max(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			min(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			xor(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			rem(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			mod(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			kron(const Matrix& A, const Matrix& B);

MMLIB_EXPORT Matrix			or(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			and(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			eeq(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			neq(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			lt(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			leq(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			gt(const Matrix& A, const Matrix& B);
MMLIB_EXPORT Matrix			geq(const Matrix& A, const Matrix& B);

inline Matrix				operator|(const Matrix& A, const Matrix& B)		{return or(A,B);	};
inline Matrix				operator&(const Matrix& A, const Matrix& B)		{return and(A,B);	};
inline Matrix				operator==(const Matrix& A, const Matrix& B)	{return eeq(A,B);	};
inline Matrix				operator!=(const Matrix& A, const Matrix& B)	{return neq(A,B);	};
inline Matrix				operator<(const Matrix& A, const Matrix& B)		{return lt(A,B);	};
inline Matrix				operator<=(const Matrix& A, const Matrix& B)	{return leq(A,B);	};
inline Matrix				operator>(const Matrix& A, const Matrix& B)		{return gt(A,B);	};
inline Matrix				operator>=(const Matrix& A, const Matrix& B)	{return geq(A,B);	};

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
plus(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
minus(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
mmul(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max_real<S1,S2>::type
mdiv(S1 A, S2 B);

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_max_op<S1,S2>::type
operator-(S1 A, S2 B)	{ return minus(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_max_op<S1,S2>::type
operator+(S1 A, S2 B)	{ return plus(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_max_op<S1,S2>::type
operator*(S1 A, S2 B)	{ return mmul(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_max_op<S1,S2>::type
operator/(S1 A, S2 B)	{ return mdiv(A,B); };

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
mul(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max_real<S1,S2>::type
div(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
idiv(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
max(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
min(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
xor(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
mod(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
rem(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max<S1,S2>::type
kron(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
or(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
and(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
eeq(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
neq(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
lt(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
geq(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
leq(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
gt(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_bool<S1,S2>::type
geq(S1 A, S2 B);


template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator|(S1 A, S2 B)		{ return or(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator||(S1 A, S2 B)		{ return or(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator&(S1 A, S2 B)		{ return and(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator&&(S1 A, S2 B)		{ return and(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator==(S1 A, S2 B)		{ return eeq(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator!=(S1 A, S2 B)		{ return neq(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator<(S1 A, S2 B)		{ return lt(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator<=(S1 A, S2 B)		{ return leq(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator>(S1 A, S2 B)		{ return gt(A,B); };

template<class S1, class S2> inline
typename details::enable_if_scal2_ret_bool_op<S1,S2>::type
operator>=(S1 A, S2 B)		{ return geq(A,B); };


template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_matrix<S1,S2>::type
pow(S1 A, S2 B, bool allow_convert_to_complex = true);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_pow<S1,S2>::type
pow_scal(S1 A, S2 B);

template<class S1, class S2> MMLIB_EXPORT
typename details::enable_if_scal2_ret_max_real<S1,S2>::type
pow_nc(S1 A, S2 B);
};