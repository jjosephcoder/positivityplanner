/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/matrix.h"

namespace mmlib
{

namespace details
{
    template<class T, class S>
    struct convert_scalar_imp
    {
        static T eval(S val);
    };
};

inline MMLIB_EXPORT Matrix   delrows(const Matrix& A,const colon& c)		{ return A.delrows(c); };
inline MMLIB_EXPORT Matrix   delcols(const Matrix& A,const colon& c)		{ return A.delcols(c); };

MMLIB_EXPORT Matrix			horzcat(const Matrix& A,const Matrix& B);
MMLIB_EXPORT Matrix			vertcat(const Matrix& A,const Matrix& B);
MMLIB_EXPORT Matrix			repmat(const Matrix &A, Integer m, Integer n);

MMLIB_EXPORT Matrix 		    full(const Matrix &m);
MMLIB_EXPORT Matrix			sparse(const Matrix &m);
MMLIB_EXPORT Matrix			band(const Matrix &m);
MMLIB_EXPORT inline Matrix	clone(const Matrix& m)						{ return m.clone();	    };
MMLIB_EXPORT Matrix			trans(const Matrix &m);
MMLIB_EXPORT Matrix			ctrans(const Matrix &m);
MMLIB_EXPORT Matrix			vec(const Matrix &m);

MMLIB_EXPORT Matrix			tril(const Matrix &m,Integer d = 0);
MMLIB_EXPORT Matrix			triu(const Matrix &m,Integer d = 0);

MMLIB_EXPORT Matrix			flipud(const Matrix &m);
MMLIB_EXPORT Matrix			fliplr(const Matrix &m);
MMLIB_EXPORT Matrix			reshape(const Matrix &A,Integer m,Integer n);

MMLIB_EXPORT Matrix			get_diag(const Matrix& m, Integer d = 0);
MMLIB_EXPORT Matrix			rot90(const Matrix& m,Integer n=1);

MMLIB_EXPORT Matrix			convert(const Matrix& A,enums::mat_type new_type);
MMLIB_EXPORT Matrix		    convert_object(const Matrix& A, details::type_info ti);

//if min != -1, then searching is stopped, if number of sub- or superdiagonals is higher
//than min
MMLIB_EXPORT Integer         get_ld(const Matrix& A, Integer min = -1);
MMLIB_EXPORT Integer         get_ud(const Matrix& A, Integer min = -1);

MMLIB_EXPORT bool            is_tril(const Matrix& A);
MMLIB_EXPORT bool            is_triu(const Matrix& A);

inline Integer		        rows(const Matrix& A)   { return A.rows(); };
inline Integer				cols(const Matrix& A)   { return A.cols(); };
inline Integer				ldiags(const Matrix& A) { return A.ldiags();};
inline Integer				udiags(const Matrix& A) { return A.udiags(); };
inline Integer				nnz(const Matrix& A)    { return A.nnz(); };
inline Integer				length(const Matrix& A) { return A.length(); };
inline Real					numel(const Matrix& A)  { return A.numel(); };
inline int_tup_2			size(const Matrix& A)   { return A.size(); }; 	

MMLIB_EXPORT Matrix          nnz(const Matrix& A, Integer dim);

template<class T,class S> 
typename details::enable_if_scal_scal<T,S,details::promote_scalar<T>>::type
convert_scalar(S val)
{
    typedef typename details::promote_scalar<T>::type TP;
    typedef typename details::promote_scalar<S>::type SP;
    return details::convert_scalar_imp<TP,SP>::eval(val);
};

};