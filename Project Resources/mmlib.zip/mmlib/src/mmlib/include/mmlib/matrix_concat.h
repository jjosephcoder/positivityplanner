/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/matrix_fwd.h"
#include "mmlib/details/mpl.h"
#include "mmlib/details/isa.h"
#include "boost/shared_ptr.hpp"

namespace mmlib
{

#pragma warning(push)
#pragma warning(disable:4251)   //warning C4251: 'mmlib::mat_row::m_data' : class 'boost::shared_ptr<T>' needs to have dll-interface to be used by clients of class 'mmlib::mat_row'

//instances of this class should be used in single thread only
class MMLIB_EXPORT mat_row
{
	private:
        typedef boost::shared_ptr<details::mat_cons_data> ref_ptr;

	private:
		Integer					m_rows;
		Integer					m_cols;
		Integer					m_nnz;
		Integer					m_value_code;

		ref_ptr					m_data;

	public:
		mat_row();		
		~mat_row();		

		mat_row(const mat_row&);
		mat_row&				operator=(const mat_row&);

		template<class S>
		typename details::enable_if<details::is_scalar<S>::value,mat_row&>::type
								operator,(S);
		mat_row&				operator,(const Matrix&);
		mat_row&				operator,(const mat_row&);
		mat_row&				operator,(const mat_col&);

		Matrix					to_matrix() const;
		void					make_unique();
        details::type_info      get_ti() const;

		friend mat_col;
		template<class M> friend struct details::sparse_matrix_constructor_row;
		template<class M> friend struct details::dense_matrix_constructor_row;
		template<class M> friend struct details::sparse_matrix_constructor_col;
		template<class M> friend struct details::dense_matrix_constructor_col;

	private:
		void					add_mat(const Matrix& mat);
		void					add_col(const mat_col&);
		void					add_row(const mat_row&);
		void					add_int(Integer val);
		void					add_real(Real val);
		void					add_complex(Real re,Real im);

		template<class S>
		mat_row&				add_scalar(S val);
		template<class S>
		void					add_scalar_impl(S val);
};

//instances of this class should be used in single thread only
class MMLIB_EXPORT mat_col
{
	private:
        typedef boost::shared_ptr<details::mat_cons_data> ref_ptr;

	private:
		Integer					m_rows;
		Integer					m_cols;
		Integer					m_nnz;
		Integer					m_value_code;

		ref_ptr					m_data;

	public:
		mat_col();		

		mat_col(const mat_col&);
		mat_col&				operator=(const mat_col&);

		~mat_col();

		template<class S>
		typename details::enable_if<details::is_scalar<S>::value,mat_col&>::type
								operator,(S);
		mat_col&				operator,(const Matrix&);
		mat_col&				operator,(const mat_row&);
		mat_col&				operator,(const mat_col&);
        details::type_info      get_ti() const;

		Matrix					to_matrix() const;
		void					make_unique();

		friend mat_row;
		template<class M> friend struct details::sparse_matrix_constructor_row;
		template<class M> friend struct details::dense_matrix_constructor_row;
		template<class M> friend struct details::sparse_matrix_constructor_col;
		template<class M> friend struct details::dense_matrix_constructor_col;

	private:
		void					add_mat(const Matrix& mat);
		void					add_col(const mat_col&);
		void					add_row(const mat_row&);
		void					add_int(Integer val);
		void					add_real(Real val);
		void					add_complex(Real re, Real im);

		template<class S>
		mat_col&				add_scalar(S val);
		template<class S>
		void					add_scalar_impl(S val);
};

#pragma warning(pop)

};