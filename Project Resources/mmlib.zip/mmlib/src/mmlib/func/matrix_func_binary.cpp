/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
 
#include "mmlib/mmlib_header.h"
#include "mmlib/visitors/basic_visitor.inl" 
#include "mmlib/visitors/basic_visitor_arg.inl" 
#include "mmlib/visitors/basic_visitor_un.inl" 
#include "mmlib/func/test_functor.h" 

#pragma warning( push )
#pragma warning(disable:4127)	// conditional expression is constant

namespace mmlib
{

namespace gd = mmlib::details;
namespace grd = mmlib::raw::details;

//===============================================================================
//								HELPERS
//===============================================================================

namespace details
{

template<class ret>
ret pow_scal_helper<ret>::eval(type_info ti, ret A, ret B)
{
    return grd::pow_helper<ret,ret>::eval(ti,A,B);
};

template<bool iso,class T1, class T2>
struct pow_helper_impl
{
	typedef typename max_type2<T1,T2,Real>::type ret_type;
	static Matrix eval(gd::type_info ti, T1 A, T2 B, bool allow_conv)
    {
	    static const bool isc = gd::is_equal<T1,Complex>::value 
							    || gd::is_equal<T2,Complex>::value;	
	    if (!allow_conv)
	    {
		    return grd::pow_helper<T1,T2>::eval(ti,A,B);
	    };
	    if (isc || test_range_pow<T1,T2>::eval(A,B))
	    {
		    return grd::pow_helper<T1,T2>::eval(ti,A,B);
	    };
	    return grd::pow_helper<Complex,Complex>::eval(ti,A,B);
    };
};
template<class T1, class T2>
struct pow_helper_impl<true,T1,T2>
{
	static Matrix eval(gd::type_info ti, T1 A, T2 B, bool )
    {
	    return grd::pow_helper<T1,T2>::eval(ti,A,B);
    };
};
template<class T1, class T2>
Matrix pow_helper<T1,T2>::eval(gd::type_info ti, T1 A, T2 B, bool allow_conv)
{
	static const bool iso = gd::is_equal<T1,Object>::value 
							|| gd::is_equal<T2,Object>::value;
    return pow_helper_impl<iso,T1,T2>::eval(ti,A,B,allow_conv);
};
template<class T1, class T2>
typename pow_helper<T1,T2>::ret_type 
pow_helper<T1,T2>::eval_nc(gd::type_info ti, T1 A, T2 B)
{
	return grd::pow_helper<T1,T2>::eval(ti,A,B);
};

template<bool iso,class T, class M>
struct pow_helper_scal_mat_impl
{
	static Matrix eval(T val, const M& mat, bool allow_conv)
    {
	    static const bool isc = gd::is_equal<T,Complex>::value 
							    || gd::is_equal<M,Complex>::value;	

	    if (!allow_conv)
	    {
		    return raw::pow(val,mat);
	    };
	    if (isc || val >= 0)
	    {
		    return raw::pow(val,mat);
	    };

	    if (test_range<M::value_type,M::struct_type,test_is_int>::eval(mat))
	    {
		    return raw::pow(val,mat);
	    };
	    return raw::pow(Complex(val),mat);
    };
};
template<class T, class M>
struct pow_helper_scal_mat_impl<true,T,M>
{
	static Matrix eval(T val, const M& mat, bool )
    {
	    return raw::pow(val,mat);
    };
};

template<class T, class M>
Matrix pow_helper_scal_mat<T,M>::eval(T val, const M& mat, bool allow_conv)
{
	static const bool iso = gd::is_equal<T,Object>::value 
							|| gd::is_equal<M,Object>::value;	
    return pow_helper_scal_mat_impl<iso,T,M>::eval(val,mat,allow_conv);
};

template<bool iso,class M, class T>
struct pow_helper_mat_scal_impl
{
	static Matrix eval(const M& mat,T val, bool allow_conv)
    {
	    static const bool isc = gd::is_equal<T,Complex>::value 
							    || gd::is_equal<M,Complex>::value;

	    if (!allow_conv)
	    {
		    return raw::pow(mat,val);
	    };

	    if (isc || is_conv_to_integer<T>::eval(val))
	    {
		    return raw::pow(mat,val);
	    };

	    if (test_range<M::value_type,M::struct_type,test_geq_zero>::eval(mat))
	    {
		    return raw::pow(mat,val);
	    };

	    return raw::pow(mat,Complex(val));
    };
};
template<class M, class T>
struct pow_helper_mat_scal_impl<true,M,T>
{
	static Matrix eval(const M& mat,T val, bool )
    {
	    return raw::pow(mat,val);
    };
};

template<class M,class T>
Matrix pow_helper_mat_scal<M,T>::eval(const M& mat,T val, bool allow_conv)
{
	static const bool iso = gd::is_equal<T,Object>::value 
							|| gd::is_equal<M,Object>::value;	
    return pow_helper_mat_scal_impl<iso,M,T>::eval(mat,val,allow_conv);
};

template<bool iso,class M1, class M2>
struct pow_helper_mat_mat_impl
{
	static Matrix eval(const M1& mat1,const M2& mat2, bool allow_conv)
    {
	    static const bool isc = gd::is_equal<M1::value_type,Complex>::value 
							    || gd::is_equal<M2::value_type,Complex>::value;

	    typedef M1::value_type val_1;
	    typedef M2::value_type val_2;
	    if (!allow_conv)
	    {
		    return raw::pow(mat1,mat2);
	    };

	    if (isc || test_range2<M1,M2,test_range_pow<val_1,val_2>>::eval(mat1,mat2))
	    {
		    return raw::pow(mat1,mat2);
	    };
    	
	    if (mat1.nnz() < mat2.nnz())
	    {
		    typedef raw::Matrix<Complex,M1::struct_type> matrix_type;
            return raw::pow(raw::converter<matrix_type,M1>::eval(gd::get_raw_ti(),mat1),mat2);
	    }
	    else
	    {
		    typedef raw::Matrix<Complex,M2::struct_type> matrix_type;
		    return raw::pow(mat1,raw::converter<matrix_type,M2>::eval(gd::get_raw_ti(),mat2));
	    };
    };
};
template<class M1, class M2>
struct pow_helper_mat_mat_impl<true,M1,M2>
{
	static Matrix eval(const M1& mat1,const M2& mat2, bool )
    {
	    return raw::pow(mat1,mat2);
    };
};

template<class M1,class M2>
Matrix pow_helper_mat_mat<M1,M2>::eval(const M1& mat1,const M2& mat2, bool allow_conv)
{
    typedef M1::value_type val_1;
    typedef M2::value_type val_2;
	static const bool iso = gd::is_equal<val_1,Object>::value 
							|| gd::is_equal<val_2,Object>::value;	

    return pow_helper_mat_mat_impl<iso,M1,M2>::eval(mat1,mat2,allow_conv);
};

};

//===============================================================================
//								OPERATORS
//===============================================================================
Matrix	mmlib::uminus(const Matrix& A)
{
	switch(A.matrix_type())
	{
		case enums::integer_scalar:
		{
			return -gd::matrix_data_accesser::get_val_int(A);
		}
		case enums::real_scalar:
		{
			return -gd::matrix_data_accesser::get_val_real(A);
		}
		case enums::complex_scalar:
		{
			return -gd::matrix_data_accesser::get_val_complex(A);
		}
		case enums::object_scalar:
		{
			return -gd::matrix_data_accesser::get_val_object(A);
		}
	};
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SGN_MIN>
                    ::make<const Matrix&>(A);
};
Matrix neg(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_NEG>
                    ::make<const Matrix&>(A);
};
Matrix is_true(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_IS_TRUE>
                    ::make<const Matrix&>(A);
};

//===============================================================================
//								OPERATORS
//===============================================================================
Matrix	mmlib::plus(const Matrix& A, const Matrix& B)
{
	switch(A.matrix_type())
	{
		case enums::integer_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   +gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   +gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   +gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   +gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
		case enums::real_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   +gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   +gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   +gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   +gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
		case enums::complex_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   +gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   +gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   +gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   +gd::matrix_data_accesser::get_val_complex(B);
				}
			};
			break;
		}
		case enums::object_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   +gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   +gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   +gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   +gd::matrix_data_accesser::get_val_complex(B);
				}
			};
			break;
		}
	};
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_PLUS);
};

Matrix	mmlib::minus(const Matrix& A, const Matrix& B)
{
	switch(A.matrix_type())
	{
		case enums::integer_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   -gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   -gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   -gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   -gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
		case enums::real_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   -gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   -gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   -gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   -gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
		case enums::complex_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   -gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   -gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   -gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   -gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
		case enums::object_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   -gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   -gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   -gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   -gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
	};
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_MINUS);
};

Matrix	mmlib::mmul(const Matrix& A, const Matrix& B)
{
	switch(A.matrix_type())
	{
		case enums::integer_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   *gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   *gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   *gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_int(A)
						   *gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
		case enums::real_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   *gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   *gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   *gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_real(A)
						   *gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
		case enums::complex_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   *gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   *gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   *gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_complex(A)
						   *gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
		case enums::object_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   *gd::matrix_data_accesser::get_val_int(B);
				}
				case enums::real_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   *gd::matrix_data_accesser::get_val_real(B);
				}
				case enums::complex_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   *gd::matrix_data_accesser::get_val_complex(B);
				}
				case enums::object_scalar:
				{
					return gd::matrix_data_accesser::get_val_object(A)
						   *gd::matrix_data_accesser::get_val_object(B);
				}
			};
			break;
		}
	};
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_MULT);
};
Matrix	mmlib::mdiv(const Matrix& A, const Matrix& B)
{
	switch(A.matrix_type())
	{
		case enums::integer_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					Integer val1 = gd::matrix_data_accesser::get_val_int(A);
					Integer val2 = gd::matrix_data_accesser::get_val_int(B);
                    return grd::div_helper<Integer,Integer>::eval(gd::get_raw_ti(),val1,val2);
				}
				case enums::real_scalar:
				{
					Integer val1 = gd::matrix_data_accesser::get_val_int(A);
					Real   val2 = gd::matrix_data_accesser::get_val_real(B);
					return grd::div_helper<Integer,Real>::eval(gd::get_raw_ti(),val1,val2);
				}
				case enums::complex_scalar:
				{
					Integer val1 = gd::matrix_data_accesser::get_val_int(A);
					Complex   val2 = gd::matrix_data_accesser::get_val_complex(B);
					return grd::div_helper<Integer,Complex>::eval(gd::get_raw_ti(),val1,val2);
				}
				case enums::object_scalar:
				{
					Integer val1 = gd::matrix_data_accesser::get_val_int(A);
					Object   val2 = gd::matrix_data_accesser::get_val_object(B);
                    gd::type_info ti = gd::return_div_ti<Integer,Object>::eval(val1,val2);
					return grd::div_helper<Integer,Object>::eval(ti,val1,val2);
				}
			};
			break;
		}
		case enums::real_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					Real val1 = gd::matrix_data_accesser::get_val_real(A);
					Integer val2 = gd::matrix_data_accesser::get_val_int(B);
					return grd::div_helper<Real,Integer>::eval(gd::get_raw_ti(),val1,val2);
				}
				case enums::real_scalar:
				{
					Real val1 = gd::matrix_data_accesser::get_val_real(A);
					Real   val2 = gd::matrix_data_accesser::get_val_real(B);
					return grd::div_helper<Real,Real>::eval(gd::get_raw_ti(),val1,val2);
				}
				case enums::complex_scalar:
				{
					Real val1 = gd::matrix_data_accesser::get_val_real(A);
					Complex   val2 = gd::matrix_data_accesser::get_val_complex(B);
					return grd::div_helper<Real,Complex>::eval(gd::get_raw_ti(),val1,val2);
				}
				case enums::object_scalar:
				{
					Real val1 = gd::matrix_data_accesser::get_val_real(A);
					Object   val2 = gd::matrix_data_accesser::get_val_object(B);
                    gd::type_info ti = gd::return_div_ti<Real,Object>::eval(val1,val2);
					return grd::div_helper<Real,Object>::eval(ti,val1,val2);
				}
			};
			break;
		}
		case enums::complex_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					Complex val1 = gd::matrix_data_accesser::get_val_complex(A);
					Integer val2 = gd::matrix_data_accesser::get_val_int(B);
					return grd::div_helper<Complex,Integer>::eval(gd::get_raw_ti(),val1,val2);
				}
				case enums::real_scalar:
				{
					Complex val1 = gd::matrix_data_accesser::get_val_complex(A);
					Real   val2 = gd::matrix_data_accesser::get_val_real(B);
					return grd::div_helper<Complex,Real>::eval(gd::get_raw_ti(),val1,val2);
				}
				case enums::complex_scalar:
				{
					Complex val1 = gd::matrix_data_accesser::get_val_complex(A);
					Complex   val2 = gd::matrix_data_accesser::get_val_complex(B);
					return grd::div_helper<Complex,Complex>::eval(gd::get_raw_ti(),val1,val2);
				}
				case enums::object_scalar:
				{
					Complex val1 = gd::matrix_data_accesser::get_val_complex(A);
					Object   val2 = gd::matrix_data_accesser::get_val_object(B);
                    gd::type_info ti = gd::return_div_ti<Complex,Object>::eval(val1,val2);
					return grd::div_helper<Complex,Object>::eval(ti,val1,val2);
				}
			};
			break;
		}
		case enums::object_scalar:
		{
			switch(B.matrix_type())
			{
				case enums::integer_scalar:
				{
					Object val1 = gd::matrix_data_accesser::get_val_object(A);
					Integer val2 = gd::matrix_data_accesser::get_val_int(B);
                    gd::type_info ti = gd::return_div_ti<Object,Integer>::eval(val1,val2);
					return grd::div_helper<Object,Integer>::eval(ti,val1,val2);
				}
				case enums::real_scalar:
				{
					Object val1 = gd::matrix_data_accesser::get_val_object(A);
					Real   val2 = gd::matrix_data_accesser::get_val_real(B);
                    gd::type_info ti = gd::return_div_ti<Object,Real>::eval(val1,val2);
					return grd::div_helper<Object,Real>::eval(ti,val1,val2);
				}
				case enums::complex_scalar:
				{
					Object val1 = gd::matrix_data_accesser::get_val_object(A);
					Complex   val2 = gd::matrix_data_accesser::get_val_complex(B);
                    gd::type_info ti = gd::return_div_ti<Object,Complex>::eval(val1,val2);
					return grd::div_helper<Object,Complex>::eval(ti,val1,val2);
				}
				case enums::object_scalar:
				{
					Object val1 = gd::matrix_data_accesser::get_val_object(A);
					Object val2 = gd::matrix_data_accesser::get_val_object(B);
                    gd::type_info ti = gd::return_div_ti<Object,Object>::eval(val1,val2);
					return grd::div_helper<Object,Object>::eval(ti,val1,val2);
				}
			};
			break;
		}
	};
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_DIV);
};

Matrix mul(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_DMUL);	
};
Matrix max(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_MAX);
};
Matrix min(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_MIN);
};
Matrix div(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_DDIV);	
};
Matrix idiv(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_DIDIV);	
};



Matrix pow(const Matrix& A, const Matrix& B, bool allow_conv)
{
	if (allow_conv)
	{
        return details::basic_binary_visitor
                    ::make(A,B,details::binary_op::OP_POW);	
	}
	else
	{
        return details::basic_binary_visitor
                    ::make(A,B,details::binary_op::OP_POW_NC);
	}
};
Matrix xor(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_XOR);
};
Matrix mod(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_MOD);
};
Matrix rem(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_REM);
};

Matrix or(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_OR);
};
Matrix and(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_AND);
};
Matrix eeq(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_EEQ);
};
Matrix neq(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_NEQ);
};
Matrix lt(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_LT);
};
Matrix leq(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_LEQ);
};
Matrix gt(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_GT);
};
Matrix geq(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_GEQ);
};

Matrix	atan2(const Matrix &A,const Matrix &B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_ATAN2);
};
Matrix	kron(const Matrix& A, const Matrix& B)
{
    return details::basic_binary_visitor
                ::make(A,B,details::binary_op::OP_KRON);
};

};

#define MACRO_INS_SCAL(cl)									\
    template mmlib::gd::cl<mmlib::Object,mmlib::Object>;	    \
	template mmlib::gd::cl<mmlib::Complex,mmlib::Complex>;	    \
	template mmlib::gd::cl<mmlib::Complex,mmlib::Real>;		\
    template mmlib::gd::cl<mmlib::Complex,mmlib::Integer>;	    \
	template mmlib::gd::cl<mmlib::Real,mmlib::Complex>;		\
	template mmlib::gd::cl<mmlib::Real,mmlib::Real>;			\
	template mmlib::gd::cl<mmlib::Integer,mmlib::Integer>;     \
    template mmlib::gd::cl<mmlib::Integer,mmlib::Complex>;	    \
    template mmlib::gd::cl<mmlib::Integer,mmlib::Real>;		\
    template mmlib::gd::cl<mmlib::Real,mmlib::Integer>;		\

	//template mmlib::gd::cl<mmlib::Object,mmlib::Complex>;	\
	//template mmlib::gd::cl<mmlib::Object,mmlib::Real>;		\
	//template mmlib::gd::cl<mmlib::Object,mmlib::Integer>;	\
    //template mmlib::gd::cl<mmlib::Complex,mmlib::Object>;	\    
    //template mmlib::gd::cl<mmlib::Real,mmlib::Object>;		\    
    //template mmlib::gd::cl<mmlib::Integer,mmlib::Object>;	\		


MACRO_INS_SCAL(pow_helper);

template mmlib::gd::pow_scal_helper<mmlib::Real>;
template mmlib::gd::pow_scal_helper<mmlib::Complex>;
template mmlib::gd::pow_scal_helper<mmlib::Object>;

#pragma warning( pop )