/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/manip.h"
#include "mmlib/details/matrix_func_unary.inl"
#include "mmlib/visitors/basic_visitor_un.inl" 
#include "mmlib/visitors/basic_visitor_arg.inl" 
#include "mmlib/exception.h"
#include "mmlib/details/scalfunc_helpers.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/func/raw/vecfunc.h"
#include "mmlib/matrix_utils.h"
#include "mmlib/matrix_gen.h"

namespace mmlib
{

namespace details
{
	template<class T>
	T sum_helper<T>::eval(T A, int dim)
	{
		return raw::sum(A,dim);
	};

	template<class T>
	T cumsum_helper<T>::eval(T A, int dim)
	{
		return raw::cumsum(A,dim);
	};

	template<class T>
	T prod_helper<T>::eval(T A, int dim)
	{
		return raw::prod(A,dim);
	};

	template<class T>
	T cumprod_helper<T>::eval(T A, int dim)
	{
		return raw::cumprod(A,dim);
	};

	template<class T>
	T sumsq_helper<T>::eval(T A, int dim)
	{
		return raw::sumsq(A,dim);
	};

	template<class T>
	T min_helper<T>::eval(T A, int dim)
	{
		return raw::min_d(A,dim);
	};
	template<class T>
    typename min_helper<T>::TR
	min_helper<T>::eval_abs(T A, int dim)
	{
		return raw::min_abs_d(A,dim);
	};

	template<class T>
	T max_helper<T>::eval(T A, int dim)
	{
		return raw::max_d(A,dim);
	};
	template<class T>
    typename max_helper<T>::TR
	max_helper<T>::eval_abs(T A, int dim)
	{
		return raw::max_abs_d(A,dim);
	};

	template<class T>
	typename mean_helper<T>::R mean_helper<T>::eval(T A, int dim)
	{
		return raw::mean(A,dim);
	};

	template<class T>
	typename std_helper<T>::R std_helper<T>::eval(T A, int dim)
	{
		return raw::std(A,dim);
	};

	template<class T>
	bool all_helper<T>::eval(T A, int dim)
	{
		return raw::all(A,dim);
	};

	template<class T>
	bool all_helper<T>::eval(T A,int dim, const test_function& t)
	{
		return raw::all(A,t,dim);
	};

	template<class T>
	bool any_helper<T>::eval(T A, int dim)
	{
		return raw::any(A,dim);
	};

	template<class T>
	bool any_helper<T>::eval(T A,int dim, const test_function& t)
	{
		return raw::any(A,t,dim);
	};

};

Matrix Matrix::clone() const
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_CLONE>
                    ::make<const Matrix&>(*this);
};
Matrix mmlib::convert(const Matrix& A,enums::mat_type new_type)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_CONVERT>
                ::make<const Matrix&,int>(A,new_type);

};
Matrix mmlib::convert_object(const Matrix& A, details::type_info ti)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_CONVERT_OBJ>
                ::make<const Matrix&,details::type_info>(A,ti);

};
Matrix mmlib::full(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_FULL>
                    ::make<const Matrix&>(A);
};
Matrix mmlib::vec(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_VEC>
                    ::make<const Matrix&>(A);
};

Matrix mmlib::sparse(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SPARSE>
                    ::make<const Matrix&>(A);
};
Matrix mmlib::band(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_BAND>
                    ::make<const Matrix&>(A);
};

Matrix mmlib::trans(const Matrix& A) 
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_TRANS>
                ::make<const Matrix&>(A);
};
Matrix mmlib::ctrans(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_CTRANS>
                ::make<const Matrix&>(A);
};
Matrix mmlib::is_finite(const Matrix& A) 
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_IS_FINITE>
                ::make<const Matrix&>(A);
};
Matrix mmlib::is_nan(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_IS_NAN>
                ::make<const Matrix&>(A);
};
Matrix mmlib::is_inf(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_IS_INF>
                ::make<const Matrix&>(A);
};
Matrix mmlib::fliplr(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_FLIPLR>
                ::make<const Matrix&>(A);
};
Matrix mmlib::flipud(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_FLIPUD>
                ::make<const Matrix&>(A);
};
Matrix mmlib::reshape(const Matrix& A,Integer m, Integer n)
{
    return details::basic_unary_visitor_2<Matrix,details::unary_op::OP_RESHAPE>
                ::make<const Matrix&,Integer,Integer>(A,m,n);
};
Matrix mmlib::repmat(const Matrix &A, Integer m, Integer n)
{
    return details::basic_unary_visitor_2<Matrix,details::unary_op::OP_REPMAT>
                ::make<const Matrix&,Integer,Integer>(A,m,n);
};
Matrix mmlib::get_diag(const Matrix& A,Integer d)
{ 
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_DIAG>
                ::make<const Matrix&,Integer>(A,d);
};
Matrix mmlib::imag(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_IMAG>
                ::make<const Matrix&>(A);
};
Matrix mmlib::real(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_REAL>
                ::make<const Matrix&>(A);
};
Matrix mmlib::abs(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ABS>
                ::make<const Matrix&>(A);
};
Matrix mmlib::arg(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ARG>
                ::make<const Matrix&>(A);
};
Matrix mmlib::angle(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ARG>
                ::make<const Matrix&>(A);
};
Matrix mmlib::conj(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_CONJ>
                ::make<const Matrix&>(A);
};

Matrix mmlib::sqrt(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SQRT>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SQRT_NC>
                    ::make<const Matrix&>(A);
	}
};
Matrix mmlib::pow2(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_POW2>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::log(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_LOG>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_LOG_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::exp(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_EXP>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::log2(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_LOG2>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_LOG2_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::log10(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_LOG10>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_LOG10_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::floor(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_FLOOR>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::ceil(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_CEIL>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::round(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ROUND>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::fix(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_FIX>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::trunc(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_TRUNC>
                ::make<const Matrix&>(A);
};

Matrix	mmlib::ifloor(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_IFLOOR>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::iceil(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ICEIL>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::iround(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_IROUND>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::ifix(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_IFIX>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::itrunc(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ITRUNC>
                ::make<const Matrix&>(A);
};

Matrix	mmlib::sign(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SIGN>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::isign(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ISIGN>
                ::make<const Matrix&>(A);
};

Matrix	mmlib::sin(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SIN>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::cos(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_COS>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::tan(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_TAN>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::cot(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_COT>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::sec(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SEC>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::csc(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_CSC>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::asin(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ASIN>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ASIN_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::acos(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACOS>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACOS_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::atan(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ATAN>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::acot(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACOT>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::asec(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ASEC>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ASEC_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::acsc(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACSC>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACSC_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::sinh(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SINH>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::cosh(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_COSH>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::tanh(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_TANH>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::coth(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_COTH>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::sech(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SECH>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::csch(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_CSCH>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::asinh(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ASINH>
                ::make<const Matrix&>(A);
};
Matrix	mmlib::acosh(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACOSH>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACOSH_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::atanh(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ATANH>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ATANH_NC>
                    ::make<const Matrix&>(A);
	}
};
Matrix	mmlib::acoth(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACOTH>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACOTH_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::asech(const Matrix &A, bool ac)
{
	if (ac)
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ASECH>
                    ::make<const Matrix&>(A);
	}
	else
	{
        return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ASECH_NC>
                    ::make<const Matrix&>(A);
	};
};
Matrix	mmlib::acsch(const Matrix &A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_ACSCH>
                ::make<const Matrix&>(A);
};

Matrix mmlib::tril(const Matrix& A,Integer d)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_TRIL>
                ::make<const Matrix&,Integer>(A,d);
};
Matrix mmlib::triu(const Matrix& A,Integer d)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_TRIU>
                ::make<const Matrix&,Integer>(A,d);
};

Matrix mmlib::sum(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_SUM>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::cumsum(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_CUMSUM>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::prod(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_PROD>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::cumprod(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_CUMPROD>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::sumsq(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_SUMSQ>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::min_d(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_MIN>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::max_d(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_MAX>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::min_abs_d(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_MIN_ABS>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::max_abs_d(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_MAX_ABS>
                ::make<const Matrix&,Integer>(A,dim);
};
mat_tup_2 mmlib::min2(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<mat_tup_2,details::unary_op::OP_MIN2>
                ::make<const Matrix&,Integer>(A,dim);
};
mat_tup_2 mmlib::max2(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<mat_tup_2,details::unary_op::OP_MAX2>
                ::make<const Matrix&,Integer>(A,dim);
};
mat_tup_2 mmlib::min_abs2(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<mat_tup_2,details::unary_op::OP_MIN_ABS2>
                ::make<const Matrix&,Integer>(A,dim);
};
mat_tup_2 mmlib::max_abs2(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<mat_tup_2,details::unary_op::OP_MAX_ABS2>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::mean(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_MEAN>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::std(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_STD>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::any(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_ANY>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::all(const Matrix& A,int dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_ALL>
                ::make<const Matrix&,Integer>(A,dim);
};
Matrix mmlib::any(const Matrix& A,const test_function& t,int dim)
{
    return details::basic_unary_visitor_2<Matrix,details::unary_op::OP_ANY_T>
                ::make<const Matrix&,const test_function&,Integer>(A,t,dim);
};
Matrix mmlib::all(const Matrix& A,const test_function& t,int dim)
{
    return details::basic_unary_visitor_2<Matrix,details::unary_op::OP_ALL_T>
                ::make<const Matrix&,const test_function&,Integer>(A,t,dim);
};
Matrix mmlib::find(const Matrix& A)
{
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_FIND>
                ::make<const Matrix&>(A);
};
Matrix mmlib::find(const Matrix& A,const test_function& t)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_FIND_T>
                ::make<const Matrix&,const test_function&>(A,t);
};
mat_tup_2 mmlib::find2(const Matrix& A)
{
    return details::basic_unary_visitor_0<mat_tup_2,details::unary_op::OP_FIND_2>
                ::make<const Matrix&>(A);
};
mat_tup_2 mmlib::find2(const Matrix& A,const test_function& t)
{
    return details::basic_unary_visitor_1<mat_tup_2,details::unary_op::OP_FIND_T_2>
                ::make<const Matrix&,const test_function&>(A,t);
};
mat_tup_3 mmlib::find3(const Matrix& A)
{
    return details::basic_unary_visitor_0<mat_tup_3,details::unary_op::OP_FIND_3>
                ::make<const Matrix&>(A);
};
mat_tup_3 mmlib::find3(const Matrix& A,const test_function& t)
{
    return details::basic_unary_visitor_1<mat_tup_3,details::unary_op::OP_FIND_T_3>
                ::make<const Matrix&,const test_function&>(A,t);
};
Matrix mmlib::sort(const Matrix& A, int dim, bool asceding)
{ 
    Matrix tmp = details::basic_unary_visitor_1<Matrix,details::unary_op::OP_SORT>
                    ::make<const Matrix&,Integer>(A,dim);

	if (asceding == false)
	{
		if (dim == 1)
		{
			return flipud(tmp);
		}
		else
		{
			return fliplr(tmp);
		};
	};
	return tmp;
};
mat_tup_2 mmlib::sort2(const Matrix& A,int dim, bool asceding)
{ 
    mat_tup_2 tmp = details::basic_unary_visitor_1<mat_tup_2,details::unary_op::OP_SORT2>
                    ::make<const Matrix&,Integer>(A,dim);

	Matrix mat = tmp.get<1>();
	Matrix ind = tmp.get<2>();
	if (asceding == false)
	{
		if (dim == 1)
		{
			mat = flipud(mat);
			ind = flipud(ind);
		}
		else
		{
			mat = fliplr(mat);
			ind = fliplr(ind);
		};
	};
	return mat_tup_2(mat,ind);
};
Matrix mmlib::sortrows(const Matrix& A)
{ 
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SORTROWS>
                ::make<const Matrix&>(A);
};
mat_tup_2 mmlib::sortrows2(const Matrix& A)
{ 
    return details::basic_unary_visitor_0<mat_tup_2,details::unary_op::OP_SORTROWS2>
                ::make<const Matrix&>(A);
};
Matrix mmlib::sortrows(const Matrix& A,const Matrix& dims)
{ 
	raw::IntegerMatrix mat_d = dims.impl<raw::IntegerMatrix>().make_explicit();

    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_SORTROWS_DIM>
                ::make<const Matrix&,raw::IntegerMatrix>(A,mat_d);
};
mat_tup_2 mmlib::sortrows2(const Matrix& A,const Matrix& dims)
{ 
	raw::IntegerMatrix mat_d = dims.impl<raw::IntegerMatrix>().make_explicit();

    return details::basic_unary_visitor_1<mat_tup_2,details::unary_op::OP_SORTROWS_DIM2>
                ::make<const Matrix&,raw::IntegerMatrix>(A,mat_d);
};
Matrix mmlib::sortcols(const Matrix& A)
{ 
    return details::basic_unary_visitor_0<Matrix,details::unary_op::OP_SORTCOLS>
                ::make<const Matrix&>(A);
};
mat_tup_2 mmlib::sortcols2(const Matrix& A)
{ 
    return details::basic_unary_visitor_0<mat_tup_2,details::unary_op::OP_SORTCOLS2>
                ::make<const Matrix&>(A);
};
Matrix mmlib::sortcols(const Matrix& A,const Matrix& dims)
{ 
	raw::IntegerMatrix mat_d = dims.impl<raw::IntegerMatrix>().make_explicit();

    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_SORTCOLS_DIM>
                ::make<const Matrix&,raw::IntegerMatrix>(A,mat_d);
};
mat_tup_2 mmlib::sortcols2(const Matrix& A,const Matrix& dims)
{ 
	raw::IntegerMatrix mat_d = dims.impl<raw::IntegerMatrix>().make_explicit();

    return details::basic_unary_visitor_1<mat_tup_2,details::unary_op::OP_SORTCOLS_DIM2>
                ::make<const Matrix&,raw::IntegerMatrix>(A,mat_d);
};

Matrix mmlib::issorted(const Matrix& A,int dim, bool asceding)
{
	Matrix tmp = A;
	if (asceding == false)
	{
		if (dim == 1)
		{
			tmp = flipud(tmp);
		}
		else
		{
			tmp = fliplr(tmp);
		};
	};

    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_ISSORTED>
                ::make<const Matrix&,int>(tmp,dim);
};
bool mmlib::issorted_rows(const Matrix& A)
{
    return details::basic_unary_visitor_0<bool,details::unary_op::OP_ISSORTED_ROWS>
                ::make<const Matrix&>(A);
}
bool mmlib::issorted_cols(const Matrix& A)
{
    return details::basic_unary_visitor_0<bool,details::unary_op::OP_ISSORTED_COLS>
                ::make<const Matrix&>(A);
}

Matrix mmlib::rot90(const Matrix& A,Integer n)
{
	Matrix tmp;
    n = n % 4;
    if (n < 0) n += 4;
    switch (n)
    {
        case 0: tmp = A; break;
		case 1: tmp = mmlib::flipud(mmlib::trans(A)); break;
        case 2: tmp = mmlib::flipud(mmlib::fliplr(A)); break;
        default: tmp = mmlib::trans(mmlib::flipud(A));
    }
    return tmp;
};

Matrix mmlib::eval_func(const Matrix& A, const scalar_function& func)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_EVAL_FUNC_SCAL>
                ::make<const Matrix&,const scalar_function&>(A,func);
};

Integer mmlib::get_ld(const Matrix& A, Integer min)
{
    return details::basic_unary_visitor_1<Integer,details::unary_op::GET_LD>
                ::make<const Matrix&>(A,min);
};
Integer mmlib::get_ud(const Matrix& A, Integer min)
{
    return details::basic_unary_visitor_1<Integer,details::unary_op::GET_UD>
                ::make<const Matrix&>(A,min);
};

bool mmlib::is_tril(const Matrix& A)
{
    return get_ud(A,0) > 0 ? false : true;
};
bool mmlib::is_triu(const Matrix& A)
{
    return get_ld(A,0) > 0 ? false : true;
};

Matrix mmlib::nnz(const Matrix& A, Integer dim)
{
    return details::basic_unary_visitor_1<Matrix,details::unary_op::OP_NNZ>
                ::make<const Matrix&,Integer>(A,dim);
};

};


#define MACRO_INS_SCAL(cl)								\
	template mmlib::details::cl<mmlib::Object>;			\
    template mmlib::details::cl<mmlib::Complex>;			\
	template mmlib::details::cl<mmlib::Real>;				\
	template mmlib::details::cl<mmlib::Integer>;

MACRO_INS_SCAL(sum_helper);
MACRO_INS_SCAL(cumsum_helper);
MACRO_INS_SCAL(prod_helper);
MACRO_INS_SCAL(cumprod_helper);
MACRO_INS_SCAL(sumsq_helper);
MACRO_INS_SCAL(min_helper);
MACRO_INS_SCAL(max_helper);
MACRO_INS_SCAL(mean_helper);
MACRO_INS_SCAL(std_helper);
MACRO_INS_SCAL(all_helper);
MACRO_INS_SCAL(any_helper);
MACRO_INS_SCAL(sqrt_helper);
MACRO_INS_SCAL(log_helper);
MACRO_INS_SCAL(log2_helper);
MACRO_INS_SCAL(log10_helper);

MACRO_INS_SCAL(asin_helper);
MACRO_INS_SCAL(acos_helper);
MACRO_INS_SCAL(asec_helper);
MACRO_INS_SCAL(acsc_helper);

MACRO_INS_SCAL(acosh_helper);
MACRO_INS_SCAL(atanh_helper);
MACRO_INS_SCAL(acoth_helper);
MACRO_INS_SCAL(asech_helper);

