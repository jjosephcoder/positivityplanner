/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/matrix_utils.h"
#include "mmlib/manip.h"
#include "mmlib/container/raw/type_decl.h"
#include "mmlib/exception.h"
#include "mmlib/timer.h"
#include "mmlib/constants.h"
#include "mmlib/details/scalfunc_helpers.h"
#include "mmlib/details/mpl.h"
#include "mmlib/details/type_info_utils.h"
#include "mmlib/utils/utils.h"

namespace mmlib
{

namespace gd = mmlib::details;

THREAD_LOCAL static details::timer_base global_timer = {0, 0};

template<class T>
struct norm_1_functor
{
	typedef raw::Matrix<T,struct_dense> matrix_type;
    typedef typename details::object_or_type<T,void, Real>::type real_type;
	static real_type eval(const matrix_type& mat)
	{
		Integer r = mat.rows(), c = mat.cols();
        gd::type_info ti = gd::return_func_ti<gd::unfunc_abs,matrix_type>::eval(mat);
        real_type out = gd::default_value<real_type>(ti);    

        const T* ptr_m = mat.ptr();

        for (Integer j = 0; j < c; ++j)
        {
		    for (Integer i = 0; i < r; ++i)
		    {
			    real_type val = mmlib::raw::details::abs_helper<T>::eval(ti,ptr_m[i]);
                if (val > out && val != constants::NaN && val != constants::Inf)
			    {
				    out = val;
			    };
		    }
            ptr_m += mat.ld();
        };
		return out;
	};
};
template<>
struct norm_1_functor<Integer>
{
	typedef raw::Matrix<Integer,struct_dense> matrix_type;
	static Real eval(const matrix_type& mat)
	{
		Integer r = mat.rows(), c = mat.cols();
        gd::type_info ti = gd::return_func_ti<gd::unfunc_abs,matrix_type>::eval(mat);
        Real out = 0.;

        const Integer* ptr_m = mat.ptr();

        for (Integer j = 0; j < c; ++j)
        {
		    for (Integer i = 0; i < r; ++i)
		    {
			    Real val = mmlib::raw::details::abs_helper<Real>::eval(ti,ptr_m[i]);
                if (val > out && val != constants::NaN && val != constants::Inf)
			    {
				    out = val;
			    };
		    }
            ptr_m += mat.ld();
        };
		return out;
	};
};
Real norm_1(const Matrix& A)
{
	Matrix mat2 = mmlib::full(A);
	switch (A.value_type())
	{
		case enums::value_integer:
		{			
			return norm_1_functor<Integer>::eval(mat2.get_impl<raw::IntegerMatrix>());
		}
		case enums::value_real:
		{
			return norm_1_functor<Real>::eval(mat2.get_impl<raw::RealMatrix>());
		}
		case enums::value_complex:
		{
			return norm_1_functor<Complex>::eval(mat2.get_impl<raw::ComplexMatrix>());
		}
		case enums::value_object:
		{
			Object tmp = norm_1_functor<Object>::eval(mat2.get_impl<raw::ObjectMatrix>());
            return tmp.to_real();
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};

void tic()
{
	global_timer.tic();
};
Real toc()
{
	return global_timer.toc();
};
std::string	tocstr()
{
	return global_timer.tocstr();
};
void tocdisp()
{
	return global_timer.tocdisp();
};


};