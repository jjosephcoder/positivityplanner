/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/matrix_gen.h"
#include "mmlib/func/raw/mvgen.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/manip.h"
#include "mmlib/matrix_concat.h"
#include "mmlib/extern/rnd.h"
#include "mmlib/exception_message.h"
#include "mmlib/utils/utils.h"

namespace mmlib
{

rand_state_ptr mmlib::get_rand_state()
{
    return details::get_rand_state();
};
void mmlib::set_rand_state(rand_state_ptr st)
{
    details::set_rand_state(st);
};

Matrix mmlib::randperm(Integer n)
{
	return Matrix(raw::randperm(n));
};
Matrix mmlib::range(Real s, Real i, Real e)
{
	return Matrix(raw::range(s,i,e));
};
Matrix mmlib::range(Real s, Real e)
{
	return Matrix(raw::range(s,e));
};
Matrix mmlib::irange(Integer s, Integer i, Integer e)
{
	return Matrix(raw::rangei(s,i,e));
};
Matrix mmlib::irange(Integer s, Integer e)
{
	return Matrix(raw::rangei(s,e));
};
Matrix mmlib::linspace(Real s, Real e, Integer n)
{
	return Matrix(raw::linspace(s,e,n));
};
Matrix mmlib::logspace(Real s, Real e, Integer n)
{
	return Matrix(raw::logspace(s,e,n));
};

Matrix mmlib::zeros(Integer r, Integer c)
{
	return Matrix(raw::zeros(r,c),false);
};
Matrix mmlib::zeros(details::type_info ti,Integer r, Integer c)
{
    return Matrix(raw::zeros(ti,r,c),false);
};
Matrix mmlib::ones(Integer r, Integer c)
{
	return Matrix(raw::ones(r,c),false);
};
Matrix mmlib::ones(details::type_info ti,Integer r, Integer c)
{
    return Matrix(raw::ones(ti,r,c),false);
};
Matrix mmlib::eye(Integer m, Integer n)
{
	return Matrix(raw::eye(m,n),false);
};
Matrix mmlib::eye(Integer m)
{
	return Matrix(raw::eye(m),false);
};
Matrix mmlib::eye(details::type_info ti,Integer m, Integer n)
{
    return Matrix(raw::eye(ti,m,n),false);
};
Matrix mmlib::eye(details::type_info ti,Integer m)
{
    return Matrix(raw::eye(ti,m),false);
};

Matrix mmlib::spzeros(Integer r, Integer c, Integer nnz)
{
    raw::RealSparseMatrix out(gd::get_raw_ti(),r,c,nnz);
    return Matrix(out,false);
};
Matrix mmlib::spzeros(details::type_info ti,Integer r, Integer c,Integer nnz)
{
    raw::ObjectSparseMatrix out(ti,r,c,nnz);
    return Matrix(out,false);
};
Matrix mmlib::bzeros(Integer r, Integer c,Integer ld, Integer ud)
{
    raw::RealBandMatrix out(gd::get_raw_ti(),r,c,ld,ud);
    out.get_struct().set_zero_matrix();
    return Matrix(out,false);
};
Matrix mmlib::bzeros(details::type_info ti,Integer r, Integer c,Integer ld, Integer ud)
{
    raw::ObjectBandMatrix out(ti,r,c,ld,ud);
    out.get_struct().set_zero_matrix();
    return Matrix(out,false);
};

Matrix mmlib::spones(Integer r, Integer c)
{
	return Matrix(raw::sparse(raw::ones(r,c)),false);
};
Matrix mmlib::spones(details::type_info ti,Integer r, Integer c)
{
    return Matrix(raw::sparse(raw::ones(ti,r,c)),false);
};
Matrix mmlib::bones(Integer r, Integer c)
{
    return band(ones(r,c));
};
Matrix mmlib::bones(details::type_info ti,Integer r, Integer c)
{
    return band(ones(ti,r,c));
};

Matrix mmlib::speye(Integer m, Integer n)
{
	return Matrix(raw::speye(m,n),false);
};
Matrix mmlib::speye(Integer m)
{
	return Matrix(raw::speye(m),false);
};
Matrix mmlib::speye(details::type_info ti,Integer m, Integer n)
{
    return Matrix(raw::speye(ti,m,n),false);
};
Matrix mmlib::speye(details::type_info ti,Integer m)
{
    return Matrix(raw::speye(ti,m),false);
};

Matrix mmlib::beye(Integer m, Integer n, Integer ld, Integer ud)
{
    return Matrix(raw::beye(m,n,ld,ud),false);
};
Matrix mmlib::beye(Integer m, Integer ld, Integer ud)
{
    return Matrix(raw::beye(m,ld,ud),false);
};
Matrix mmlib::beye(details::type_info ti,Integer m, Integer n, Integer ld, Integer ud)
{
    return Matrix(raw::beye(ti,m,n,ld,ud),false);
};
Matrix mmlib::beye(details::type_info ti,Integer m, Integer ld, Integer ud)
{
    return Matrix(raw::beye(ti,m,ld,ud),false);
};
Matrix mmlib::izeros(Integer r, Integer c)
{
	return Matrix(raw::zerosi(r,c),false);
};
Matrix mmlib::iones(Integer r, Integer c)
{
	return Matrix(raw::onesi(r,c),false);
};
Matrix mmlib::ieye(Integer m, Integer n)
{
	return Matrix(raw::eyei(m,n),false);
};
Matrix mmlib::ieye(Integer m)
{
	return Matrix(raw::eyei(m),false);
};
Matrix mmlib::ispzeros(Integer r, Integer c, Integer nnz)
{
    raw::IntegerSparseMatrix out(gd::get_raw_ti(),r,c,nnz);
	return Matrix(out,false);
};
Matrix mmlib::ibzeros(Integer r, Integer c,Integer ld, Integer ud)
{
    raw::IntegerBandMatrix out(gd::get_raw_ti(),r,c,ld,ud);
    out.get_struct().set_zero_matrix();
    return Matrix(out,false);
};
Matrix mmlib::ispones(Integer r, Integer c)
{
	return Matrix(raw::sparse(raw::onesi(r,c)),false);
};
Matrix mmlib::ibones(Integer r, Integer c)
{
    return band(iones(r,c));
};
Matrix mmlib::ispeye(Integer m, Integer n)
{
	return Matrix(raw::speyei(m,n),false);
};
Matrix mmlib::ispeye(Integer m)
{
	return Matrix(raw::speyei(m),false);
};
Matrix mmlib::ibeye(Integer m, Integer n, Integer ld, Integer ud)
{
    return Matrix(raw::beyei(m,n,ld,ud),false);
};
Matrix mmlib::ibeye(Integer m, Integer ld, Integer ud)
{
    return Matrix(raw::beyei(m,ld,ud),false);
};


Matrix mmlib::czeros(Integer r, Integer c)
{
	return Matrix(raw::zerosc(r,c),false);
};
Matrix mmlib::cones(Integer r, Integer c)
{
	return Matrix(raw::onesc(r,c),false);
};
Matrix mmlib::ceye(Integer m, Integer n)
{
	return Matrix(raw::eyec(m,n),false);
};
Matrix mmlib::ceye(Integer m)
{
	return Matrix(raw::eyec(m),false);
};
Matrix mmlib::cspzeros(Integer r, Integer c, Integer nnz)
{
    raw::ComplexSparseMatrix out(gd::get_raw_ti(),r,c,nnz);
    out.get_struct().set_zero_matrix();
	return Matrix(out,false);
};
Matrix mmlib::cbzeros(Integer r, Integer c,Integer ld, Integer ud)
{
    raw::ComplexBandMatrix out(gd::get_raw_ti(),r,c,ld,ud);
    out.get_struct().set_zero_matrix();
    return Matrix(out,false);
};
Matrix mmlib::cspones(Integer r, Integer c)
{
	return Matrix(raw::sparse(raw::onesc(r,c)),false);
};
Matrix mmlib::cbones(Integer r, Integer c)
{
    return band(cones(r,c));
};
Matrix mmlib::cspeye(Integer m, Integer n)
{
	return Matrix(raw::speyec(m,n),false);
};
Matrix mmlib::cspeye(Integer m)
{
	return Matrix(raw::speyec(m),false);
};
Matrix mmlib::cbeye(Integer m, Integer n, Integer ld, Integer ud)
{
    return Matrix(raw::beyec(m,n,ld,ud),false);
};
Matrix mmlib::cbeye(Integer m, Integer ld, Integer ud)
{
    return Matrix(raw::beyec(m,ld,ud),false);
};

Real mmlib::rand()
{
	return raw::rand();
};
Real mmlib::randn()
{
	return raw::randn();
};
Complex mmlib::crandn()
{
	return Complex(raw::randn(),raw::randn());
};
Complex mmlib::crand()
{
	return Complex(raw::rand(),raw::rand());
};

Integer mmlib::irand()
{
    return details::genrand_int32();
};

void mmlib::init_genrand(unsigned long s)
{
	details::init_genrand(s);
};


Matrix	mmlib::rand(Integer m, Integer n)
{
	return Matrix(raw::rand(m,n),false);
};
Matrix	mmlib::irand(Integer m, Integer n)
{
	return Matrix(raw::randi(m,n),false);
};
Matrix	mmlib::crand(Integer m, Integer n)
{
	return Matrix(raw::randc(m,n),false);
};
Matrix	mmlib::randn(Integer m, Integer n)
{
	return Matrix(raw::randn(m,n),false);
};
Matrix	mmlib::crandn(Integer m, Integer n)
{
	return Matrix(raw::randnc(m,n),false);
};
Matrix	mmlib::sprand(Integer m, Integer n, Real d)
{
	return Matrix(raw::sprand(m,n,d),false);
};
Matrix	mmlib::isprand(Integer m, Integer n, Real d)
{
	return Matrix(raw::sprandi(m,n,d),false);
};
Matrix	mmlib::csprand(Integer m, Integer n, Real d)
{
	return Matrix(raw::sprandc(m,n,d),false);
};
Matrix	mmlib::sprandn(Integer m, Integer n, Real d)
{
	return Matrix(raw::sprandn(m,n,d),false);
};
Matrix	mmlib::csprandn(Integer m, Integer n, Real d)
{
	return mmlib::Matrix(raw::sprandnc(m,n,d),false);
};

Matrix	mmlib::rand_band(Integer m, Integer n, Integer ld, Integer ud)
{
	ld = max(min(ld,m-1),0);
	ud = max(min(ud,n-1),0);

	raw::RealBandMatrix res(gd::get_raw_ti(),m,n,ld,ud);

    Real* ptr_res = res.rep_ptr();

    Integer res_size = res.size();
	for (Integer j = 0; j < res_size; ++j)
	{
		ptr_res[j] = rand();
	}
    if (ld == 0)
    {
        if (ud == 0)    res.get_struct().set_diag_matrix();
        else            res.get_struct().set_triu_matrix();
    }
    else if (ud == 0)
    {
        res.get_struct().set_tril_matrix();
    };
	return Matrix(res,false);
};
Matrix	mmlib::randn_band(Integer m, Integer n, Integer ld, Integer ud)
{
	ld = max(min(ld,m-1),0);
	ud = max(min(ud,n-1),0);

	raw::RealBandMatrix res(gd::get_raw_ti(),m,n,ld,ud);
    Real* ptr_res = res.rep_ptr();

    Integer res_size = res.size();
	for (Integer j = 0; j < res_size; ++j)
	{
		ptr_res[j] = randn();
	}
    if (ld == 0)
    {
        if (ud == 0)    res.get_struct().set_diag_matrix();
        else            res.get_struct().set_triu_matrix();
    }
    else if (ud == 0)
    {
        res.get_struct().set_tril_matrix();
    };
	return Matrix(res,false);
};
Matrix	mmlib::crand_band(Integer m, Integer n, Integer ld, Integer ud)
{
	ld = max(min(ld,m-1),0);
	ud = max(min(ud,n-1),0);

	raw::ComplexBandMatrix res(gd::get_raw_ti(),m,n,ld,ud);
    Complex* ptr_res = res.rep_ptr();

    Integer res_size = res.size();
	for (Integer j = 0; j < res_size; ++j)
	{
		ptr_res[j] = Complex(rand(),rand());
	}
    if (ld == 0)
    {
        if (ud == 0)    res.get_struct().set_diag_matrix();
        else            res.get_struct().set_triu_matrix();
    }
    else if (ud == 0)
    {
        res.get_struct().set_tril_matrix();
    };
	return Matrix(res,false);
};
Matrix	mmlib::crandn_band(Integer m, Integer n, Integer ld, Integer ud)
{
	ld = max(min(ld,m-1),0);
	ud = max(min(ud,n-1),0);

	raw::ComplexBandMatrix res(gd::get_raw_ti(),m,n,ld,ud);
    Complex* ptr_res = res.rep_ptr();

    Integer res_size = res.size();
	for (Integer j = 0; j < res_size; ++j)
	{
		ptr_res[j] = Complex(randn(),randn());
	}
    if (ld == 0)
    {
        if (ud == 0)    res.get_struct().set_diag_matrix();
        else            res.get_struct().set_triu_matrix();
    }
    else if (ud == 0)
    {
        res.get_struct().set_tril_matrix();
    };
	return Matrix(res,false);
};
Matrix	mmlib::irand_band(Integer m, Integer n, Integer ld, Integer ud)
{
	ld = max(min(ld,m-1),0);
	ud = max(min(ud,n-1),0);

	raw::IntegerBandMatrix res(gd::get_raw_ti(),m,n,ld,ud);
    Integer* ptr_res = res.rep_ptr();

    Integer res_size = res.size();
	for (Integer j = 0; j < res_size; ++j)
	{
		ptr_res[j] = irand();
	}
    if (ld == 0)
    {
        if (ud == 0)    res.get_struct().set_diag_matrix();
        else            res.get_struct().set_triu_matrix();
    }
    else if (ud == 0)
    {
        res.get_struct().set_tril_matrix();
    };
	return Matrix(res,false);
};


Matrix mmlib::diag(const Matrix& mat, Integer d)
{
	switch (mat.value_type())
	{
		case enums::value_integer:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::diag(mat2.get_impl<raw::IntegerMatrix>(),d),false);
		}
		case enums::value_real:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::diag(mat2.get_impl<raw::RealMatrix>(),d),false);
		}
		case enums::value_complex:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::diag(mat2.get_impl<raw::ComplexMatrix>(),d),false);
		}
		case enums::value_object:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::diag(mat2.get_impl<raw::ObjectMatrix>(),d),false);
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};
Matrix mmlib::bdiag(const Matrix &mat, Integer d)
{
	switch (mat.value_type())
	{
		case enums::value_integer:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::bdiag(mat2.get_impl<raw::IntegerMatrix>(),d),false);
		}
		case enums::value_real:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::bdiag(mat2.get_impl<raw::RealMatrix>(),d),false);
		}
		case enums::value_complex:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::bdiag(mat2.get_impl<raw::ComplexMatrix>(),d),false);
		}
		case enums::value_object:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::bdiag(mat2.get_impl<raw::ObjectMatrix>(),d),false);
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};
Matrix mmlib::spdiag(const Matrix &mat, Integer d)
{
	switch (mat.value_type())
	{
		case enums::value_integer:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::spdiag(mat2.get_impl<raw::IntegerMatrix>(),d),false);
		}
		case enums::value_real:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::spdiag(mat2.get_impl<raw::RealMatrix>(),d),false);
		}
		case enums::value_complex:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::spdiag(mat2.get_impl<raw::ComplexMatrix>(),d),false);
		}
		case enums::value_object:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::spdiag(mat2.get_impl<raw::ObjectMatrix>(),d),false);
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};
Matrix mmlib::horzcat(const Matrix& A,const Matrix& B)
{
	return mat_row(), A, B; 
};
Matrix mmlib::vertcat(const Matrix& A,const Matrix& B)
{
	return mat_col(), A, B; 
};
Matrix mmlib::diags(const Matrix &mat, const Matrix &d, Integer m, Integer n)
{
	raw::IntegerMatrix mat_d = d.impl<raw::IntegerMatrix>();

	switch (mat.value_type())
	{
		case enums::value_integer:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::diags(mat2.get_impl<raw::IntegerMatrix>(),mat_d,m,n),false);
		}
		case enums::value_real:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::diags(mat2.get_impl<raw::RealMatrix>(),mat_d,m,n),false);
		}
		case enums::value_complex:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::diags(mat2.get_impl<raw::ComplexMatrix>(),mat_d,m,n),false);
		}
		case enums::value_object:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::diags(mat2.get_impl<raw::ObjectMatrix>(),mat_d,m,n),false);
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};
Matrix mmlib::bdiags(const Matrix &mat, const Matrix &d, Integer m, Integer n)
{
	raw::IntegerMatrix mat_d = d.impl<raw::IntegerMatrix>();

	switch (mat.value_type())
	{
		case enums::value_integer:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::bdiags(mat2.get_impl<raw::IntegerMatrix>(),mat_d,m,n),false);
		}
		case enums::value_real:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::bdiags(mat2.get_impl<raw::RealMatrix>(),mat_d,m,n),false);
		}
		case enums::value_complex:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::bdiags(mat2.get_impl<raw::ComplexMatrix>(),mat_d,m,n),false);
		}
		case enums::value_object:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::bdiags(mat2.get_impl<raw::ObjectMatrix>(),mat_d,m,n),false);
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};
Matrix mmlib::spdiags(const Matrix &mat, const Matrix &d, Integer m, Integer n)
{
	raw::IntegerMatrix mat_d = d.impl<raw::IntegerMatrix>();

	switch (mat.value_type())
	{
		case enums::value_integer:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::spdiags(mat2.get_impl<raw::IntegerMatrix>(),mat_d,m,n),false);
		}
		case enums::value_real:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::spdiags(mat2.get_impl<raw::RealMatrix>(),mat_d,m,n),false);
		}
		case enums::value_complex:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::spdiags(mat2.get_impl<raw::ComplexMatrix>(),mat_d,m,n),false);
		}
		case enums::value_object:
		{
			Matrix mat2 = mmlib::full(mat);
			return Matrix(raw::spdiags(mat2.get_impl<raw::ObjectMatrix>(),mat_d,m,n),false);
		}
		default:
		{
			assertion(0,"unknown case");
			throw;
		}
	};
};

Matrix mmlib::IntegerMatrix(Integer rows,Integer cols)
{
    raw::IntegerMatrix out(gd::get_raw_ti(),Integer(),rows,cols);
    out.get_struct().set_zero_matrix();
	return Matrix(out,false);
};
Matrix mmlib::RealMatrix(Integer rows,Integer cols)
{
    raw::RealMatrix out(gd::get_raw_ti(),Real(),rows,cols);
    out.get_struct().set_zero_matrix();
	return Matrix(out,false);
};
Matrix mmlib::ComplexMatrix(Integer rows,Integer cols)
{
    raw::ComplexMatrix out(gd::get_raw_ti(),Complex(),rows,cols);
    out.get_struct().set_zero_matrix();
	return Matrix(out,false);
};
Matrix mmlib::ObjectMatrix(details::type_info ti,Integer rows,Integer cols)
{
    raw::ObjectMatrix out(ti,Object(ti),rows,cols);
    out.get_struct().set_zero_matrix();
	return Matrix(out,false);
};

Matrix mmlib::IntegerMatrix(Integer rows,Integer cols,const Integer *arr)
{
	return Matrix(raw::IntegerMatrix(gd::get_raw_ti(),arr,rows,cols),false);
};
Matrix mmlib::RealMatrix(Integer rows,Integer cols,const Real *arr)
{
	return Matrix(raw::RealMatrix(gd::get_raw_ti(),arr,rows,cols),false);
};
Matrix mmlib::ComplexMatrix(Integer rows,Integer cols,const Complex *arr)
{
	return Matrix(raw::ComplexMatrix(gd::get_raw_ti(),arr,rows,cols),false);
};
Matrix mmlib::ComplexMatrix(Integer rows,Integer cols,const Real *ar_r,const Real *ar_i)
{
	return Matrix(raw::ComplexMatrix(gd::get_raw_ti(),ar_r,ar_i,rows,cols),false);
};
Matrix mmlib::IntegerMatrix(Integer val,Integer rows,Integer cols)
{
    raw::IntegerMatrix out(gd::get_raw_ti(),val,rows,cols);
    if (val == 0)
    {
        out.get_struct().set_zero_matrix();
    };
	return Matrix(out,false);
};
Matrix mmlib::RealMatrix(Real val,Integer rows,Integer cols)
{
    raw::RealMatrix out(gd::get_raw_ti(),val,rows,cols);
    if (val == 0.)
    {
        out.get_struct().set_zero_matrix();
    };
	return Matrix(out,false);
};
Matrix mmlib::ComplexMatrix(Complex val,Integer rows,Integer cols)
{
    raw::ComplexMatrix out(gd::get_raw_ti(),val,rows,cols);
    if (val == 0.)
    {
        out.get_struct().set_zero_matrix();
    };
	return Matrix(out,false);
};
Matrix mmlib::ObjectMatrix(details::type_info ti,Object val,Integer rows,Integer cols)
{
    raw::ObjectMatrix out(ti,val,rows,cols);
    if (val == mmlib::details::default_value<Object>(ti))
    {
        out.get_struct().set_zero_matrix();
    };
	return Matrix(out,false);
};


Matrix mmlib::IntegerBandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	ldiags = max(min(ldiags,rows-1),0);
	udiags = max(min(udiags,cols-1),0);

	raw::IntegerBandMatrix tmp(gd::get_raw_ti(),rows,cols,ldiags,udiags);
    Integer* ptr_res = tmp.rep_ptr();

    Integer tmp_size = tmp.size();
	for (Integer i = 0; i < tmp_size; ++i)
	{
		ptr_res[i] = 0;
	};
    tmp.get_struct().set_zero_matrix();
	return Matrix(tmp,false);
};
Matrix mmlib::RealBandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	ldiags = max(min(ldiags,rows-1),0);
	udiags = max(min(udiags,cols-1),0);

	raw::RealBandMatrix tmp(gd::get_raw_ti(),rows,cols,ldiags,udiags);
    Real* ptr_tmp = tmp.rep_ptr();

    Integer tmp_size = tmp.size();
	for (Integer i = 0; i < tmp_size; ++i)
	{
		ptr_tmp[i] = 0;
	};
    tmp.get_struct().set_zero_matrix();
	return Matrix(tmp,false);
};
Matrix mmlib::ComplexBandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	ldiags = max(min(ldiags,rows-1),0);
	udiags = max(min(udiags,cols-1),0);

	raw::ComplexBandMatrix tmp(gd::get_raw_ti(),rows,cols,ldiags,udiags);
    Complex* ptr_tmp = tmp.rep_ptr();

    Integer tmp_size = tmp.size();
	for (Integer i = 0; i < tmp_size; ++i)
	{
		ptr_tmp[i] = 0;
	};
    tmp.get_struct().set_zero_matrix();
	return Matrix(tmp,false);
};
Matrix mmlib::ObjectBandMatrix(gd::type_info ti, Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	ldiags = max(min(ldiags,rows-1),0);
	udiags = max(min(udiags,cols-1),0);

	raw::ObjectBandMatrix tmp(ti,rows,cols,ldiags,udiags);
    Object* ptr_tmp = tmp.rep_ptr();

    Integer tmp_size = tmp.size();
	for (Integer i = 0; i < tmp_size; ++i)
	{
		ptr_tmp[i] = Object(ti);
	};
    tmp.get_struct().set_zero_matrix();
	return Matrix(tmp,false);
};


Matrix mmlib::IntegerBandMatrix2(Integer val,Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	ldiags = max(min(ldiags,rows-1),0);
	udiags = max(min(udiags,cols-1),0);

	raw::IntegerBandMatrix tmp(gd::get_raw_ti(),rows,cols,ldiags,udiags);
    Integer* ptr_tmp = tmp.rep_ptr();

    Integer tmp_size = tmp.size();
	for (Integer i = 0; i < tmp_size; ++i)
	{
		ptr_tmp[i] = val;
	};
    if (val == 0)
    {
        tmp.get_struct().set_zero_matrix();
    };
	return Matrix(tmp,false);
};
Matrix mmlib::RealBandMatrix2(Real val,Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	ldiags = max(min(ldiags,rows-1),0);
	udiags = max(min(udiags,cols-1),0);

	raw::RealBandMatrix tmp(gd::get_raw_ti(),rows,cols,ldiags,udiags);
    Real* ptr_tmp = tmp.rep_ptr();

    Integer tmp_size = tmp.size();
	for (Integer i = 0; i < tmp_size; ++i)
	{
		ptr_tmp[i] = val;
	};
    if (val == 0.)
    {
        tmp.get_struct().set_zero_matrix();
    };
	return Matrix(tmp,false);
};
Matrix mmlib::ComplexBandMatrix2(Complex val,Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	ldiags = max(min(ldiags,rows-1),0);
	udiags = max(min(udiags,cols-1),0);

	raw::ComplexBandMatrix tmp(gd::get_raw_ti(),rows,cols,ldiags,udiags);
    Complex* ptr_tmp = tmp.rep_ptr();

    Integer tmp_size = tmp.size();
	for (Integer i = 0; i < tmp_size; ++i)
	{
		ptr_tmp[i] = val;
	};
    if (val == 0.)
    {
        tmp.get_struct().set_zero_matrix();
    };
	return Matrix(tmp,false);
};

Matrix mmlib::IntegerSparseMatrix(Integer rows,Integer cols, Integer nzmax)
{
	return Matrix(raw::IntegerSparseMatrix(gd::get_raw_ti(),rows,cols,nzmax),false);
};
Matrix mmlib::RealSparseMatrix(Integer rows,Integer cols, Integer nzmax)
{
	return Matrix(raw::RealSparseMatrix(gd::get_raw_ti(),rows,cols,nzmax),false);
};
Matrix mmlib::ComplexSparseMatrix(Integer rows,Integer cols, Integer nzmax)
{
	return Matrix(raw::ComplexSparseMatrix(gd::get_raw_ti(),rows,cols,nzmax),false);
};
Matrix mmlib::ObjectSparseMatrix(gd::type_info ti, Integer rows,Integer cols, Integer nzmax)
{
	return Matrix(raw::ObjectSparseMatrix(ti,rows,cols,nzmax),false);
};


Matrix mmlib::IntegerSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Integer *trip_x,
										Integer r, Integer c, Integer nnz)
{
	return Matrix(raw::IntegerSparseMatrix(gd::get_raw_ti(),trip_r,trip_c,trip_x,r,c,nnz),false);
};
Matrix mmlib::RealSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Real *trip_x,
										Integer r, Integer c, Integer nnz)
{
	return Matrix(raw::RealSparseMatrix(gd::get_raw_ti(),trip_r,trip_c,trip_x,r,c,nnz),false);
};
Matrix mmlib::ComplexSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Complex *trip_x,
										Integer r, Integer c, Integer nnz)
{
	return Matrix(raw::ComplexSparseMatrix(gd::get_raw_ti(),trip_r,trip_c,trip_x,r,c,nnz),false);
};
Matrix mmlib::ComplexSparseMatrix(const Integer *trip_r, const Integer *trip_c, 
										const Real *trip_re, const Real *trip_im,
										Integer r, Integer c, Integer nnz)
{
	return Matrix(raw::ComplexSparseMatrix(gd::get_raw_ti(),trip_r,trip_c,trip_re,trip_im,r,c,nnz),false);
};

Matrix mmlib::IntegerSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Integer *trip_x,
										Integer r, Integer c, Integer nnz, Integer nzmax)
{
	return Matrix(raw::IntegerSparseMatrix(gd::get_raw_ti(),trip_r,trip_c,trip_x,r,c,nnz,nzmax),false);
};
Matrix mmlib::RealSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Real *trip_x,
										Integer r, Integer c, Integer nnz, Integer nzmax)
{
	return Matrix(raw::RealSparseMatrix(gd::get_raw_ti(),trip_r,trip_c,trip_x,r,c,nnz,nzmax),false);
};
Matrix mmlib::ComplexSparseMatrix(const Integer *trip_r, const Integer *trip_c, const Complex *trip_x,
										Integer r, Integer c, Integer nnz, Integer nzmax)
{
	return Matrix(raw::ComplexSparseMatrix(gd::get_raw_ti(),trip_r,trip_c,trip_x,r,c,nnz,nzmax),false);
};
Matrix mmlib::ComplexSparseMatrix(const Integer *trip_r, const Integer *trip_c, 
										const Real *trip_re, const Real *trip_im,
										Integer r, Integer c, Integer nnz, Integer nzmax)
{
	return Matrix(raw::ComplexSparseMatrix(gd::get_raw_ti(),trip_r,trip_c,trip_re,trip_im,r,c,nnz,nzmax),false);
};
Matrix mmlib::SparseMatrix(const Matrix& trip_r, const Matrix& trip_c, const Matrix& trip_x,
										Integer r, Integer c)
{
	Integer nnz = trip_x.nnz();
	return SparseMatrix(trip_r,trip_c,trip_x,r,c,nnz);
};
Matrix mmlib::SparseMatrix(const Matrix& trip_r, const Matrix& trip_c, const Matrix& trip_x,
										Integer r, Integer c, Integer nzmax)
{
	Matrix rm = mmlib::full(trip_r);
	Matrix cm = mmlib::full(trip_c);
	Matrix xm = mmlib::full(trip_x);

	raw::IntegerMatrix ri = rm.impl<raw::IntegerMatrix>();
	raw::IntegerMatrix ci = cm.impl<raw::IntegerMatrix>();

	if (ri.rows() != 1 && ri.cols() != 1)
	{
		throw error::error_not_vec(ri.rows(),ri.cols());
	}
    if (ci.rows() != 1 && ci.cols() != 1)
	{
		throw error::error_not_vec(ci.rows(),ci.cols());
	};
	if (xm.rows() != 1 && xm.cols() != 1)
	{
		throw error::error_not_vec(xm.rows(),xm.cols());
	};

	Integer size = ri.size();
	Integer xsize = imult(xm.rows(),xm.cols());
	Integer nz = size;

	if (ci.size() != size || xsize != size)
	{
		throw error::error_invalid_vectors_spmat(ri.size(),ci.size(),xsize);		
	};	

    ri.assign(ri.make_explicit());
    ci.assign(ci.make_explicit());

	switch(trip_x.value_type())
	{
		case enums::value_integer:
		{
			raw::IntegerMatrix x = xm.get_impl<raw::IntegerMatrix>();
            x.assign(x.make_explicit());
			return Matrix(raw::IntegerSparseMatrix(gd::get_raw_ti(),ri.ptr(),ci.ptr(),x.ptr(),r,c,nz,nzmax),false);
		}
		case enums::value_real:
		{
			raw::RealMatrix x = xm.get_impl<raw::RealMatrix>();
            x.assign(x.make_explicit());
			return Matrix(raw::RealSparseMatrix(gd::get_raw_ti(),ri.ptr(),ci.ptr(),x.ptr(),r,c,nz,nzmax),false);
		}
		case enums::value_complex:
		{
			raw::ComplexMatrix x = xm.get_impl<raw::ComplexMatrix>();
            x.assign(x.make_explicit());
			return Matrix(raw::ComplexSparseMatrix(gd::get_raw_ti(),ri.ptr(),ci.ptr(),x.ptr(),r,c,nz,nzmax),false);
		}
		case enums::value_object:
		{
			raw::ObjectMatrix x = xm.get_impl<raw::ObjectMatrix>();
            x.assign(x.make_explicit());
            return Matrix(raw::ObjectSparseMatrix(xm.get_ti(),ri.ptr(),ci.ptr(),x.ptr(),r,c,nz,nzmax),false);
		}
		default:
		{
			assertion(0,"unknown value type");
			throw;
		}
	};
};

Matrix	mmlib::UninitializedIntegerMatrix(Integer rows,Integer cols)
{
	return Matrix(raw::IntegerMatrix(gd::get_raw_ti(),rows,cols),false);
};
Matrix	mmlib::UninitializedRealMatrix(Integer rows,Integer cols)
{
	return Matrix(raw::RealMatrix(gd::get_raw_ti(),rows,cols),false);
};
Matrix	mmlib::UninitializedComplexMatrix(Integer rows,Integer cols)
{
	return Matrix(raw::ComplexMatrix(gd::get_raw_ti(),rows,cols),false);
};
Matrix	mmlib::UninitializedObjectMatrix(gd::type_info ti, Integer rows,Integer cols)
{
	return Matrix(raw::ObjectMatrix(ti,rows,cols),false);
};

Matrix	mmlib::UninitializedIntegerBandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	return Matrix(raw::IntegerBandMatrix(gd::get_raw_ti(),rows,cols,ldiags,udiags),false);
};
Matrix	mmlib::UninitializedRealBandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	return Matrix(raw::RealBandMatrix(gd::get_raw_ti(),rows,cols,ldiags,udiags),false);
};
Matrix	mmlib::UninitializedComplexBandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	return Matrix(raw::ComplexBandMatrix(gd::get_raw_ti(),rows,cols,ldiags,udiags),false);
};
Matrix	mmlib::UninitializedObjectBandMatrix(gd::type_info ti, Integer rows,Integer cols, Integer ldiags, Integer udiags)
{
	return Matrix(raw::ObjectBandMatrix(ti,rows,cols,ldiags,udiags),false);
};

Matrix	mmlib::UninitializedIntegerSparseMatrix(Integer rows,Integer cols, Integer nzmax)
{
	return Matrix(raw::IntegerSparseMatrix(gd::get_raw_ti(),rows,cols,nzmax),false);
};
Matrix	mmlib::UninitializedRealSparseMatrix(Integer rows,Integer cols, Integer nzmax)
{
	return Matrix(raw::RealSparseMatrix(gd::get_raw_ti(),rows,cols,nzmax),false);
};
Matrix	mmlib::UninitializedComplexSparseMatrix(Integer rows,Integer cols, Integer nzmax)
{
	return Matrix(raw::ComplexSparseMatrix(gd::get_raw_ti(),rows,cols,nzmax),false);
};
Matrix	mmlib::UninitializedObjectSparseMatrix(gd::type_info ti, Integer rows,Integer cols, Integer nzmax)
{
	return Matrix(raw::ObjectSparseMatrix(ti,rows,cols,nzmax),false);
};


Matrix mmlib::DenseMatrix(Integer rows,Integer cols, enums::value_type vt)
{
	switch (vt)
	{
		case enums::value_integer:  return IntegerMatrix(rows,cols);
		case enums::value_real:     return RealMatrix(rows,cols);
		case enums::value_complex:  return ComplexMatrix(rows,cols);
		case enums::value_object:
            throw error::error_object_value_type_not_allowed();
		default:
			assertion(0,"unknown case");
			throw;
	};
};
Matrix mmlib::BandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags, enums::value_type vt)
{
	switch (vt)
	{
		case enums::value_integer:  return IntegerBandMatrix(rows,cols,ldiags,udiags);
		case enums::value_real:     return RealBandMatrix(rows,cols,ldiags,udiags);
		case enums::value_complex:  return ComplexBandMatrix(rows,cols,ldiags,udiags);
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
		default:
			assertion(0,"unknown case");
			throw;
	};
};
Matrix mmlib::SparseMatrix(Integer rows,Integer cols, Integer nzmax, enums::value_type vt)
{
	switch (vt)
	{
		case enums::value_integer:  return IntegerSparseMatrix(rows,cols,nzmax);
		case enums::value_real:     return RealSparseMatrix(rows,cols,nzmax);
		case enums::value_complex:  return ComplexSparseMatrix(rows,cols,nzmax);
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
		default:
			assertion(0,"unknown case");
			throw;
	};
};


Matrix mmlib::UninitializedDenseMatrix(Integer rows,Integer cols, enums::value_type vt)
{
	switch (vt)
	{
		case enums::value_integer:  return UninitializedIntegerMatrix(rows,cols);
		case enums::value_real:     return UninitializedRealMatrix(rows,cols);
		case enums::value_complex:  return UninitializedComplexMatrix(rows,cols);
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
		default:
			assertion(0,"unknown case");
			throw;
	};
};
Matrix mmlib::UninitializedBandMatrix(Integer rows,Integer cols, Integer ldiags, Integer udiags, 
                                     enums::value_type vt)
{
	switch (vt)
	{
		case enums::value_integer:  return UninitializedIntegerBandMatrix(rows,cols,ldiags,udiags);
		case enums::value_real:     return UninitializedRealBandMatrix(rows,cols,ldiags,udiags);
		case enums::value_complex:  return UninitializedComplexBandMatrix(rows,cols,ldiags,udiags);
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
		default:
			assertion(0,"unknown case");
			throw;
	};
};
Matrix mmlib::UninitializedSparseMatrix(Integer rows,Integer cols, Integer nzmax, enums::value_type vt)
{
	switch (vt)
	{
		case enums::value_integer:  return UninitializedIntegerSparseMatrix(rows,cols,nzmax);
		case enums::value_real:     return UninitializedRealSparseMatrix(rows,cols,nzmax);
		case enums::value_complex:  return UninitializedComplexSparseMatrix(rows,cols,nzmax);
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
		default:
			assertion(0,"unknown case");
			throw;
	};
};
Matrix mmlib::range(Real s, Real i, Real e, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return irange(convert_scalar<Integer>(s),convert_scalar<Integer>(i),
                            convert_scalar<Integer>(e));
        }
        case enums::value_real:
        {
            return range(s,i,e);
        }
        case enums::value_complex:
        {
            return range(s,i,e)*Complex(0,1);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::range(Real s, Real e, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return irange(convert_scalar<Integer>(s),convert_scalar<Integer>(e));
        }
        case enums::value_real:
        {
            return range(s,e);
        }
        case enums::value_complex:
        {
            return range(s,e)*Complex(0,1);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::zeros(Integer r, Integer c, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return izeros(r,c);
        }
        case enums::value_real:
        {
            return zeros(r,c);
        }
        case enums::value_complex:
        {
            return czeros(r,c);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::spzeros(Integer r, Integer c,Integer nnz, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return ispzeros(r,c,nnz);
        }
        case enums::value_real:
        {
            return spzeros(r,c,nnz);
        }
        case enums::value_complex:
        {
            return cspzeros(r,c,nnz);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
}
Matrix mmlib::ones(Integer r, Integer c, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return iones(r,c);
        }
        case enums::value_real:
        {
            return ones(r,c);
        }
        case enums::value_complex:
        {
            return cones(r,c);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::spones(Integer r, Integer c, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return ispones(r,c);
        }
        case enums::value_real:
        {
            return spones(r,c);
        }
        case enums::value_complex:
        {
            return cspones(r,c);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::eye(Integer r, Integer c, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return ieye(r,c);
        }
        case enums::value_real:
        {
            return eye(r,c);
        }
        case enums::value_complex:
        {
            return ceye(r,c);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::eye(Integer m, enums::value_type vt)
{
    return eye(m,m,vt);
};
Matrix mmlib::speye(Integer r, Integer c, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return ispeye(r,c);
        }
        case enums::value_real:
        {
            return speye(r,c);
        }
        case enums::value_complex:
        {
            return cspeye(r,c);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::speye(Integer m, enums::value_type vt)
{
    return speye(m,m,vt);
};
Matrix mmlib::rand(Integer m, Integer n,enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return irand(m,n);
        }
        case enums::value_real:
        {
            return rand(m,n);
        }
        case enums::value_complex:
        {
            return crand(m,n);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::randn(Integer m, Integer n,enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            throw error::error_integer_value_type_not_allowed();
        }
        case enums::value_real:
        {
            return randn(m,n);
        }
        case enums::value_complex:
        {
            return crandn(m,n);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::sprand(Integer m, Integer n, Real d,enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return isprand(m,n,d);
        }
        case enums::value_real:
        {
            return sprand(m,n,d);
        }
        case enums::value_complex:
        {
            return csprand(m,n,d);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::sprandn(Integer m, Integer n, Real d,enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            throw error::error_integer_value_type_not_allowed();
        }
        case enums::value_real:
        {
            return sprandn(m,n,d);
        }
        case enums::value_complex:
        {
            return csprandn(m,n,d);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::rand_band(Integer m, Integer n, Integer ld, Integer ud,enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return irand_band(m,n,ld,ud);
        }
        case enums::value_real:
        {
            return rand_band(m,n,ld,ud);
        }
        case enums::value_complex:
        {
            return crand_band(m,n,ld,ud);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::randn_band(Integer m, Integer n, Integer ld, Integer ud,enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            throw error::error_integer_value_type_not_allowed();
        }
        case enums::value_real:
        {
            return randn_band(m,n,ld,ud);
        }
        case enums::value_complex:
        {
            return crandn_band(m,n,ld,ud);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::bzeros(Integer r, Integer c,Integer ld, Integer ud, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return ibzeros(r,c,ld,ud);
        }
        case enums::value_real:
        {
            return bzeros(r,c,ld,ud);
        }
        case enums::value_complex:
        {
            return cbzeros(r,c,ld,ud);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::bones(Integer r, Integer c, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return ibones(r,c);
        }
        case enums::value_real:
        {
            return bones(r,c);
        }
        case enums::value_complex:
        {
            return cbones(r,c);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::beye(Integer m, Integer n, Integer ld, Integer ud, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return ibeye(m,n,ld,ud);
        }
        case enums::value_real:
        {
            return beye(m,n,ld,ud);
        }
        case enums::value_complex:
        {
            return cbeye(m,n,ld,ud);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};
Matrix mmlib::beye(Integer m, Integer ld, Integer ud, enums::value_type vt)
{
    switch (vt)
    {
        case enums::value_integer:
        {
            return ibeye(m,ld,ud);
        }
        case enums::value_real:
        {
            return beye(m,ld,ud);
        }
        case enums::value_complex:
        {
            return cbeye(m,ld,ud);
        }
        case enums::value_object:
            throw error::error_object_value_type_not_allowed();
        default:
			assertion(0,"unknown case");
			throw;
    };
};

namespace details
{
    Integer real_to_int(Real val)
    {
        if (val - (Integer)val != 0)
        {
            error::get_global_messanger().warning_precision_lost_real_to_int(val);
                
        };
        return (Integer)val;
    };
    Real complex_to_real(const Complex& val)
    {
        if (imag(val) != 0)
        {
            error::get_global_messanger().warning_precision_lost_compl_to_real(val);            
        };
        return real(val);
    };
    Integer complex_to_int(const Complex& val)
    {
        return real_to_int(complex_to_real(val));
    };

    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Integer,Integer>
    {
        static Integer eval(Integer val)
        {
            return val;
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Real,Integer>
    {
        static Real eval(Integer val)
        {
            return val;
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Complex,Integer>
    {
        static Complex eval(Integer val)
        {
            return val;
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Integer,Real>
    {
        static Integer eval(Real val)
        {
            return real_to_int(val);
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Real,Real>
    {
        static Real eval(Real val)
        {
            return val;
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Complex,Real>
    {
        static Complex eval(Real val)
        {
            return val;
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Integer,Complex>
    {
        static Integer eval(Complex val)
        {
            return complex_to_int(val);
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Real,Complex>
    {
        static Real eval(Complex val)
        {
            return complex_to_real(val);
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Complex,Complex>
    {
        static Complex eval(Complex val)
        {
            return val;
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Integer,Object>
    {
        static Integer eval(Object val)
        {
            return val.to_integer();
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Real,Object>
    {
        static Real eval(Object val)
        {
            return val.to_real();
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Complex,Object>
    {
        static Complex eval(Object val)
        {
            return val.to_complex();
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Object,Object>
    {
        static Object eval(Object val)
        {
            return val;
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Object,Integer>
    {
        static Object eval(Integer)
        {
            throw error::error_object_value_type_not_allowed();
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Object,Real>
    {
        static Object eval(Real)
        {
            throw error::error_object_value_type_not_allowed();
        };
    };
    template<>
    struct MMLIB_EXPORT convert_scalar_imp<Object,Complex>
    {
        static Object eval(Complex)
        {
            throw error::error_object_value_type_not_allowed();
        };
    };
};

};
