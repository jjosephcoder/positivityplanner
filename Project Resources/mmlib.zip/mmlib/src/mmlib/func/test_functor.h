/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

namespace mmlib { namespace details
{

//=====================================================================
//						TEST MATRIX
//=====================================================================
struct test_geq_zero
{
	static bool eval(Real val)	{ return val >= 0.; };
};
struct test_m1_1
{
	static bool eval(Real val)	{ return val >= -1. && val <= 1.; };
};
struct test_inf_m1_1_inf
{
	static bool eval(Real val)	{ return val <= -1. || val >= 1.; };
};
struct test_1_inf
{
	static bool eval(Real val)	{ return val >= 1.; };
};
struct test_0_1
{
	static bool eval(Real val)	{ return val >= 0. && val <= 1.; };
};
struct test_is_int
{
	static bool eval(Real val)	{ return (val - (Integer)val) == 0.; };
};

template<bool iso,class vt, class st, class test>
struct test_range_impl
{};
template<class vt, class st, class test>
struct test_range_impl<true,vt,st,test>
{
	typedef raw::Matrix<vt,st> M1;
	static bool eval(const M1& )
	{
		return true;
	};
};
template<class vt, class test>
struct test_range_impl<false,vt,struct_dense,test>
{
	typedef raw::Matrix<vt,struct_dense> M1;
	static bool eval(const M1& A)
	{
        const vt* ptr_A = A.ptr();

		for (Integer j = 0; j < A.cols(); ++j)
		{
		    for (Integer i = 0; i < A.rows(); ++i)
		    {
			    if (!test::eval(ptr_A[i]))
			    {
				    return false;
			    };
		    };
            ptr_A += A.ld();
        };

		return true;
	};
};
template<class vt, class test>
struct test_range_impl<false,vt,struct_sparse,test>
{
	typedef raw::Matrix<vt,struct_sparse> M1;
	static bool eval(const M1& A)
	{
		Integer r = A.rows(), c = A.cols(), nz = A.nnz();
		if (Real(nz) < Real(r)*Real(c))
		{
			if (!test::eval(0.))
			{
				return false;
			};
		};

		if (nz == 0)
		{
			return true;
		};

		const raw::details::spdat<vt>& rep = A.rep();
		const vt* d_x = rep.ptr_x() + rep.offset();

		for (Integer i = 0; i < nz; ++i)
		{
			if (!test::eval(d_x[i]))
			{
				return false;
			};
		}
		return true;
	};
};
template<class vt, class test>
struct test_range_impl<false,vt,struct_banded,test>
{
	typedef raw::Matrix<vt,struct_banded> M1;
	static bool eval(const M1& A)
	{
		Integer r = A.rows(), c = A.cols(), nz = A.nnz();
		if (Real(nz) < Real(r)*Real(c))
		{
			if (!test::eval(0.))
			{
				return false;
			};
		};

		if (nz == 0)
		{
			return true;
		};

        const vt* ptr_A = A.rep_ptr();

		for (Integer j = 0; j <  c; ++j)
		{
			Integer fr = A.first_row(j);
			Integer lr = A.last_row(j);
			Integer pos = A.first_elem_pos(j);

			for (Integer i = fr; i <= lr; ++i, ++pos)
			{
				if (!test::eval(ptr_A[pos]))
				{
					return false;
				};
			};

            ptr_A += A.ld();
		}
		return true;
	};
};
template<class vt, class st, class test>
struct test_range
{
	typedef raw::Matrix<vt,st> M1;
	static const bool iso = details::is_equal<vt,Object>::value;	
	static bool eval(const M1& A)
	{
		return test_range_impl<iso,vt,st,test>::eval(A);
	};
};
template<class st, class test>
struct test_range<Complex,st,test>
{
	typedef raw::Matrix<Complex,st> M1;
	static bool eval(const M1& )
	{
		return true;
	};
};


//=====================================================================
//						TEST MATRIX MATRIX
//=====================================================================
template<class T>	
struct is_conv_to_integer
{};
template<>
struct is_conv_to_integer<Integer>
{
	static const bool eval(Integer )	{	return true;	};
};
template<>
struct is_conv_to_integer<Complex>
{
	static const bool eval(Complex )	{	return false;	};
};
template<>
struct is_conv_to_integer<Real>
{
	static const bool eval(Real A)			
	{	
		return (A - (Integer)A) == 0;	
	};
};

template<class T1, class T2>
struct test_range_pow
{
	static bool eval(T1 A,T2 B)
	{
		if (A >= 0 || is_conv_to_integer<T2>::eval(B))
		{
			return true;
		};
		return false;
	};
};
template<class T1>
struct test_range_pow<T1,Integer>
{
	static bool eval(T1 ,Integer )
	{
		return true;
	};
};

template<class test, bool is_inv, class vt1, class vt2>
struct eval_F2
{
	static bool eval(vt1 A, vt2 B)
	{
		return test::eval(A,B);
	};
};
template<class test, class vt1, class vt2>
struct eval_F2<test,true,vt1,vt2>
{
	static bool eval(vt1 A, vt2 B)
	{
		return test::eval(B,A);
	};
};

template<class vt1, class vt2, class st1, class st2, class test, bool is_inv>
struct test_range2_impl
{};
template<class vt2, class st1, class st2, class test, bool is_inv>
struct test_range2_impl<Complex,vt2,st1,st2,test,is_inv>
{
	typedef raw::Matrix<Complex,st1> MT1;
	typedef raw::Matrix<vt2,st2> MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		return true;
	};
};
template<class vt1, class st1, class st2, class test, bool is_inv>
struct test_range2_impl<vt1, Complex,st1,st2,test,is_inv>
{	
	typedef raw::Matrix<vt1,st1> MT1;
	typedef raw::Matrix<Complex,st2> MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		return true;
	};
};
template<class st1, class st2, class test, bool is_inv>
struct test_range2_impl<Complex, Complex,st1,st2,test,is_inv>
{	
	typedef raw::Matrix<Complex,st1> MT1;
	typedef raw::Matrix<Complex,st2> MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		return true;
	};
};
//--------------------------------------------------------------------
//				GM - GM
//--------------------------------------------------------------------
template<class vt1, class vt2, class test, bool is_inv>
struct test_range2_impl<vt1,vt2,struct_dense,struct_dense,test,is_inv>
{
	typedef raw::Matrix<vt1,struct_dense> MT1;
	typedef raw::Matrix<vt2,struct_dense> MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		typedef eval_F2<test,is_inv,vt1,vt2> eval_func;

        const vt1* ptr_A = A.ptr();
        const vt2* ptr_B = B.ptr();

        for (Integer j = 0; j < A.cols(); ++j)
        {
		    for (Integer i = 0; i < A.rows(); ++i)
		    {
			    if (!eval_func::eval(ptr_A[i],ptr_B[i]))
			    {
    				return false;
	    		};
            };

            ptr_A += A.ld();
            ptr_B += B.ld();
		};
		return true;
	};
};

//--------------------------------------------------------------------
//				GM - SM
//--------------------------------------------------------------------
template<class vt1, class vt2, class test, bool is_inv>
struct test_range2_impl<vt1,vt2,struct_dense,struct_sparse,test,is_inv>
{
	typedef raw::Matrix<vt1,struct_dense> MT1;
	typedef raw::Matrix<vt2,struct_sparse> MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		if (A.rows() == 0 || A.cols() == 0 || B.nnz() == 0)
		{
			return true;
		};
		Integer c = A.cols(); 			
	 
		const raw::details::spdat<vt2>& Bd = B.rep();
		const Integer* Bd_c		= Bd.ptr_c();
		const Integer* Bd_r		= Bd.ptr_r();
		const vt2* Bd_x	        = Bd.ptr_x();
        const vt1* ptr_A        = A.ptr();

		typedef eval_F2<test,is_inv,vt1,vt2> eval_func;

		for (Integer j = 0; j < c; ++j)
		{
			for (Integer k = Bd_c[j]; k < Bd_c[j + 1] ; ++k)
			{
				Integer p		= Bd_r[k];
				if (!eval_func::eval(ptr_A[p],Bd_x[k]))
				{
					return false;
				};
			};
            ptr_A += A.ld();
		};
 
	    return true;
	};
};

//--------------------------------------------------------------------
//				GM - BM
//--------------------------------------------------------------------
template<class vt1, class vt2, class test, bool is_inv>
struct test_range2_impl<vt1,vt2,struct_dense,struct_banded,test,is_inv>
{
	typedef raw::Matrix<vt1,struct_dense> MT1;
	typedef raw::Matrix<vt2,struct_banded> MT2;

	static bool eval(const MT1& A, const MT2& B)
	{	
		Integer r = A.rows(), c = A.cols();

		typedef eval_F2<test,is_inv,vt1,vt2> eval_func;

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			Integer rc = std::min(r,c);
            const vt1* ptr_A = A.ptr();
            const vt2* ptr_B = B.rep_ptr();

			for (Integer j = 0; j < rc; ++j)
			{
				if (!eval_func::eval(ptr_A[0],ptr_B[0]))
				{
					return false;
				};

                ptr_A += A.ld() + 1;
                ptr_B += B.ld();
			};
		}
		else
		{
            const vt1* ptr_A = A.ptr();
            const vt2* ptr_B = B.rep_ptr();

			for (Integer j = 0; j < c; ++j)
			{
				Integer first_row = B.first_row(j);
				Integer last_row  = B.last_row(j);
				Integer first_elem= B.first_elem_pos(j);

				for (Integer i = first_row, pos_B = first_elem; i <= last_row; ++i, ++pos_B)
				{
					if (!eval_func::eval(ptr_A[i],ptr_B[pos_B]))
					{
						return false;
					};
				};

                ptr_A   += A.ld();
				ptr_B   += B.ld();
			};
		}; 
	    return true;
	};
};
//--------------------------------------------------------------------
//				SM - GM
//--------------------------------------------------------------------
template<class vt1, class vt2, class test, bool is_inv>
struct test_range2_impl<vt1,vt2,struct_sparse,struct_dense,test,is_inv>
{
	typedef raw::Matrix<vt1,struct_sparse> MT1;
	typedef raw::Matrix<vt2,struct_dense>  MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		return test_range2_impl<vt2,vt1,struct_dense,struct_sparse,test,!is_inv>
			::eval(B,A);
	};
};

//--------------------------------------------------------------------
//				SM - SM
//--------------------------------------------------------------------
template<class vt1, class vt2, class test, bool is_inv>
struct test_range2_impl<vt1,vt2,struct_sparse,struct_sparse,test,is_inv>
{
	typedef raw::Matrix<vt1,struct_sparse> MT1;
	typedef raw::Matrix<vt2,struct_sparse> MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		Integer r = A.rows(), c = A.cols();

		if ((r == 0) || (c == 0) )
		{
			return true;
		};
		
		Integer nzret = std::min(A.nnz(),B.nnz());

		if (nzret == 0)
		{
			return true;
		};

		const raw::details::spdat<vt1>&		Ad = A.rep();
		const raw::details::spdat<vt2>&		Bd = B.rep();

		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const vt1* Ad_x				= Ad.ptr_x();

		const Integer* Bd_c			= Bd.ptr_c();
		const Integer* Bd_r			= Bd.ptr_r();
		const vt2* Bd_x				= Bd.ptr_x();

		typedef eval_F2<test,is_inv,vt1,vt2> eval_func;
	 	 
		for (Integer j = 0; j < c; ++j)
		{
			Integer ka				= Ad_c[j]; 
			Integer kb				= Bd_c[j];

			while (ka < Ad_c[j+1] && kb < Bd_c[j+1])
			{
				if (Ad_r[ka] < Bd_r[kb])
				{
					++ka;
				}
				else if (Ad_r[ka] > Bd_r[kb])
				{
					++kb; 
				}
				else
				{ 
					if (!eval_func::eval(Ad_x[ka],Bd_x[kb]))
					{
						return false;
					};
					++ka; 
					++kb;
				};
			};
		};

		return true;
	};
};

//--------------------------------------------------------------------
//				SM - BM
//--------------------------------------------------------------------
template<class vt1, class vt2, class test, bool is_inv>
struct test_range2_impl<vt1,vt2,struct_sparse,struct_banded,test,is_inv>
{
	typedef raw::Matrix<vt1,struct_sparse> MT1;
	typedef raw::Matrix<vt2,struct_banded> MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		Integer r = A.rows(), c = A.cols();

		if ((r == 0) || (c == 0) || A.nnz() == 0)
		{
			return true;
		};	

		const raw::details::spdat<vt1>& Ad	= A.rep();
		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const vt1* Ad_x				= Ad.ptr_x();

		typedef eval_F2<test,is_inv,vt1,vt2> eval_func;

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			Integer rc = std::min(r,c);
            const vt2* ptr_B = B.rep_ptr();

			for (Integer j = 0; j < rc; ++j)
			{
				Integer ka;
				bool exist = Ad.isentry(j,j,ka);

				if (exist)
				{
					if (!eval_func::eval(Ad_x[ka],ptr_B[0]))
					{
						return false;
					};
				};
                ptr_B += B.ld();
			};
		}
		else
		{
            const vt2* ptr_B = B.rep_ptr();

			for (Integer j = 0; j < c; ++j, ptr_B += B.ld())
			{
				Integer first_row		= B.first_row(j);
				Integer last_row		= B.last_row(j);
				Integer pos_B			= B.first_elem_pos(j);
				Integer kb				= first_row;

				if (first_row >= r)
				{
					continue;
				};

				Integer ka;
				Ad.isentry(kb,j,ka);

				if (ka == Ad_c[j+1] || Ad_r[ka] > last_row)
				{
					continue;
				};
				while (ka < Ad_c[j+1] && kb <= last_row)
				{
					if (Ad_r[ka] > kb)
					{
						++kb; 
						++pos_B;
					}
					else
					{ 
						if (!eval_func::eval(Ad_x[ka],ptr_B[pos_B]))
						{
							return false;
						};
						++ka; 
						++kb;
						++pos_B;
					};
				};                
			};
		};

		return true;
	};
};
//--------------------------------------------------------------------
//				BM - GM
//--------------------------------------------------------------------
template<class vt1, class vt2, class test, bool is_inv>
struct test_range2_impl<vt1,vt2,struct_banded,struct_dense,test,is_inv>
{
	typedef raw::Matrix<vt1,struct_banded> MT1;
	typedef raw::Matrix<vt2,struct_dense>  MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		return test_range2_impl<vt2,vt1,struct_dense,struct_banded,test,!is_inv>
			::eval(B,A);
	};
};

//--------------------------------------------------------------------
//				BM - SM
//--------------------------------------------------------------------
template<class vt1, class vt2, class test, bool is_inv>
struct test_range2_impl<vt1,vt2,struct_banded,struct_sparse,test,is_inv>
{
	typedef raw::Matrix<vt1,struct_banded> MT1;
	typedef raw::Matrix<vt2,struct_sparse>  MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		return test_range2_impl<vt2,vt1,struct_sparse,struct_banded,test,!is_inv>
			::eval(B,A);
	};
};

//--------------------------------------------------------------------
//				BM - BM
//--------------------------------------------------------------------
template<class vt1, class vt2, class test, bool is_inv>
struct test_range2_impl<vt1,vt2,struct_banded,struct_banded,test,is_inv>
{
	typedef raw::Matrix<vt1,struct_banded> MT1;
	typedef raw::Matrix<vt2,struct_banded>  MT2;

	static bool eval(const MT1& A, const MT2& B)
	{
		Integer r = A.rows(), c = A.cols();
		Integer ua = A.udiags(), la = A.ldiags(), ub = B.udiags(), lb = B.ldiags();
	
		Integer kl = (la > lb) ? la : lb;
		Integer ku = (ua > ub) ? ua : ub;

		kl		= std::min(kl,la);
		ku		= std::min(ku,ua);
		kl		= std::min(kl,lb);
		ku		= std::min(ku,ub);

		//Integer lu = kl + ku;

		typedef eval_F2<test,is_inv,vt1,vt2> eval_func;

		if (la == 0 && lb == 0 && ua == 0 && ub == 0)
		{
			Integer rc = std::min(r,c);
            const vt2* ptr_B = B.rep_ptr();
            const vt1* ptr_A = A.rep_ptr();

			for (Integer i = 0; i < rc; ++i)
			{
				if (!eval_func::eval(ptr_A[0], ptr_B[0]))
				{
					return false;
				};
                ptr_A += A.ld();
                ptr_B += B.ld();
			};
			return true;
		};

        const vt2* ptr_B = B.rep_ptr();
        const vt1* ptr_A = A.rep_ptr();

		// subdiagonals
		for (Integer d = 1, ist = ku + 2, jsta = ua + 1, jstb = ub + 1; d <= kl; ++d, ++ist)
		{
			Integer s = (r - d < c) ? r - d : c;
			if ( (d <= la) && (d <= lb) )
			{
				for (Integer i = 1, jja = jsta, jjb = jstb;
					 i <= s; ++i, jja += A.ld(), jjb += B.ld())
				{
					if (!eval_func::eval(ptr_A[jja], ptr_B[jjb]))
					{
						return false;
					};
				};
				++jsta;
                ++jstb;
			}
			else if (d <= la)
			{
				++jsta;
			}
			else
			{
				++jstb;
			};
		};

		// main & superdiagonals
		for (Integer d = 0, jsta = ua, jstb = ub; d <= ku; ++d)
		{
			Integer s = (c - d < r) ? c - d : r;
			if ( (d <= ua) && (d <= ub) )
			{
				for (Integer i = 1, jja = jsta, jjb = jstb; i <= s; ++i, jja += A.ld(), jjb += B.ld())
				{
					if (!eval_func::eval(ptr_A[jja], ptr_B[jjb]))
					{
						return false;
					};
				};
				jsta += A.ld() - 1; 
                jstb += B.ld() - 1;
			}
			else if (d <= ua)
			{
				jsta += A.ld() - 1;
			}
			else
			{
				jstb += B.ld() - 1;
			};
		};
		return true;
	};
};

template<class M1, class M2, class test>
struct test_range2
{
	static bool eval(const M1& A, const M2& B)
	{
		typedef M1::value_type vt1;
		typedef M2::value_type vt2;
		typedef M1::struct_type st1;
		typedef M2::struct_type st2;
		return test_range2_impl<vt1,vt2,st1,st2,test,false>::eval(A,B);
	};
};

};};