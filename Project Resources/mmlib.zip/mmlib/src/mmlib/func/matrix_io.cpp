/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/matrix_io.h"
#include "mmlib/matrix_traits.h"
#include "mmlib/container/matrix2.inl"
#include "mmlib/details/extract_type.h" 
#include "mmlib/visitors/extract_type_switch.h" 
#include "mmlib/func/raw/disp.h"
#include "mmlib/container/matrix_container.inl"
#include "mmlib/func/raw/io.h"
#include "mmlib/matrix_gen.h"
#include "mmlib/base/serialize.h"

namespace mmlib
{

namespace details
{
    template<class value_type>
    struct matrix_value_string{};
    template<> struct matrix_value_string<Integer>
    {
	    static std::string eval()	{	return "Integer";	};
    };
    template<> struct matrix_value_string<Real>
    {
	    static std::string eval()	{	return "Real";		};
    };
    template<> struct matrix_value_string<Complex>
    {
	    static std::string eval()	{	return "Complex";	};
    };
    template<> struct matrix_value_string<Object>
    {
	    static std::string eval()	{	return "Object";	};
    };

    template<class struct_type>
    struct matrix_struct_string{};

    template<> struct matrix_struct_string<struct_dense>
    {
	    static std::string eval()	{	return "dense";	};
    };
    template<> struct matrix_struct_string<struct_banded>
    {
	    static std::string eval()	{	return "banded";	};
    };
    template<> struct matrix_struct_string<struct_sparse>
    {
	    static std::string eval()	{	return "sparse";	};
    };

    static std::string get_struct_flag_string(struct_flag sf)
    {
        switch (sf.get())
        {
            case details::struct_flag_impl::zero:      return "zero";
            case details::struct_flag_impl::id:        return "identity";
            case details::struct_flag_impl::diag:      return "diagonal";
            case details::struct_flag_impl::tril:      return "ltriang";
            case details::struct_flag_impl::triu:      return "utriang";
            case details::struct_flag_impl::sym:       return "symmetric";
            case details::struct_flag_impl::her:       return "hermitian";
            case details::struct_flag_impl::unitary:   return "unitary";
            case details::struct_flag_impl::qtril:     return "qltriang";
            case details::struct_flag_impl::qtriu:     return "qutriang";
            case details::struct_flag_impl::general:   return "general";
            default:                                   return "unknown";
        };
    };

    struct save_functor : public details::extract_type_1<std::ostream&,save_functor,true>
    {
        template<class T>
        static std::ostream& eval(const Matrix&, const T& mat, std::ostream& os)
        {
            mmlib::struct_flag sf = mat.get_struct();

            os << "\n[\n";
            os << matrix_value_string<T::value_type>::eval() << ' ';
		    os << matrix_struct_string<T::struct_type>::eval();
            os << ' ' << get_struct_flag_string(sf);
            os << '\n';
            raw::save(os,mat);
            os << "\n]\n";
            return os;
        };
        template<class T>
        static std::ostream& eval_scalar(const Matrix&, const T& mat, std::ostream& os)
        {
            os << "\n[\n";
            os << matrix_value_string<T>::eval() << ' ';
		    os << "scalar" << '\n';
            mmlib::raw::details::write(os,mat);
            os << "\n]\n";
            return os;
        };
    };
    template<class T>
    struct load_functor_impl
    {
        static Matrix eval(std::istream& is)
        {
            typedef raw::Matrix<T::value_type,T::struct_type> matrix_type;
		    matrix_type tmp(gd::get_raw_ti());
		    raw::load(is,tmp);
		    return Matrix(tmp,false);
        };
    };
    template<class s_type>
    struct load_functor_impl<raw::Matrix<Object,s_type>>
    {
        static Matrix eval(std::istream& is)
        {
            typedef raw::Matrix<Object,s_type> matrix_type;

            gd::type_info ti = gd::get_empty_ti();
            raw::load(is,ti);

		    matrix_type tmp(ti);
		    raw::load(is,tmp);
		    return Matrix(tmp,false);
        };
    };
    struct load_functor : public details::extract_type_switch_type<Matrix,load_functor>
    {
        template<class T>
        static Matrix eval(std::istream& is)
        {
            return load_functor_impl<T>::eval(is);
        };
        template<class T>
        static Matrix eval_scalar(std::istream& is)
        {
		    T tmp;
            mmlib::raw::details::skipblank(is);
		    mmlib::raw::details::read(is,tmp);
            mmlib::raw::details::skipblank(is);
            return Matrix(tmp,false);
        };
        template<>
        static Matrix eval_scalar<Object>(std::istream& is)
        {
            gd::type_info ti = gd::get_empty_ti();
            raw::load(is,ti);

		    Object tmp(ti);
            mmlib::raw::details::skipblank(is);
		    mmlib::raw::details::read(is,tmp);
            mmlib::raw::details::skipblank(is);
            return Matrix(tmp,false);
        };
    };

    static void load_begin(std::istream& is)
    {
	    raw::details::skipblank(is);
	    if (!is.good())
	    {
		    throw error::error_unable_to_read_matrix();
	    };
	    char c;
	    is.get(c);

	    if (!is.good() || c != '[')
	    {
		    throw error::error_unable_to_read_matrix();
	    };

	    raw::details::skipblank(is);
	    if (!is.good())
	    {
		    throw error::error_unable_to_read_matrix();
	    };
    };
    static void load_end(std::istream& is)
    {
        char c;
        is.get(c);
        if (c != ']')
        {
		    throw error::error_unable_to_read_matrix();
	    };
        is.get(c);
        if (c != '\n')
        {
		    throw error::error_unable_to_read_matrix();
	    };

    };
    static void load_matrix_type(std::istream& is,enums::value_type& val_type,
                            enums::struct_type& struct_type, struct_flag& sf)
    {
	    std::string tmp;

	    is >> tmp;
	    if (!is.good())
	    {
		    throw error::error_unable_to_read_matrix();
	    };

	    if (tmp == "integer" || tmp == "Integer" || tmp == "INTEGER" || tmp == "int")
	    {
		    val_type = enums::value_integer;
	    }
	    else if (tmp == "real" || tmp == "Real" || tmp == "REAL" || tmp == "float" || tmp == "double")
	    {
		    val_type = enums::value_real;
	    }
	    else if (tmp == "complex" || tmp == "Complex" || tmp == "COMPLEX")
	    {
		    val_type = enums::value_complex;
	    }
	    else if (tmp == "object" || tmp == "Object" || tmp == "OBJECT")
	    {
		    val_type = enums::value_object;
	    }
	    else
	    {
		    throw error::error_unable_to_read_matrix();
	    };

	    is >> tmp;
	    if (!is.good())
	    {
		    throw error::error_unable_to_read_matrix();
	    };

	    if (tmp == "dense" || tmp == "Dense" || tmp == "DENSE")
	    {
		    struct_type = enums::struct_dense;
	    }
	    else if (tmp == "banded" || tmp == "Banded" || tmp == "BANDED" || tmp == "band" || tmp == "Band" || tmp == "BAND")
	    {
		    struct_type = enums::struct_banded;
	    }
	    else if (tmp == "sparse" || tmp == "Sparse" || tmp == "SPARSE")
	    {
		    struct_type = enums::struct_sparse;
	    }
	    else if (tmp == "scalar" || tmp == "Scalar" || tmp == "SCALAR")
	    {
		    struct_type = enums::struct_scalar;
	    }
	    else
	    {
		    throw error::error_unable_to_read_matrix();
	    };

        if (struct_type != enums::struct_scalar)
        {
            is >> tmp;
        }
        else
        {
            tmp = "general";
        };

        if (tmp == "zero"      || tmp == "Zero"        || tmp == "ZERO")
        {
            sf = struct_flag(details::struct_flag_impl::zero);
        }
        else if (tmp == "identity"  || tmp == "Identity"    || tmp == "IDENTITY")
        {
            sf = struct_flag(details::struct_flag_impl::id);
        }
        else if (tmp == "diagonal"  || tmp == "Diagonal"    || tmp == "DIAGONAL")
        {
            sf = struct_flag(details::struct_flag_impl::diag);
        }
        else if (tmp == "ltriang"   || tmp == "Ltriang"     || tmp == "LTRIANG")
        {
            sf = struct_flag(details::struct_flag_impl::tril);
        }
        else if (tmp == "utriang"   || tmp == "Utriang"     || tmp == "UTRIANG")
        {
            sf = struct_flag(details::struct_flag_impl::triu);
        }
        else if (tmp == "symmetric" || tmp == "Symmetric"   || tmp == "SYMMETIC")
        {
            sf = struct_flag(details::struct_flag_impl::sym);
        }
        else if (tmp == "hermitian" || tmp == "Hermitian"   || tmp == "HERMITIAN")
        {
            sf = struct_flag(details::struct_flag_impl::her);
        }
        else if (tmp == "unitary"   || tmp == "Unitary"     || tmp == "UNITARY")
        {
            sf = struct_flag(details::struct_flag_impl::unitary);
        }
        else if (tmp == "qltriang"  || tmp == "Qltriang"    || tmp == "QLTRIANG")
        {
            sf = struct_flag(details::struct_flag_impl::qtril);
        }
        else if (tmp == "qutriang"  || tmp == "Qutriang"    || tmp == "QUTRIANG")
        {
            sf = struct_flag(details::struct_flag_impl::qtriu);
        }
        else if (tmp == "general"   || tmp == "General"     || tmp == "GENERAL")
        {
            sf = struct_flag(details::struct_flag_impl::general);
        }
        else if (tmp == "unknown"   || tmp == "Unknown"     || tmp == "UNKNOWN")
        {
            sf = struct_flag(details::struct_flag_impl::general);
        }
        else
        {
            throw error::error_unable_to_read_matrix();
        };


	    raw::details::skipblank(is);
	    if (!is.good())
	    {
		    throw error::error_unable_to_read_matrix();
	    };
    };
};

std::ostream& mmlib::operator<<(std::ostream& os, const Matrix& A)
{
    return details::save_functor::make<const Matrix&,std::ostream&>(A,os);
};
std::istream& mmlib::operator>>(std::istream& is, Matrix& A)
{
    enums::value_type   val_type;
    enums::struct_type  struct_type;
    struct_flag sf;
    details::load_begin(is);

    details::load_matrix_type(is,val_type,struct_type,sf);

    enums::mat_type mat_type = matrix_traits::get_matrix_type(val_type,struct_type);

    A = details::load_functor::make<std::istream&>(mat_type,is);
    details::load_end(is);
    A.set_struct(sf);
    return is;
};

void mmlib::disp(const Matrix& m)
{
	disp_stream tmp(raw::get_console_output());
	return disp(tmp,m);
};
void mmlib::disp(disp_stream& os,const Matrix& m)
{
	switch(m.matrix_type())
	{
		case enums::integer_scalar:
		{
			return raw::disp(os,m.get_scalar<Integer>());
		}
		case enums::real_scalar:
		{
			return raw::disp(os,m.get_scalar<Real>());
		}
		case enums::complex_scalar:
		{
			return raw::disp(os,m.get_scalar<Complex>());
		}
		case enums::object_scalar:
		{
			return raw::disp(os,m.get_scalar<Object>());
		}
		default:
		{
            return details::matrix_data_accesser::get_ptr(m)->disp(os);
		}
	};
};
void mmlib::disp(char* val)
{
	disp_stream tmp(raw::get_console_output());
	return disp(tmp,val);
};
void mmlib::disp(const std::string& val)
{
	disp_stream tmp(raw::get_console_output());
	return disp(tmp,val);
};

void mmlib::details::disp_impl(Integer val)
{
	disp_stream tmp(raw::get_console_output());
	return details::disp_impl(tmp,val);
};
void mmlib::details::disp_impl(const Real& val)
{
	disp_stream tmp(raw::get_console_output());
	return details::disp_impl(tmp,val);
};
void mmlib::details::disp_impl(const Complex& val)
{
	disp_stream tmp(raw::get_console_output());
	return details::disp_impl(tmp,val);
};

void mmlib::disp(disp_stream& os, char* val)
{
	raw::disp(os, val);
};
void mmlib::disp(disp_stream& os, const std::string& val)
{
	raw::disp(os, val);
};
void mmlib::details::disp_impl(disp_stream& os, Integer val)
{
	raw::disp(os, val);
};
void mmlib::details::disp_impl(disp_stream& os, const Real& val)
{
	raw::disp(os, val);
};
void mmlib::details::disp_impl(disp_stream& os, const Complex& val)
{
	raw::disp(os, val);
};

namespace details
{
    struct serialize_save_functor : public details::extract_type_1<void,serialize_save_functor,true>
    {
        template<class T>
        static void eval(const Matrix& h, const T& , oarchive_impl& os)
        {
            typedef matrix_container<T::value_type,T::struct_type> cont_type;
			const cont_type* c = static_cast<const cont_type*>(matrix_data_accesser::get_ptr(h));
			os << c;
        };
        template<class T>
        static void eval_scalar(const Matrix& , const T& mat, oarchive_impl& os)
        {
            mmlib::details::serialize_save(os,mat,0);
        };
        template<>
        static void eval_scalar<Object>(const Matrix& , const Object& mat, oarchive_impl& os)
        {
            type_info ti = mat.get_ti();
            mmlib::details::serialize_save(os,ti,0);
            mmlib::details::serialize_save(os,mat,0);
        };
    };

    template<class T, class S, class Mat>
    static void init(T& owner,S* cont, Mat& mat)
    {
        owner.m_ref = mat.get_refstr();
        owner.mat_ptr = cont; 
        if (cont->get_count() > 0)
        {        
            owner.m_ref->increase();
        };
        cont->increase();
    };
    struct serialize_load_functor : public details::extract_type_switch_type<Matrix,serialize_load_functor>
    {
        template<class T>
        static Matrix eval(iarchive_impl& is)
        {
			typedef matrix_container<T::value_type,T::struct_type> cont_type;
			cont_type* tmp;
			is >> tmp;

            Matrix out;
            init(matrix_data_accesser::get_base(out).m_value.m_mat,tmp,tmp->get());
            enums::mat_type mt = matrix_traits::mat_type_info_type<T>::matrix_code;
			matrix_data_accesser::get_base(out).m_type = mt;
            return out;
        };
        template<class T>
        static Matrix eval_scalar(iarchive_impl& is)
        {
            T val;
            mmlib::details::serialize_load(is,val,0);
            return val;
        };
        template<>
        static Matrix eval_scalar<Object>(iarchive_impl& is)
        {
            type_info ti = get_raw_ti();
            mmlib::details::serialize_load(is,ti,0);

            Object val(ti);
            mmlib::details::serialize_save(is,val,0);
            return val;
        };
    };
};

void mmlib::load(iarchive & ar, Matrix& m)
{
	int code;
	ar.get() >> code;

    m = details::serialize_load_functor::make<iarchive_impl&>((enums::mat_type)code,ar.get());
};

void mmlib::save(oarchive & ar, const Matrix& m)
{
    int code = m.matrix_type();
    ar.get() << code;
    return details::serialize_save_functor::make<const Matrix&,oarchive_impl&>(m,ar.get());
};

};