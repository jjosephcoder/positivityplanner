/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/mmlib_header.h"
#include "mmlib/base/optim_params.h"
#include "mmlib/container/raw/type_decl.h"

#include <vector>

namespace mmlib { namespace details
{

//======================================================================
//                          matrix_info
//======================================================================


class matrix_info
{
	private:
		Integer				    m_rows;
		Integer				    m_cols;
		enums::struct_type	    m_str;
		enums::value_type	    m_val_type;
        struct_flag             m_flag;
		Real				    m_nnz;

	public:
		matrix_info();

		matrix_info(const Matrix& mat);

		static matrix_info	link_info(const matrix_info&, const matrix_info&);
		static Real			estimate_cost(const matrix_info&, const matrix_info&);
        static Real			estimate_cost_nnz(const matrix_info&, const matrix_info&);
		static Real			struct_mult_cost(enums::struct_type, enums::struct_type);
        static Real			estim_nnz(const matrix_info&, const matrix_info&);
};

matrix_info::matrix_info()
:m_rows(0),m_cols(0),m_str(enums::struct_scalar), m_val_type(enums::value_integer), m_nnz(0)
{};

matrix_info::matrix_info(const Matrix& mat)
:m_rows(mat.rows()),m_cols(mat.cols()),m_str(mat.struct_type()), 
 m_val_type(mat.value_type()), m_nnz(mat.nnz()), m_flag(mat.get_struct())
{};

matrix_info matrix_info::link_info(const matrix_info& mi1, const matrix_info& mi2)
{
	matrix_info out;
	out.m_rows      = mi1.m_rows;
	out.m_cols      = mi2.m_cols;
	out.m_str       = std::max(mi1.m_str,mi2.m_str);
	out.m_val_type  = std::max(mi1.m_val_type,mi2.m_val_type);
    out.m_nnz       = estim_nnz(mi1,mi2);
    out.m_flag      = struct_flag::mult_struct(mi1.m_flag,mi2.m_flag);

	return out;
};
Real matrix_info::estim_nnz(const matrix_info& mi1, const matrix_info& mi2)
{
    if (mi1.m_cols == 0 || mi2.m_cols == 0 || mi1.m_rows == 0 || mi2.m_rows == 0)
    {
        return 0;
    };
    switch(mi1.m_flag.get())
    {
        case struct_flag::zero:      return 0;
        case struct_flag::id:        return mi2.m_nnz;
        case struct_flag::diag:
        {
            if (mi1.m_rows == mi1.m_cols) 
                return mi2.m_nnz;
            break;
        }
    };
    switch(mi2.m_flag.get())
    {
        case struct_flag::zero:      return 0;
        case struct_flag::id:        return mi1.m_nnz;
        case struct_flag::diag:
        {
            if (mi2.m_rows == mi2.m_cols) 
                return mi1.m_nnz;
            break;
        }
    };

	Real rb = Real(mi2.m_nnz)/Real(mi2.m_cols);
	Real da = Real(mi1.m_nnz)/Real(mi1.m_rows)/Real(mi1.m_cols);
	Real db = Real(mi2.m_nnz)/Real(mi2.m_rows)/Real(mi2.m_cols);
	Real pb0 = std::pow(1. - db,Real(mi2.m_rows));

	Real nnz  = 0;
	if (pb0 != 1.)
	{
		rb      = std::min(rb/(1-pb0),Real(mi2.m_rows));
		Real ed = (1. - std::pow(1. - da,rb))*(1-pb0);

		nnz     = mi1.m_rows*mi2.m_cols*ed;
	};
    assertion(nnz/mi1.m_rows/mi2.m_cols <= 1,"error in estimation of number of nonzeros");
    return nnz;
};
Real matrix_info::estimate_cost(const matrix_info& mi1, const matrix_info& mi2)
{
    Real out = estimate_cost_nnz(mi1,mi2);
    if (out == 0)
    {
        return 0;
    };

	if (mi1.m_val_type == enums::value_complex || mi2.m_val_type == enums::value_complex)
	{
		out			= out * 4.;
	}
	else if (mi2.m_val_type == enums::value_object || mi1.m_val_type == enums::value_object)
	{
		out			= out * 100.;
	};

	out				= out * struct_mult_cost(mi1.m_str, mi2.m_str);
	return out;
};
Real matrix_info::estimate_cost_nnz(const matrix_info& mi1, const matrix_info& mi2)
{
	if (mi2.m_nnz == 0 || mi1.m_nnz == 0)
	{
		return 0;
	};
	if (mi2.m_flag.is_zero() == true || mi1.m_flag.is_zero() == true)
	{
		return 0;
	};
	if (mi2.m_flag.is_id() == true || mi1.m_flag.is_id() == true)
	{
		return 0;
	};
    if (mi1.m_flag.is_diag() == true)
    {
        return mi2.m_nnz;
    };
    if (mi2.m_flag.is_diag() == true)
    {
        return mi1.m_nnz;
    };

	Real out = 0;
	Real rb = Real(mi2.m_nnz)/mi2.m_cols;
	Real da = Real(mi1.m_nnz)/Real(mi1.m_rows)/Real(mi1.m_cols);
	Real db = Real(mi2.m_nnz)/Real(mi2.m_rows)/Real(mi2.m_cols);
	Real pb0 = std::pow(1. - db,Real(mi2.m_rows));
	if (pb0 == 1.)
	{
		return out;
	};
	rb				= min(rb/(1-pb0),mi2.m_rows);

	out             = da*rb*mi2.m_cols;
    return out;
};
Real matrix_info::struct_mult_cost(enums::struct_type s1, enums::struct_type s2)
{
	switch (s1)
	{
		case enums::struct_dense:
			switch (s2)
			{
				case enums::struct_dense:
                    return optim_params::mult_cost_dense_dense;
				case enums::struct_sparse:
					return optim_params::mult_cost_dense_sparse;
				case enums::struct_banded:
					return optim_params::mult_cost_dense_banded;
			};
			break;
		case enums::struct_sparse:
			switch (s2)
			{
				case enums::struct_dense:
					return optim_params::mult_cost_sparse_dense;
				case enums::struct_sparse:
					return optim_params::mult_cost_sparse_sparse;
				case enums::struct_banded:
					return optim_params::mult_cost_sparse_banded;
			};
			break;
		case enums::struct_banded:
			switch (s2)
			{
				case enums::struct_dense:
					return optim_params::mult_cost_banded_dense;
				case enums::struct_sparse:
					return optim_params::mult_cost_banded_sparse;
				case enums::struct_banded:
					return optim_params::mult_cost_banded_banded;
			};
			break;
	};
	assertion(0,"unknown case");
	throw;
};

//======================================================================
//                          matrix_chain
//======================================================================
class matrix_chain
{
	private:
		std::vector<Matrix>     m_list;
        raw::IntegerMatrix		m_indices;	
		Matrix					m_scal;
        bool                    scaled;

	public:
		matrix_chain(Integer n);
		
        void    add(const Matrix& m);
		Matrix	make();

	private:
		Matrix	make(Integer i, Integer j);
        Matrix  mult(const Matrix& A, const Matrix& B);
        void	factor();
};

matrix_chain::matrix_chain(Integer n)
:m_indices(details::get_raw_ti())
{
    m_list.reserve(n);
    m_scal = 1.;
    scaled = false;
};
		
void matrix_chain::add(const Matrix& m)
{
    if (m.is_scalar())
    {
        m_scal = m_scal*m;
        return;
    }
    if (m_list.size() > 0)
    {
        error::check_mul(m_list.back().rows(),m_list.back().cols(),m.rows(),m.cols());
    };
    m_list.push_back(m);
};
Matrix matrix_chain::make()
{
    if (m_list.size() == 0)
    {
        return m_scal;
    };
    if (m_list.size() == 1)
    {
        return mult(m_scal,m_list[0]);
    };
    if (m_list.size() == 2)
    {
        Integer nz1 = m_list[0].nnz();
        Integer nz2 = m_list[1].nnz();
        if (nz1 < nz2)
        {
            return mult(mult(m_scal, m_list[0]),m_list[1]);
        }
        else
        {
            return mult(m_list[0],mult(m_scal,m_list[1]));
        };
    };

    factor();
    return make(1,m_list.size());
};
void matrix_chain::factor()
{
	Integer N       = m_list.size();

    m_indices.assign(raw::IntegerMatrix(details::get_raw_ti(),N,N));
    raw::RealMatrix m_cost = raw::RealMatrix(details::get_raw_ti(),N,N);

    Real* ptr_cost = m_cost.ptr();
    Integer* ptr_i = m_indices.ptr();

	for (Integer i = 0, pos = 0; i < N; ++i, pos += m_cost.ld() + 1)
	{
		ptr_cost[pos] = 0;
	};

	typedef std::vector<matrix_info>	vec_info;
	typedef std::vector<vec_info>		mat_info;

	mat_info m_info(N);

	for (Integer i = 0; i < N; ++i)
	{
		const Matrix& A = m_list[i];
		matrix_info inf_A(A);

		vec_info v_info(N);
		v_info[i] = inf_A;

		for (Integer k = i+1; k < N; ++k)
		{
			const Matrix& B = m_list[k];
			matrix_info inf_B(B);

			inf_A = matrix_info::link_info(inf_A,inf_B);
			v_info[k] = inf_A;
		};

		m_info[i] = v_info;
	};

    Integer ldc = m_cost.ld();
    Integer ldi = m_indices.ld();

	for (Integer l = 1; l < N; ++l)
	{
		for (Integer i = 0; i < N-l; ++i)
		{            
			Integer j = i + l;
			ptr_cost[i+j*ldc] = constants::Inf;

			for (Integer k = i; k < j; ++k)
			{
				Real cost = matrix_info::estimate_cost(m_info[i][k],m_info[k+1][j]);
				Real q = ptr_cost[i+k*ldc] + ptr_cost[k+1+j*ldc] + cost;

				if (q < ptr_cost[i+j*ldc])
				{
					ptr_cost[i+j*ldc] = q;
					ptr_i[i+j*ldi] = k+1;
				};
			};
		};
	};
	return;
};
Matrix matrix_chain::make(Integer i, Integer j)
{
	if (i==j)
	{
		if (scaled)
		{
			return m_list[i-1];
		}
		else
		{
			scaled = true;
			return mult(m_scal,m_list[i-1]);
		};
	};

	Integer k = m_indices.ptr()[i-1+(j-1)*m_indices.ld()];
	Matrix X = make(i,k);
	Matrix Y = make(k+1,j);
	return mult(X,Y);
};
Matrix matrix_chain::mult(const Matrix& A, const Matrix& B)
{
    if ((A.value_type() == enums::value_integer) && (B.value_type() == enums::value_integer))
    {
        if (A.nnz() < B.nnz())
        {
            return (A+0.)*B;
        }
        else
        {
            return A*(B+0.);
        };
    }
    else
    {
        return A*B;
    };
};
};

//======================================================================
//                          chain_mult
//======================================================================
Matrix mmlib::chain_mult(const Matrix& A1, const Matrix& A2, const Matrix& A3)
{
    details::matrix_chain mc(3);
    mc.add(A1); mc.add(A2); mc.add(A3);

    return mc.make();
};
Matrix mmlib::chain_mult(const Matrix& A1, const Matrix& A2, const Matrix& A3, const Matrix& A4)
{
    details::matrix_chain mc(4);
    mc.add(A1); mc.add(A2); mc.add(A3); mc.add(A4);

    return mc.make();
};
Matrix mmlib::chain_mult(const Matrix& A1, const Matrix& A2, const Matrix& A3, const Matrix& A4, 
                        const Matrix& A5)
{
    details::matrix_chain mc(5);
    mc.add(A1); mc.add(A2); mc.add(A3); mc.add(A4); mc.add(A5);

    return mc.make();
};
Matrix mmlib::chain_mult(const Matrix& A1, const Matrix& A2, const Matrix& A3, const Matrix& A4, 
                        const Matrix& A5, const Matrix& A6)
{
    details::matrix_chain mc(6);
    mc.add(A1); mc.add(A2); mc.add(A3); mc.add(A4); mc.add(A5); mc.add(A6);

    return mc.make();
};

};