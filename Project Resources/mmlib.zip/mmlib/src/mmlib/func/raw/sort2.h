/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/enablers.h"
#include "mmlib/mp/promote_type.h"
#include "mmlib/base/return_types.h"

namespace mmlib { namespace raw
{

template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sort>>::type
sort(const M& arg_1,Integer dim)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sort(promote_type::eval(arg_1),dim);
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sort>>::type
sort(const M& arg_1,Integer dim, IntegerMatrix& ind)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sort_2(promote_type::eval(arg_1),dim,ind);
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sortrows>>::type
sortrows(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sortrows(promote_type::eval(arg_1));
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sortcols>>::type
sortcols(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sortcols(promote_type::eval(arg_1));
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sortrows_2>>::type
sortrows2(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sortrows_2(promote_type::eval(arg_1));
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sortcols_2>>::type
sortcols2(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sortcols_2(promote_type::eval(arg_1));
};

template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sortrows>>::type
sortrows(const M& arg_1, const IntegerMatrix & dims)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sortrows(promote_type::eval(arg_1),dims);
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sortcols>>::type
sortcols(const M& arg_1, const IntegerMatrix & dims)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sortcols(promote_type::eval(arg_1),dims);
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sortrows_2>>::type
sortrows2(const M& arg_1, const IntegerMatrix & dims)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sortrows_2(promote_type::eval(arg_1),dims);
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::sortcols_2>>::type
sortcols2(const M& arg_1, const IntegerMatrix & dims)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_sortcols_2(promote_type::eval(arg_1),dims);
};

template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::issorted>>::type
issorted(const M& arg_1,Integer dim)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_issorted(promote_type::eval(arg_1),dim);
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::issorted_rows>>::type
issorted_rows(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_issorted_rows(promote_type::eval(arg_1));
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::issorted_cols>>::type
issorted_cols(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::sort_helper<promote_type::type>::eval_issorted_cols(promote_type::eval(arg_1));
};

};};
