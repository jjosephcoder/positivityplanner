/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/container/raw/type_decl.h"
#include "mmlib/func/raw/mmul.h"
#include "mmlib/mp/instantiate.h"
#include "mmlib/blas/blas.h"
#include "mmlib/constants.h"
#include "mmlib/func/raw/converter.h"
#include <vector>
#include "mmlib/utils/sort.h"
#include "mmlib/func/raw/matfunc.h"
#include "mmlib/utils/utils.h"
#include "mmlib/details/scalfunc_helpers.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/details/type_info_utils.h"
#include "mmlib/details/lapack_utils.h"

namespace mmlib { namespace raw { namespace details
{

template<class SP1, class SP2>
Integer estmulnnz(const SP1 &A, const SP2 &B)
{
    Integer M = A.rows(), K = A.cols(), N = B.cols(),  ANNZ = A.nnz(), BNNZ = B.nnz();    
    double da = (double) ANNZ / ((double) M * (double) K);
	double db = (double) BNNZ / ((double) N * (double) K);
	double pb0 = pow_nc(1. - db,K);
	if (pb0 == 1.)
	{
		return 0;
	};
	double rb = (double) BNNZ / (double) N;
	rb = (rb/(1-pb0) < K)? rb/(1-pb0) : K;
	
    double ed = (1. - pow_nc(1. - da, rb))*(1-pb0);

    return icast((double) M * (double) N * ed * 1.05);
};

template<class ret, class in>
struct correct_int
{
	static in eval(in val)				{	return val;		};
};
template<>
struct correct_int<Integer,Integer>
{
	static Integer eval(Integer val)	{	return val;		};
};
template<class ret>
struct correct_int<ret,Integer>
{
	static Real eval(Integer val)		{	return val;};
};


template<class ret_type, class M1, class M2,class str_1, class str_2>
struct eval_mult { };

//========================================================================
//                      DENSE - DENSE
//========================================================================
template<class V>
struct eval_dense_diag
{
    typedef raw::Matrix<V,struct_dense> DM;

    static DM eval1(const DM& A, const DM& B)
    {
        if (B.get_struct().is_diag())
        {
            return eval_diag_diag(A,B);
        };

        Integer M = A.rows(), N = B.cols(), K = A.cols();
        Integer K1 = std::min(M,K);

        DM diag(A.get_ti(), K1, 1);

        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
        V Z = gd::default_value<V>(ret_ti);

        DM C(A.get_ti(), Z, M, N);

        const V* A_ptr  = A.ptr();
        const V* B_ptr  = B.ptr();
        V* D_ptr        = diag.ptr();
        V* C_ptr        = C.ptr();

        for(Integer i = 0; i < K1; ++i)
        {
            D_ptr[i]    = A_ptr[0];
            A_ptr       += A.ld() + 1;
        };

        for (Integer j = 0; j < N; ++j)
        {
            for (Integer i = 0; i < K1; ++i)
            {
                C_ptr[i]    = D_ptr[i]*B_ptr[i];
            };
            C_ptr       += C.ld();
            B_ptr       += B.ld();
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };

    static DM eval2(const DM& A, const DM& B)
    {
        if (A.get_struct().is_diag())
        {
            return eval_diag_diag(A,B);
        };

        Integer M = A.rows(), N = B.cols(), K = A.cols();
        Integer K1 = std::min(N,K);

        DM diag(B.get_ti(), K1, 1);

        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
        V Z = gd::default_value<V>(ret_ti);

        DM C(A.get_ti(), Z, M, N);

        const V* A_ptr  = A.ptr();
        const V* B_ptr  = B.ptr();
        V* C_ptr        = C.ptr();
        V* D_ptr        = diag.ptr();

        for(Integer i = 0; i < K1; ++i)
        {
            D_ptr[i]    = B_ptr[0];
            B_ptr       += B.ld() + 1;
        };

        for (Integer j = 0; j < K1; ++j)
        {
            V tmp       = D_ptr[j];
            if (tmp == 0.)
            {
                C_ptr   += C.ld();
                A_ptr   += A.ld();
                continue;
            };

            for (Integer i = 0; i < M; ++i)
            {
                C_ptr[i]    = A_ptr[i]*tmp;
            };

            C_ptr       += C.ld();
            A_ptr       += A.ld();
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };    
    static DM eval_diag_diag(const DM& A, const DM& B)
    {
        Integer M = A.rows(), N = B.cols(), K = A.cols();
        K = std::min(std::min(K,N),M);

        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
        V Z = gd::default_value<V>(ret_ti);

        DM C(A.get_ti(), Z, M, N);

        const V* A_ptr  = A.ptr();
        const V* B_ptr  = B.ptr();
        V* C_ptr        = C.ptr();

        for (Integer i = 0; i < K; ++i)
        {
            C_ptr[0]    = A_ptr[0]*B_ptr[0];
            A_ptr       += A.ld()+1;
            B_ptr       += B.ld()+1;
            C_ptr       += C.ld()+1;
        };

        C.set_struct(struct_flag(struct_flag::diag));
        return C;
    };
};


template<class ret_type>
struct eval_dense_dense{};

template<class V>
struct eval_dense_dense_generic
{
    typedef raw::Matrix<V,struct_dense> DM;
    static DM eval(const DM& A, const DM& B)
    {
        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
		Integer M = A.rows(), N = B.cols(), K = A.cols();
		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());

        V Z = gd::default_value<V>(ret_ti);

		if ((M == 0) || (K == 0) || (N == 0))
        {
            DM out(ret_ti,Z, M, N);
            out.get_struct().set_zero_matrix();
            return out;
        };
        if (A.get_struct().is_diag())
        {
            return eval_dense_diag<V>::eval1(A,B);
        };
        if (B.get_struct().is_diag())
        {
            return eval_dense_diag<V>::eval2(A,B);
        };

        DM out(ret_ti,Z, M, N);

        const V* ptr_A  = A.ptr();
        const V* ptr_B  = B.ptr();
        V* ptr_C        = out.ptr();
        const V* ptr_As = ptr_A;

	    for (Integer j = 0; j < N; ++j) 
		{			
            ptr_A = ptr_As;
			for (Integer l = 0; l < K; ++l) 
			{
				V temp = ptr_B[l];
				if (temp != 0) 
				{					
					for (Integer k = 0; k < M; ++k) 
					{
						ptr_C[k] += temp * ptr_A[k];
					};
				};

                ptr_A += A.ld();
			};
            ptr_B += B.ld();
            ptr_C += out.ld();
		};

        out.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return out;
    };
};

template<class V>
struct eval_dense_dense_lapack
{
    typedef raw::Matrix<V,struct_dense> DM;
    static DM eval(const DM& A, const DM& B)
    {
        gd::type_info ret_ti = gd::get_raw_ti();
		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());

		Integer M = A.rows(), N = B.cols(), K = A.cols();
		V scal1 = 1.0;

		if ((M == 0) || (K == 0) || (N == 0))
        {
            DM out(ret_ti,0., M, N);
            out.get_struct().set_zero_matrix();
            return out;
        };

		if ((M == 1) && (N == 1))
        {
            switch (A.get_struct().get())
            {
                case struct_flag::diag:     K = std::min(K,1L);break;
                case struct_flag::tril:     K = std::min(K,1L);break;
                case struct_flag::qtril:    K = std::min(K,2L);break;
            };
            switch (B.get_struct().get())
            {
                case struct_flag::diag:     K = std::min(K,1L);break;
                case struct_flag::triu:     K = std::min(K,1L);break;
                case struct_flag::qtriu:    K = std::min(K,2L);break;
            };
            V ret(lapack::dot(K, gd::lap(A.ptr()), A.ld(), gd::lap(B.ptr()), 1));
            return DM(ret_ti,ret,1,1);
        };			

		if (K == 1)
		{
            DM C(ret_ti,0., M, N);

            Integer M1 = M, N1 = N;
            switch (A.get_struct().get())
            {
                case struct_flag::diag:     M1 = std::min(M,1L);break;
                case struct_flag::triu:     M1 = std::min(M,1L);break;
                case struct_flag::qtriu:    M1 = std::min(M,2L);break;
            };
            switch (B.get_struct().get())
            {
                case struct_flag::diag:     N1 = std::min(N,1L);break;
                case struct_flag::tril:     N1 = std::min(N,1L);break;
                case struct_flag::qtril:    N1 = std::min(N,2L);break;
            };
			
            lapack::geru(M1, N1, *gd::lap(&scal1), gd::lap(A.ptr()),1,gd::lap(B.ptr()),B.ld(),
                            gd::lap(C.ptr()), C.ld());

            if (M1 == 1 && N1 == 1)     C.set_struct(struct_flag(struct_flag::diag));
            else if (M1 == 1)           C.set_struct(struct_flag(struct_flag::triu));
            else if (N1 == 1)           C.set_struct(struct_flag(struct_flag::tril));

			return C;
		}        

        if (A.size() >= B.size())
        {
            switch(A.get_struct().get())
            {
                case struct_flag::diag:     return eval_diag1(A,B);
                case struct_flag::tril:     if (M == K) return eval_tril1(A,B); break;
                case struct_flag::triu:     if (M == K) return eval_triu1(A,B); break;
                case struct_flag::sym:      return eval_sym1(A,B);
                case struct_flag::her:      return eval_her1(A,B);
            };
            switch(B.get_struct().get())
            {
                case struct_flag::diag:     return eval_diag2(A,B);
                case struct_flag::tril:     if (K == N) return eval_tril2(A,B); break;
                case struct_flag::triu:     if (K == N) return eval_triu2(A,B); break;
                case struct_flag::sym:      return eval_sym2(A,B);
                case struct_flag::her:      return eval_her2(A,B);            
            };
        }
        else
        {
            switch(B.get_struct().get())
            {
                case struct_flag::diag:     return eval_diag2(A,B);
                case struct_flag::tril:     if (K == N) return eval_tril2(A,B); break;
                case struct_flag::triu:     if (K == N) return eval_triu2(A,B); break;
                case struct_flag::sym:      return eval_sym2(A,B);
                case struct_flag::her:      return eval_her2(A,B);
            };
            switch(A.get_struct().get())
            {
                case struct_flag::diag:     return eval_diag1(A,B);
                case struct_flag::tril:     if (M == K) return eval_tril1(A,B); break;
                case struct_flag::triu:     if (M == K) return eval_triu1(A,B); break;
                case struct_flag::sym:      return eval_sym1(A,B);
                case struct_flag::her:      return eval_her1(A,B);            
            };
        };

        return eval_general(A,B);
    };
    static DM eval_general(const DM& A, const DM& B)
    {
        gd::type_info ret_ti = gd::get_raw_ti();
        V scal1 = 1.0, scal0 = 0.0;
        Integer M = A.rows(), N = B.cols(), K = A.cols();

        DM C(ret_ti,M, N);	
		
		if (N == 1)
		{
			lapack::gemv("N", M, K, *gd::lap(&scal1), gd::lap(A.ptr()), A.ld(),
							gd::lap(B.ptr()), 1, *gd::lap(&scal0), gd::lap(C.ptr()), 1);
			return C;
		}		
		else if (M == 1)
		{
			lapack::gemv("T", K, N, *gd::lap(&scal1), gd::lap(B.ptr()), B.ld(),
							gd::lap(A.ptr()), A.ld(), *gd::lap(&scal0), gd::lap(C.ptr()), C.ld());
			return C;
		}
        else
        {
            lapack::gemm("N", "N", M, N, K, *gd::lap(&scal1), gd::lap(A.ptr()), A.ld(), gd::lap(B.ptr()), B.ld(), 
                                *gd::lap(&scal0), gd::lap(C.ptr()), C.ld());
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
		return C;
    };
    static DM eval_triu1(const DM& A, const DM& B)
    {
        Integer M = A.rows(), N = B.cols(), K = A.cols();
        if (M != K)
        {
            return eval_general(A,B);
        };

        V scal1 = 1.0;
        DM C = B.copy();

        if (N == 1)
        {
            lapack::trmv("U", "N", "N", M, gd::lap(A.ptr()), A.ld(), gd::lap(C.ptr()), 1);
        }
        else
        {
            lapack::trmm("L", "U", "N", "N", K, N, *gd::lap(&scal1), gd::lap(A.ptr()), A.ld(), 
                            gd::lap(C.ptr()), C.ld());
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static DM eval_triu2(const DM& A, const DM& B)
    {
        Integer M = A.rows(), N = B.cols(), K = A.cols();
        if (N != K)
        {
            return eval_general(A,B);
        };

        DM C = A.copy();
        V scal1 = 1.;

        if (M == 1)
        {
            lapack::trmv("U", "T", "N", N, gd::lap(B.ptr()), B.ld(), gd::lap(C.ptr()), C.ld());
        }
        else
        {
            lapack::trmm("R", "U", "N", "N", M, K, *gd::lap(&scal1), gd::lap(B.ptr()), B.ld(), 
                            gd::lap(C.ptr()), C.ld());
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static DM eval_tril1(const DM& A, const DM& B)
    {
        Integer M = A.rows(), N = B.cols(), K = A.cols();
        if (M != K)
        {
            return eval_general(A,B);
        };
    
        V scal1 = 1.0;
        DM C = B.copy();

        if (N == 1)
        {
            lapack::trmv("L", "N", "N", M, gd::lap(A.ptr()), A.ld(), gd::lap(C.ptr()), 1);
        }
        else
        {
            lapack::trmm("L", "L", "N", "N", K, N, *gd::lap(&scal1), gd::lap(A.ptr()), A.ld(), 
                            gd::lap(C.ptr()), C.ld());
        }

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static DM eval_tril2(const DM& A, const DM& B)
    {
        Integer M = A.rows(), N = B.cols(), K = A.cols();
        if (M != K)
        {
            return eval_general(A,B);
        };
    
        V scal1 = 1.0;
        DM C = A.copy();

        if (M == 1)
        {
            lapack::trmv("L", "T", "N", N, gd::lap(B.ptr()), B.ld(), gd::lap(C.ptr()), C.ld());
        }
        else
        {
            lapack::trmm("R", "L", "N", "N", M, K, *gd::lap(&scal1), gd::lap(B.ptr()), B.ld(), 
                        gd::lap(C.ptr()), C.ld());
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static DM eval_sym1(const DM& A, const DM& B)
    {
        Integer M = B.rows(), N = B.cols();

        DM C(A.get_ti(), M, N);
        V scal1 = 1., scal0 = 0.;

        lapack::symm("L", "U", M, N, *gd::lap(&scal1), gd::lap(A.ptr()), A.ld(), gd::lap(B.ptr()), 
                    B.ld(), *gd::lap(&scal0), gd::lap(C.ptr()), C.ld());

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static DM eval_sym2(const DM& A, const DM& B)
    {
        Integer M = A.rows(), N = B.cols();
        V scal1 = 1.0, scal0 = 0.0;

        DM C(A.get_ti(), M, N);

        lapack::symm("R", "U", M, N, *gd::lap(&scal1), gd::lap(B.ptr()), B.ld(), gd::lap(A.ptr()), 
                    A.ld(), *gd::lap(&scal0), gd::lap(C.ptr()), C.ld());

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static DM eval_her1(const DM& A, const DM& B)
    {
        Integer M = B.rows(), N = B.cols();
        V scal1 = 1.0, scal0 = 0.0;

        DM C(A.get_ti(), M, N);

        if (N == 1)
        {
            lapack::hemv("U", M, *gd::lap(&scal1), gd::lap(A.ptr()), A.ld(), gd::lap(B.ptr()), 1, 
                        *gd::lap(&scal0), gd::lap(C.ptr()), 1);
        }
        else
        {
            lapack::hemm("L", "U", M, N, *gd::lap(&scal1), gd::lap(A.ptr()), A.ld(), gd::lap(B.ptr()), B.ld(), 
                        *gd::lap(&scal0), gd::lap(C.ptr()), C.ld());
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static DM eval_her2(const DM& A, const DM& B)
    {
        Integer M = A.rows(), N = B.cols();
        V scal1 = 1.0, scal0 = 0.0;

        DM C(A.get_ti(), M, N);
        lapack::hemm("R", "U", M, N, *gd::lap(&scal1), gd::lap(B.ptr()), B.ld(), gd::lap(A.ptr()), A.ld(), 
                        *gd::lap(&scal0), gd::lap(C.ptr()), C.ld());

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static DM eval_diag1(const DM& A, const DM& B)
    {
        return eval_dense_diag<V>::eval1(A,B);
    };
    static DM eval_diag2(const DM& A, const DM& B)
    {
        return eval_dense_diag<V>::eval2(A,B);
    };    
};

template<> struct eval_dense_dense<IntegerMatrix>
{
	static IntegerMatrix eval(const IntegerMatrix& A, const IntegerMatrix& B)
	{
        return eval_dense_dense_generic<Integer>::eval(A,B);
	};
}; 
template<> struct eval_dense_dense<ObjectMatrix>
{
	static ObjectMatrix eval(const ObjectMatrix& A, const ObjectMatrix& B)
	{
        return eval_dense_dense_generic<Object>::eval(A,B);
	};
}; 
template<> struct eval_dense_dense<RealMatrix>
{
	static RealMatrix eval(const RealMatrix& A, const RealMatrix& B)
	{
        return eval_dense_dense_lapack<Real>::eval(A,B);
    };
};
template<> struct eval_dense_dense<ComplexMatrix>
{
	static ComplexMatrix eval(const ComplexMatrix& A, const ComplexMatrix& B)
	{
        return eval_dense_dense_lapack<Complex>::eval(A,B);
    };
};

template<class ret_type, class M1, class M2>
struct eval_mult<ret_type,M1,M2,struct_dense,struct_dense> 
{ 
    static ret_type eval(const M1& A, const M2& B)
	{
        gd::type_info ret_ti = gd::return_mult_ti<M1,M2>::eval(A,B);

		ret_type AC = converter<ret_type,M1>::eval(ret_ti,A);
		ret_type BC = converter<ret_type,M2>::eval(ret_ti,B);
		return eval_dense_dense<ret_type>::eval(AC,BC);
	};
};

//========================================================================
//                      DENSE - BAND
//========================================================================
template<class V>
struct eval_dense_band_diag
{
    typedef raw::Matrix<V,struct_dense>     M1;
    typedef raw::Matrix<V,struct_banded>    M2;

    static M1 eval1(const M1& A, const M2& B)
    {
        if (B.get_struct().is_diag() || (B.ldiags() == 0 && B.udiags() == 0))
        {
            return eval_diag_diag(A,B);
        };

        Integer M = A.rows(), N = B.cols(), K = A.cols();
        Integer K1 = std::min(M,K);

        M1 diag(A.get_ti(), K1, 1);

        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
        V Z = gd::default_value<V>(ret_ti);

        M1 C(A.get_ti(), Z, M, N);

        const V* A_ptr  = A.ptr();
        V* D_ptr        = diag.ptr();
        V* C_ptr        = C.ptr();
        const V* B_ptr  = B.rep_ptr();

        for(Integer i = 0; i < K1; ++i)
        {
            D_ptr[i]    = A_ptr[0];
            A_ptr       += A.ld() + 1;
        };

        Integer ldb = B.ld();
	    for (Integer j = 0; j < N; ++j) 
		{	
			Integer first_row = B.first_row(j);
            Integer last_row = std::min(B.last_row(j),K1-1);

            Integer pos_B = B.first_elem_pos(j);

			for (Integer l = first_row; l <= last_row; ++l, ++pos_B) 
			{
                C_ptr[l]    = D_ptr[l]*B_ptr[pos_B];
			};
            C_ptr       += C.ld();
            B_ptr       += ldb;
		};

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static M1 eval2(const M1& A, const M2& B)
    {
        if (A.get_struct().is_diag())
        {
            return eval_diag_diag(A,B);
        };

        Integer M = A.rows(), N = B.cols(), K = A.cols();
        Integer K1 = std::min(N,K);

        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
        V Z = gd::default_value<V>(ret_ti);

        M1 C(A.get_ti(), Z, M, N);

        const V* A_ptr  = A.ptr();
        const V* B_ptr  = &B(1,1);
        V* C_ptr        = C.ptr();
        Integer ldb     = B.ld();

        for (Integer j = 0; j < K1; ++j)
        {
            V tmp       = B_ptr[0];
            if (tmp == 0.)
            {
                C_ptr   += C.ld();
                A_ptr   += A.ld();
                B_ptr   += ldb;
                continue;
            };

            for (Integer i = 0; i < M; ++i)
            {
                C_ptr[i]    = A_ptr[i]*tmp;
            };

            C_ptr       += C.ld();
            A_ptr       += A.ld();
            B_ptr       += ldb;
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static M1 eval_diag_diag(const M1& A, const M2& B)
    {
        Integer M = A.rows(), N = B.cols(), K = A.cols();
        K = std::min(std::min(K,N),M);

        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
        V Z = gd::default_value<V>(ret_ti);

        M1 C(A.get_ti(), Z, M, N);

        const V* A_ptr  = A.ptr();
        const V* B_ptr  = &B(1,1);
        V* C_ptr        = C.ptr();
        Integer ldb     = B.ld();

        for (Integer i = 0; i < K; ++i)
        {
            C_ptr[0]    = A_ptr[0]*B_ptr[0];
            A_ptr       += A.ld()+1;
            B_ptr       += ldb;
            C_ptr       += C.ld()+1;
        };

        C.set_struct(struct_flag(struct_flag::diag));
        return C;
    };
};

template<class ret_type>
struct eval_dense_band{};

template<class V>
struct eval_dense_band_generic
{
    typedef raw::Matrix<V,struct_dense> M1;
    typedef raw::Matrix<V,struct_banded> M2;
    static M1 eval(const M1& A, const M2& B)
	{
        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());

		Integer M = A.rows(), N = B.cols(), K = A.cols();

		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());

        V Z = gd::default_value<V>(ret_ti);

		if ((M == 0) || (K == 0) || (N == 0))
		{
			M1 out(ret_ti,Z, M, N);
            out.get_struct().set_zero_matrix();
            return out;
		};		

        if (A.get_struct().is_diag())
        {
            return eval_dense_band_diag<V>::eval1(A,B);
        };
        if (B.get_struct().is_diag() || (B.ldiags() == 0 && B.udiags() == 0))
        {
            return eval_dense_band_diag<V>::eval2(A,B);
        };

		M1 C(ret_ti,M, N);
        V* ptr_C = C.ptr();

        Integer C_size = C.size();
		for (Integer i = 0; i < C_size; ++i)
		{
			ptr_C[i] = Z;
		};

        const V* ptr_A;
        const V* ptr_B = B.rep_ptr();

	    for (Integer j = 0; j < N; ++j) 
		{	
			Integer fr = B.first_row(j);
			Integer lr = B.last_row(j);
			Integer pos_A = imult(fr,A.ld());

            ptr_A = A.ptr() + pos_A;

			for (Integer l = fr, lp = B.first_elem_pos(j); l <= lr; ++l, ++lp) 
			{
				V temp = ptr_B[lp];
				if (temp != 0) 
				{	
					for (Integer k = 0; k < M; ++k) 
					{
						ptr_C[k] += temp * ptr_A[k];
					};
				};
                ptr_A += A.ld();
			};

            ptr_B += B.ld();
			ptr_C += C.ld();
		};

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
		return C;
	};
};
template<class V>
struct eval_dense_band_lapack
{
    typedef raw::Matrix<V,struct_dense> M1;
    typedef raw::Matrix<V,struct_banded> M2;
    static M1 eval(const M1& A, const M2& B)
	{
        gd::type_info ret_ti = gd::get_raw_ti();

		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());

		Integer M = A.rows(), K = B.rows(), N = B.cols();
        Integer kl = B.ldiags(), ku = B.udiags();
        V scal1 = 1.0, scal0 = 0.0;

		if (K == 0 || N == 0 || M == 0) 
		{
			M1 out(ret_ti,0., M, N);
            out.get_struct().set_zero_matrix();
            return out;
		};		

        if (A.get_struct().is_diag())
        {
            return eval_dense_band_diag<V>::eval1(A,B);
        };
        if (B.get_struct().is_diag() || (B.ldiags() == 0 && B.udiags() == 0))
        {
            return eval_dense_band_diag<V>::eval2(A,B);
        };

		if (M == 1)
		{
            M1 C(ret_ti,1, N);

            lapack::gbmv("T", K, N, kl, ku, *gd::lap(&scal1), gd::lap(B.rep_ptr()), B.ld(), 
                    gd::lap(A.ptr()), A.ld(), *gd::lap(&scal0), gd::lap(C.ptr()), C.ld());
            return C;
		};

        switch(B.get_struct().get())
        {
            case struct_flag::tril:     if (N == K) return eval_tril(A,B); break;
            case struct_flag::triu:     if (N == K) return eval_triu(A,B); break;
            case struct_flag::sym:      return eval_sym(A,B);
        };

        return eval_general(A,B);
	};
    static M1 eval_general(const M1& A, const M2& B)
    {
        gd::type_info ret_ti = gd::get_raw_ti();
        Integer M = A.rows(), K = B.rows(), N = B.cols();
        Integer kl = B.ldiags(), ku = B.udiags();
        V scal1 = 1.0, scal0 = 0.0;

        M1 C(ret_ti,M, N);

	    const V *A_ptr  = A.ptr();
	    V *C_ptr        = C.ptr();

	    for (Integer i = 1; i <= M; ++i, ++A_ptr, ++C_ptr)
	    {
            lapack::gbmv("T", K, N, kl, ku, *gd::lap(&scal1), gd::lap(B.rep_ptr()), B.ld(), gd::lap(A_ptr), 
                        A.ld(), *gd::lap(&scal0), gd::lap(C_ptr), C.ld());
	    };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
		return C;
    };

    static M1 eval_tril(const M1& A, const M2& B)
    {
        gd::type_info ret_ti = gd::get_raw_ti();
        Integer M = A.rows(), K = A.cols();
        Integer kl = B.ldiags();

        M1 C = A.copy();
	    V *C_ptr        = C.ptr();

        const M2::value_type* ptr_B = B.rep_ptr() + B.udiags();

	    for (Integer i = 1; i <= M; ++i, ++C_ptr)
	    {
            lapack::tbmv("L","T", "N", K, kl, gd::lap(ptr_B), B.ld(), gd::lap(C_ptr), C.ld());
	    };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static M1 eval_triu(const M1& A, const M2& B)
    {
        gd::type_info ret_ti = gd::get_raw_ti();
        Integer M = A.rows(), K = A.cols();
        Integer ku = B.udiags();

        M1 C = A.copy();
	    V *C_ptr        = C.ptr();

	    for (Integer i = 1; i <= M; ++i, ++C_ptr)
	    {
            lapack::tbmv("U","T", "N", K, ku, gd::lap(B.rep_ptr()), B.ld(), gd::lap(C_ptr), C.ld());
	    };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static M1 eval_sym(const M1& A, const M2& B);
};
template<>
eval_dense_band_lapack<Real>::M1 
eval_dense_band_lapack<Real>::eval_sym(const M1& A, const M2& B)
{
    typedef Real V;

    gd::type_info ret_ti = gd::get_raw_ti();
    Integer M = A.rows(), K = A.cols(), N = B.cols();
    Integer kl = B.ldiags(), ldb = B.ld();
    V scal1 = 1., scal0 = 0.;

    M1 C(ret_ti,M, N);
    const V* A_ptr  = A.ptr();
    V *C_ptr        = C.ptr();

    for (Integer i = 1; i <= M; ++i, ++C_ptr, ++A_ptr)
    {
        lapack::sbmv<Real>("U",K, kl, *gd::lap(&scal1), gd::lap(B.rep_ptr()), ldb, gd::lap(A_ptr), A.ld(),
                    *gd::lap(&scal0), gd::lap(C_ptr), C.ld());
    };

    C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
    return C;
};
template<>
eval_dense_band_lapack<Complex>::M1 
eval_dense_band_lapack<Complex>::eval_sym(const M1& A, const M2& B)
{
    return eval_general(A,B);
};

template<> struct eval_dense_band<IntegerMatrix>
{
	static IntegerMatrix eval(const IntegerMatrix& A, const IntegerBandMatrix& B)
	{
        return eval_dense_band_generic<Integer>::eval(A,B);
	};
}; 
template<> struct eval_dense_band<ObjectMatrix>
{
	static ObjectMatrix eval(const ObjectMatrix& A, const ObjectBandMatrix& B)
	{
        return eval_dense_band_generic<Object>::eval(A,B);
	};
}; 
template<> struct eval_dense_band<RealMatrix>
{
	static RealMatrix eval(const RealMatrix& A, const RealBandMatrix& B)
	{
        return eval_dense_band_lapack<Real>::eval(A,B);
    };
};
template<> struct eval_dense_band<ComplexMatrix>
{
	static ComplexMatrix eval(const ComplexMatrix& A, const ComplexBandMatrix& B)
	{
        return eval_dense_band_lapack<Complex>::eval(A,B);
    };
};
template<class ret_type, class M1, class M2>
struct eval_mult<ret_type,M1,M2,struct_dense,struct_banded> 
{ 
	static ret_type eval(const M1& A, const M2& B)
	{
        gd::type_info ret_ti = gd::return_mult_ti<M1,M2>::eval(A,B);

		typedef ret_type::value_type value_type;
		typedef Matrix<value_type,struct_dense>  MP1;
		typedef Matrix<value_type,struct_banded> MP2;
		return eval_dense_band<ret_type>::eval(converter<MP1,M1>::eval(ret_ti,A),
                                                converter<MP2,M2>::eval(ret_ti,B));
	};
};

//========================================================================
//                      BAND - DENSE
//========================================================================
template<class V>
struct eval_band_dense_diag
{
    typedef raw::Matrix<V,struct_dense>     M1;
    typedef raw::Matrix<V,struct_banded>    M2;

    static M1 eval1(const M2& A, const M1& B)
    {
        if (B.get_struct().is_diag())
        {
            return eval_diag_diag(A,B);
        };
        Integer M = A.rows(), N = B.cols(), K = A.cols();
        Integer K1 = std::min(M,K);

        M1 diag(A.get_ti(), K1, 1);

        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
        V Z = gd::default_value<V>(ret_ti);

        M1 C(A.get_ti(), Z, M, N);

        const V* A_ptr  = &A(1,1);
        const V* B_ptr  = B.ptr();
        V* D_ptr        = diag.ptr();
        V* C_ptr        = C.ptr();
        Integer lda     = A.ld();

        for(Integer i = 0; i < K1; ++i)
        {
            D_ptr[i]    = A_ptr[0];
            A_ptr       += lda;
        };

        for (Integer j = 0; j < N; ++j)
        {
            for (Integer i = 0; i < K1; ++i)
            {
                C_ptr[i]    = D_ptr[i]*B_ptr[i];
            };
            C_ptr       += C.ld();
            B_ptr       += B.ld();
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static M1 eval2(const M2& A, const M1& B)
    {
        if (A.get_struct().is_diag() || (A.ldiags() == 0 && A.udiags() == 0))
        {
            return eval_diag_diag(A,B);
        };
        Integer M = A.rows(), N = B.cols(), K = A.cols();
        Integer K1 = std::min(N,K);

        M1 diag(B.get_ti(), K1, 1);

        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
        V Z = gd::default_value<V>(ret_ti);

        M1 C(A.get_ti(), Z, M, N);

        const V* A_ptr  = A.rep_ptr();
        const V* B_ptr  = B.ptr();
        V* C_ptr        = C.ptr();
        V* D_ptr        = diag.ptr();
        Integer lda     = A.ld();

        for(Integer i = 0; i < K1; ++i)
        {
            D_ptr[i]    = B_ptr[0];
            B_ptr       += B.ld() + 1;
        };

        for (Integer j = 0; j < K1; ++j)
        {
            V tmp       = D_ptr[j];
            if (tmp == 0.)
            {
                C_ptr   += C.ld();
                A_ptr   += lda;
                continue;
            };

			Integer first_row = A.first_row(j);
            Integer last_row = A.last_row(j);
            Integer pos_A = A.first_elem_pos(j);

			for (Integer l = first_row; l <= last_row; ++l, ++pos_A) 
			{
                C_ptr[l]    = tmp*A_ptr[pos_A];
			};

            C_ptr       += C.ld();
            A_ptr       += lda;
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static M1 eval_diag_diag(const M2& A, const M1& B)
    {
        Integer M = A.rows(), N = B.cols(), K = A.cols();
        K = std::min(std::min(K,N),M);

        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
        V Z = gd::default_value<V>(ret_ti);

        M1 C(A.get_ti(), Z, M, N);

        const V* A_ptr  = &A(1,1);
        const V* B_ptr  = B.ptr();
        V* C_ptr        = C.ptr();
        Integer lda     = A.ld();

        for (Integer i = 0; i < K; ++i)
        {
            C_ptr[0]    = A_ptr[0]*B_ptr[0];
            A_ptr       += lda;
            B_ptr       += B.ld()+1;            
            C_ptr       += C.ld()+1;
        };

        C.set_struct(struct_flag(struct_flag::diag));
        return C;
    };
};
template<class V> 
struct eval_band_dense_generic
{
    typedef raw::Matrix<V,struct_dense> M1;
    typedef raw::Matrix<V,struct_banded> M2;

	static M1 eval(const M2& A, const M1& B)
	{
        gd::type_info ret_ti = gd::return_mult_ti2(A.get_ti(),B.get_ti());
		Integer M = A.rows(), N = B.cols(), K = A.cols();

		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());
        V Z = gd::default_value<V>(ret_ti);

		if ((M == 0) || (K == 0) || (N == 0))
		{
			M1 out(ret_ti, Z, M, N);		
            out.get_struct().set_zero_matrix();
            return out;
		};

        if (A.get_struct().is_diag() || (A.ldiags() == 0 && A.udiags() == 0))
        {
            return eval_band_dense_diag<V>::eval1(A,B);
        };
        if (B.get_struct().is_diag())
        {
            return eval_band_dense_diag<V>::eval2(A,B);
        };

		M1 C(ret_ti, Z, M, N);
        const V* ptr_B  = B.ptr();
        V* ptr_C        = C.ptr();

	    for (Integer j = 0; j < N; ++j) 
		{
            const V* ptr_A = A.rep_ptr();

			for (Integer l = 0; l < K; ++l) 
			{
				V temp = ptr_B[l];

				if (temp != 0.) 
				{					
					Integer first_row = A.first_row(l);
					Integer last_row = A.last_row(l);
					Integer pos_A = A.first_elem_pos(l);

					for (Integer k = first_row; k <= last_row; ++k) 
					{
						ptr_C[k] += temp * ptr_A[pos_A++];
					};
				};
                ptr_A += A.ld();
			};
            ptr_B += B.ld();
			ptr_C += C.ld();
		};

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
		return C;
	};
};

template<class V> 
struct eval_band_dense_lapack
{
    typedef raw::Matrix<V,struct_dense> M1;
    typedef raw::Matrix<V,struct_banded> M2;

	static M1 eval(const M2& A, const M1& B)
	{
        gd::type_info ret_ti = gd::get_raw_ti();
		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());

		Integer M = A.rows(), K = A.cols(), N = B.cols();

		if (M == 0 || N == 0 || K == 0)
		{
			M1 out(ret_ti, 0., M, N);
            out.get_struct().set_zero_matrix();
            return out;
		};

        if (A.get_struct().is_diag() || (A.ldiags() == 0 && A.udiags() == 0))        
        {
            return eval_band_dense_diag<V>::eval1(A,B);
        };
        if (B.get_struct().is_diag())
        {
            return eval_band_dense_diag<V>::eval2(A,B);
        };

        switch(A.get_struct().get())
        {
            case struct_flag::tril:     if (M == K) return eval_tril(A,B); break;
            case struct_flag::triu:     if (M == K) return eval_triu(A,B); break;
            case struct_flag::sym:      return eval_sym(A,B);
            case struct_flag::her:      return eval_her(A,B);            
        };

        return eval_general(A,B);
	};
    static M1 eval_general(const M2& A, const M1& B)
    {
        gd::type_info ret_ti = gd::get_raw_ti();
        Integer M = A.rows(), K = B.rows(), Bc = B.cols();
        Integer kl = A.ldiags(), ku = A.udiags();
        V scal1 = 1.0, scal0 = 0.0;

		M1 C(ret_ti, M, Bc);

		if (Bc == 1)
		{
            lapack::gbmv("N", M, K, kl, ku, *gd::lap(&scal1), gd::lap(A.rep_ptr()), A.ld(), 
                        gd::lap(B.ptr()), 1, *gd::lap(&scal0), gd::lap(C.ptr()), 1);
			return C;
		}

		const V *B_ptr = B.ptr();
		V *C_ptr = C.ptr();
		for (Integer i = 1; i <= Bc; ++i, B_ptr += B.ld(), C_ptr += C.ld())
		{
            lapack::gbmv("N", M, K, kl, ku, *gd::lap(&scal1), gd::lap(A.rep_ptr()), A.ld(), 
                    gd::lap(B_ptr), 1, *gd::lap(&scal0), gd::lap(C_ptr), 1);
		};

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
		return C;
    };
    static M1 eval_tril(const M2& A, const M1& B)
    {
        gd::type_info ret_ti = gd::get_raw_ti();
        Integer M = A.rows(), N = B.cols();
        Integer kl = A.ldiags();
        const M2::value_type* ptr_A = A.rep_ptr() + A.udiags();

        M1 C = B.copy();
	    V *C_ptr        = C.ptr();

	    for (Integer i = 1; i <= N; ++i, C_ptr+= C.ld())
	    {
            lapack::tbmv("L","N", "N", M, kl, gd::lap(ptr_A), A.ld(), gd::lap(C_ptr), 1);
	    };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };

    static M1 eval_triu(const M2& A, const M1& B)
    {
        gd::type_info ret_ti = gd::get_raw_ti();
        Integer N = B.cols();
        Integer ku = A.udiags();

        M1 C = B.copy();
	    V *C_ptr        = C.ptr();

	    for (Integer i = 1; i <= N; ++i, C_ptr+= C.ld())
	    {
            lapack::tbmv("U","N", "N", A.cols(), ku, gd::lap(A.rep_ptr()), A.ld(), gd::lap(C_ptr), 1);
	    };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static M1 eval_her(const M2& A, const M1& B)
    {
        gd::type_info ret_ti = gd::get_raw_ti();
        Integer M = A.rows(), N = B.cols();
        Integer kl = A.ldiags();
        V scal1 = 1., scal0 = 0.;

        M1 C(ret_ti,M, N);
        const V* B_ptr  = B.ptr();
        V *C_ptr        = C.ptr();

        for (Integer i = 1; i <= N; ++i)
        {
            lapack::hbmv("U", A.cols(), kl, *gd::lap(&scal1), gd::lap(A.rep_ptr()), A.ld(), 
                        gd::lap(B_ptr), 1, *gd::lap(&scal0), gd::lap(C_ptr), 1);

            B_ptr   += B.ld();
            C_ptr   += C.ld();
        };

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
        return C;
    };
    static M1 eval_sym(const M2& A, const M1& B);
};
template<>
eval_band_dense_lapack<Real>::M1 
eval_band_dense_lapack<Real>::eval_sym(const M2& A, const M1& B)
{
    typedef Real V;
    gd::type_info ret_ti = gd::get_raw_ti();
    Integer M = A.rows(), N = B.cols();
    Integer kl = A.ldiags();
    V scal1 = 1., scal0 = 0.;

    M1 C(ret_ti,M, N);
    const V* B_ptr  = B.ptr();
    V *C_ptr        = C.ptr();

    for (Integer i = 1; i <= N; ++i)
    {
        lapack::sbmv("U", A.cols(), kl, *gd::lap(&scal1), gd::lap(A.rep_ptr()), A.ld(), gd::lap(B_ptr), 1,
                    *gd::lap(&scal0), gd::lap(C_ptr), 1);

        C_ptr   += C.ld();
        B_ptr   += B.ld();
    };

    C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
    return C;
};
template<>
eval_band_dense_lapack<Complex>::M1 
eval_band_dense_lapack<Complex>::eval_sym(const M2& A, const M1& B)
{
    return eval_general(A,B);
};


template<class ret_type>
struct eval_band_dense{};

template<> struct eval_band_dense<IntegerMatrix>
{
	static IntegerMatrix eval(const IntegerBandMatrix& A,const IntegerMatrix& B)
	{
        return eval_band_dense_generic<Integer>::eval(A,B);
	};
}; 
template<> struct eval_band_dense<ObjectMatrix>
{
	static ObjectMatrix eval(const ObjectBandMatrix& A,const ObjectMatrix& B)
	{
        return eval_band_dense_generic<Object>::eval(A,B);
	};
}; 
template<> struct eval_band_dense<RealMatrix>
{
	static RealMatrix eval(const RealBandMatrix& A, const RealMatrix& B)
	{
        return eval_band_dense_lapack<Real>::eval(A,B);
    };
};
template<> struct eval_band_dense<ComplexMatrix>
{
	static ComplexMatrix eval(const ComplexBandMatrix& A,const ComplexMatrix& B)
	{
        return eval_band_dense_lapack<Complex>::eval(A,B);
    };
};
template<class ret_type, class M1, class M2>
struct eval_mult<ret_type,M1,M2,struct_banded,struct_dense> 
{ 
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef ret_type::value_type value_type;
		typedef Matrix<value_type,struct_banded>  MP1;
		typedef Matrix<value_type,struct_dense>   MP2;

        gd::type_info ret_ti = gd::return_mult_ti<M1,M2>::eval(A,B);
		return eval_band_dense<ret_type>::eval(converter<MP1,M1>::eval(ret_ti,A),
                                                converter<MP2,M2>::eval(ret_ti,B));
	};
};

//========================================================================
//                      DENSE - SPARSE
//========================================================================
template<class ret_type, class M1, class M2>
struct eval_mult<ret_type,M1,M2,struct_dense,struct_sparse> 
{ 
	static ret_type eval(const M1& X, const M2& A)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type			val_type_1;
		typedef typename M2::value_type			val_type_2;

        gd::type_info ret_ti = gd::return_mult_ti<M1,M2>::eval(X,A);

		Integer r = X.rows(), c = A.cols();

		error::check_mul(X.rows(), X.cols(), A.rows(), A.cols());
        val_type_ret Z = gd::default_value<val_type_ret>(ret_ti);
        val_type_1 Z1 = gd::default_value<val_type_1>(ret_ti);
        
		ret_type Y(ret_ti, Z, r, c);

		if (r == 0 || X.cols() == 0 || c == 0 || A.nnz() == 0)
		{
            Y.get_struct().set_zero_matrix();
			return Y;
		};
		const spdat<val_type_2>& d     = A.rep();
        const Integer* d_c      = d.ptr_c();
        const Integer* d_r      = d.ptr_r();
        const val_type_2* d_x   = d.ptr_x();

        val_type_ret* ptr_Y     = Y.ptr();
        bool is_diag            = X.get_struct().is_diag();

        if (is_diag)
        {
            M1 D(X.get_ti(),Z1,A.rows(),1);
            val_type_1* ptr_D   = D.ptr();
            const val_type_1* ptr_X = X.ptr();

            Integer k = std::min(X.rows(),X.cols());

            for (Integer i = 0; i < k; ++i)
            {
                ptr_D[i] = ptr_X[0];
                ptr_X   += X.ld() + 1;
            };

            for (Integer j = 0; j < c; ++j)
            {
                for (Integer k = d_c[j]; k < d_c[j+1]; ++k)
                {
                    Integer l       = d_r[k];
                    val_type_2 val  = d_x[k];
                    ptr_Y[l]        += val*ptr_D[l];
                };

                ptr_Y += Y.ld();
            };
        }
        else
        {
            for (Integer j = 0; j < c; ++j)
            {
                for (Integer k = d_c[j]; k < d_c[j+1]; ++k)
                {
                    Integer l       = d_r[k];
                    val_type_2 val  = d_x[k];
                    if (val == 0)
                    {
                        continue;
                    };
                    const val_type_1* ptr_X = X.ptr()+l*X.ld();
                    for (Integer i = 0; i < r; ++i)
                    {
                        ptr_Y[i]    += val*ptr_X[i];
                    };
                };

                ptr_Y += Y.ld();
            };
        };

        Y.set_struct(struct_flag::mult_struct(X.get_struct(),A.get_struct()));
		return Y;
	};
};
//========================================================================
//                      SPARSE - DENSE
//========================================================================
template<class ret_type, class M1, class M2>
struct eval_mult<ret_type,M1,M2,struct_sparse,struct_dense> 
{ 
	static ret_type eval(const M1& A,const M2& X)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type			val_type_1;
		typedef typename M2::value_type			val_type_2;

        gd::type_info ret_ti = gd::return_mult_ti<M1,M2>::eval(A,X);

        Integer M = A.rows(), K = A.cols(), N = X.cols();		
		error::check_mul(A.rows(), A.cols(), X.rows(), X.cols());

        val_type_ret Z = gd::default_value<val_type_ret>(ret_ti);
        val_type_2 Z2 = gd::default_value<val_type_2>(gd::get_ti(X));

		ret_type Y(ret_ti, Z, M, N);

		if (M == 0 || N == 0 || K == 0 || A.nnz() == 0)
        {
            Y.get_struct().set_zero_matrix();
            return Y;
        };

		const spdat<val_type_1>& d     = A.rep();
        const Integer * A_c     = d.ptr_c();
        const Integer * A_r     = d.ptr_r();
        const val_type_1* A_x   = d.ptr_x();

        const val_type_2* ptr_X = X.ptr();
        val_type_ret* ptr_Y     = Y.ptr();

        bool is_diag            = X.get_struct().is_id();
        if (is_diag)
        {
            Integer K1 = std::min(N,K);

		    for (Integer j = 0; j < K1; ++j)
            {
			    val_type_2 val = ptr_X[j];
			    if (val == Z2)
			    {
				    continue;
			    };
			    for (Integer i = A_c[j]; i < A_c[j + 1]; ++i)
			    {
				    ptr_Y[A_r[i]] += val * A_x[i];
			    };
                ptr_X += X.ld();
                ptr_Y += Y.ld();
            };
        }
        else
        {
		    for (Integer j = 0; j < N; ++j)
            {
			    for (Integer k = 0; k < K; ++k)
			    {
				    val_type_2 val = ptr_X[k];
				    if (val == Z2)
				    {
					    continue;
				    };
				    for (Integer i = A_c[k]; i < A_c[k + 1]; ++i)
				    {
					    ptr_Y[A_r[i]] += val * A_x[i];
				    };
			    }
                ptr_X += X.ld();
                ptr_Y += Y.ld();
            };
        };

        Y.set_struct(struct_flag::mult_struct(A.get_struct(),X.get_struct()));
		return Y;
	};
};

//========================================================================
//                      SPARSE - SPARSE
//========================================================================
template<class ret_type, class M1, class M2>
struct eval_mult<ret_type,M1,M2,struct_sparse,struct_sparse> 
{ 
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type			val_type_1;
		typedef typename M2::value_type		    val_type_2;

        gd::type_info ret_ti = gd::return_mult_ti<M1,M2>::eval(A,B);

		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());

        val_type_2 Z2 = gd::default_value<val_type_2>(gd::get_ti(B));

		const Integer Cr = A.rows(), Cc = B.cols();

		if (Cr == 0 || Cc == 0 || A.cols() == 0 || A.nnz() == 0 || B.nnz() == 0)
		{
			ret_type out(ret_ti, Cr, Cc);
            out.get_struct().set_zero_matrix();
            return out;
		};

		ret_type C(ret_ti, Cr, Cc, estmulnnz(A, B));
		spdat<val_type_ret>& d = C.rep();
		const spdat<val_type_1>& Ad = A.rep();
		const spdat<val_type_2>& Bd = B.rep();

		struct xind
		{
			val_type_ret x;
			Integer ind;

            xind(gd::type_info ti)
                :x(gd::default_value<val_type_ret>(ti))
            {};
		};
        gd::vector<xind>      work(ret_ti,Cr);

		for (Integer i = 0 ; i < Cr; ++i)
		{
			work[i].ind = 0;
		};

		Integer nz		= 0;

		Integer * d_c		= d.ptr_c();
		Integer * d_r		= d.ptr_r();
		val_type_ret * d_x	= d.ptr_x();

		const Integer * A_c		= Ad.ptr_c();
		const Integer * A_r		= Ad.ptr_r();
		const val_type_1 * A_x	= Ad.ptr_x();

		const Integer * B_c		= Bd.ptr_c();
		const Integer * B_r		= Bd.ptr_r();
		const val_type_2 * B_x	= Bd.ptr_x();

		for (Integer j = 0; j < Cc; ++j)
		{
			d_c[j] = nz;
			Integer dnz = B_c[j + 1] - B_c[j];			

			if (dnz <= 1)
			{				
				if (dnz == 0)
				{					
					continue;
				};
				Integer k = B_c[j];
				val_type_2 Bx = B_x[k];
				Integer Br = B_r[k];
				if (Bx == Z2)
				{
					continue;
				};

				dnz = A_c[Br + 1] - A_c[Br];

    			if (nz + dnz > d.nzmax()) 
    			{
					d.memadd( d.nzmax() + dnz);

					d_r		= d.ptr_r();
					d_x		= d.ptr_x();
    			};

		        for (Integer ka = A_c[Br]; ka < A_c[Br + 1]; ++ka)
	            {
					d_r[nz]	= A_r[ka];
					d_x[nz] = Bx * A_x[ka];
					++nz;
				};
				continue;
			};

    		if (nz + Cr > d.nzmax()) 
    		{
				d.memadd( d.nzmax() + Cr);

				d_r		= d.ptr_r();
				d_x		= d.ptr_x();
    		};

			Integer nz_old = nz;
			Integer nk = 0;

    		for (Integer k = B_c[j] ; k < B_c[j + 1] ; ++k)
    		{
				val_type_2 Bx = B_x[k];
				Integer Br = B_r[k];
				if (Bx == Z2)
				{
					continue;
				};

				Integer nzs = nz;

		        for (Integer ka = A_c[Br]; ka < A_c[Br + 1]; ++ka)
	            {
					Integer i = A_r[ka];
					if (work[i].ind < j + 1)
					{
						work[i].ind = j + 1;
						work[i].x	= Bx * A_x[ka];
						d_r[nz]		= i;
						++nz;
					}
					else 
					{
						work[i].x	+= Bx * A_x[ka];
					};
				};

				if (nz - nzs > 0)
				{
					++nk;
				};
    		}
			if (nk > 1)
			{
				utils::sort_q(d_r+nz_old,nz - nz_old);
			};
			for (Integer k = d_c[j]; k < nz ; ++k) 
			{
				d_x[k] = work[d_r[k]].x;
			};
		};
		d_c[Cc] = nz;

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
		return C;
	};
};
//========================================================================
//                      SPARSE - BAND
//========================================================================
template<class ret_type, class M1, class M2>
struct eval_mult<ret_type,M1,M2,struct_sparse,struct_banded> 
{ 
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type			val_type_1;
		typedef typename M2::value_type		    val_type_2;

        gd::type_info ret_ti = gd::return_mult_ti<M1,M2>::eval(A,B);

		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());

        val_type_2 Z2 = gd::default_value<val_type_2>(gd::get_ti(B));

		const Integer Cr = A.rows(), Cc = B.cols();

		if (Cr == 0 || Cc == 0 || A.cols() == 0 || A.nnz() == 0)
		{
			ret_type out(ret_ti, Cr, Cc);
            out.get_struct().set_zero_matrix();
            return out;
		};

        const val_type_2* ptr_B = B.rep_ptr();

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			ret_type C(ret_ti, Cr, Cc, A.nnz());
			spdat<val_type_ret>& d = C.rep();
			const spdat<val_type_1>& Ad = A.rep();

			Integer nz			= 0;
			Integer * d_c		= d.ptr_c();
			Integer * d_r		= d.ptr_r();
			val_type_ret * d_x	= d.ptr_x();

			const Integer* Ad_c		= Ad.ptr_c();
			const Integer* Ad_r		= Ad.ptr_r();
			const val_type_1* Ad_x  = Ad.ptr_x();

			Integer rc = std::min(B.rows(),B.cols());
			for (Integer j = 0; j < rc; ++j, ptr_B += B.ld())
			{
				d_c[j] = nz;
				val_type_2 Bx = ptr_B[0];
				if (Bx == Z2)
				{
					continue;
				};
				for (Integer ka = Ad_c[j]; ka < Ad_c[j+1]; ++ka)
				{
					d_x[nz]	= Ad_x[ka]*Bx;
					d_r[nz]	= Ad_r[ka];
					++nz;
				};
			}
			for (Integer j = rc; j < Cc; ++j)
			{
				d_c[j] = nz;
			}

			d_c[Cc] = nz;
			d.memadd(-1);

            C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
			return C;
		}
		else
		{
			ret_type C(ret_ti, Cr, Cc, estmulnnz(A, B));
			spdat<val_type_ret>& d = C.rep();
			const spdat<val_type_1>& Ad = A.rep();

			Integer nz			= 0;
			Integer * d_c		= d.ptr_c();
			Integer * d_r		= d.ptr_r();
			val_type_ret * d_x	= d.ptr_x();

			const Integer* Ad_c		= Ad.ptr_c();
			const Integer* Ad_r		= Ad.ptr_r();
			const val_type_1* Ad_x  = Ad.ptr_x();

			gd::vector<val_type_ret>    work_x(ret_ti,Cr);
			std::vector<Integer>	    work_ind(Cr,0);

			for (Integer j = 0; j < Cc; ++j)
			{
    			if (nz + Cr > d.nzmax()) 
    			{
					d.memadd( d.nzmax() + Cr);

					d_r		= d.ptr_r();
					d_x		= d.ptr_x();
    			};


				d_c[j] = nz;
				Integer nz_old = nz;
				Integer nk = 0;

    			for (Integer k = B.first_row(j), pos = B.first_elem_pos(j); 
						k <= B.last_row(j); ++k, ++pos)
    			{
					val_type_2 Bx = ptr_B[pos];
					if (Bx == Z2)
					{
						continue;
					};
					Integer nzs = nz;

					for (Integer ka = Ad_c[k]; ka < Ad_c[k+1]; ++ka)
					{
						Integer i = Ad_r[ka];
						if (work_ind[i] < j + 1)
						{
							work_ind[i] = j + 1;
							work_x[i]	= Bx * Ad_x[ka];
							d_r[nz]		= i;
							++nz;
						}
						else 
						{
							work_x[i] += Bx * Ad_x[ka];
						};
					}
					if (nz - nzs > 0)
					{
						++nk;
					};
    			}
				if (nk > 1)
				{
					utils::sort_q(d_r+nz_old,nz - nz_old);
				};
				for (Integer k = d_c[j]; k < nz ; ++k) 
				{
					d_x[k] = work_x[d_r[k]] ;
				};

                ptr_B += B.ld();
			}
			d_c[Cc] = nz;

			d.memadd(-1);
            C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
			return C;
		};
	};
};

//========================================================================
//                      BAND - SPARSE
//========================================================================
template<class ret_type, class M1, class M2>
struct eval_mult<ret_type,M1,M2,struct_banded,struct_sparse> 
{ 
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type			val_type_1;
		typedef typename M2::value_type		    val_type_2;

        gd::type_info ret_ti = gd::return_mult_ti<M1,M2>::eval(A,B);

		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());

        val_type_2 Z2 = gd::default_value<val_type_2>(gd::get_ti(B));
        val_type_1 Z1 = gd::default_value<val_type_1>(gd::get_ti(A));

		const Integer Cr = A.rows(), Cc = B.cols();

		if (Cr == 0 || Cc == 0 || A.cols() == 0 || A.nnz() == 0 || B.nnz() == 0)
		{
			ret_type out(ret_ti, Cr, Cc);
            out.get_struct().set_zero_matrix();
            return out;
		};

        const val_type_1* ptr_A = A.rep_ptr();

		if (A.ldiags() == 0 && A.udiags() == 0)
		{
			ret_type C(ret_ti, Cr, Cc, B.nnz());
			spdat<val_type_ret>& d = C.rep();
			const spdat<val_type_2>& Bd = B.rep();

			Integer nz		= 0;

			Integer * d_c			= d.ptr_c();
			Integer * d_r			= d.ptr_r();
			val_type_ret * d_x		= d.ptr_x();

			const Integer* Bd_c		= Bd.ptr_c();
			const Integer* Bd_r		= Bd.ptr_r();
			const val_type_2* Bd_x	= Bd.ptr_x();

			Integer rc				= std::min(A.rows(),A.cols());
			for (Integer j = 0; j < Cc; ++j)
			{
				d_c[j] = nz;

    			for (Integer k = Bd_c[j] ; k < Bd_c[j + 1] ; ++k)
    			{
					val_type_2 Bx	= Bd_x[k];
					Integer Br		= Bd_r[k];
					if (Bx == Z2 || Br >= rc)
					{
						continue;
					};
					val_type_1 v	= ptr_A[Br*A.ld()];
					if (v == Z1)
					{
						continue;
					};
					d_r[nz]			= Br;
					d_x[nz]			= Bx*v;
					++nz;
    			}
			};
			d_c[Cc] = nz;

			d.memadd(-1);
            C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
			return C;
		}
		else
		{
			ret_type C(ret_ti, Cr, Cc, estmulnnz(A, B));
			spdat<val_type_ret>& d = C.rep();
			const spdat<val_type_2>& Bd = B.rep();

			gd::vector<val_type_ret>  work_x(ret_ti,Cr);
			std::vector<Integer>	  work_ind(Cr,0);

			Integer nz		= 0;

			Integer * d_c			= d.ptr_c();
			Integer * d_r			= d.ptr_r();
			val_type_ret * d_x		= d.ptr_x();

			const Integer* Bd_c		= Bd.ptr_c();
			const Integer* Bd_r		= Bd.ptr_r();
			const val_type_2* Bd_x	= Bd.ptr_x();

			for (Integer j = 0; j < Cc; ++j)
			{
    			if (nz + Cr > d.nzmax()) 
    			{
					d.memadd( d.nzmax() + Cr);

					d_r				= d.ptr_r();
					d_x				= d.ptr_x();
    			};

				d_c[j] = nz;
				Integer nz_old = nz;
				Integer nk = 0;

    			for (Integer k = Bd_c[j] ; k < Bd_c[j + 1] ; ++k)
    			{
					val_type_2 Bx	= Bd_x[k];
					Integer Br		= Bd_r[k];
					if (Bx == Z2)
					{
						continue;
					};
					Integer nzs = nz;

					Integer first_row	= A.first_row(Br);
					Integer last_row	= A.last_row(Br);
					Integer pos			= A.first_elem_pos(Br) + imult(Br,A.ld());

					for (Integer ka = first_row; ka <= last_row; ++ka, ++pos)
					{
						val_type_1 v	= ptr_A[pos];
						if (v == Z1)
						{
							continue;
						};
						if (work_ind[ka] < j + 1)
						{
							work_ind[ka] = j + 1;
							work_x[ka]	= Bx * v;
							d_r[nz]		= ka;
							++nz;
						}
						else 
						{
							work_x[ka]	+= Bx * v;
						};
					};

					if (nz - nzs > 0)
					{
						++nk;
					};
    			}
				if (nk > 1)
				{
					utils::sort_q(d_r+nz_old,nz - nz_old);
				};
				for (Integer k = d_c[j]; k < nz ; ++k) 
				{
					d_x[k] = work_x[d_r[k]];
				};
			};
			d_c[Cc] = nz;

			d.memadd(-1);
            C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
			return C;
		};
	};
};
//========================================================================
//                      BAND - BAND
//========================================================================
template<class ret_type, class M1, class M2>
struct eval_mult<ret_type,M1,M2,struct_banded,struct_banded> 
{ 
	static ret_type eval(const M1& A, const M2& B)
	{
		error::check_mul(A.rows(), A.cols(), B.rows(), B.cols());

        gd::type_info ret_ti = gd::return_mult_ti<M1,M2>::eval(A,B);        

		Integer r = A.rows(), c = B.cols();

		Integer l = std::min(std::max(r-1, 0L), A.ldiags() + B.ldiags());
		Integer u = std::min(std::max(c-1, 0L), A.udiags() + B.udiags());

		typedef ret_type::value_type value_type_ret;

        value_type_ret Z = gd::default_value<value_type_ret>(ret_ti);

		Matrix<value_type_ret,struct_banded> C(ret_ti, r, c, l, u);

		typedef M1::value_type val_type_1;
		typedef M2::value_type val_type_2;

        const val_type_1* ptr_A = A.rep_ptr();
        const val_type_2* ptr_B = B.rep_ptr();
        value_type_ret * ptr_C  = C.rep_ptr();

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			Integer rc = std::min(B.rows(),B.cols());
			if (A.ldiags() == 0 && A.udiags() == 0)
			{
				for (Integer j = 0; j < rc; ++j)
				{
					ptr_C[j] = ptr_A[0]*ptr_B[0];
                    ptr_A += A.ld();
                    ptr_B += B.ld();
				};

				for (Integer j = rc; j < C.cols(); ++j)
				{
					ptr_C[j] = Z;
				};

                C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
				return C;
			}
			else
			{
                Integer C_size = C.size();
                for (Integer j = 0; j < C_size; ++j)
                {
                    ptr_C[j] = Z;
                };
				for (Integer j = 0; j < rc; ++j, ptr_A += A.ld(), ptr_B += B.ld(), ptr_C += C.ld())
				{
					val_type_2 v = ptr_B[0];

                    if (v == 0)
                    {
                        continue;
                    };

					Integer fr = A.first_row(j);
					Integer lr = A.last_row(j);
					Integer pos_A = A.first_elem_pos(j);
					Integer pos_C = C.first_elem_pos(j);

					for (Integer i = fr; i <= lr; ++i, ++pos_A, ++pos_C)
					{
						ptr_C[pos_C] = ptr_A[pos_A]*v;
					};
				};
                C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
				return C;
			};
		};

		if (A.ldiags() == 0 && A.udiags() == 0)
		{
			Integer rc = std::min(A.rows(),A.cols());

            Integer C_size = C.size();
            for (Integer j = 0; j < C_size; ++j)
            {
                ptr_C[j] = Z;
            };
			for (Integer j = 0; j < B.cols(); ++j)
			{
				Integer fr = B.first_row(j);
				Integer lr = B.last_row(j);
				Integer lr2 = std::min(lr,rc-1);
				Integer pos_B = B.first_elem_pos(j);
				Integer pos_C = C.first_elem_pos(j);

                const val_type_1* ptr_A0 = ptr_A + fr*A.ld();

				for (Integer i = fr; i <= lr2; ++i, ++pos_B, ++pos_C)
				{
					ptr_C[pos_C] = ptr_A0[0]*ptr_B[pos_B];
                    ptr_A0 += A.ld();
				};

                ptr_B += B.ld();
                ptr_C += C.ld();
			};

            C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
			return C;
		};

		for (Integer j = 0; j < c; ++j)
		{
            Integer ic = C.first_elem_pos(j);

			for (Integer i = C.first_row(j); i <= C.last_row(j); ++i, ++ic)
			{				
				ptr_C[ic] = Z;

				Integer ks = std::max(A.first_col(i), B.first_row(j));
				Integer ke = std::min(A.last_col(i), B.last_row(j));
				Integer ia = A.first_elem_pos(ks) + i - A.first_row(ks) + imult(ks, A.ld());
				Integer ib = B.first_elem_pos(j) + ks - B.first_row(j);

				for (Integer k = ks; k <= ke; ++k, ia += A.ld()-1, ++ib)
				{
					ptr_C[ic] += ptr_A[ia] * ptr_B[ib];
				};
			};

            ptr_B += B.ld();
            ptr_C += C.ld();            
		};

        C.set_struct(struct_flag::mult_struct(A.get_struct(),B.get_struct()));
		return C;
	};
};


//scal
template<class ret_type, class Mat, class T, class struct_type>
struct scal_impl{};

template<class ret_type, class Mat, class T>
struct scal_impl<ret_type,Mat,T,struct_banded>
{
	static ret_type eval(const Mat &m,T a)
	{
        Integer c = m.cols();

        typedef typename ret_type::value_type   val_type_ret;
        typedef typename Mat::value_type        val_type_in;

		typedef Matrix<ret_type::value_type,struct_banded> ret_type_band;		

        gd::type_info ret_ti = gd::return_mult_ti<Mat,T>::eval(m,a); 
        gd::type_info ti_real = gd::get_ti_real(gd::get_ti(a));

        T Z = gd::default_value<T>(gd::get_ti(a));

		if (a == Z)
		{
			typedef ret_type::value_type val_type;
			typedef ret_type::struct_type str_type;
			return mmlib::details::zero_matrix<val_type,str_type>::eval(ret_ti,m.rows(),m.cols());
		};		

		if (a == 1)
		{
            return converter<ret_type,Mat>::eval(ret_ti,m);
		}
		else
		{
            ret_type_band res(ret_ti, m.rows(),m.cols(),m.ldiags(),m.udiags());

			typedef mmlib::details::real_type<T>::type real_t;
			real_t im(imag_helper<T>::eval(ti_real,a));

            real_t ZR = gd::default_value<real_t>(gd::get_ti(im));

            val_type_ret* ptr_res       = res.rep_ptr();
            const val_type_in* ptr_m    = m.rep_ptr();

			if (im == ZR)
			{
				real_t rea(real_helper<T>::eval(ti_real,a));
                for (Integer i = 0; i < c; ++i)
                {
                    Integer fr = m.first_row(i);
                    Integer lr = m.last_row(i);

                    Integer pos = m.first_elem_pos(i);

                    for (Integer k = fr; k <= lr; ++k, ++pos)
                    {
                        ptr_res[pos] = ptr_m[pos] * rea;
                    };

                    ptr_res += res.ld();
                    ptr_m   += m.ld();
                };
			}
			else
			{
                for (Integer i = 0; i < c; ++i)
                {
                    Integer fr = m.first_row(i);
                    Integer lr = m.last_row(i);

                    Integer pos = m.first_elem_pos(i);

                    for (Integer k = fr; k <= lr; ++k, ++pos)
                    {
                        ptr_res[pos] = ptr_m[pos] * a;
                    };

                    ptr_res += res.ld();
                    ptr_m   += m.ld();
                };

			};

            struct_flag::value_type vt = struct_flag::get_value_type(a);
            res.get_struct() = m.get_struct().get_scal_mult(vt);
		    return converter<ret_type,ret_type_band>::eval(ret_ti, res);
		};
	};
};
template<class ret_type, class Mat, class T>
struct scal_impl<ret_type,Mat,T,struct_dense>
{
	static ret_type eval(const Mat &m,T a)
	{
        typedef typename Mat::value_type val_type_in;
        typedef typename ret_type::value_type val_type;

        gd::type_info ret_ti = gd::return_mult_ti<Mat,T>::eval(m,a); 
        gd::type_info ti_real = gd::get_ti_real(gd::get_ti(a)); 

        T Z = gd::default_value<T>(gd::get_ti(a));

		if (a == Z || m.get_struct().is_zero())
		{
			ret_type out(ret_ti,Z,m.rows(),m.cols());
            out.get_struct().set_zero_matrix();
            return out;
		};		

		if (a == 1)
		{
            return converter<ret_type,Mat>::eval(ret_ti,m);
		};

        ret_type res(ret_ti, m.rows(),m.cols());

		typedef mmlib::details::real_type<T>::type real_t;
		real_t im(imag_helper<T>::eval(ti_real,a));
        real_t ZR = gd::default_value<real_t>(gd::get_ti(im));

        const val_type_in* ptr_m = m.ptr();
        val_type* ptr_res = res.ptr();

		if (im == ZR)
		{
			real_t rea(real_helper<T>::eval(ti_real,a));
            for (Integer j = 0; j < m.cols(); ++j)
            {
                for (Integer i = 0; i < m.rows(); ++i)
                {
                    ptr_res[i] = rea * ptr_m[i];
                };
                ptr_m += m.ld();
                ptr_res += res.ld();
            };
		}
		else
		{
            for (Integer j = 0; j < m.cols(); ++j)
            {
                for (Integer i = 0; i < m.rows(); ++i)
                {
                    ptr_res[i] = a * ptr_m[i];
                };
                ptr_m += m.ld();
                ptr_res += res.ld();
            };
		};

        struct_flag::value_type vt = struct_flag::get_value_type(a);
        res.get_struct() = m.get_struct().get_scal_mult(vt);
		return res;
	};
};
template<class ret_type, class Mat, class T>
struct scal_impl<ret_type,Mat,T,struct_sparse>
{
	static ret_type eval(const Mat &A,T a)
	{
		typedef typename ret_type::value_type val_type_ret;
		typedef typename Mat::value_type val_type;

        gd::type_info ret_ti = gd::return_mult_ti<Mat,T>::eval(A,a); 
        gd::type_info ti_real = gd::get_ti_real(gd::get_ti(a));

        T Z = gd::default_value<T>(gd::get_ti(a));

		Integer s = A.nnz();

		const spdat<val_type>& Ad = A.rep();		

		if (s == 0 || a == Z)
		{
			typedef ret_type::value_type val_type;
			typedef ret_type::struct_type str_type;
			return mmlib::details::zero_matrix<val_type,str_type>::eval(ret_ti,A.rows(),A.cols());
		};
		
		typedef Matrix<val_type_ret,struct_sparse> SparseMatrix;
		SparseMatrix C(ret_ti, Ad.rows(), Ad.cols(), s);
		spdat<val_type_ret>& d = C.rep();

        const Integer* Ad_c  = Ad.ptr_c();
        const Integer* Ad_r  = Ad.ptr_r() + Ad.offset();
		const val_type* Ad_x = Ad.ptr_x() + Ad.offset();

        Integer* d_c        = d.ptr_c();
        Integer* d_r        = d.ptr_r();
        val_type_ret* d_x   = d.ptr_x();

		if (a == 1)
		{
			for (Integer i = 0; i < s; ++i)
			{
				d_x[i] = val_type_ret(Ad_x[i]);
			};
		}
		else
		{
			typedef mmlib::details::real_type<T>::type real_t;
			real_t im(imag_helper<T>::eval(ti_real,a));

            real_t ZR = gd::default_value<real_t>(gd::get_ti(im));

			if (im == ZR)
			{
				real_t rea(real_helper<T>::eval(ti_real,a));
				for (Integer i = 0; i < s; ++i)
				{
					d_x[i] = Ad_x[i] * rea;
				};
			}
			else
			{
				for (Integer i = 0; i < s; ++i)
				{
					d_x[i] = Ad_x[i] * a;
				};
			};
		};

		for(Integer i = 0; i < s; ++i)
		{
			d_r[i]  = Ad_r[i];
		};
		for(Integer i = 0; i <= Ad.cols(); ++i)
		{
			d_c[i]  = Ad_c[i] - Ad.offset();
		};

        struct_flag::value_type vt = struct_flag::get_value_type(a);
        C.get_struct() = A.get_struct().get_scal_mult(vt);
		return converter<ret_type,SparseMatrix>::eval(ret_ti,C);
	};
};

template<class ret_type, class Mat, class T>
struct scal 
{};
template<class ret_type, class Mat>
struct scal<ret_type,Mat,Integer>
{
	static ret_type eval(const Mat &m,Integer a)
	{
		return scal_impl<ret_type,Mat,Integer,Mat::struct_type>::eval(m,a);
	};
};
template<class ret_type, class Mat>
struct scal<ret_type,Mat,Real>
{
	static ret_type eval(const Mat &m,Real a)
	{
		if (a == constants::NaN || a == constants::Inf || a == -constants::Inf)
		{
            gd::type_info ret_ti = gd::return_mult_ti<Mat,Real>::eval(m,a);

			typedef Matrix<ret_type::value_type,struct_dense> FullMatrix;
			FullMatrix mp = converter<FullMatrix,Mat>::eval(ret_ti, m);
            mp.get_struct().reset(false);
			FullMatrix tmp = scal_impl<FullMatrix,FullMatrix,Real,struct_dense>::eval(mp,a);
			return converter<ret_type,FullMatrix>::eval(ret_ti, tmp);
		};
		return scal_impl<ret_type,Mat,Real,Mat::struct_type>::eval(m,a);
	};
};
template<class ret_type, class Mat>
struct scal<ret_type,Mat,Complex>
{
	static ret_type eval(const Mat &m,const Complex& a)
	{
		Real ar = real(a);
		Real ai = imag(a);

		if (ar == constants::NaN || ar == constants::Inf || ar == -constants::Inf 
				|| ai == constants::NaN || ai == constants::Inf || ai == -constants::Inf)
		{
            gd::type_info ret_ti = gd::return_mult_ti<Mat,Complex>::eval(m,a);

			typedef Matrix<ret_type::value_type,struct_dense> FullMatrix;
			FullMatrix mp = converter<FullMatrix,Mat>::eval(ret_ti, m);
            mp.get_struct().reset(false);
			FullMatrix tmp = scal_impl<FullMatrix,FullMatrix,Complex,struct_dense>::eval(mp,a);
			return converter<ret_type,FullMatrix>::eval(ret_ti, tmp);
		};
		return scal_impl<ret_type,Mat,Complex,Mat::struct_type>::eval(m,a);
	};
};
template<class ret_type, class Mat>
struct scal<ret_type,Mat,Object>
{
	static ret_type eval(const Mat &m,Object a)
	{
		return scal_impl<ret_type,Mat,Object,Mat::struct_type>::eval(m,a);
	};
};
template<class M1,class M2>
typename mult_helper<M1,M2>::ret_type 
mult_helper<M1,M2>::eval(const M1& A, const M2& B)
{
	typedef M1::struct_type str_type_1;
	typedef M2::struct_type str_type_2;    

	if (A.rows() == 1 && A.cols() == 1) 
	{
		return scal<ret_type,M2,M1::value_type>::eval( B, A(1,1));
	};
	if (B.rows() == 1 && B.cols() == 1) 
	{
		return scal<ret_type,M1,M2::value_type>::eval( A, B(1,1));
	};

	return eval_mult<ret_type,M1,M2,str_type_1,str_type_2>::eval(A,B);
};

template<class ret_type, class M1, class T, class ret_value>
struct div_helper2
{
	static ret_type eval(const M1& A, T b)
	{
		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<T,Integer>::value,
				Real,
				T
			>::type TP;

        gd::type_info ret_ti = gd::return_div_ti<M1,T>::eval(A,b);
        TP inv = div_helper<Real,T>::eval(ret_ti,1.,b);
		return scal<ret_type,M1,TP>::eval(A, inv);
	};
};

template<class M1,class T>
typename scal_helper_impl<M1,T>::ret_type_mul 
scal_helper_impl<M1,T>::eval(const M1& A, T b)
{
	return scal<ret_type_mul,M1,T>::eval(A, b);
};

template<class M1,class T>
typename scal_helper_impl<M1,T>::ret_type_div 
scal_helper_impl<M1,T>::eval_div(const M1& A, T b)
{
	return div_helper2<ret_type_div,M1,T,ret_type_div::value_type>::eval(A, b);
};

};};};

MACRO_INSTANTIATE_GG_2(mmlib::raw::details::mult_helper)
MACRO_INSTANTIATE_GST_2(mmlib::raw::details::mult_helper)
MACRO_INSTANTIATE_STG_2(mmlib::raw::details::mult_helper)
MACRO_INSTANTIATE_STST_2(mmlib::raw::details::mult_helper)

MACRO_INSTANTIATE_GS_2(mmlib::raw::details::scal_helper_impl)
MACRO_INSTANTIATE_STS_2(mmlib::raw::details::scal_helper_impl)
