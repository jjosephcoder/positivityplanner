/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/io.h"
#include <vector>
#include "mmlib/exception.h"
#include "mmlib/details/scalfunc_helpers.h"
#include "mmlib/func/raw/mvgen.h"
#include "mmlib/constants.h"
#include "mmlib/utils/utils.h"
#include "mmlib/base/integer.h"

namespace mmlib { namespace raw 
{
 
// go to the end of line (or eof)
static void skiptoeol(std::istream &is)
{
    char c;

    while (is)
    {
        is.get(c);
        if (c == '\n') break;
    }
};

// skip all lines, in which the first character that is not whitespace
// is '#' or '%'
void details::skipblank(std::istream &is)
{
    char c;

    while (is)
    {
        is.get(c);
        if ((c != ' ') && (c != '\t') && (c != '\n'))
        {
            if ((c == '#') || (c == '%')) skiptoeol(is);
            else 
            {
                is.putback(c);
                break;
            }
        }
    }
};
static bool checkeol(std::istream &is)
{
    char c;

    while (is)
    {
        is.get(c);
        if (c != ' ' && c != '\t')
        {
            if (c == '\n')
                return true;

            if (c == '#' || c == '%' )
            {
                skiptoeol(is);
                return true;
            }

            is.putback(c);
            return false;
        }
    }

    if (is.eof()) return true;
    return false;
}
static bool checkeof(std::istream &is)
{
    char c;
    is.get(c);
    is.putback(c);

    if (c == ']')   return true;
    else            return false;
}
// check if we have empty object mark '[]'
static bool checkempty(std::istream &is)
{
    char c = 0;

    if (is.eof()) return true;

    while (is)
    {
        is.get(c);
        if ((c != ' ') && (c != '\t')  && (c != '\n')) break;
    }

    if (c == ']')
    {
        is.putback(c);
        return true;
    }
    else
    {
        is.putback(c);
    };

    return false;
}

Integer details::maxwidth(const IntegerMatrix &m)
{
    Integer maxabs = 1;

    const Integer* ptr_m = m.ptr();

    for (Integer j = 0; j < m.cols(); ++j)
    {
        for (Integer i = 0; i < m.rows(); ++i)
        {
            Integer tmp = ptr_m[i];
            Integer aei = tmp >= 0 ? tmp : -tmp;
            if (aei > maxabs)
            {
                maxabs = aei;
            };
        };
        ptr_m += m.ld();
    };

    return (Integer) std::log10((double) maxabs) + 2;
}

bool Iread(std::istream &is, Integer &i)
{
    int c;

    is >> i;
    if (is.fail() || is.bad()) return false;
    else
    {
        if (is.eof()) return true;
        c = is.peek();
        if ((c == ' ') || (c == '\t') || (c == '\n')) return true;
    }
    return false;
}

static bool Rread_helper(std::istream &is, Real &r)
{
    char c = 0;
    bool neg = false;

    while (is)
    {
        is.get(c);
        if ((c != ' ') && (c != '\t')  && (c != '\n')) break;
    }

    if (is.eof()) return false;

    if (c == '-') neg = true; else is.putback(c);
    if (is)
    {
        is.get(c);
        if (is && ((c == 'i') || (c == 'I')))
        {
            is.get(c);
            if (is && ((c == 'n') || (c == 'N')))
            {
                is.get(c);
                if ((c == 'f') ||(c == 'F'))
                {
					r = (neg) ? -constants::Inf : constants::Inf;
                    return true;
                }
                else return false;
            }
            else return false;
        }
        if (is && ((c == 'n') || (c == 'N')))
        {
            is.get(c);
            if (is && ((c == 'a') ||(c == 'A')))
            {
                is.get(c);
                if (((c == 'n') || (c == 'N')) && !neg)
                {
                    r = constants::NaN;
                    return true;
                }
                else return false;
            }
            else return false;
        }
        if (c == '-') return false; // double -
    }
    else return false;

    is.putback(c);
    is >> r;
    if (is.fail() || is.bad()) return false;
    if (neg) r = -r;

    return true;
};

bool Rread(std::istream &is, Real &r)
{
    Real tmp;
    int c;

    if (Rread_helper(is, tmp))
    {
        if (is.eof())
        {
            r = tmp;
            return true;
        }
        c = is.peek();
        if ((c == ' ') || (c == '\t') || (c == '\n'))
        {
            r = tmp;
            return true;
        }
    }

    return false;
}

bool Cread(std::istream &is, Complex &cm)
{
    Real r, i;
    char c = 0;

    while (is)
    {
        is.get(c);
        if ((c != ' ') && (c != '\t')  && (c != '\n')) break;
    }

    if (is.eof()) return false;

    if (c == '(') // format '(re, im)'
    {
        while (is)
        {
            is.get(c);
            if ((c != ' ') && (c != '\t')) break;
        }
        if (!is) return false;
        if (c == '\n') return false; // everything should be in one line
        is.putback(c);
        if (!Rread_helper(is, r)) return false;
        while (is)
        {
            is.get(c);
            if ((c != ' ') && (c != '\t')) break;
        }
        if (!is) return false;
        if (c != ',') return false;
        while (is)
        {
            is.get(c);
            if ((c != ' ') && (c != '\t')) break;
        }
        if (!is) return false;
        if (c == '\n') return false; // everything should be in one line
        is.putback(c);
        if (!Rread_helper(is, i)) return false;
        while (is)
        {
            is.get(c);
            if ((c != ' ') && (c != '\t')) break;
        }
        if (!is) return false;
        if (c != ')') return false;
        if (is.eof())
        {
            cm = Complex(r, i);
            return true;
        }
		{
			int c = is.peek();
			if ((c != ' ') && (c != '\t') && (c != '\n')) return false;
			cm = Complex(r, i);
		};
        return true;
    }

    is.putback(c);
    // format 're im' (complex number as a pair of reals 
    // separated by whitespace or tab)
    if (!Rread_helper(is, r)) return false;
    while (is)
    {
        is.get(c);
        if ((c != ' ') && (c != '\t')) break;
    }
    if (!is) return false;
    if (c == '\n') return false; // everything should be in one line
    is.putback(c);
    if (!Rread_helper(is, i)) return false;

	{
		int c = is.peek();
		if ((c != ' ') && (c != '\t') && (c != '\n')) return false;
		cm = Complex(r, i);
	};

    return true;
}
template<>
bool details::read<Integer>(std::istream& is,Integer& x)
{
	return Iread(is,x);
}
template<>
bool details::read<Real>(std::istream& is,Real& x)
{
	return Rread(is,x);
}
template<>
bool details::read<Object>(std::istream& is,Object& x)
{
    is >> x;
	if (is.fail() || is.bad())  return false;
    else                        return true;
}
template<>
bool details::read<gd::type_info>(std::istream& is,gd::type_info& x)
{
    is >> x;
	if (is.fail() || is.bad())  return false;
    else                        return true;
}
template<>
bool details::read<Complex>(std::istream& is,Complex& x)
{
	return Cread(is,x);
}
template<>
void details::write<Integer>(std::ostream& os,Integer x)
{
	os << x;
};
template<>
void details::write<Real>(std::ostream& os,Real x)
{
    gd::type_info ti = gd::get_raw_ti();

	if (details::isnan_helper<Real>::eval(ti,x))
	{
		os << "NaN";
	}
	else if (details::isinf_helper<Real>::eval(ti,x))
	{
		if (x < 0)
		{
			os << "-Inf";
		}
		else
		{
			os << "Inf";
		};
	}
	else
	{
		os << x;
	};
};
template<>
void details::write<Object>(std::ostream& os,Object x)
{
	os << x;
};
template<>
void details::write<gd::type_info>(std::ostream& os,gd::type_info x)
{
	os << x;
};
template<>
void details::write<Complex>(std::ostream& os,Complex x)
{
	write(os,mmlib::complex::real(x));
	os << ' ';
	write(os,mmlib::complex::imag(x));
};

template<class V, class S>
struct writemat_format
{};

template<class V, class S>
struct readmat_format
{};

template <class val_type>
struct writemat_format<val_type,struct_dense>
{
	static std::ostream& eval(std::ostream &os, const Matrix<val_type,struct_dense> &m)
	{
		Integer r = m.rows(), c = m.cols(), s = m.size();

		os << r << ' ' << c;

		if (s)
		{
			for (Integer i = 0; i < r; ++i)
			{
                os << '\n';
                const val_type* ptr_m = m.ptr() + i;
				for (Integer j = 0; j < c; ++j)
				{
					details::write(os,*ptr_m);
					if (j < c)
                    {
                        os << ' ';
                    };
                    ptr_m += m.ld();
				}				
			}
		};

		return os;
	};
};
template <class val_type>
struct readmat_format<val_type,struct_dense>
{
	static std::istream& eval(std::istream &is, Matrix<val_type,struct_dense> &mat)
	{
		std::vector< val_type > data;
		val_type buf = mmlib::details::default_value<val_type>(mat.get_ti());
		Integer r = 0, c = 0, prevc = 0;

		mat.reset_unique();
		details::skipblank(is);

		Integer mr, mc;

		is >> mr; 
		is >> mc;

		details::skipblank(is);
		if (!is.good())		goto err;

		if (checkempty(is))
		{
			if (mc == 0 || mr == 0)
			{
				mat.reset_unique(mr, mc);
				return is;
			}			
			else
			{
				goto err;
			};
		};

		try
		{
			data.reserve(imult_c(mr,mc));
		}
		catch(...)
		{};

		while (is)
		{
			if (details::read(is, buf))
			{
				try 
				{
					data.push_back(buf);
				} 
				catch (std::bad_alloc const&) 
				{ 
					throw error::error_alloc_ext(); 
				}
				if (c == 0)
                {
                    ++r; // new row starts
                };
				++c;
			}
			else if ((is.eof() && !is.fail() && !is.bad()) && 
					 ((prevc == 0) || (c == prevc)))
			{
				break;
			}
			else
			{
				goto err;
			};

			if (checkeol(is))
			{
				if ((prevc == 0) || (c == prevc))
				{
					prevc = c;
					c = 0;
				}
				else goto err;

				if (checkeof(is)) // blank line
				{
					c = prevc;
					break;
				};
			};
		};

		if (mr != r || mc != c)
		{
			goto err;
		}
		mat.reset_unique(r, c);

		{
			for (Integer i = 0, ii = 0; i < r; ++i)
			{
                val_type* ptr_mat = mat.ptr() + i;

				for (Integer j = 0; j < c; ++j)
				{
					*ptr_mat = data[ii++];
                    ptr_mat += mat.ld();
				};
			};
		};

		return is;

	err:
		throw error::error_unable_to_read_matrix();
	};
};


template <class val_type>
struct writemat_format<val_type,struct_sparse>
{
	static std::ostream& eval(std::ostream &os, const Matrix<val_type,struct_sparse> &m)
	{
		Integer i, k, c = m.cols(), n = m.nnz();

		os << m.rows() << ' ' << m.cols();

		if (n == 0)
		{
			return os;
		}

		const details::spdat<val_type>& tmp = m.rep();

        const Integer* tmp_c    = tmp.ptr_c();
        const Integer* tmp_r    = tmp.ptr_r();
        const val_type* tmp_x   = tmp.ptr_x();

		for (i = 0; i < c; ++i)
		{
			for (k = tmp_c[i]; k < tmp_c[i + 1]; ++k)
			{
                os << '\n';
				os << (tmp_r[k] + 1) << ' ' << (i + 1) << ' ';
				details::write(os,tmp_x[k]);				
			};
		};

		return os;
	};
};
template <class val_type>
struct readmat_format<val_type,struct_sparse>
{
	static std::istream& eval(std::istream &is, Matrix<val_type,struct_sparse> &m)
	{
		Integer i, k, nnz, r = 0, c = 0, bufi = 0, bufj = 0;
        val_type bufx = mmlib::details::default_value<val_type>(m.get_ti());

		std::vector<Integer> ri, ci, p;
		std::vector<val_type> xv;
		//details::spdat<val_type> d(m.get_ti());

		m.reset();
		details::skipblank(is);

		Integer mr, mc;
		is >> mr;
		is >> mc;

		details::skipblank(is);
		if (!is.good())		goto err;

		if (checkempty(is))
		{
			m.assign(Matrix<val_type,struct_sparse>(m.get_ti(),mr,mc));
			return is;
		};

		while (is)
		{
			if (details::read(is, bufi))
			{
				try 
				{
					ri.push_back(bufi);
				} 
				catch (std::bad_alloc const&) 
				{ 
					throw error::error_alloc_ext(); 
				}
				if (bufi > r) r = bufi;
				if (bufi < 1) goto err;
			}
			else if (is.eof() && !is.fail() && !is.bad())
			{
				break;
			}
			else
			{
				goto err;
			};
			if (checkeol(is)) goto err;
			if (details::read(is, bufj))
			{
				try 
				{
					ci.push_back(bufj);
				} 
				catch (std::bad_alloc const&) 
				{ 
					throw error::error_alloc_ext(); 
				}
				if (bufj > c) c = bufj;
				if (bufj < 1) goto err;
			}
			else
			{
				goto err;
			};
			if (checkeol(is)) goto err;
			if (details::read(is, bufx))
			{
				try 
				{
					xv.push_back(bufx);
				} 
				catch (std::bad_alloc const&) 
				{ 
					throw error::error_alloc_ext(); 
				}
				if (bufj > c) c = bufj;
			}
			else
			{
				goto err;
			};
			if (checkeol(is))
			{
				if (checkeof(is)) break;
			}
			else
			{
				goto err;
			};
		};

		nnz = ri.size();

		if (nnz == 0)
		{
			m.assign(Matrix<val_type,struct_sparse>(m.get_ti(),mr,mc));
			return is;
		};

		if (r > mr || c > mc)
		{
			goto err;
		};
		
		try 
		{
			p = std::vector<Integer>(mc + 1, 0);
		} 
		catch (std::bad_alloc const&) 
		{ 
			throw error::error_alloc_ext(); 
		}

		for (i = 0; i < nnz; ++i)
        {
            ++p[ci[i]];
        };

        {
            details::spdat<val_type> d = details::spdat<val_type>(m.get_ti(), mr, mc, nnz);

            Integer* d_c    = d.ptr_c();
            Integer* d_r    = d.ptr_r();
            val_type* d_x   = d.ptr_x();

		    for (k = 0, i = 1; i <= mc; ++i)
		    {
			    p[i] += k;
			    k = d_c[i] = p[i];
		    }

		    for (i = 0; i < nnz; ++i)
		    {
			    k = p[ci[i] - 1]++;
			    d_r[k] = ri[i] - 1;
			    d_x[k] = xv[i];
		    }

		    p.clear();
		    ri.clear();
		    ci.clear();
		    xv.clear();

		    d.sort();
		    d.adddupl();

		    m.assign(sparse_matrix_base<val_type>(d));
        };

		return is;

	err:
		throw error::error_unable_to_read_matrix();
	};
};
template <class val_type>
struct writemat_format<val_type,struct_banded>
{
	static std::ostream& eval(std::ostream &os, const Matrix<val_type,struct_banded> &m)
	{
		Integer r = m.rows(), c = m.cols(), ld = m.ldiags(), ud = m.udiags();

		os << r << ' ' << c << ' '<< ld << ' ' << ud;

		if (r == 0 || c == 0)
		{
			return os;
		};

        const val_type* ptr_m = m.rep_ptr();

		// main & superdiagonals
		for (Integer d = ud, jst = imult(m.ld(),ud); d >= 0; --d, jst -= m.ld()-1)
		{
            os << '\n';
			Integer s = (c - d < r) ? c - d : r;
			for (Integer i = 1, jj = jst; i <= s; ++i, jj += m.ld())
			{
				details::write(os,ptr_m[jj]);
				if (i < s)
				{
					os << ' ';
				};
			};			
		};

		// subdiagonals
		for (Integer d = 1, jst = ud + 1; d <= ld; ++d, ++jst)
		{
            os << '\n';
			Integer s = (r - d < c) ? r - d : c;
			for (Integer i = 1, jj = jst; i <= s; ++i, jj += m.ld())
			{
				details::write(os,ptr_m[jj]);
				if (i < s)
				{
					os << ' ';
				};
			};			
		}
		return os;
	};
};
template <class val_type>
struct readmat_format<val_type,struct_banded>
{
	static std::istream& eval(std::istream &is, Matrix<val_type,struct_banded> &mat)
	{		
		details::skipblank(is);

        IntegerMatrix d_ind(mmlib::details::get_raw_ti());

		typedef Matrix<val_type,struct_dense> matrix_type;
		matrix_type diags(mat.get_ti());

        val_type Z = mmlib::details::default_value<val_type>(mat.get_ti());
		val_type buf = Z;

		Integer mr, mc, ml, md;

		is >> mr; 
		is >> mc;
		is >> ml;
		is >> md;

		details::skipblank(is);
		if (!is.good())		goto err;

		if (checkempty(is))
		{
			if (mc == 0 || mr == 0)
			{
				mat.assign(Matrix<val_type,struct_banded>(mat.get_ti(),mr, mc, ml, md));
				return is;
			}			
			else
			{
				goto err;
			};
		};		

		Integer s = (mc < mr) ? mc : mr;

		diags.reset_unique(s,ml+md+1);
        val_type* ptr_diags = diags.ptr();

		{
            Integer diags_size = diags.size();
			for (Integer i = 0; i < diags_size; ++i)
			{
				ptr_diags[i] = Z;
			};		

			Integer d = ml+md+1;
			Integer pos = 0;

			while (is)
			{
				if (details::read(is, buf))
				{
					if (pos >= s || d < 1)
                    {
                        goto err;
                    };
					ptr_diags[pos+(d-1)*diags.ld()] = buf;
					++pos;
				}
				else
				{
					goto err;
				};

				if (checkeol(is))
				{
					pos = 0;
					--d;

					if (checkeof(is))
					{
						if (d > 0)
                        {
                            goto err;
                        };
						break;
					};
				};
			};

			Integer nd = ml+md+1;
			d_ind.reset_unique(nd,1);
            Integer* ptr_d_ind = d_ind.ptr();
			ml = -ml;
			for (Integer i = 0; i < nd; ++i)
			{
				ptr_d_ind[i] = ml;
				++ml;
			};
		};

		mat.assign(bdiags(diags,d_ind,mr,mc));

		return is;

	err:
		throw error::error_unable_to_read_matrix();
	};
};

template<class val_type,class struct_type>
std::istream& raw::load(std::istream &is, Matrix<val_type,struct_type> &mat)
{
	return readmat_format<val_type, struct_type>::eval(is, mat);
};
std::ostream& raw::save(std::ostream& os, const gd::type_info& ti)
{
    os << ti;
    return os;
};
std::istream& raw::load(std::istream& is, gd::type_info& ti)
{
    is >> ti;
    return is;
};

template<class val_type,class struct_type>
std::ostream& raw::save(std::ostream &os, const Matrix<val_type,struct_type> &m)
{
	return writemat_format<val_type,struct_type>::eval(os, m);
};

template std::ostream& save(std::ostream &os, const Matrix<Integer,struct_dense> &m);
template std::ostream& save(std::ostream &os, const Matrix<Integer,struct_sparse> &m);
template std::ostream& save(std::ostream &os, const Matrix<Integer,struct_banded> &m);

template std::ostream& save(std::ostream &os, const Matrix<Real,struct_dense> &m);
template std::ostream& save(std::ostream &os, const Matrix<Real,struct_sparse> &m);
template std::ostream& save(std::ostream &os, const Matrix<Real,struct_banded> &m);

template std::ostream& save(std::ostream &os, const Matrix<Complex,struct_dense> &m);
template std::ostream& save(std::ostream &os, const Matrix<Complex,struct_sparse> &m);
template std::ostream& save(std::ostream &os, const Matrix<Complex,struct_banded> &m);

template std::ostream& save(std::ostream &os, const Matrix<Object,struct_dense> &m);
template std::ostream& save(std::ostream &os, const Matrix<Object,struct_sparse> &m);
template std::ostream& save(std::ostream &os, const Matrix<Object,struct_banded> &m);

template std::istream& load(std::istream &is, Matrix<Integer,struct_dense> &m);
template std::istream& load(std::istream &is, Matrix<Integer,struct_sparse> &m);
template std::istream& load(std::istream &is, Matrix<Integer,struct_banded> &m);

template std::istream& load(std::istream &is, Matrix<Real,struct_dense> &m);
template std::istream& load(std::istream &is, Matrix<Real,struct_sparse> &m);
template std::istream& load(std::istream &is, Matrix<Real,struct_banded> &m);

template std::istream& load(std::istream &is, Matrix<Complex,struct_dense> &m);
template std::istream& load(std::istream &is, Matrix<Complex,struct_sparse> &m);
template std::istream& load(std::istream &is, Matrix<Complex,struct_banded> &m);

template std::istream& load(std::istream &is, Matrix<Object,struct_dense> &m);
template std::istream& load(std::istream &is, Matrix<Object,struct_sparse> &m);
template std::istream& load(std::istream &is, Matrix<Object,struct_banded> &m);

};};