/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <vector>

#pragma warning( push )
#pragma warning(disable:4723)	// potential divide by 0


namespace mmlib { namespace raw
{

// accumulator
// value must not depend on number of zeros
template<class in_type, class out_type>
class accumulator	
{
	protected:
		Integer					size;
		out_type				state;
		std::vector<out_type>	state_array;	//vector of states, need to be set only if
												//reset_array is called

	public:
		accumulator(){};

		void set_size(Integer size) {};			//set number of elements along given dimension
		void reset() {};						//reset state
		void reset_array(Integer s) {};			//reset state array of size s
		bool add(in_type value){};				//returns true is value is known
		void add(Integer p,in_type value){};	//add new value at pos p (zero based)
		bool add_zero(){};						//at least one zero exists returns true is value is known
		void add_zero(Integer p){};				//at least one zero exists at pos p, returns true is value is known

		out_type value() const {};				//	
		out_type value(Integer p) const {};		//return value at pos p	
};

template<	class ret_type, 
			class in_type, 
			class accumulator
		>
struct eval_vec_functor
{ 
	static ret_type eval(const in_type &x, int dim) 
	{
		typedef ret_type::struct_type ret_str;
		typedef in_type::struct_type  in_str;

        gd::type_info ret_ti = gd::return_func_ti<accumulator,in_type>::eval(x);
		accumulator accum(ret_ti);

		return eval_vec_functor_impl<ret_type,in_type,accumulator,ret_str,in_str>::eval(x,dim,accum);		
	};
	static ret_type eval(const in_type &x, int dim, accumulator& accum) 
	{
		typedef ret_type::struct_type ret_str;
		typedef in_type::struct_type  in_str;

		return eval_vec_functor_impl<ret_type,in_type,accumulator,ret_str,in_str>::eval(x,dim,accum);		
	};
	static ret_type eval_cum(const in_type &x, int dim) 
	{
		typedef ret_type::struct_type ret_str;
		typedef in_type::struct_type  in_str;

        gd::type_info ret_ti = gd::return_func_ti<accumulator,in_type>::eval(x);

		accumulator accum(ret_ti);
		return eval_vec_functor_impl<ret_type,in_type,accumulator,ret_str,in_str>::eval_cum(x,dim,accum);		
	};
	static ret_type eval_cum(const in_type &x, int dim, accumulator& accum) 
	{
		typedef ret_type::struct_type ret_str;
		typedef in_type::struct_type  in_str;

		return eval_vec_functor_impl<ret_type,in_type,accumulator,ret_str,in_str>::eval_cum(x,dim,accum);		
	};
};

template<	class ret_type, 
			class in_type, 
			class accumulator,
			class ret_str,
			class in_str
		>
struct eval_vec_functor_impl{};

template<	class ret_type, 
			class in_type, 
			class accumulator
			//class ret_str = struct_dense,
			//class in_str = struct_sparse
		>
struct eval_vec_functor_impl<ret_type,in_type,accumulator,struct_dense,struct_sparse>
{ 
	static ret_type eval(const in_type &m, int d, accumulator& accum)
	{
		typedef ret_type::value_type value_type;		
		typedef in_type::value_type value_type_in;		

        gd::type_info ret_ti = gd::return_func_ti<accumulator,in_type>::eval(m);

		Integer r = m.rows(), c = m.cols();

		error::check_dim(d);		

		const details::spdat<value_type_in>& Ad = m.rep();
		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const value_type_in* Ad_x	= Ad.ptr_x();

		if (d == 1)
		{			
			ret_type res(ret_ti, 1,c);
            value_type* ptr_res = res.ptr();

			accum.set_size(r);

			if (c == 0)
			{
				return res;
			};

			if (r == 0)
			{
				accum.reset();
				value_type val =  accum.value();
				for (Integer j = 0; j < c; ++j)
				{
					ptr_res[j] = val;
				};
				return res;
			};			

			for (Integer j = 0; j < c; ++j)
			{
				accum.reset();

				Integer nz = Ad_c[j + 1] - Ad_c[j];
				bool ret_known = false;
				if (r-nz>0)
				{
					ret_known = accum.add_zero();
				};

				if (ret_known)
				{
					ptr_res[j] = accum.value();
				}
				else
				{
					for (Integer k = Ad_c[j] ; k < Ad_c[j + 1] ; ++k)
					{
						if (accum.add(Ad_x[k]))
						{
							break;
						};
					};
					ptr_res[j] = accum.value();
				};				
			};
			return res;
		};
	 
		ret_type res(ret_ti, r, 1);
        value_type* ptr_res = res.ptr();
		accum.set_size(c);

		if (r == 0)
		{
			return res;
		};		

		if (c == 0)
		{
			accum.reset();
			value_type val =  accum.value();
			for (Integer j = 0; j < r; ++j)
			{
				ptr_res[j] = val;
			};
			return res;
		};
		
		accum.reset_array(r);

		std::vector<Integer> nz(r,0);

		for (Integer j = 0; j < c; ++j)
		{
			for (Integer k = Ad_c[j] ; k < Ad_c[j + 1] ; ++k)
			{
				Integer p = Ad_r[k];
				++nz[p];
				accum.add(p,Ad_x[k]);
			};
		};
		for (Integer i = 0; i < r; ++i)
		{
			if (nz[i] < c)
			{
				accum.add_zero(i);
			};
			ptr_res[i] = accum.value(i);
		};

		return res;	
	};
	static ret_type eval_cum(const in_type &m, int d, accumulator& accum)
	{
		typedef Matrix<typename in_type::value_type,struct_dense> full_matrix;
		return eval_vec_functor_impl<ret_type,full_matrix,accumulator,struct_dense,struct_dense>::eval_cum(full(m),d,accum);
	};
};


template<	class ret_type, 
			class in_type, 
			class accumulator
			//class ret_str = struct_dense,
			//class in_str = struct_dense
		>
struct eval_vec_functor_impl<ret_type,in_type,accumulator,struct_dense,struct_dense>
{ 
	static ret_type eval(const in_type &m, int d, accumulator& accum)
	{
		typedef ret_type::value_type value_type;
        typedef in_type::value_type value_type_in;
        gd::type_info ret_ti = gd::return_func_ti<accumulator,in_type>::eval(m);

		ret_type res(ret_ti);        
        const value_type_in* ptr_m = m.ptr();

		Integer r = m.rows(), c = m.cols();
	 
		error::check_dim(d);		
	 
		if (d == 1)
		{
			accum.set_size(r);
			res.reset_unique(1, c);
            value_type* ptr_res = res.ptr();

			if (r == 0)
			{
				accum.reset();
				value_type val =  accum.value();
				for (Integer j = 0; j < c; ++j)
				{
					ptr_res[j] = val;
				};
				return res;
			};

			for (Integer j = 0; j < c; ++j)
			{
				accum.reset();
				for (Integer i = 0; i < r; ++i)
				{
					if (accum.add(ptr_m[i]))
					{
						break;
					};
				};
				ptr_res[j] = accum.value();
                ptr_m += m.ld();
			};
			return res;
		};
	 
		accum.set_size(c);
		res.reset_unique(r, 1);
        value_type* ptr_res = res.ptr();
	 
		if (c == 0)
		{
			accum.reset();
			value_type val =  accum.value();
			for (Integer j = 0; j < r; ++j)
			{
				ptr_res[j] = val;
			};
			return res;
		};

		for (Integer i = 0; i < r; ++i)
		{
			accum.reset();
            ptr_m = m.ptr() + i;
			for (Integer j = 0; j < c; ++j, ptr_m += m.ld())
			{
				if (accum.add(*ptr_m))
				{
					break;
				};
			};
			ptr_res[i] = accum.value();
		}
	 
		return res;
	};
	static ret_type eval_cum(const in_type &m, int d, accumulator& accum)
	{
		Integer r = m.rows(), c = m.cols();

        gd::type_info ret_ti = gd::return_func_ti<accumulator,in_type>::eval(m);

		ret_type res(ret_ti, r,c);
        const in_type::value_type* ptr_m = m.ptr();
        ret_type::value_type* ptr_res = res.ptr();

		error::check_dim(d);

		if (d == 1)
		{
			accum.set_size(r);
			accum.reset();

			for (Integer j = 0; j < c; ++j)
			{
				for (Integer i = 0; i < r; ++i)
				{
					accum.add(ptr_m[i]);
					ptr_res[i] = accum.value();
				}
                ptr_m += m.ld();
                ptr_res += res.ld();
			}
			return res;
		}

		accum.set_size(c);

		for (Integer i = 0; i < r; ++i)
		{			
			accum.reset();

            ptr_m = m.ptr() + i;
            ptr_res = res.ptr() + i;

			for (Integer j = 0; j < c; ++j)
			{
				accum.add(*ptr_m);
				*ptr_res = accum.value();

                ptr_m   += m.ld();
                ptr_res += res.ld();
			}
		}

		return res;
	};
};

template<	class ret_type, 
			class in_type, 
			class accumulator
			//class ret_str = struct_dense,
			//class in_str = struct_banded
		>
struct eval_vec_functor_impl<ret_type,in_type,accumulator,struct_dense,struct_banded>
{
	static ret_type eval(const in_type& m, int d, accumulator& accum)
	{
		typedef ret_type::value_type value_type;
        typedef in_type::value_type value_type_in;
        gd::type_info ret_ti = gd::return_func_ti<accumulator,in_type>::eval(m);

		ret_type res(ret_ti);		

		Integer r = m.rows(), c = m.cols();
	 
		error::check_dim(d);		

        const value_type_in* ptr_m = m.rep_ptr();        
	 
		if (d == 1)
		{
			accum.set_size(r);
			res.reset_unique(1, c);
            value_type* ptr_res = res.ptr();

			if (r == 0)
			{
				accum.reset();
				value_type val =  accum.value();
				for (Integer j = 0; j < c; ++j)
				{
					ptr_res[j] = val;
				};
				return res;
			};

			if (m.ldiags() == 0 && m.udiags() == 0)
			{
				for (Integer j = 0; j < c; ++j, ptr_m += m.ld())
				{
					accum.reset();

					if (j > 0 || j < r-1)
					{
						bool is_known = accum.add_zero();
						if (is_known)
						{
							ptr_res[j] = accum.value();
							continue;
						};
					};

					if (j < r)
					{
						accum.add(ptr_m[0]);
					};

					ptr_res[j] = accum.value();
				};
			}
			else
			{
				for (Integer j = 0; j < c; ++j, ptr_m += m.ld())
				{
					accum.reset();

					Integer row_f = m.first_row(j);
					Integer row_l = m.last_row(j);
					Integer row_p = m.first_elem_pos(j);

					if (row_f > 0 || row_l < r-1)
					{
						bool is_known = accum.add_zero();
						if (is_known)
						{
							ptr_res[j] = accum.value();
							continue;
						};
					};

					for (Integer i = row_f; i <= row_l; ++i, ++row_p)
					{
						if (accum.add(ptr_m[row_p]))
						{
							break;
						};
					};

					ptr_res[j] = accum.value();
				};
			};
			return res;
		};
		accum.set_size(c);
		res.reset_unique(r, 1);
        value_type* ptr_res = res.ptr();
	 
		if (c == 0)
		{
			accum.reset();
			value_type val =  accum.value();
			for (Integer j = 0; j < r; ++j)
			{
				ptr_res[j] = val;
			};
			return res;
		};

		if (m.ldiags() == 0 && m.udiags() == 0)
		{
			for (Integer i = 0; i < r; ++i, ptr_m += m.ld())
			{
				accum.reset();

				if (i > 0 || i < c-1)
				{
					bool is_known = accum.add_zero();
					if (is_known)
					{
						ptr_res[i] = accum.value();
						continue;
					};
				};

				if (i < c)
				{
					accum.add(ptr_m[0]);
				};

				ptr_res[i] = accum.value();
			}
		}
		else
		{
			Integer dpos = m.ld() - 1;

			for (Integer i = 0; i < r; ++i)
			{
				accum.reset();

				Integer col_f = m.first_col(i);
				Integer col_l = m.last_col(i);
				Integer pos   = m.first_elem_pos_row(i);

				if (col_f > 0 || col_l < c-1)
				{
					bool is_known = accum.add_zero();
					if (is_known)
					{
						ptr_res[i] = accum.value();
						continue;
					};
				};

				for (Integer j = col_f; j <= col_l; ++j, pos += dpos)
				{
					if (accum.add(ptr_m[pos]))
					{
						break;
					};
				};			

				ptr_res[i] = accum.value();
			}
		};
		return res;
	};
	static ret_type eval_cum(const in_type &m, int d, accumulator& accum)
	{
		typedef Matrix<typename in_type::value_type,struct_dense> full_matrix;

        gd::type_info ret_ti = m.get_ti();

		ret_type mp = converter<full_matrix,in_type>::eval(ret_ti,m);
		return eval_vec_functor_impl<ret_type,full_matrix,accumulator,struct_dense,struct_dense>::eval_cum(mp,d,accum);
	};
};

};};

#pragma warning( pop )