/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/kron.h"
#include "mmlib/mp/instantiate.h"
#include "mmlib/func/raw/mmul.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/utils/utils.h"
#include "mmlib/blas/blas.h"
#include "mmlib/details/lapack_utils.h"
#include "mmlib/base/integer.h"

namespace mmlib { namespace raw { namespace details
{
 
inline Complex operator*(const Complex& A, Integer B)
{
	return Complex(real(A)*B,imag(A)*B);
};
inline Complex operator*(Integer B, const Complex& A)
{
	return Complex(real(A)*B,imag(A)*B);
};

template<class V>
struct kron_row_col
{
	typedef Matrix<V,struct_dense> mat_type;

	static mat_type eval(const mat_type& A, const mat_type& B)
	{
		Integer As = A.size(), Bs = B.size();
        Integer lda = (A.rows() == 1)? A.ld() : 1;
        Integer ldb = (B.rows() == 1)? B.ld() : 1;

		mat_type res(A.get_ti(),Bs,As);
        const V* ptr_A = A.ptr();
        V* ptr_res = res.ptr();

        for (Integer i = 0; i < As; ++i, ptr_A += lda)
        {
            const V* ptr_B = B.ptr();

            V aij = ptr_A[0];     

            if (gd::is_zero(aij) == false)
			{
				for (Integer Bi = 0; Bi < Bs; ++Bi)
				{
					ptr_res[Bi] = aij * ptr_B[Bi];
				};
                ptr_B += ldb;
			}
			else
			{
				for (Integer Bi = 0; Bi < Bs; ++Bi)
				{
					ptr_res[Bi] = aij;
				};
			};
            ptr_res += res.ld();
        };
		return res;
	};
};
template<>
struct kron_row_col<Real>
{
	typedef Matrix<Real,struct_dense> mat_type;

	static mat_type eval(const mat_type& A, const mat_type& B)
	{
		Integer As = A.size(), Bs = B.size();

		mat_type res(A.get_ti(),0., Bs, As);

		Real alph = 1.;

        lapack::geru(Bs, As, *gd::lap(&alph), gd::lap(B.ptr()), 1, gd::lap(A.ptr()), A.ld(), 
                    gd::lap(res.ptr()), Bs);

        return res;
	};
};
template<>
struct kron_row_col<Complex>
{
	typedef Matrix<Complex,struct_dense> mat_type;

	static mat_type eval(const mat_type& A, const mat_type& B)
	{
		Integer As = A.size(), Bs = B.size();

		mat_type res(A.get_ti(),0., Bs, As);

		Complex alph = 1.;

        lapack::geru(Bs, As, *gd::lap(&alph), gd::lap(B.ptr()), 1, gd::lap(A.ptr()), A.ld(), 
                gd::lap(res.ptr()), res.ld());

        return res;
	};
};

template<class ret_type,class M1,class M2,class str1, class str2>
struct eval_kron
{};

template<class ret_type,class M1,class M2>
struct eval_kron<ret_type,M1,M2,struct_dense,struct_dense>
{
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef M1::value_type val_1;
        typedef M2::value_type val_2;
		typedef ret_type::value_type val_ret;

        const val_1* ptr_A = A.ptr();
        const val_2* ptr_B = B.ptr();

        mmlib::details::type_info ret_ti 
            = mmlib::details::return_kron_ti<M1,M2>::eval(A,B);

		Integer Ar = A.rows(), Ac = A.cols();
		Integer Br = B.rows(), Bc = B.cols();

		if (Ar == 1 && Ac == 1&& Br == 1 && Bc == 1)
		{
			return ret_type(ret_ti,ptr_A[0] * ptr_B[0],1,1);
		};

		error::check_size(Ar,Br);
		error::check_size(Ac,Bc);

		Integer resr = imult_c(Ar,Br), resc = imult_c(Ac,Bc);

		if (!resr || !resc) 
		{
			return ret_type(ret_ti,resr, resc);
		};	

		// A is row vector, B is column vector.
		if (Ar == 1 && Bc == 1)
		{
			return kron_row_col<val_ret>::eval(converter<ret_type,M1>::eval(ret_ti,A),
                                                converter<ret_type,M2>::eval(ret_ti,B));
		}

		// B is row vector, A is column vector.
		if (Br == 1 && Ac == 1)
		{
			return kron_row_col<val_ret>::eval(converter<ret_type,M2>::eval(ret_ti,B),
                                                converter<ret_type,M1>::eval(ret_ti,A));
		}

		ret_type res(ret_ti,resr, resc);
        val_ret* ptr_res = res.ptr();

		for (Integer Aj = 0; Aj < Ac; ++Aj)
		{
            ptr_B = B.ptr();
			for (Integer Bj = 0; Bj < Bc; ++Bj)
			{
			    for (Integer Ai = 0, pos_ret = 0; Ai < Ar; ++Ai)
			    {
				    val_1 aij = ptr_A[Ai];

					if (gd::is_zero(aij) == false)
					{
						for (Integer Bi = 0; Bi < Br; ++Bi, ++pos_ret)
						{
							ptr_res[pos_ret] = aij * ptr_B[Bi];
						};
					}
					else
					{
						for (Integer Bi = 0; Bi < Br; ++Bi, ++pos_ret)
						{
							ptr_res[pos_ret] = val_ret(aij);
						};
					};
				};
                ptr_B += B.ld();
                ptr_res += res.ld();
			};
            ptr_A += A.ld();
		};

		return res;
	};
};
template<class ret_type,class M1,class M2>
struct eval_kron<ret_type,M1,M2,struct_dense,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		typedef ret_type::value_type	val_ret;

        mmlib::details::type_info ret_ti 
            = mmlib::details::return_kron_ti<M1,M2>::eval(A,B);

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();
		Integer Br = B.rows(), Bc = B.cols(), Bn = B.nnz();
	 
		error::check_size(Ar,Br);
		error::check_size(Ac,Bc);

        const val_type_1* ptr_A = A.ptr();

		Integer Cr = imult_c(Ar,Br), Cc = imult_c(Ac,Bc), Cn = imult_c(An,Bn);

		if (!Cn) 
		{
			return ret_type(ret_ti,Cr,Cn);
		};
	 
		const spdat<val_type_2>& Bd	= B.rep();
		const Integer* Bd_c			= Bd.ptr_c();
		const Integer* Bd_r			= Bd.ptr_r();
		const val_type_2* Bd_x		= Bd.ptr_x();

		ret_type C(ret_ti,Cr, Cc, Cn);
		spdat<val_ret>& d = C.rep(); 
	 
        Integer* d_c = d.ptr_c();
        Integer* d_r = d.ptr_r();
        val_ret* d_x = d.ptr_x();

		for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj)
		{
			for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			{
				d_c[cj + 1] = d_c[cj];
				for (Integer ka = 0, arBr = 0; ka < Ar; ++ka, arBr += Br)
				{
					val_type_1 aijx = ptr_A[ka];

					if (gd::is_zero(aijx) == false)
					{
						d_c[cj + 1] += Bd_c[bj + 1] - Bd_c[bj];
						for (Integer kb = Bd_c[bj]; kb < Bd_c[bj + 1]; ++kb, ++k)
						{
							d_r[k] = arBr + Bd_r[kb];
							d_x[k] = aijx * Bd_x[kb];
						};
					};
				};
			};
            ptr_A += A.ld();
		};

		d.memadd(-1);
		return C;
	};
};
template<class ret_type,class M1,class M2>
struct eval_kron<ret_type,M1,M2,struct_dense,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		typedef ret_type::value_type	val_ret;

        mmlib::details::type_info ret_ti 
            = mmlib::details::return_kron_ti<M1,M2>::eval(A,B);

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();
		Integer Br = B.rows(), Bc = B.cols(), Bn = B.nnz();
	 
		error::check_size(Ar,Br);
		error::check_size(Ac,Bc);

		Integer Cr = imult_c(Ar,Br), Cc = imult_c(Ac,Bc), Cn = imult_c(An,Bn);

		if (!Cn) 
		{
			return ret_type(ret_ti,Cr,Cn);
		};
	 
		ret_type C(ret_ti,Cr, Cc, Cn);
		spdat<val_ret>& d = C.rep(); 
        const val_type_1* ptr_A = A.ptr();

        Integer* d_c = d.ptr_c();
        Integer* d_r = d.ptr_r();
        val_ret* d_x = d.ptr_x();

		Integer rc_B = std::min(B.rows(),B.cols());

        const val_type_2* ptr_B = B.rep_ptr();

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
		    for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj)
		    {
                ptr_B = B.rep_ptr();
			    for (Integer bj = 0; bj < Bc; ++bj, ++cj, ptr_B += B.ld())
			    {
				    d_c[cj + 1] = d_c[cj];                    
					for (Integer ka = 0, arBr = 0; ka < Ar; ++ka, arBr += Br)
					{
						val_type_1 aijx = ptr_A[ka];

						if (gd::is_zero(aijx) == false)
						{
							if (bj >= rc_B)
							{
								continue;
							};
							val_type_2 tmp = ptr_B[0];
							if (gd::is_zero(tmp) == true)
							{
								continue;
							};
							d_r[k] = arBr + bj;
							d_x[k] = aijx * tmp;
							++k;

							++d_c[cj + 1];
						};
					};
				}
                ptr_A += A.ld();
            };
        }
        else
        {
		    for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj)
		    {
                ptr_B = B.rep_ptr();
			    for (Integer bj = 0; bj < Bc; ++bj, ++cj, ptr_B += B.ld())
			    {
				    d_c[cj + 1] = d_c[cj];

					for (Integer ka = 0, arBr = 0; ka < Ar; ++ka, arBr += Br)
					{
						val_type_1 aijx = ptr_A[ka];

						if (gd::is_zero(aijx) == false)
						{
							Integer first_row = B.first_row(bj);
							Integer last_row = B.last_row(bj);
							Integer pos_B = B.first_elem_pos(bj);

							Integer nz = 0;
							for (Integer kb = first_row; kb <= last_row; ++kb, ++pos_B)
							{
								val_type_2 tmp = ptr_B[pos_B];
								if (gd::is_zero(tmp) == true)
								{
									continue;
								};
								d_r[k] = arBr + kb;
								d_x[k] = aijx * tmp;
								++k;
								++nz;
							};

							d_c[cj + 1] += nz;
						};
					};
				};
                ptr_A += A.ld();
			};            
		};

		d.memadd(-1);
		return C;
	};
};

template<class ret_type,class M1,class M2>
struct eval_kron<ret_type,M1,M2,struct_sparse,struct_dense>
{
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		typedef ret_type::value_type	val_ret;

        mmlib::details::type_info ret_ti 
            = mmlib::details::return_kron_ti<M1,M2>::eval(A,B);

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();
		Integer Br = B.rows(), Bc = B.cols(), Bn = B.nnz();
	 
		error::check_size(Ar,Br);
		error::check_size(Ac,Bc);

		Integer Cr = imult_c(Ar,Br), Cc = imult_c(Ac,Bc), Cn = imult_c(An,Bn);

		if (!Cn) 
		{
			return ret_type(ret_ti,Cr,Cn);
		};
	 
		const spdat<val_type_1>& Ad	= A.rep();
		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const val_type_1* Ad_x		= Ad.ptr_x();

		ret_type C(ret_ti,Cr, Cc, Cn); 
		spdat<val_ret>& d = C.rep();
        const val_type_2* ptr_B = B.ptr();

        Integer* d_c = d.ptr_c();
        Integer* d_r = d.ptr_r();
        val_ret* d_x = d.ptr_x();
	 
		for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj)
		{
            ptr_B = B.ptr();
			for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			{
				d_c[cj + 1] = d_c[cj];
				for (Integer ka = Ad_c[aj]; ka < Ad_c[aj + 1]; ++ka)
				{					
					val_type_1 aijx = Ad_x[ka];			
					
					if (gd::is_zero(aijx) == true)
					{
						continue;
					};

					Integer arBr = imult(Ad_r[ka], Br);
					Integer nz = 0;
					for (Integer kb = 0; kb < Br; ++kb)
					{
						val_type_2 tmp = ptr_B[kb]; 
						if (gd::is_zero(tmp) == false)
						{
							d_r[k] = arBr + kb;
							d_x[k] = aijx * tmp;
							++nz;
							++k;
						};
					};
					d_c[cj + 1] += nz;
				};
                ptr_B += B.ld();
			};
		};

		d.memadd(-1);
		return C;
	};
};
template<class ret_type,class M1,class M2>
struct eval_kron<ret_type,M1,M2,struct_sparse,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		typedef ret_type::value_type	val_ret;

        mmlib::details::type_info ret_ti 
            = mmlib::details::return_kron_ti<M1,M2>::eval(A,B);

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();
		Integer Br = B.rows(), Bc = B.cols(), Bn = B.nnz();
	 
		error::check_size(Ar,Br);
		error::check_size(Ac,Bc);

		Integer Cr = imult_c(Ar,Br), Cc = imult_c(Ac,Bc), Cn = imult_c(An,Bn);

		if (!Cn) 
		{
			return ret_type(ret_ti,Cr,Cn);
		};
	 
		const spdat<val_type_1>& Ad	= A.rep();
		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const val_type_1* Ad_x		= Ad.ptr_x();

		const spdat<val_type_2>& Bd = B.rep();
		const Integer* Bd_c			= Bd.ptr_c();
		const Integer* Bd_r			= Bd.ptr_r();
		const val_type_2* Bd_x		= Bd.ptr_x();

		ret_type C(ret_ti,Cr, Cc, Cn); 
		spdat<val_ret>& d = C.rep();
	 
        Integer* d_c = d.ptr_c();
        Integer* d_r = d.ptr_r();
        val_ret* d_x = d.ptr_x();

		for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj)
		{
			for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			{
				d_c[cj + 1] = d_c[cj];
				for (Integer ka = Ad_c[aj]; ka < Ad_c[aj + 1]; ++ka)
				{					
					val_type_1 aijx = Ad_x[ka];
					if (gd::is_zero(aijx) == true)
					{
						continue;
					};

					Integer arBr = imult(Ad_r[ka],Br);
					d_c[cj + 1] += Bd_c[bj + 1] - Bd_c[bj];
					for (Integer kb = Bd_c[bj]; kb < Bd_c[bj + 1]; ++kb, ++k)
					{
						d_r[k] = arBr + Bd_r[kb];
						d_x[k] = aijx * Bd_x[kb];
					};
				};
			};
		};

		d.memadd(-1);
		return C;
	};
};
template<class ret_type,class M1,class M2>
struct eval_kron<ret_type,M1,M2,struct_sparse,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		typedef ret_type::value_type	val_ret;

        mmlib::details::type_info ret_ti 
            = mmlib::details::return_kron_ti<M1,M2>::eval(A,B);

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();
		Integer Br = B.rows(), Bc = B.cols(), Bn = B.nnz();
	 
		error::check_size(Ar,Br);
		error::check_size(Ac,Bc);

		Integer Cr = imult_c(Ar,Br), Cc = imult_c(Ac,Bc), Cn = imult_c(An,Bn);

		if (!Cn) 
		{
			return ret_type(ret_ti,Cr,Cn);
		};
	 
		const spdat<val_type_1>& Ad	= A.rep();
		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const val_type_1* Ad_x		= Ad.ptr_x();

		ret_type C(ret_ti,Cr, Cc, Cn);
		spdat<val_ret>& d = C.rep();
		Integer rc_B = std::min(B.rows(),B.cols());
	 
        Integer* d_c = d.ptr_c();
        Integer* d_r = d.ptr_r();
        val_ret* d_x = d.ptr_x();

        const val_type_2* ptr_B = B.rep_ptr();

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
    		for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj)
	    	{
                ptr_B = B.rep_ptr();
		    	for (Integer bj = 0; bj < Bc; ++bj, ++cj, ptr_B+= B.ld())
			    {
				    d_c[cj + 1] = d_c[cj];

					for (Integer ka = Ad_c[aj]; ka < Ad_c[aj + 1]; ++ka)
					{					
						val_type_1 aijx = Ad_x[ka];
						if (gd::is_zero(aijx) == true)
						{
							continue;
						};

						Integer arBr = imult(Ad_r[ka],Br);

						if (bj >= rc_B)
						{
							continue;
						};
						val_type_2 tmp = ptr_B[0];
						if (gd::is_zero(tmp) == true)
						{
							continue;
						};

						d_r[k] = arBr + bj;
						d_x[k] = aijx * tmp;
						++k;
						++d_c[cj + 1];
					};
				}
            }
        }
		else
		{
    		for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj)
	    	{
                ptr_B = B.rep_ptr();
		    	for (Integer bj = 0; bj < Bc; ++bj, ++cj, ptr_B+= B.ld())
			    {
				    d_c[cj + 1] = d_c[cj];
					for (Integer ka = Ad_c[aj]; ka < Ad_c[aj + 1]; ++ka)
					{					
						val_type_1 aijx = Ad_x[ka];
						if (gd::is_zero(aijx) == true)
						{
							continue;
						};

						Integer arBr = imult(Ad_r[ka],Br);
						
						Integer first_row = B.first_row(bj);
						Integer last_row = B.last_row(bj);
						Integer pos_B = B.first_elem_pos(bj);

						Integer nz = 0;
						for (Integer kb = first_row; kb <= last_row; ++kb, ++pos_B)
						{
							val_type_2 tmp = ptr_B[pos_B];
							if (gd::is_zero(tmp) == true)
							{
								continue;
							};

							d_r[k] = arBr + kb;
							d_x[k] = aijx * tmp;
							++k;
							++nz;
						};

						d_c[cj + 1] += nz;
					};
				};
			};
		};

		d.memadd(-1);
		return C;
	};
};
template<class ret_type,class M1,class M2>
struct eval_kron<ret_type,M1,M2,struct_banded,struct_dense>
{
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		typedef ret_type::value_type	val_ret;

        mmlib::details::type_info ret_ti 
            = mmlib::details::return_kron_ti<M1,M2>::eval(A,B);

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();
		Integer Br = B.rows(), Bc = B.cols(), Bn = B.nnz();
	 
		error::check_size(Ar,Br);
		error::check_size(Ac,Bc);

		Integer Cr = imult_c(Ar,Br), Cc = imult_c(Ac,Bc), Cn = imult_c(An,Bn);

		if (Cr == 0 || Cc == 0) 
		{
			return ret_type(ret_ti,Cr,Cc);
		};
	 
		ret_type C(ret_ti,Cr, Cc, Cn); 
		spdat<val_ret>& d = C.rep();
		Integer nz = 0;

        Integer* d_c = d.ptr_c();
        Integer* d_r = d.ptr_r();
        val_ret* d_x = d.ptr_x();

		Integer rc_A = std::min(A.rows(),A.cols());

        const val_type_1* ptr_A = A.rep_ptr();
        const val_type_2* ptr_B = B.ptr();

		if (A.ldiags() == 0 && A.udiags() == 0)
		{	 
            Integer cj = 0;
		    for (Integer aj = 0, arBr = 0; aj < rc_A; ++aj, ptr_A += A.ld(), arBr += Br)
		    {
				val_type_1 aijx = ptr_A[0];
				if (gd::is_zero(aijx) == true)
				{
			        for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			        {
				        d_c[cj] = nz;
                    };
					continue;
				};
                ptr_B = B.ptr();
			    for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			    {
				    d_c[cj] = nz;

					for (Integer kb = 0; kb < Br; ++kb)
					{
						val_type_2 tmp = ptr_B[kb]; 
                        if (!mmlib::details::is_zero(tmp))
						{
							d_r[nz] = arBr + kb;
							d_x[nz] = aijx * tmp;
							++nz;
						};
					};
                    ptr_B += B.ld();
				}                
			};
		    for (Integer aj = rc_A; aj < Ac; ++aj)
		    {
			    for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			    {
				    d_c[cj] = nz;
                };
            };
            d_c[Cc] = nz;
		}
		else
		{
		    for (Integer aj = 0, cj = 0; aj < Ac; ++aj, ptr_A += A.ld())
		    {
                ptr_B = B.ptr();

			    for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			    {
                    d_c[cj] = nz;

					Integer fr      = A.first_row(aj);
					Integer lr      = A.last_row(aj);
					Integer pos_A   = A.first_elem_pos(aj);
                    Integer arBr    = imult(fr,Br);

					for (Integer ka = fr; ka <= lr; ++ka, ++pos_A, arBr += Br)
					{					
						val_type_1 aijx = ptr_A[pos_A];
						if (gd::is_zero(aijx) == true)
						{
							continue;
						};

						for (Integer kb = 0; kb < Br; ++kb)
						{
							val_type_2 tmp = ptr_B[kb]; 
                            if (!mmlib::details::is_zero(tmp))
							{
								d_r[nz] = arBr + kb;
								d_x[nz] = aijx * tmp;
								++nz;
							};
						};
					};
                    ptr_B += B.ld();
				};
            };
        };

		d_c[Cc] = nz;

		d.memadd(-1);
		return C;
	};
};
template<class ret_type,class M1,class M2>
struct eval_kron<ret_type,M1,M2,struct_banded,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		typedef ret_type::value_type	val_ret;

        mmlib::details::type_info ret_ti 
            = mmlib::details::return_kron_ti<M1,M2>::eval(A,B);

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();
		Integer Br = B.rows(), Bc = B.cols(), Bn = B.nnz();
	 
		error::check_size(Ar,Br);
		error::check_size(Ac,Bc);

		Integer Cr = imult_c(Ar,Br), Cc = imult_c(Ac,Bc), Cn = imult_c(An,Bn);

		if (!Cn) 
		{
			return ret_type(ret_ti,Cr,Cn);
		};

		const spdat<val_type_2>& Bd = B.rep();
		const Integer* Bd_c			= Bd.ptr_c();
		const Integer* Bd_r			= Bd.ptr_r();
		const val_type_2* Bd_x		= Bd.ptr_x();

		ret_type C(ret_ti,Cr, Cc, Cn); 
		spdat<val_ret>& d = C.rep();

        Integer* d_c = d.ptr_c();
        Integer* d_r = d.ptr_r();
        val_ret* d_x = d.ptr_x();

		Integer rc_A = std::min(A.rows(),A.cols());

        const val_type_1* ptr_A = A.rep_ptr();

		if (A.ldiags() == 0 && A.udiags() == 0)
		{
            Integer cj = 0;
    		for (Integer aj = 0, k = 0, arBr = 0; aj < rc_A; ++aj, ptr_A += A.ld(), arBr += Br)
	    	{
				val_type_1 aijx = ptr_A[0];
				if (gd::is_zero(aijx) == true)
				{
		    	    for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			        {
				        d_c[cj + 1] = d_c[cj];
                    };
					continue;
				};

		    	for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			    {
				    d_c[cj + 1] = d_c[cj];
					d_c[cj + 1] += Bd_c[bj + 1] - Bd_c[bj];

					for (Integer kb = Bd_c[bj]; kb < Bd_c[bj + 1]; ++kb, ++k)
					{
						d_r[k] = arBr + Bd_r[kb];
						d_x[k] = aijx * Bd_x[kb];
					};
				}
			};
    		for (Integer aj = rc_A; aj < Ac; ++ aj)
	    	{
		    	for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			    {
				    d_c[cj + 1] = d_c[cj];
                };
            };
		}
		else
		{
    		for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj, ptr_A += A.ld())
	    	{
		    	for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			    {
                    d_c[cj + 1]     = d_c[cj];

					Integer fr      = A.first_row(aj);
					Integer lr      = A.last_row(aj);
					Integer pos_A   = A.first_elem_pos(aj);
                    Integer arBr    = imult(fr,Br);

					for (Integer ka = fr; ka <= lr; ++ka, ++pos_A, arBr += Br)
					{					
						val_type_1 aijx = ptr_A[pos_A];
						if (gd::is_zero(aijx) == true)
						{
							continue;
						};
						
						d_c[cj + 1] += Bd_c[bj + 1] - Bd_c[bj];
						for (Integer kb = Bd_c[bj]; kb < Bd_c[bj + 1]; ++kb, ++k)
						{
							d_r[k] = arBr + Bd_r[kb];
							d_x[k] = aijx * Bd_x[kb];
						};
					};
				};
            };
        };

		d.memadd(-1);
		return C;
	};
};
template<class ret_type,class M1,class M2>
struct eval_kron<ret_type,M1,M2,struct_banded,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B)
	{
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		typedef ret_type::value_type	val_ret;

        mmlib::details::type_info ret_ti 
            = mmlib::details::return_kron_ti<M1,M2>::eval(A,B);

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();
		Integer Br = B.rows(), Bc = B.cols(), Bn = B.nnz();
	 
		error::check_size(Ar,Br);
		error::check_size(Ac,Bc);

		Integer Cr = imult_c(Ar,Br), Cc = imult_c(Ac,Bc), Cn = imult_c(An,Bn);

		if (!Cn) 
		{
			return ret_type(ret_ti,Cr,Cn);
		};
	 
		ret_type C(ret_ti,Cr, Cc, Cn); 
		spdat<val_ret>& d = C.rep();

        Integer* d_c = d.ptr_c();
        Integer* d_r = d.ptr_r();
        val_ret* d_x = d.ptr_x();

		Integer rc_B = std::min(B.rows(),B.cols());
		Integer rc_A = std::min(A.rows(),A.cols());

        const val_type_1* ptr_A = A.rep_ptr();
        const val_type_2* ptr_B = B.rep_ptr();
	 
		if (A.ldiags() == 0 && A.udiags() == 0 && B.ldiags() == 0 && B.udiags() == 0)
		{
            Integer cj = 0;
            Integer k = 0;
			for (Integer aj = 0, arBr = 0; aj < rc_A; ++aj, ptr_A += A.ld(), arBr += Br)
			{
				val_type_1 aijx = ptr_A[0];
				if (gd::is_zero(aijx) == true)
				{
                    for (Integer j = 0; j < Bc; ++j, ++cj)
                    {
                        d_c[cj] = k;
                    };
					continue;
				};

                ptr_B = B.rep_ptr();

				for (Integer bj = 0; bj < rc_B; ++bj, ++cj, ptr_B += B.ld())
				{
					d_c[cj] = k;

					val_type_2 tmp = ptr_B[0];
					if (gd::is_zero(tmp) == true)
					{
						continue;
					};

					d_r[k] = arBr + bj;
					d_x[k] = aijx * tmp;
					++k;
				};
				for (Integer bj = rc_B; bj < Bc; ++bj, ++cj)
				{
					d_c[cj] = k;
                };
			};
            for (Integer aj = rc_A; aj < Ac; ++ aj)
            {
                for (Integer j = 0; j < Bc; ++j, ++cj)
                {
                    d_c[cj] = k;
                };
            };
            d_c[Cc] = k;
			d.memadd(-1);
			return C;
		};
		if (B.ldiags() == 0 && B.udiags() == 0)
		{
		    for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj, ptr_A += A.ld())
		    {
                ptr_B = B.rep_ptr();

			    for (Integer bj = 0; bj < rc_B; ++bj, ++cj, ptr_B+= B.ld())
			    {
				    d_c[cj + 1]     = d_c[cj];

				    val_type_2 tmp = ptr_B[0];
				    if (gd::is_zero(tmp) == true)
				    {
					    continue;
				    };

				    Integer fr_A    = A.first_row(aj);
				    Integer lr_A    = A.last_row(aj);
				    Integer pos_A   = A.first_elem_pos(aj);
                    Integer arBr    = imult(fr_A,Br) + bj;

				    for (Integer ka = fr_A; ka <= lr_A; ++ka, ++pos_A, arBr += Br)
				    {					
					    val_type_1 aijx = ptr_A[pos_A];
					    if (gd::is_zero(aijx) == true)
					    {
						    continue;
					    };

					    d_r[k] = arBr;
					    d_x[k] = aijx * tmp;
					    ++k;

					    ++d_c[cj + 1];
				    };
			    };
			    for (Integer bj = rc_B; bj < Bc; ++bj, ++cj)
			    {
				    d_c[cj + 1] = d_c[cj];
                };
		    };
        }
        else if (A.ldiags() == 0 && A.udiags() == 0)
        {
            Integer arBr = 0;
            Integer cj = 0;
		    for (Integer aj = 0, k = 0; aj < rc_A; ++aj, ptr_A += A.ld(), arBr += Br)
		    {
			    val_type_1 aijx = ptr_A[0];
			    if (gd::is_zero(aijx) == true)
			    {
			        for (Integer bj = 0; bj < Bc; ++bj, ++cj)
			        {
				        d_c[cj + 1] = d_c[cj];
                    };
				    continue;
			    };

                ptr_B = B.rep_ptr();
			    for (Integer bj = 0; bj < Bc; ++bj, ++cj, ptr_B+= B.ld())
			    {
				    d_c[cj + 1]         = d_c[cj];
				
				    Integer first_row   = B.first_row(bj);
				    Integer last_row    = B.last_row(bj);
				    Integer pos_B       = B.first_elem_pos(bj);

				    Integer nz = 0;
				    for (Integer kb = first_row; kb <= last_row; ++kb, ++pos_B)
				    {
					    val_type_2 tmp  = ptr_B[pos_B];
					    if (gd::is_zero(tmp) == true)
					    {
						    continue;
					    };

					    d_r[k] = arBr + kb;
					    d_x[k] = aijx * tmp;
					    ++k;
					    ++nz;
				    };

				    d_c[cj + 1] += nz;
			    };
		    };
		    for (Integer aj = rc_A; aj < Ac; ++ aj)
		    {
		        for (Integer bj = 0; bj < Bc; ++bj, ++cj)
		        {
			        d_c[cj + 1] = d_c[cj];
                };
            };
        }
        else
        {
		    for (Integer aj = 0, cj = 0, k = 0; aj < Ac; ++aj, ptr_A += A.ld())
		    {
                ptr_B = B.rep_ptr();
			    for (Integer bj = 0; bj < Bc; ++bj, ++cj, ptr_B+= B.ld())
			    {
				    d_c[cj + 1] = d_c[cj];

				    Integer fr_A    = A.first_row(aj);
				    Integer lr_A    = A.last_row(aj);
				    Integer pos_A   = A.first_elem_pos(aj);
                    Integer arBr    = imult(fr_A,Br);

				    for (Integer ka = fr_A; ka <= lr_A; ++ka, ++pos_A, arBr += Br)
				    {					
					    val_type_1 aijx = ptr_A[pos_A];
					    if (gd::is_zero(aijx) == true)
					    {
						    continue;
					    };
					
					    Integer first_row = B.first_row(bj);
					    Integer last_row = B.last_row(bj);
					    Integer pos_B = B.first_elem_pos(bj);

					    Integer nz = 0;
					    for (Integer kb = first_row; kb <= last_row; ++kb, ++pos_B)
					    {
						    val_type_2 tmp = ptr_B[pos_B];
						    if (gd::is_zero(tmp) == true)
						    {
							    continue;
						    };

						    d_r[k] = arBr + kb;
						    d_x[k] = aijx * tmp;
						    ++k;
						    ++nz;
					    };

					    d_c[cj + 1] += nz;
				    };
			    };
		    };
        };

		d.memadd(-1);
		return C;
	};
};


template<class M1, class M2>
typename kron_helper<M1,M2>::ret_type 
kron_helper<M1,M2>::eval(const M1& A, const M2& B)
{
	typedef M1::struct_type str_type_1;
	typedef M2::struct_type str_type_2;

	return eval_kron<ret_type,M1,M2,str_type_1,str_type_2>::eval(A,B);
};
};};};

MACRO_INSTANTIATE_GG_2(mmlib::raw::details::kron_helper)
MACRO_INSTANTIATE_GST_2(mmlib::raw::details::kron_helper)
MACRO_INSTANTIATE_STG_2(mmlib::raw::details::kron_helper)
MACRO_INSTANTIATE_STST_2(mmlib::raw::details::kron_helper)
