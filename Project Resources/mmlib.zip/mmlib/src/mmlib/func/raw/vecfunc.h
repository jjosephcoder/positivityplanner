/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/error/error_check.h"
#include "mmlib/eval_functors.h"
#include "mmlib/details/enablers.h"
#include "mmlib/base/return_types.h"
#include "mmlib/mp/promote_type.h"
#include "mmlib/utils/utils.h"

namespace mmlib { namespace raw
{

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::sum>>::type
sum(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	typedef typename promote_type::type MP;
	return details::vec_manip_helper<MP>::eval_sum(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::sum>>::type
sum(const M& m, int d = 1)
{
	error::check_dim(d);
	return m;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::nnz>>::type
nnz(const M& m, int dim)
{
	typedef promote_type<M> promote_type;
	typedef typename promote_type::type MP;
	return details::vec_manip_helper<MP>::eval_nnz(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::nnz>>::type
nnz(const M& m, int d)
{
	error::check_dim(d);
    return mmlib::details::is_zero(m)? 0 : 1;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::prod>>::type
prod(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_prod(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::prod>>::type
prod(const M& m, int d = 1)
{
	error::check_dim(d);
	return m;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::cumsum>>::type
cumsum(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_cumsum(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::cumsum>>::type
cumsum(const M& m, int d = 1)
{
	error::check_dim(d);
	return m;
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::cumprod>>::type
cumprod(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_cumprod(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::cumprod>>::type
cumprod(const M& m, int d = 1)
{
	error::check_dim(d);
	return m;
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::sumsq>>::type
sumsq(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_sumsq(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::sumsq>>::type
sumsq(const M& m, int d = 1)
{
	error::check_dim(d);
	return m*m;
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::min>>::type
min(const M& m)
{
	return min_d(m,1);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::min>>::type
min_d(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_min(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::min_abs>>::type
min_abs_d(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_min_abs(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::min>>::type
min(const M& m)
{
	return m;
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::min>>::type
min_d(const M& m, int d = 1)
{
	error::check_dim(d);
	return m;
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::min_abs>>::type
min_abs_d(const M& m, int d = 1)
{
	error::check_dim(d);
    return raw::abs(m);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::min_2>>::type
min2(const M& m, int dim)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_min2(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::min_abs2>>::type
min_abs2(const M& m, int dim)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_min_abs2(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::min_2>>::type
min2(const M& m, int d)
{
	error::check_dim(d);
    typedef return_type_scalar<M,raw_functions::min_2>::type ret_type;
	IntegerMatrix ind(gd::get_raw_ti(),Integer(1),1,1);
	return ret_type(m,ind);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::min_abs2>>::type
min_abs2(const M& m, int d)
{
	error::check_dim(d);
    typedef return_type_scalar<M,raw_functions::min_abs2>::type ret_type;
	IntegerMatrix ind(gd::get_raw_ti(),Integer(1),1,1);
    return ret_type(raw::abs(m),ind);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::max>>::type
max(const M& m)
{
	return max_d(m);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::max>>::type
max_d(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_max(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::max_abs>>::type
max_abs_d(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_max_abs(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::max>>::type
max_d(const M& m, int d = 1)
{
	error::check_dim(d);
	return m;
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::max_abs>>::type
max_abs_d(const M& m, int d = 1)
{
	error::check_dim(d);
    return raw::abs(m);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::max>>::type
max(const M& m)
{
	error::check_dim(d);
	return m;
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::max_2>>::type
max2(const M& m, int dim)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_max2(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::max_abs2>>::type
max_abs2(const M& m, int dim)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_max_abs2(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::max_2>>::type
max2(const M& m, int d)
{
	error::check_dim(d);
    typedef return_type_scalar<M,raw_functions::max_2>::type ret_type;
	IntegerMatrix ind(gd::get_raw_ti(),Integer(1),1,1);
	return ret_type(m,ind);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::max_abs2>>::type
max_abs2(const M& m, int d)
{
	error::check_dim(d);
    typedef return_type_scalar<M,raw_functions::max_abs2>::type ret_type;
	IntegerMatrix ind(gd::get_raw_ti(),Integer(1),1,1);
	return ret_type(raw::abs(m),ind);
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::mean>>::type
mean(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_mean(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::mean>>::type
mean(const M& m, int d = 1)
{
	error::check_dim(d);
	return m;
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::std>>::type
std(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_std(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::std>>::type
std(const M& m, int d = 1)
{
	error::check_dim(d);
    return gd::default_value<M>(gd::get_ti(m));
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::all>>::type
all(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_all(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::all>>::type
all(const M& m, int d = 1)
{
	error::check_dim(d);
	typedef mmlib::details::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_istrue>::eval(m);
	return details::is_true_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::all>>::type
all(const M& m, const test_function& t, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_all(promote_type::eval(m),t, dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::all>>::type
all(const M& m, const test_function& t, int d = 1)
{
	error::check_dim(d);
	typedef mmlib::details::promote_scalar<M>::type MP;
	return t.eval(MP(m));
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::any>>::type
any(const M& m, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_any(promote_type::eval(m),dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::any>>::type
any(const M& m, int d = 1)
{
	error::check_dim(d);
	typedef mmlib::details::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_istrue>::eval(m);
	return details::is_true_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::any>>::type
any(const M& m, const test_function& t, int dim = 1)
{
	typedef promote_type<M> promote_type;
	return details::vec_manip_helper<typename promote_type::type>::eval_any(promote_type::eval(m),t,dim);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::any>>::type
any(const M& m, const test_function& t, int = 1)
{
	typedef mmlib::details::promote_scalar<M>::type MP;
	return t.eval(MP(m));
};

}};
