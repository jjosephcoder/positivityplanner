/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/enablers.h"
#include "mmlib/mp/promote_type.h"
#include "mmlib/base/return_types.h"

namespace mmlib { namespace raw
{

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::kron>>::type
kron(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::kron_helper<MP1,MP2>::eval(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::kron>>::type
kron(const M1& A,const M2& B)
{
	typedef promote_type<M1>					promote_type_1;	
	typedef promote_type_1::type				MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;

	return details::kron_scal_helper<MP1,MP2>::eval(promote_type_1::eval(A),(MP2)B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::kron>>::type
kron(const M1& A,const M2& B)
{
	typedef promote_type<M2>					promote_type_2;	
	typedef promote_type_2::type				MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;

	return details::kron_scal_helper<MP2,MP1>::eval(promote_type_2::eval(B),(MP1)A);
};


};};
