/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#pragma warning( push )
#pragma warning(disable:4127)	// conditional expression is constant
#pragma warning(disable:4100)	// 'fun' : unreferenced formal parameter (strange warning)
#pragma warning(disable:4723)	// potential divide by 0

namespace mmlib { namespace raw
{

namespace gd = mmlib::details;

template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ
		>
struct eval_bin_functor
{
	static ret_type eval(const M1& A, const M2& B) 
	{
		typedef typename ret_type::struct_type str_ret;
		typedef typename M1::struct_type str_1;
		typedef typename M2::struct_type str_2;

		return details::eval_bin_functor_impl
			<ret_type,functor,M1,M2,ZZ,ZN,NZ,false,
			typename ret_type::struct_type,
			typename M1::struct_type,					
			typename M2::struct_type
			>::eval(A,B,functor());
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ
		>
struct eval_bin_functor2
{
	static ret_type eval(const M1& A, const M2& B, const functor& func) 
	{
		typedef typename ret_type::struct_type str_ret;
		typedef typename M1::struct_type str_1;
		typedef typename M2::struct_type str_2;

		return details::eval_bin_functor_impl
			<ret_type,functor,M1,M2,ZZ,ZN,NZ,false,
			typename ret_type::struct_type,
			typename M1::struct_type,					
			typename M2::struct_type
			>::eval(A,B,func);
	};
};

template<class func,bool is_inv,class ret_type, class in1, class in2>
struct eval_F_impl
{
	static ret_type eval(gd::type_info ti, in1 a, in2 b,const func& fun)
	{
		ret_type out = fun.eval<ret_type,in1,in2>(ti,a,b);
		return out;
	};
};
template<class func,class ret_type, class in1, class in2>
struct eval_F_impl<func,true,ret_type,in1,in2>
{
	static ret_type eval(gd::type_info ti, in1 a, in2 b, const func& fun)
	{
		ret_type out = fun.eval<ret_type,in2,in1>(ti,b,a);
		return out;
	};
};
template<class func,bool is_inv,class ret_type, class in1, class in2>
struct eval_F
{
	const func& f;

	eval_F ( const func& f) : f(f) {};

	ret_type eval(gd::type_info ti, in1 a, in2 b)
	{
		return eval_F_impl<func,is_inv,ret_type,in1,in2>::eval(ti,a,b,f);
	};

	private:
		eval_F(const eval_F&);
		eval_F& operator=(const eval_F&);
};
namespace details
{

template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ,
			bool is_inv,
			class str_ret,
			class str_1,						
			class str_2
		>
struct eval_bin_functor_impl
{};

//--------------------------------------------------------------------
//				GM - GM
//--------------------------------------------------------------------
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,	//0,1
			bool ZN,	//0,1
			bool NZ,	//0,1
			bool is_inv
			//class str_ret = struct_dense,
			//class str_1= struct_dense,
			//class str_2= struct_dense
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,NZ,is_inv,
			struct_dense,struct_dense,struct_dense>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type	val_type_1;
		typedef typename M2::value_type	val_type_2;

        gd::type_info ret_ti = gd::return_func_ti<functor,M1,M2>::eval(A,B);

        Integer r = A.rows(), c = A.cols();
		error::check_eeop(r, c, B.rows(), B.cols()); 

		ret_type res = ret_type(ret_ti, r, c); 
	 
		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

        const val_type_1* ptr_A = A.ptr();
        const val_type_2* ptr_B = B.ptr();
        val_type_ret* ptr_res = res.ptr();

        for (Integer j = 0; j < c; ++j)
        {
            for (Integer i = 0; i < r; ++i)
            {
                ptr_res[i] = ef.eval(ret_ti,ptr_A[i],ptr_B[i]); 
            };
            ptr_A += A.ld();
            ptr_B += B.ld();
            ptr_res += res.ld();
        };
	 
		return res; 
	};
};

//--------------------------------------------------------------------
//				GM - SM
//--------------------------------------------------------------------
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,	//0,1
			bool ZN,	//0,1
			//bool NZ,	//0
			bool is_inv
			//class str_ret = struct_dense,
			//class str_1= struct_dense,
			//class str_2= struct_sparse
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,false,is_inv,
					struct_dense,struct_dense,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type	val_type_1;
		typedef typename M2::value_type	val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols()); 

		ret_type res = ret_type(ret_ti,A.rows(), A.cols()); 

        const val_type_1* ptr_A = A.ptr();
        val_type_ret* ptr_res = res.ptr();

		Integer r = A.rows(), c = A.cols();

		if (B.nnz() == 0)
		{
            for (Integer j = 0; j < c; ++j)
            {
                for (Integer i = 0; i < r; ++i)
                {
                    ptr_res[i] = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,ptr_A[i]);
                };
                ptr_res += res.ld();
                ptr_A += A.ld();
            };
			return res;
		};
	 
		const spdat<val_type_2>& Bd = B.rep();
		const Integer* Bd_c		= Bd.ptr_c();
		const Integer* Bd_r		= Bd.ptr_r();
		const val_type_2* Bd_x	= Bd.ptr_x();

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

		for (Integer j = 0; j < c; ++j)
		{
			Integer pos = 0;
			for (Integer k = Bd_c[j]; k < Bd_c[j + 1] ; ++k)
			{
				Integer p = Bd_r[k];
				while (pos < p)
				{
					ptr_res[pos] = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,ptr_A[pos]);
					++pos;
				}
				ptr_res[pos] = ef.eval(ret_ti,ptr_A[pos],Bd_x[k]);
				++pos;
			};
			while (pos < r)
			{
				ptr_res[pos] = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,ptr_A[pos]);
				++pos;
			};

            ptr_res += res.ld();
            ptr_A += A.ld();
		};
 
	    return res;
	};
};

template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,	//0	
			bool ZN,	//0,1
			//bool NZ,	//1
			bool is_inv
			//class str_ret = struct_sparse,
			//class str_1= struct_dense,
			//class str_2= struct_sparse
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,false,ZN,true,is_inv,
					struct_sparse,struct_dense,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type	val_type_1;
		typedef typename M2::value_type	val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols()); 

		ret_type res = ret_type(ret_ti,A.rows(), A.cols(),B.nnz() + A.rows()); 

		if (A.rows() == 0 || A.cols() == 0)
		{
			return res;
		};
		Integer r = A.rows(), c = A.cols(); 			
	 
		const spdat<val_type_2>& Bd = B.rep();
		const Integer* Bd_c		= Bd.ptr_c();
		const Integer* Bd_r		= Bd.ptr_r();
		const val_type_2* Bd_x	= Bd.ptr_x();

		spdat<val_type_ret>& d	= res.rep();
		Integer* d_c			= d.ptr_c();
		Integer* d_r			= d.ptr_r();
		val_type_ret* d_x		= d.ptr_x();

		Integer nz				= 0;

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

        val_type_1 Z1           = gd::default_value<val_type_1>(A.get_ti());
        val_type_2 Z2           = gd::default_value<val_type_2>(B.get_ti());
		val_type_ret ret_zz		= ef.eval(ret_ti,Z1,Z2);

        const val_type_1* ptr_A = A.ptr();

		if (B.nnz() == 0)
		{
			for (Integer j = 0; j < c; ++j)
			{
				d_c[j]				= nz;

    			if (nz + r > d.nzmax()) 
    			{
					d.memadd( d.nzmax() + r);
					d_r				= d.ptr_r();
					d_x				= d.ptr_x();
    			};

                for (Integer i = 0; i < r; ++i)
                {
                    if (gd::is_zero(ptr_A[i]))
					{
						d_r[nz]	= i;
						d_x[nz]	= ret_zz;
						++nz;
					};
                };
                ptr_A += A.ld();
			};

			d_c[c] = nz;
			d.memadd(-1);
	 
			return res;
		};

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]				= nz;
			Integer pos	        = 0;

    		if (nz + r > d.nzmax()) 
    		{
				d.memadd( d.nzmax() + r);
				d_r				= d.ptr_r();
				d_x				= d.ptr_x();
    		};

			for (Integer k = Bd_c[j]; k < Bd_c[j + 1] ; ++k)
			{
				Integer p		= Bd_r[k];
				for (;pos < p; ++pos)
				{
					if (gd::is_zero(ptr_A[pos]))
					{
						d_r[nz]	= pos;
						d_x[nz]	= ret_zz;
						++nz;
					};
				};
				val_type_ret tmp = ef.eval(ret_ti,ptr_A[pos++],Bd_x[k]);
				if (!gd::is_zero(tmp))
				{
					d_r[nz]		= p;
					d_x[nz]		= tmp;
					++nz;
				};
			};
			for (;pos < r; ++pos)
			{
				if (gd::is_zero(ptr_A[pos]))
				{
					d_r[nz]	= pos;
					d_x[nz]	= ret_zz;
					++nz;
				};
			};

            ptr_A += A.ld();
		};

		d_c[c] = nz;
		d.memadd(-1);
 
	    return res;
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,	//1
			bool ZN,	//0,1
			//bool NZ,	//1
			bool is_inv
			//class str_ret = struct_sparse,
			//class str_1= struct_dense,
			//class str_2= struct_sparse
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,true,ZN,true,is_inv,
					struct_sparse,struct_dense,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type	val_type_1;
		typedef typename M2::value_type	val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols()); 

		ret_type res = ret_type(ret_ti,A.rows(), A.cols(),B.nnz() + A.rows()); 

		if (A.rows() == 0 || A.cols() == 0 || B.nnz() == 0)
		{
			return res;
		};
		Integer c = A.cols(); 			
	 
		const spdat<val_type_2>& Bd = B.rep();
		const Integer* Bd_c		= Bd.ptr_c();
		const Integer* Bd_r		= Bd.ptr_r();
		const val_type_2* Bd_x	= Bd.ptr_x();

		spdat<val_type_ret>& d	= res.rep();
		Integer* d_c			= d.ptr_c();
		Integer* d_r			= d.ptr_r();
		val_type_ret* d_x		= d.ptr_x();

        const val_type_1* ptr_A = A.ptr();

		Integer nz				= 0;

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]				= nz;

			for (Integer k = Bd_c[j]; k < Bd_c[j + 1] ; ++k)
			{
				Integer p		= Bd_r[k];

				val_type_ret tmp = ef.eval(ret_ti,ptr_A[p],Bd_x[k]);
                if (!gd::is_zero(tmp))
				{
					d_r[nz]		= p;
					d_x[nz]		= tmp;
					++nz;
				};
			};

            ptr_A += A.ld();
		};

		d_c[c] = nz;
		d.memadd(-1);
 
	    return res;
	};
};
//--------------------------------------------------------------------
//				GM - B
//--------------------------------------------------------------------
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//1
			bool ZN,		//0,1
			//bool NZ,		//1
			bool is_inv
			//class str_ret = struct_banded,
			//class str_1= struct_dense,
			//class str_2= struct_banded
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,true,ZN,true,is_inv,
						struct_banded,struct_dense,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type	val_type_1;
		typedef typename M2::value_type	val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols()); 
		
		ret_type res = ret_type(ret_ti,B.rows(), B.cols(),B.ldiags(), B.udiags()); 

		Integer r = A.rows(), c = A.cols();

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

        const val_type_1* ptr_A = A.ptr();
        const val_type_2* ptr_B = B.rep_ptr();
        val_type_ret* ptr_res = res.rep_ptr();

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			Integer rc = std::min(r,c);
			for (Integer j = 0; j < rc; ++j, ptr_A += A.ld()+1)
			{
				val_type_2 tmp = ptr_B[0];
				ptr_res[j] = ef.eval(ret_ti,*ptr_A,tmp);
                ptr_B += B.ld();
			};
		}
		else
		{
			for (Integer j = 0; j < c; ++j)
			{
				Integer first_row = B.first_row(j);
				Integer last_row  = B.last_row(j);
				Integer first_elem= B.first_elem_pos(j);

				for (Integer i = first_row, pos_B = first_elem; i <= last_row; ++i, ++pos_B)
				{
					val_type_2 tmp = ptr_B[pos_B];
					ptr_res[pos_B] = ef.eval(ret_ti,ptr_A[i],tmp);
				};

                ptr_A += A.ld();
				ptr_B += B.ld();
                ptr_res += res.ld();				
			};
		}; 
	    return res;
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,		//0,1
			bool ZN,		//0,1
			//bool NZ,		//0
			bool is_inv
			//class str_ret = struct_dense,
			//class str_1= struct_dense,
			//class str_2= struct_banded
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,false,is_inv,
						struct_dense,struct_dense,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type	val_type_1;
		typedef typename M2::value_type	val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols()); 
		
		ret_type res = ret_type(ret_ti,A.rows(), A.cols()); 

		Integer r = A.rows(), c = A.cols();

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

        const val_type_1* ptr_A = A.ptr();
        const val_type_2* ptr_B = B.rep_ptr();
        val_type_ret* ptr_res   = res.ptr();

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			Integer rc = std::min(r,c);            

			for (Integer j = 0; j < rc; ++j)
			{
				for (Integer i = 0; i < j; ++i)
				{
					ptr_res[i] = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,ptr_A[i]);
				};

				ptr_res[j] = ef.eval(ret_ti,ptr_A[j],ptr_B[0]);

				for (Integer i = j+1; i < r; ++i)
				{
					ptr_res[i] = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,ptr_A[i]);
				};

                ptr_A += A.ld();
                ptr_B += B.ld();
                ptr_res += res.ld();
			};
			for (Integer j = rc; j < c; ++j)
			{
				for (Integer i = 0; i < r; ++i)
				{
					ptr_res[i] = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,ptr_A[i]);
				};
                ptr_A += A.ld();
                ptr_res += res.ld();
			};
		}
		else
		{
			for (Integer j = 0; j < c; ++j)
			{
				Integer first_row = B.first_row(j);
				Integer last_row  = B.last_row(j);
				Integer first_elem= B.first_elem_pos(j);

				for (Integer i = 0; i < first_row && i < r; ++i)
				{
					ptr_res[i] = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,ptr_A[i]);
				};

				for (Integer i = first_row, pos_B = first_elem; i <= last_row; ++i, ++pos_B)
				{
					val_type_2 tmp = ptr_B[pos_B];
					ptr_res[i] = ef.eval(ret_ti,ptr_A[i],tmp);
				};

				for (Integer i = last_row+1; i < r; ++i)
				{
					ptr_res[i] = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,ptr_A[i]);
				};

                ptr_A += A.ld();
				ptr_B += B.ld();
                ptr_res += res.ld();
			};
		}; 
	    return res;
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//0
			bool ZN,		//0,1
			//bool NZ,		//1
			bool is_inv
			//class str_ret = struct_sparse,
			//class str_1= struct_dense,
			//class str_2= struct_banded
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,false,ZN,true,is_inv,
						struct_sparse,struct_dense,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef typename ret_type::value_type	val_type_ret;
		typedef typename M1::value_type	val_type_1;
		typedef typename M2::value_type	val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols()); 
		
		Integer r = A.rows(), c = A.cols();

		ret_type res = ret_type(ret_ti,B.rows(), B.cols(), B.nnz() + r);

		if (B.rows() == 0 || B.cols() == 0 || B.nnz() == 0)
		{
			return res;
		};

		spdat<val_type_ret>& d	= res.rep();

        val_type_1 zero_1		= gd::default_value<val_type_1>(gd::get_ti(A));
        val_type_2 zero_2		= gd::default_value<val_type_2>(gd::get_ti(B));

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

		val_type_ret zz			= ef.eval(ret_ti,zero_1,zero_2);

		Integer nz				= 0;

		Integer* d_c			= d.ptr_c();
		Integer* d_r			= d.ptr_r();
		val_type_ret* d_x		= d.ptr_x();

        const val_type_1* ptr_A = A.ptr();
        const val_type_2* ptr_B = B.rep_ptr();

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			Integer rc			= std::min(r,c);
			for (Integer j = 0; j < rc; ++j)
			{
				d_c[j]			= nz;
    			if (nz + r > d.nzmax()) 
    			{
					d.memadd( d.nzmax() + r);

					d_r			= d.ptr_r();
					d_x			= d.ptr_x();
    			};

				if (!gd::is_zero(zz))
				{
					for (Integer i = 0; i < j; ++i)
					{
						val_type_1 tmp  = ptr_A[i];
						if (gd::is_zero(tmp))
						{
							d_r[nz]		= i;
							d_x[nz]		= zz;
							++nz;
						};
					};
				};

				val_type_ret val = ef.eval(ret_ti,ptr_A[j],ptr_B[0]);
				if (!gd::is_zero(val))
				{
					d_r[nz]		= j;
					d_x[nz]		= val;
					++nz;
				};

				if (!gd::is_zero(zz))
				{
					for (Integer i = j+1; i < r; ++i)
					{
						val_type_1 tmp  = ptr_A[i];

						if (gd::is_zero(tmp))
						{
							d_r[nz]		= i;
							d_x[nz]		= zz;
							++nz;
						};
					};
				};

                ptr_A += A.ld();
                ptr_B += B.ld();
			};

			if (!gd::is_zero(zz))
			{
				for (Integer j = rc; j < c; ++j)
				{
					d_c[j]			    = nz;

    				if (nz + r > d.nzmax()) 
    				{
						d.memadd( d.nzmax() + r);

						d_r				= d.ptr_r();
						d_x				= d.ptr_x();
    				};
					
					for (Integer i = 0; i < r; ++i)
					{
						val_type_1 tmp  = ptr_A[i];
						if (gd::is_zero(tmp))
						{
							d_r[nz]		= i;
							d_x[nz]		= zz;
							++nz;
						};
					};

                    ptr_A += A.ld();
				};
			}
			else
			{
				for (Integer j = rc; j < c; ++j)
				{
					d_c[j]			    = nz;
				};
			};
			d_c[c] = nz;

			d.memadd(-1);
			return res;
		};

		for (Integer j = 0; j < c; ++j)
		{
    		if (nz + r > d.nzmax()) 
    		{
				d.memadd( d.nzmax() + r);

				d_r				= d.ptr_r();
				d_x				= d.ptr_x();
    		};

			d_c[j]			    = nz;

			Integer first_row = B.first_row(j);
			Integer last_row  = B.last_row(j);
			Integer first_elem= B.first_elem_pos(j);
			
			if (!gd::is_zero(zz))
			{
				for (Integer i = 0; i < first_row && i < r; ++i)
				{
					val_type_1 tmp  = ptr_A[i];
					if (gd::is_zero(tmp))
					{
						d_r[nz]		= i;
						d_x[nz]		= zz;
						++nz;
					};
				};
			};

			for (Integer i = first_row, pos_B = first_elem; i <= last_row; ++i, ++pos_B)
			{
				val_type_2 tmp = ptr_B[pos_B];
				val_type_ret val = ef.eval(ret_ti,ptr_A[i],tmp);
				if (!gd::is_zero(val))
				{
					d_r[nz]		= i;
					d_x[nz]		= val;
					++nz;
				};
			};

			if (!gd::is_zero(zz))
			{
				for (Integer i = last_row+1; i < r; ++i)
				{
					val_type_1 tmp  = ptr_A[i];

					if (gd::is_zero(tmp))
					{
						d_r[nz]		= i;
						d_x[nz]		= zz;
						++nz;
					};
				};
			};

            ptr_A += A.ld();
			ptr_B += B.ld();
		};

		d_c[c] = nz;
		d.memadd(-1);
 
	    return res;
	};
};
//--------------------------------------------------------------------
//				SM - GM
//--------------------------------------------------------------------
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,			
			bool ZN,			
			bool NZ,			
			bool is_inv
			//class str_ret = struct_sparse,
			//class str_1= struct_sparse,
			//class str_2= struct_dense
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,NZ,is_inv,
						struct_sparse,struct_sparse,struct_dense>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		return eval_bin_functor_impl<ret_type,functor,M2,M1,ZZ,NZ,ZN,!is_inv,
										struct_sparse,struct_dense,struct_sparse>
										::eval(B,A,func);
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ,
			bool is_inv
			//class str_ret = struct_dense,
			//class str_1= struct_sparse,
			//class str_2= struct_dense
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,NZ,is_inv,
						struct_dense,struct_sparse,struct_dense>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		return eval_bin_functor_impl<ret_type,functor,M2,M1,ZZ,NZ,ZN,!is_inv,
										struct_dense,struct_dense,struct_sparse>
										::eval(B,A,func);
	};
};

//--------------------------------------------------------------------
//				SM - SM
//--------------------------------------------------------------------
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//1
			//bool ZN,		//0
			//bool NZ,		//0
			bool is_inv
			//class str_ret = struct_sparse,
			//class str_1= struct_sparse,
			//class str_2= struct_sparse
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,true,false,false,is_inv,
						struct_sparse,struct_sparse,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef ret_type::value_type	val_type_ret;
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols());

		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0)
		{
			return ret_type(ret_ti,r, c);
		};
		
		Integer nzret = B.nnz() + A.nnz();

		ret_type res(ret_ti, r, c, nzret);
		if (nzret == 0)
		{
			return res;
		};

		const spdat<val_type_1>&	Ad = A.rep();
		const spdat<val_type_2>&	Bd = B.rep();
		spdat<val_type_ret>&		d  = res.rep();

		Integer* d_c				= d.ptr_c();
		Integer* d_r				= d.ptr_r();
		val_type_ret* d_x			= d.ptr_x();

		Integer nz					= 0;

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

		if (A.nnz() == 0)
		{
			const Integer* Bd_c			= Bd.ptr_c();
			const Integer* Bd_r			= Bd.ptr_r();
			const val_type_2* Bd_x		= Bd.ptr_x();

			for (Integer j = 0; j < c; ++j)
			{
				Integer kb				= Bd_c[j];
				d_c[j]					= nz;

				while (kb < Bd_c[j+1])
				{				
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>(ret_ti,Bd_x[kb]);
					d_r[nz]			= Bd_r[kb]; 
					d_x[nz]			= tmp;				
					++nz; 
					++kb; 
				};
			};
			d_c[c] = nz;
			d.memadd(-1);
			return res;
		};
		if (B.nnz() == 0)
		{
			const Integer* Ad_c			= Ad.ptr_c();
			const Integer* Ad_r			= Ad.ptr_r();
			const val_type_1* Ad_x		= Ad.ptr_x();

			for (Integer j = 0; j < c; ++j)
			{
				Integer ka				= Ad_c[j];
				d_c[j]					= nz;

				while (ka < Ad_c[j+1])
				{				
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,Ad_x[ka]);
					d_r[nz]		= Ad_r[ka]; 
					d_x[nz]		= tmp;
					++nz;
					++ka;
				};
			};
			d_c[c] = nz;
			d.memadd(-1);
			return res;
		};

		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const val_type_1* Ad_x		= Ad.ptr_x();

		const Integer* Bd_c			= Bd.ptr_c();
		const Integer* Bd_r			= Bd.ptr_r();
		const val_type_2* Bd_x		= Bd.ptr_x();
	 	 
		for (Integer j = 0; j < c; ++j)
		{
			Integer ka				= Ad_c[j]; 
			Integer kb				= Bd_c[j];

			d_c[j]					= nz;

			while ((ka < Ad_c[j+1]) && (kb < Bd_c[j+1]))
			{
				if (Ad_r[ka] < Bd_r[kb])
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,Ad_x[ka]);
					d_r[nz]		= Ad_r[ka]; 
					d_x[nz]		= tmp;
					++nz; 
					++ka;
				}
				else if (Ad_r[ka] > Bd_r[kb])
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>(ret_ti,Bd_x[kb]);
					d_r[nz]		= Bd_r[kb]; 
					d_x[nz]		= tmp;
					++nz; 
					++kb; 
				}
				else
				{ 
					val_type_ret tmp = ef.eval(ret_ti,Ad_x[ka],Bd_x[kb]);
					if (!gd::is_zero(tmp))
					{
						d_r[nz]		= Ad_r[ka]; 
						d_x[nz]		= tmp;
						++nz; 
					};
					++ka; 
					++kb;
				};
			};
			while (ka < Ad_c[j+1])
			{
				val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,Ad_x[ka]);
				d_r[nz]		= Ad_r[ka]; 
				d_x[nz]		= tmp;
				++nz;
				++ka;
			};
			while (kb < Bd_c[j+1])
			{				
				val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>(ret_ti,Bd_x[kb]);
				d_r[nz]			= Bd_r[kb]; 
				d_x[nz]			= tmp;				
				++nz; 
				++kb; 
			};
		};

		d_c[c] = nz;
		d.memadd(-1);
		return res;
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//1
			//bool ZN,		//1
			//bool NZ,		//1
			bool is_inv
			//class str_ret = struct_sparse,
			//class str_1= struct_sparse,
			//class str_2= struct_sparse
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,true,true,true,is_inv,
						struct_sparse,struct_sparse,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef ret_type::value_type	val_type_ret;
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols());

		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0)
		{
			return ret_type(ret_ti,r, c);
		};
		
		Integer nzret = std::min(A.nnz(),B.nnz());

		ret_type res(ret_ti, r, c, nzret);
		if (r == 0 || c == 0 || nzret == 0)
		{
			return res;
		};

		const spdat<val_type_1>&	Ad = A.rep();
		const spdat<val_type_2>&	Bd = B.rep();
		spdat<val_type_ret>&		d  = res.rep();

		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const val_type_1* Ad_x		= Ad.ptr_x();


		const Integer* Bd_c			= Bd.ptr_c();
		const Integer* Bd_r			= Bd.ptr_r();
		const val_type_2* Bd_x		= Bd.ptr_x();

		Integer* d_c				= d.ptr_c();
		Integer* d_r				= d.ptr_r();
		val_type_ret* d_x			= d.ptr_x();

		Integer nz					= 0;

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);
	 	 
		for (Integer j = 0; j < c; ++j)
		{
			Integer ka				= Ad_c[j]; 
			Integer kb				= Bd_c[j];

			d_c[j]					= nz;

			while ((ka < Ad_c[j+1]) && (kb < Bd_c[j+1]))
			{
				if (Ad_r[ka] < Bd_r[kb])
				{
					++ka;
				}
				else if (Ad_r[ka] > Bd_r[kb])
				{
					++kb; 
				}
				else
				{ 
					val_type_ret tmp = ef.eval(ret_ti,Ad_x[ka],Bd_x[kb]);
					if (!gd::is_zero(tmp))
					{
						d_r[nz]		= Ad_r[ka]; 
						d_x[nz]		= tmp;
						++nz; 
					};
					++ka; 
					++kb;
				};
			};
		};

		d_c[c] = nz;
		d.memadd(-1);
		return res;
	};
};

template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//0
			bool ZN,		//0,1
			bool NZ,		//0,1
			bool is_inv
			//class str_ret = struct_dense,
			//class str_1= struct_sparse,
			//class str_2= struct_sparse
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,false,ZN,NZ,is_inv,
							struct_dense,struct_sparse,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef ret_type::value_type	val_type_ret;
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols());

		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0)
		{
			return ret_type(ret_ti,r, c);
		};
		
        val_type_1 zero1    		= gd::default_value<val_type_1>(A.get_ti());
        val_type_2 zero2    		= gd::default_value<val_type_2>(B.get_ti());

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

		val_type_ret zz				= ef.eval(ret_ti,zero1,zero2);

		ret_type res(ret_ti,zz,r,c);

		if (A.nnz() == 0 && B.nnz() == 0)
		{
            if (zz == gd::default_value<val_type_ret>(ret_ti))
            {
                res.get_struct().set_zero_matrix();
            };
			return res;
		};

		const spdat<val_type_1>& Ad = A.rep();
		const spdat<val_type_2>& Bd = B.rep();

        val_type_ret* ptr_res = res.ptr();

		if (A.nnz() == 0)
		{
			const Integer* Bd_c			= Bd.ptr_c();
			const Integer* Bd_r			= Bd.ptr_r();
			const val_type_2* Bd_x		= Bd.ptr_x();

			for (Integer j = 0; j < c; ++j)
			{ 
				Integer kb				= Bd_c[j];

				while (kb < Bd_c[j+1])
				{
					val_type_ret tmp    = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                        (ret_ti,Bd_x[kb]);
					ptr_res[Bd_r[kb]]   = tmp;
					++kb; 
				};

                ptr_res += res.ld();
			};
			return res;
		};

		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const val_type_1* Ad_x		= Ad.ptr_x();

		if (B.nnz() == 0)
		{
			for (Integer j = 0; j < c; ++j)
			{
				Integer ka			= Ad_c[j]; 

				while (ka < Ad_c[j+1])
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                        (ret_ti,Ad_x[ka]);
					ptr_res[Ad_r[ka]] = tmp;
					++ka; 
				};

                ptr_res += res.ld();
			};

			return res;
		};

		const Integer* Bd_c			= Bd.ptr_c();
		const Integer* Bd_r			= Bd.ptr_r();
		const val_type_2* Bd_x		= Bd.ptr_x();
	 	 
		for (Integer j = 0; j < c; ++j)
		{
			Integer ka				= Ad_c[j]; 
			Integer kb				= Bd_c[j];

			while (ka < Ad_c[j+1] && kb < Bd_c[j+1])
			{
				if (Ad_r[ka] < Bd_r[kb])
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                        (ret_ti,Ad_x[ka]);
					ptr_res[Ad_r[ka]] = tmp;
					++ka; 
				}
				else if (Ad_r[ka] > Bd_r[kb])
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                        (ret_ti,Bd_x[kb]);
					ptr_res[Bd_r[kb]] = tmp;
					++kb; 
				}
				else
				{ 
					val_type_ret tmp = ef.eval(ret_ti,Ad_x[ka],Bd_x[kb]);
					ptr_res[Bd_r[kb]] = tmp;
					++ka; 
					++kb;
				};
			};
			while (ka < Ad_c[j+1])
			{
				val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,Ad_x[ka]);
				ptr_res[Ad_r[ka]] = tmp;
				++ka; 
			};
			while (kb < Bd_c[j+1])
			{
				val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>(ret_ti,Bd_x[kb]);
				ptr_res[Bd_r[kb]] = tmp;
				++kb; 
			};

            ptr_res += res.ld();
		};

		return res;
	};
};
//--------------------------------------------------------------------
//				SM - B
//--------------------------------------------------------------------
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//1
			//bool ZN,		//1
			//bool NZ,		//1
			bool is_inv
			//class str_ret = struct_banded,
			//class str_1= struct_sparse,
			//class str_2= struct_banded
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,true,true,true,is_inv,
						struct_banded,struct_sparse,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef ret_type::value_type	val_type_ret;
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols());

		Integer r = A.rows(), c = A.cols();

        val_type_ret zero_r = gd::default_value<val_type_ret>(ret_ti);

		if (r == 0 || c == 0)
		{
			ret_type out(ret_ti,r, c, 0, 0);
            return out;
		};
		if (A.nnz() == 0)
		{
			ret_type res(ret_ti,r,c, 0, 0);

            val_type_ret* ptr_res = res.rep_ptr();

            Integer res_size = res.size();
			for(Integer i = 0; i < res_size; ++i)
			{
				ptr_res[i] = zero_r;
			};

			return res;
		};
		
		ret_type res(ret_ti,r,c, B.ldiags(), B.udiags());

		const spdat<val_type_1>& Ad = A.rep();

		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const val_type_1* Ad_x		= Ad.ptr_x();

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

        val_type_ret* ptr_res       = res.rep_ptr();
        const val_type_2* ptr_B     = B.rep_ptr();

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			Integer rc = std::min(r,c);
			for (Integer j = 0, pos_B = 0; j < rc; ++j, ++pos_B)
			{
				Integer ka;
				bool exist = Ad.isentry(j,j,ka);

				if (!exist)
				{
					ptr_res[pos_B] = zero_r;
				}
				else
				{
					ptr_res[pos_B] = ef.eval(ret_ti,Ad_x[ka],ptr_B[0]);
				};

                ptr_B += B.ld();
			};
		}
		else
		{
			for (Integer j = 0; j < c; ++j, ptr_B += B.ld(), ptr_res += res.ld())
			{
				Integer first_row		= B.first_row(j);
				Integer last_row		= B.last_row(j);
				Integer pos_B			= B.first_elem_pos(j);
				Integer kb				= first_row;

				if (first_row >= r)
				{
					continue;
				};

				Integer ka;
				Ad.isentry(kb,j,ka);

				if (ka == Ad_c[j+1] || Ad_r[ka] > last_row)
				{
					for (Integer i = first_row; i <= last_row; ++i, ++pos_B)
					{
						ptr_res[pos_B] = zero_r;
					};
					continue;
				};
				while ((ka < Ad_c[j+1]) && (kb <= last_row))
				{
					if (Ad_r[ka] > kb)
					{
						val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                    (ret_ti,ptr_B[pos_B]);
						ptr_res[pos_B] = tmp;
						++kb; 
						++pos_B;
					}
					else
					{ 
						val_type_ret tmp = ef.eval(ret_ti,Ad_x[ka],ptr_B[pos_B]);
						ptr_res[pos_B] = tmp;
						++ka; 
						++kb;
						++pos_B;
					};
				};
				while (kb <= last_row)
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                    (ret_ti,ptr_B[pos_B]);
					ptr_res[pos_B] = tmp;
					++kb; 
					++pos_B;
				};
			};
		};

		return res;
	};
};

template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//1
			//bool ZN,		//0
			//bool NZ,		//0
			bool is_inv
			//class str_ret = struct_sparse,
			//class str_1= struct_sparse,
			//class str_2= struct_banded
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,true,false,false,is_inv,
						struct_sparse,struct_sparse,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef ret_type::value_type	val_type_ret;
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols());

		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0)
		{
			return ret_type(ret_ti,r, c);
		};
		
		Integer nnze = A.nnz() + B.nnz();

		ret_type res(ret_ti,r,c, nnze);
		if (r == 0 || c == 0 || nnze == 0)
		{
			return res;
		};

		const spdat<val_type_1>& Ad = A.rep();

		spdat<val_type_ret>& d		= res.rep();

		Integer* d_c				= d.ptr_c();
		Integer* d_r				= d.ptr_r();
		val_type_ret* d_x			= d.ptr_x();

		Integer nz = 0;

        const val_type_2* ptr_B     = B.rep_ptr();

		if (A.nnz() == 0)
		{
			if (B.ldiags() == 0 && B.udiags() == 0)
			{
				Integer rc = std::min(r,c);
				for (Integer j = 0; j < rc; ++j)
				{
					d_c[j]					= nz;

					val_type_2 val2			= ptr_B[0];
					if (!gd::is_zero(val2))
					{
						val_type_ret tmp    = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                            (ret_ti,val2);
						d_r[nz]				= j;
						d_x[nz]				= tmp;
						++nz;
					};
                    ptr_B += B.ld();
				};
				for (Integer j = rc; j < c; ++j)
				{
					d_c[j]					= nz;
				};

				d_c[c] = nz;
				d.memadd(-1);
			}
			else
			{
				for (Integer j = 0; j < c; ++j)
				{					
					Integer first_row		= B.first_row(j);
					Integer last_row		= std::min(B.last_row(j),r-1);
					Integer kb				= first_row;
					Integer pos_B			= B.first_elem_pos(j);

					d_c[j]					= nz;

					while (kb <= last_row)
					{
						val_type_2 val2     = ptr_B[pos_B];
						if (!gd::is_zero(val2))
						{
							val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                            (ret_ti,val2);

							d_r[nz]		= kb;
							d_x[nz]		= tmp;
							++nz;
						};
						++kb; 
						++pos_B;
					};

					ptr_B += B.ld();
				};

				d_c[c] = nz;
				d.memadd(-1);
			};

			return res;
		};

		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const val_type_1* Ad_x		= Ad.ptr_x();

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			Integer rc = std::min(r,c);
			for (Integer j = 0; j < rc; ++j, ptr_B += B.ld())
			{
				Integer ka				= Ad_c[j]; 
				d_c[j]					= nz;

				while (ka < Ad_c[j+1] && Ad_r[ka] < j)
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,Ad_x[ka]);
					d_r[nz]				= Ad_r[ka];
					d_x[nz]				= tmp;
					++nz;
					++ka; 
				};
				if (ka < Ad_c[j+1] && Ad_r[ka] == j)
				{
					val_type_ret tmp = ef.eval(ret_ti,Ad_x[ka],ptr_B[0]);
					if (!gd::is_zero(tmp))
					{
						d_r[nz]		= j;
						d_x[nz]		= tmp;
						++nz;
					};
					++ka; 
				}
				else
				{
					val_type_2 val2 = ptr_B[0];
					if (!gd::is_zero(val2))
					{
						val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                        (ret_ti,val2);

						d_r[nz]		= j;
						d_x[nz]		= tmp;
						++nz;
					};
				};
				while (ka < Ad_c[j+1])
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,Ad_x[ka]);
					d_r[nz]				= Ad_r[ka];
					d_x[nz]				= tmp;
					++nz;
					++ka; 
				};
			};
			for (Integer j = rc; j < c; ++j)
			{
				d_c[j]					= nz;

				for (Integer ka = Ad_c[j]; ka < Ad_c[j+1]; ++ka)
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,Ad_x[ka]);
					d_r[nz]				= Ad_r[ka];
					d_x[nz]				= tmp;
					++nz;
				};
			};

			d_c[c] = nz;

			d.memadd(-1);
		}
		else
		{
			for (Integer j = 0; j < c; ++j)
			{
				Integer ka				= Ad_c[j]; 
				Integer first_row		= B.first_row(j);
				Integer last_row		= std::min(B.last_row(j),r-1);
				Integer kb				= first_row;
				Integer pos_B			= B.first_elem_pos(j);

				d_c[j]					= nz;

				while ((ka < Ad_c[j+1]) && (kb <= last_row))
				{
					if (Ad_r[ka] < kb)
					{
						val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,Ad_x[ka]);
						d_r[nz]			= Ad_r[ka];
						d_x[nz]			= tmp;
						++nz;
						++ka; 
					}
					else if (Ad_r[ka] > kb)
					{
						val_type_2 val2 = ptr_B[pos_B];
						if (!gd::is_zero(val2))
						{
							val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                            (ret_ti,val2);

							d_r[nz]		= kb;
							d_x[nz]		= tmp;
							++nz;
						};
						++kb; 
						++pos_B;
					}
					else
					{ 
						val_type_ret tmp = ef.eval(ret_ti,Ad_x[ka],ptr_B[pos_B]);
						if (!gd::is_zero(tmp))
						{
							d_r[nz]		= kb;
							d_x[nz]		= tmp;
							++nz;
						};
						++ka; 
						++kb;
						++pos_B;
					};
				};
				while (ka < Ad_c[j+1])
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>(ret_ti,Ad_x[ka]);
					d_r[nz]				= Ad_r[ka];
					d_x[nz]				= tmp;
					++nz;
					++ka; 
				};
				while (kb <= last_row)
				{
					val_type_2 val2 = ptr_B[pos_B];
					if (!gd::is_zero(val2))
					{
						val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                        (ret_ti,val2);

						d_r[nz]		= kb;
						d_x[nz]		= tmp;
						++nz;
					};
					++kb; 
					++pos_B;
				};

				ptr_B += B.ld();
			};

			d_c[c] = nz;

			d.memadd(-1);
		};

		return res;
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//0
			bool ZN,		//0,1
			bool NZ,		//0,1
			bool is_inv
			//class str_ret = struct_dense,
			//class str_1= struct_sparse,
			//class str_2= struct_banded
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,false,ZN,NZ,is_inv,
						struct_dense,struct_sparse,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef ret_type::value_type	val_type_ret;
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols());

		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0)
		{
			return ret_type(ret_ti,r, c);
		};
		
        val_type_1 zero1			= gd::default_value<val_type_1>(gd::get_ti(A));
		val_type_2 zero2			= gd::default_value<val_type_2>(gd::get_ti(B));

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

		val_type_ret zz				= ef.eval(ret_ti,zero1,zero2);

		ret_type res(ret_ti,zz,r,c);

		const spdat<val_type_1>& Ad = A.rep();

        const val_type_2* ptr_B     = B.rep_ptr();
        val_type_ret* ptr_res       = res.ptr();

		if (A.nnz() == 0)
		{
			if (B.ldiags() == 0 && B.udiags() == 0)
			{
				Integer rc = std::min(r,c);
				for (Integer j = 0; j < rc; ++j)
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                    (ret_ti,ptr_B[0]);
					ptr_res[j]  = tmp;
                    ptr_res     += res.ld();
                    ptr_B       += B.ld();
				};                
			}
			else
			{
				for (Integer j = 0; j < c; ++j)
				{
					Integer first_row		= B.first_row(j);
					Integer last_row		= B.last_row(j);
					Integer kb				= first_row;
					Integer pos_B			= B.first_elem_pos(j);

					while (kb <= last_row)
					{
						val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                        (ret_ti,ptr_B[pos_B]);
						ptr_res[kb] = tmp;
						++kb; 
						++pos_B;
					};
					ptr_B += B.ld();
                    ptr_res += res.ld();
				};
			};
			return res;
		};

		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const val_type_1* Ad_x		= Ad.ptr_x();
	 	 
		if (B.ldiags() == 0 && B.udiags() == 0)
		{
			Integer rc = std::min(r,c);
			for (Integer j = 0; j < c; ++j)
			{
				Integer ka				= Ad_c[j]; 

				while (ka < Ad_c[j+1] && Ad_r[ka] < j)
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                                        (ret_ti,Ad_x[ka]);
					ptr_res[Ad_r[ka]] = tmp;
					++ka; 
				};
				if (j < rc && ka < Ad_c[j+1] && Ad_r[ka] == j)
				{
					val_type_ret tmp = ef.eval(ret_ti,Ad_x[ka],ptr_B[0]);
					ptr_res[j] = tmp;
					++ka; 
				}
				else if (j < rc)
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                    (ret_ti,ptr_B[0]);
					ptr_res[j] = tmp;
				};
				while (ka < Ad_c[j+1])
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                                    (ret_ti,Ad_x[ka]);
					ptr_res[Ad_r[ka]] = tmp;
					++ka; 
				};

                ptr_res += res.ld();
                ptr_B += B.ld();
			};
		}
		else
		{
			for (Integer j = 0; j < c; ++j)
			{
				Integer ka				= Ad_c[j]; 
				Integer first_row		= B.first_row(j);
				Integer last_row		= B.last_row(j);
				Integer kb				= first_row;
				Integer pos_B			= B.first_elem_pos(j);

				if (first_row >= r)
				{
					while (ka < Ad_c[j+1])
					{
						val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                                        (ret_ti,Ad_x[ka]);
						ptr_res[Ad_r[ka]] = tmp;
						++ka; 
					};
					ptr_B += B.ld();
                    ptr_res += res.ld();
					continue;
				};

				while ((ka < Ad_c[j+1]) && (kb <= last_row))
				{
					if (Ad_r[ka] < kb)
					{
						val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                                        (ret_ti,Ad_x[ka]);
						ptr_res[Ad_r[ka]] = tmp;
						++ka; 
					}
					else if (Ad_r[ka] > kb)
					{
						val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                        (ret_ti,ptr_B[pos_B]);
						ptr_res[kb] = tmp;
						++kb; 
						++pos_B;
					}
					else
					{ 
						val_type_ret tmp = ef.eval(ret_ti,Ad_x[ka],ptr_B[pos_B]);
						ptr_res[kb] = tmp;
						++ka; 
						++kb;
						++pos_B;
					};
				};
				while (ka < Ad_c[j+1])
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                                        (ret_ti,Ad_x[ka]);
					ptr_res[Ad_r[ka]] = tmp;
					++ka; 
				};
				while (kb <= last_row)
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                        (ret_ti,ptr_B[pos_B]);
					ptr_res[kb] = tmp;
					++kb; 
					++pos_B;
				};


				ptr_B += B.ld();
                ptr_res += res.ld();
			};
		};

		return res;
	};
};

//--------------------------------------------------------------------
//				B - GM
//--------------------------------------------------------------------
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ,
			bool is_inv
			//class str_ret = struct_banded,
			//class str_1= struct_banded,
			//class str_2= struct_dense
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,NZ,is_inv,
						struct_banded,struct_banded,struct_dense>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		return eval_bin_functor_impl<ret_type,functor,M2,M1,ZZ,NZ,ZN,!is_inv,
										struct_banded,struct_dense,struct_banded>
										::eval(B,A,func);
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ,
			bool is_inv
			//class str_ret = struct_dense,
			//class str_1= struct_banded,
			//class str_2= struct_dense
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,NZ,is_inv,
						struct_dense,struct_banded,struct_dense>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		return eval_bin_functor_impl<ret_type,functor,M2,M1,ZZ,NZ,ZN,!is_inv,
										struct_dense,struct_dense,struct_banded>
										::eval(B,A,func);
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ,
			bool is_inv
			//class str_ret = struct_sparse,
			//class str_1= struct_banded,
			//class str_2= struct_dense
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,NZ,is_inv,
							struct_sparse,struct_banded,struct_dense>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		return eval_bin_functor_impl<ret_type,functor,M2,M1,ZZ,NZ,ZN,!is_inv,
										struct_sparse,struct_dense,struct_banded>
										::eval(B,A,func);
	};
};

//--------------------------------------------------------------------
//				B - SM
//--------------------------------------------------------------------
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ,
			bool is_inv
			//class str_ret = struct_banded,
			//class str_1= struct_banded,
			//class str_2= struct_sparse
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,NZ,is_inv,
							struct_banded,struct_banded,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		return eval_bin_functor_impl<ret_type,functor,M2,M1,ZZ,NZ,ZN,!is_inv,
										struct_banded,struct_sparse,struct_banded>
										::eval(B,A,func);
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ,
			bool is_inv
			//class str_ret = struct_dense,
			//class str_1= struct_banded,
			//class str_2= struct_sparse
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,NZ,is_inv,
							struct_dense,struct_banded,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		return eval_bin_functor_impl<ret_type,functor,M2,M1,ZZ,NZ,ZN,!is_inv,
										struct_dense,struct_sparse,struct_banded>
										::eval(B,A,func);
	};
};
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			bool ZZ,
			bool ZN,
			bool NZ,
			bool is_inv
			//class str_ret = struct_sparse,
			//class str_1= struct_banded,
			//class str_2= struct_sparse
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,ZZ,ZN,NZ,is_inv,
							struct_sparse,struct_banded,struct_sparse>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		return eval_bin_functor_impl<ret_type,functor,M2,M1,ZZ,NZ,ZN,!is_inv,
										struct_sparse,struct_sparse,struct_banded>
										::eval(B,A,func);
	};
};

//--------------------------------------------------------------------
//				B - B
//--------------------------------------------------------------------
template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//0
			bool ZN,		//0,1
			bool NZ,		//0,1
			bool is_inv
			//class str_ret = struct_dense,
			//class str_1= struct_banded,
			//class str_2= struct_banded
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,false,ZN,NZ,is_inv,
							struct_dense,struct_banded,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef ret_type::value_type	val_type_ret;
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		error::check_eeop(A.rows(), A.cols(), B.rows(), B.cols());

		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0)
		{
			return ret_type(ret_ti,r, c);
		};
		
        val_type_1 zero1			= gd::default_value<val_type_1>(gd::get_ti(A));
		val_type_2 zero2			= gd::default_value<val_type_2>(gd::get_ti(B));

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

		val_type_ret zz				= ef.eval(ret_ti,zero1,zero2);

		ret_type res(ret_ti,zz,r,c);

        const val_type_1* ptr_A     = A.rep_ptr();
        const val_type_2* ptr_B     = B.rep_ptr();
        val_type_ret* ptr_res       = res.ptr();

		if (A.ldiags() == 0 && B.ldiags() == 0 && A.udiags() == 0 && B.udiags() == 0)
		{
			Integer rc = std::min(r,c);
			for (Integer i = 0; i < rc; ++i)
			{
				ptr_res[i]  = ef.eval(ret_ti,ptr_A[0],ptr_B[0]);

                ptr_A       += A.ld();
                ptr_B       += B.ld();
                ptr_res     += res.ld();
			};
			return res;
		};
	 	 
		for (Integer j = 0; j < c; ++j)
		{
			Integer fr1				= A.first_row(j);
			Integer fr2				= B.first_row(j);
			Integer lr1				= std::min(A.last_row(j),r-1);
			Integer lr2				= std::min(B.last_row(j),r-1);
			Integer pa				= A.first_elem_pos(j);
			Integer pb				= B.first_elem_pos(j);

			Integer ka				= fr1;
			Integer kb				= fr2;
			Integer pos_ret			= std::min(ka,kb);

			while ((ka <= lr1) && (kb <= lr2))
			{
				if (ka < kb)
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                                    (ret_ti,ptr_A[pa]);
					ptr_res[pos_ret] = tmp;
					++pos_ret;
					++ka; 
					++pa;
				}
				else if (ka > kb)
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                    (ret_ti,ptr_B[pb]);
					ptr_res[pos_ret] = tmp;
					++pos_ret;
					++kb; 
					++pb;
				}
				else
				{ 
					val_type_ret tmp = ef.eval(ret_ti,ptr_A[pa],ptr_B[pb]);
					ptr_res[pos_ret] = tmp;
					++ka; 
					++kb;
					++pa;
					++pb;
					++pos_ret;
				};
			};
			while (ka <= lr1)
			{
				val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                                (ret_ti,ptr_A[pa]);
				ptr_res[pos_ret] = tmp;
				++ka; 
				++pa;
				++pos_ret;
			};
			while (kb <= lr2)
			{
				val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                (ret_ti,ptr_B[pb]);
				ptr_res[pos_ret] = tmp;
				++kb; 
				++pb;
				++pos_ret;
			};

            ptr_A += A.ld();
            ptr_B += B.ld();
            ptr_res += res.ld();
		};

		return res;
	};
};

template<	class ret_type, 
			class functor,
			class M1, 
			class M2,
			//bool ZZ,		//1
			bool ZN,		//0,1
			bool NZ,		//0,1
			bool is_inv
			//class str_ret = struct_banded,
			//class str_1= struct_banded,
			//class str_2= struct_banded
		>
struct eval_bin_functor_impl<ret_type,functor,M1,M2,true,ZN,NZ,is_inv,
						struct_banded,struct_banded,struct_banded>
{
	static ret_type eval(const M1& A, const M2& B, const functor& func)
	{
		typedef ret_type::value_type	val_type_ret;
		typedef M1::value_type			val_type_1;
		typedef M2::value_type			val_type_2;
		static const bool zero_on_right = !is_inv;

        gd::type_info ret_ti 
            = gd::return_func_ti<functor,M1,M2>::eval(A,B);

		Integer r = A.rows(), c = A.cols();
		Integer ua = A.udiags(), la = A.ldiags(), ub = B.udiags(), lb = B.ldiags();
 
		error::check_eeop(r, c, B.rows(), B.cols());
	 
		Integer kl = (la > lb) ? la : lb;
		Integer ku = (ua > ub) ? ua : ub;

		if (ZN == true)
		{
			kl		= std::min(kl,la);
			ku		= std::min(ku,ua);
		};
		if (NZ == true)
		{
			kl		= std::min(kl,lb);
			ku		= std::min(ku,ub);
		};

		Integer lu = kl + ku;
		ret_type res(ret_ti,r, c, kl, ku);

		typedef eval_F<functor,is_inv,val_type_ret,val_type_1,val_type_2> eval_func;
		eval_func ef(func);

        const val_type_1* ptr_A = A.rep_ptr();
        const val_type_2* ptr_B = B.rep_ptr();
        val_type_ret* ptr_res   = res.rep_ptr();

		if (la == 0 && lb == 0 && ua == 0 && ub == 0)
		{
			Integer rc = std::min(r,c);
			for (Integer i = 0; i < rc; ++i)
			{
				ptr_res[i] = ef.eval(ret_ti,ptr_A[0], ptr_B[0]);
                ptr_A += A.ld();
                ptr_B += B.ld();
			};
			return res;
		};

		// subdiagonals
		for (Integer d = 1, ist = ku + 1, jsta = ua + 1, jstb = ub + 1; d <= kl; ++d, ++ist)
		{
			Integer s = (r - d < c) ? r - d : c;
			if ( (d <= la) && (d <= lb) )
			{
				for (Integer i = 1, ii = ist, jja = jsta, jjb = jstb;
					 i <= s; ++i, ii += res.ld(), jja += A.ld(), jjb += B.ld())
				{
					val_type_ret tmp = ef.eval(ret_ti,ptr_A[jja], ptr_B[jjb]);
					ptr_res[ii] = tmp;
				};
				++jsta; 
                ++jstb;
			}
			else if (d <= la)
			{
				for (Integer i = 1, ii = ist, jja = jsta; i <= s; ++i, ii += res.ld(), jja += A.ld())
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                                    (ret_ti,ptr_A[jja]);

					ptr_res[ii] = tmp;
				};
				++jsta;
			}
			else
			{
				for (Integer i = 1, ii = ist, jjb = jstb; i <= s; ++i, ii += res.ld(), jjb += B.ld())
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                    (ret_ti,ptr_B[jjb]);
					ptr_res[ii] = tmp;
				};
				++jstb;
			};
		};

		// main & superdiagonals
		for (Integer d = 0, ist = ku, jsta = ua, jstb = ub; d <= ku; ++d, ist += lu)
		{
			Integer s = (c - d < r) ? c - d : r;
			if ( d <= ua && d <= ub )
			{
				for (Integer i = 1, ii = ist, jja = jsta, jjb = jstb;
					 i <= s; ++i, ii += res.ld(), jja += A.ld(), jjb += B.ld())
				{
					val_type_ret tmp = ef.eval(ret_ti,ptr_A[jja], ptr_B[jjb]);
					ptr_res[ii] = tmp;
				};
				jsta += A.ld() - 1; 
                jstb += B.ld() - 1;
			}
			else if (d <= ua)
			{
				for (Integer i = 1, ii = ist, jja = jsta; i <= s; ++i, ii += res.ld(), jja += A.ld())
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_1,zero_on_right>
                                                    (ret_ti,ptr_A[jja]);
					ptr_res[ii] = tmp;
				};
				jsta += A.ld() - 1;
			}
			else
			{
				for (Integer i = 1, ii = ist, jjb = jstb; i <= s; ++i, ii += res.ld(), jjb += B.ld())
				{
					val_type_ret tmp = func.eval_zero<val_type_ret,val_type_2,!zero_on_right>
                                                    (ret_ti,ptr_B[jjb]);
					ptr_res[ii] = tmp;
				};
				jstb += B.ld() - 1;
			};
		};
	 
		return res;
	};
};

};};};

#pragma warning( pop )