/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/mvgen.h"
#include "mmlib/func/raw/scalfunc.h"
#include "mmlib/constants.h"
#include "mmlib/extern/rnd.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/utils/utils.h"

namespace mmlib { namespace raw
{

template<class V> V one_helper(gd::type_info )           { return V(1); };
template<> Object   one_helper<Object>(gd::type_info ti) { return Object(ti,Integer(1)); };

namespace gd = mmlib::details;

IntegerMatrix rangei(Integer s, Integer i, Integer e)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    if ((i == 0) || ((e - s) / i < 0))
    {
        return IntegerMatrix(ret_ti,1,0);
    };

    Integer j, n = (e - s) / i + 1, jj;

    IntegerMatrix res(ret_ti,1,n);
	Integer * ptr = res.ptr();
    for (j = 0, jj = s; j < n; ++j, jj += i)
	{
        *(ptr++) = jj;
	};

    return res;
}
RealMatrix range(Real s, Real i, Real e)
{
    gd::type_info ret_ti = gd::get_raw_ti();
    if (i == 0 || (e-s)*i < 0)
    {
        return RealMatrix(ret_ti,1,0);
    };

    Real en = s + std::floor((e - s) / i) * i;
    Integer ii, n = icast(round(1. + (en - s) / i)); 

    RealMatrix res(ret_ti,1,n);

	Real * ptr = res.ptr();
    for (ii = 0; ii < n; ++ii)
	{
		*(ptr++) = s + i * Real(ii);
	};

    return res;
}


RealMatrix linspace(Real s, Real e, Integer n)
{
    gd::type_info ret_ti = gd::get_raw_ti();
    if (n <= 1)
    {
        return RealMatrix(ret_ti,e,1, 1);
    };

    Integer i;
    RealMatrix res(ret_ti,1,n);

	Real * ptr  = res.ptr();
    for (i = 1; i <= n; ++i)
	{
        *(ptr++) = s + (e - s) * Real(i-1)/Real(n - 1);
	};

    return res;
}


RealMatrix logspace(Real s, Real e, Integer n)
{
    gd::type_info ret_ti = gd::get_raw_ti();
    if (n <= 1)
    {
		return (e == constants::pi) ? RealMatrix(ret_ti,constants::pi,1, 1) :
                             RealMatrix(ret_ti,pow(10., e),1, 1);
    };

    Integer i;
    RealMatrix res(ret_ti,1,n);

	if (e == constants::pi) e = constants::log10pi;

	Real * ptr = res.ptr();
    for (i = 1; i <= n; ++i)
	{
        *(ptr++) = pow(10., s + (e - s) * Real(i-1)/Real(n - 1));
	};

    return res;
}


IntegerMatrix randperm(Integer N)
{
	error::check_randperm_arg(N);

    gd::type_info ret_ti = gd::get_raw_ti();

    if (N == 0)
    {
        return IntegerMatrix(ret_ti,1,0);
    };

    IntegerMatrix res = rangei(1, N);
    Integer* ptr_res = res.ptr();

    for (Integer i = 0, k = N; i < N; ++i, --k)
    {
        Integer sw = ptr_res[i];
        Integer j = i + icast(k * mmlib::details::genrand_real2());
        ptr_res[i] = ptr_res[j];
        ptr_res[j] = sw;
    }

    return res;
}

RealMatrix eye(Integer r, Integer c)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    RealMatrix res(ret_ti,0.0, r, c);

    Integer i, n = (r < c) ? r : c, rp1 = r + 1;

	if ( n == 0)
	{
		return res;
	};

	Real * ptr = res.ptr();
    for (i = 0; i < n; ++i)
	{
		*ptr = 1.;
		ptr += rp1;
	};

    if (r == c)
    {
        res.get_struct().set_id_matrix();
    }
    else
    {
        res.get_struct().set_diag_matrix();
    };
    return res;
}
IntegerMatrix eyei(Integer r, Integer c)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    IntegerMatrix res(ret_ti,Integer(), r, c);

    Integer i, n = (r < c) ? r : c, rp1 = r + 1;

	if ( n == 0)
	{
		return res;
	};

	Integer * ptr = res.ptr();

    for (i = 0; i < n; ++i)
	{
		*ptr = 1;
		ptr += rp1;
	};

    if (r == c)
    {
        res.get_struct().set_id_matrix();
    }
    else
    {
        res.get_struct().set_diag_matrix();
    };
    return res;
}
ComplexMatrix eyec(Integer r, Integer c)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    ComplexMatrix res(ret_ti, 0.0, r, c);

    Integer n = (r < c) ? r : c, rp1 = r + 1;

	if ( n == 0)
	{
		return res;
	};

	Complex * ptr = res.ptr();

    for (Integer i = 0; i < n; ++i)
	{
		*ptr = 1.;
		ptr += rp1;
	};

    if (r == c)
    {
        res.get_struct().set_id_matrix();
    }
    else
    {
        res.get_struct().set_diag_matrix();
    };
    return res;
}
ObjectMatrix eye(gd::type_info ti,Integer r, Integer c)
{
    gd::type_info ret_ti = ti;

    ObjectMatrix res(ret_ti,gd::default_value<Object>(ti), r, c);

    Integer i, n = (r < c) ? r : c, rp1 = r + 1;

	if ( n == 0)
	{
		return res;
	};

	Object * ptr = res.ptr();
    for (i = 0; i < n; ++i)
	{
		*ptr = Object(ti,1L);
		ptr += rp1;
	};

    if (r == c)
    {
        res.get_struct().set_id_matrix();
    }
    else
    {
        res.get_struct().set_diag_matrix();
    };
    return res;
}

Real rand()
{
    return mmlib::details::genrand_real1();
}


RealMatrix rand(Integer r, Integer c)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    RealMatrix res(ret_ti,r, c);

    Integer n = res.size();

	if (n == 0)
	{
		return res;
	};
	Real * ptr = res.ptr();
    for (Integer i = 0; i < n; ++i)
	{
		*(ptr++) = mmlib::details::genrand_real1();
	};

    return res;
}
IntegerMatrix randi(Integer r, Integer c)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    IntegerMatrix res(ret_ti,r, c);

    Integer i, n = res.size();

	if (n == 0)
	{
		return res;
	};
	Integer * ptr = res.ptr();
    for (i = 0; i < n; ++i)
	{
        *(ptr++) = mmlib::details::genrand_int32();
	};

    return res;
}
ComplexMatrix randc(Integer r, Integer c)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    ComplexMatrix res(ret_ti,r, c);

    Integer i, n = res.size();

	if (n == 0)
	{
		return res;
	};

	Complex * ptr = res.ptr();
    for (i = 0; i < n; ++i)
	{
        *(ptr++) = Complex(mmlib::details::genrand_real1(),mmlib::details::genrand_real1());
	};

    return res;
};

Real randn()
{
    return mmlib::details::gen_norm();
}


RealMatrix randn(Integer r, Integer c)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    RealMatrix res(ret_ti,r, c);

    Integer i, n = res.size();

	if (n == 0)
	{
		return res;
	};

	Real * ptr = res.ptr();
    for (i = 0; i < n; ++i)
	{
        *(ptr++) = mmlib::details::gen_norm();
	};

    return res;
}

ComplexMatrix randnc(Integer r, Integer c)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    ComplexMatrix res(ret_ti,r, c);

    Integer i, n = res.size();

	if (n==0)
	{
		return res;
	};

	Complex * ptr = res.ptr();
    for (i = 0; i < n; ++i)
	{
        *(ptr++) = Complex(mmlib::details::gen_norm(),mmlib::details::gen_norm());
	};

    return res;
}

template<class ret_type, class in_type>
struct diag_helper
{
    static ret_type eval(gd::type_info ret_ti, const in_type& v0, Integer d)
	{ 
        typedef typename in_type::value_type value_type_in;
		typedef typename ret_type::value_type value_type_ret;

        in_type v = v0.make_explicit();

        value_type_ret Z = gd::default_value<value_type_ret>(ret_ti);

		Integer n = v.size();
		error::check_diag_arg(v.rows(), v.cols());

		if (n == 0) 
        {
            return ret_type(ret_ti);
        };

        Integer r, c, st;
	    if (d >= 0)
		{
			r = n + d, c = n + d, st = imult(d,r);
		}
		else
		{
			r = n - d, c = n - d, st = - d;
		};
 
		ret_type res(ret_ti, Z, r, c);

		if (n==0)
		{
			return res;
		};

		value_type_ret* ptr = res.ptr() + st;
        const value_type_in* ptr_v = v.ptr();
        Integer ldv = (v.rows() == 1)? v.ld() : 1;

	    for (Integer i = 0; i < n; ++i)
		{
			*ptr = ptr_v[0];
			ptr += res.ld() + 1;
            ptr_v += ldv;
		};
 
        if (d == 0)     res.get_struct().set_diag_matrix();
        else if (d > 0) res.get_struct().set_triu_matrix();
        else            res.get_struct().set_tril_matrix();

	    return res;
	};
};

IntegerMatrix diag(const IntegerMatrix &v, Integer d)
{
    gd::type_info ret_ti = gd::get_raw_ti();
	return diag_helper<IntegerMatrix,IntegerMatrix>::eval(ret_ti,v,d);
};
RealMatrix diag(const RealMatrix &v, Integer d)
{
    gd::type_info ret_ti = gd::get_raw_ti();
	return diag_helper<RealMatrix,RealMatrix>::eval(ret_ti,v,d);
}
ComplexMatrix diag(const ComplexMatrix &v, Integer d)
{
    gd::type_info ret_ti = gd::get_raw_ti();
	return diag_helper<ComplexMatrix,ComplexMatrix>::eval(ret_ti,v,d);
}
ObjectMatrix diag(const ObjectMatrix &v, Integer d)
{
    gd::type_info ret_ti = v.get_ti();
	return diag_helper<ObjectMatrix,ObjectMatrix>::eval(ret_ti,v,d);
};

template<class V>
struct bdiag_helper
{
    typedef raw::Matrix<V,struct_dense>     DM;
    typedef raw::Matrix<V,struct_banded>    BM;

    static BM eval(const DM& v0, Integer d)
    {
        DM v = v0.make_explicit();
        gd::type_info ret_ti = v.get_ti();        

        error::check_bspdiag_1starg(v.rows(), v.cols());

        Integer dl = v.size();

		if (dl == 0) 
        {
            return BM(ret_ti,0,0,0,0);
        };

        Integer n, kl, ku;

        if (d >= 0)
	    {
            n = dl + d, kl = 0, ku = d;
	    }
        else
	    {
            n = dl - d, kl = -d, ku = 0;
	    };

        BM res(ret_ti, n, n, kl, ku);

        Integer sz = res.size();

	    if (sz == 0)
	    {
		    return res;
	    };
        
        Integer ldr = res.ld();
        Integer ldv = (v.rows() == 1)? v.ld() : 1;
        Integer iist;

        if (d >= 0)
	    {
            iist = imult(d,ldr);
	    }
        else
	    {
            iist = - d;
	    };

	    V * ptr = res.rep_ptr();
	    const V * ptr_in = v.ptr();

        if (d != 0) 
	    {
		    memset(ptr,0,imult_c(sz,sizeof(V)));
	    }

	    ptr += iist;
        for (Integer i = 0; i < dl; ++i)
	    {
		    *ptr = *ptr_in;
		    ptr += ldr;
            ptr_in += ldv;
	    };

        if (d == 0)     res.get_struct().set_diag_matrix();
        else if (d > 0) res.get_struct().set_triu_matrix();
        else            res.get_struct().set_tril_matrix();

        return res;
    };
};
IntegerBandMatrix bdiag(const IntegerMatrix &v, Integer d)
{
    return bdiag_helper<Integer>::eval(v,d);
}
ObjectBandMatrix bdiag(const ObjectMatrix &v, Integer d)
{
    return bdiag_helper<Object>::eval(v,d);
}

IntegerBandMatrix bdiag(const IntegerSparseMatrix &v, Integer d)
{
	return bdiag(full(v),d);
};

RealBandMatrix bdiag(const RealMatrix &v, Integer d)
{
    return bdiag_helper<Real>::eval(v,d);
}
RealBandMatrix bdiag(const RealSparseMatrix &v, Integer d)
{
	return bdiag(full(v),d);
};
ComplexBandMatrix bdiag(const ComplexMatrix &v, Integer d)
{
    return bdiag_helper<Complex>::eval(v,d);
}
ComplexBandMatrix bdiag(const ComplexSparseMatrix &v, Integer d)
{
	return bdiag(full(v),d);
};

template<class V>
struct bdiags_helper
{
    typedef raw::Matrix<V,struct_dense>     DM;
    typedef raw::Matrix<V,struct_banded>    BM;

    static BM eval(const DM& B, const IntegerMatrix &d0, Integer m, Integer n)
    {
        IntegerMatrix d = d0.make_explicit();

        error::check_bspdiags_2ndarg(d.rows(), d.cols());

        gd::type_info ret_ti = B.get_ti();

	    Integer mi = constants::MaxInt, mx = constants::MinInt;
	    Integer s = d.size(), c = B.cols(), r = B.rows();

        if (s != c)
        {
            throw error::error_bspdiags_nonconf();
        };        
        
        if (std::min(m,n) != r)
        {
            throw error::error_bspdiags_nonconf();
        };

	    const Integer * ptr_d = d.ptr();
        Integer ldd = (d.rows() == 1)? d.ld() : 1;

        for (Integer k = 0; k < s; ++k)
        {
            if (*ptr_d < mi) mi = *ptr_d;
            if (*ptr_d > mx) mx = *ptr_d;

		    ptr_d += ldd;
        }

        Integer kl = (mi < 0) ? -mi : 0;
        Integer ku = (mx > 0) ? mx : 0;

        if (m < 0 || n < 0 || (n > 0 && ku + 1 > n) || (m > 0 && kl + 1 > m) 
                || (n == 0 && ku != 0) || (m == 0 && kl != 0))
        {
            throw error::error_bspdiags_nonconf();
        };

        BM res(ret_ti,m, n, kl, ku);

        Integer sz = res.size();
	    if (sz == 0)
	    {
		    return res;
	    };

	    V * ptr = res.rep_ptr();
	    memset(ptr,0,imult_c(sz,sizeof(V)));

        Integer ldr = res.ld();
        ptr_d = d.ptr();

        for (Integer k = 0; k < s; ++k)
        {
		    Integer diag = ptr_d[0];
            ptr_d += ldd;

		    Integer fp, nelem;
		    if (diag <= 0)
		    {
			    fp = ku + 1 - diag;
			    nelem = (m+diag < n) ? m+diag : n;
		    }
		    else
		    {
			    fp = imult(res.ld(),diag) + res.first_elem_pos(diag)+1;
			    nelem = (m < n-diag) ? m : n-diag;			
		    }

		    ptr = res.rep_ptr() + fp - 1;
		    const V * ptr_B = B.ptr() + imult(k,B.ld());
		    for (Integer i = 0; i < nelem; ++i)
		    {
			    *ptr = *(ptr_B++);
			    ptr += ldr;
		    };
        }

        return res;
    };
};
IntegerBandMatrix bdiags(const IntegerMatrix &B, const IntegerMatrix &d,
              Integer m, Integer n)
{
    return bdiags_helper<Integer>::eval(B,d,m,n);
}
RealBandMatrix bdiags(const RealMatrix &B, const IntegerMatrix &d,
              Integer m, Integer n)
{
    return bdiags_helper<Real>::eval(B,d,m,n);
}
ComplexBandMatrix bdiags(const ComplexMatrix &B, const IntegerMatrix &d,
              Integer m, Integer n)
{
    return bdiags_helper<Complex>::eval(B,d,m,n);
}
ObjectBandMatrix bdiags(const ObjectMatrix &B, const IntegerMatrix &d,
              Integer m, Integer n)
{
    return bdiags_helper<Object>::eval(B,d,m,n);
}


IntegerMatrix diags(const IntegerMatrix &B, const IntegerMatrix &d,
              Integer m, Integer n)
{
    gd::type_info ti_int = gd::get_raw_ti();
	return converter_deduce<IntegerMatrix>::eval(ti_int,bdiags(B, d, m, n));
}
RealMatrix diags(const RealMatrix &B, const IntegerMatrix &d,
              Integer m, Integer n)
{
    gd::type_info ret_ti = gd::get_raw_ti();
	return converter_deduce<RealMatrix>::eval(ret_ti,bdiags(B, d, m, n));
}
ComplexMatrix diags(const ComplexMatrix &B, const IntegerMatrix &d,
              Integer m, Integer n)
{
    gd::type_info ret_ti = gd::get_raw_ti();
	return converter_deduce<ComplexMatrix>::eval(ret_ti,bdiags(B, d, m, n));
}
ObjectMatrix diags(const ObjectMatrix &B, const IntegerMatrix &d,
              Integer m, Integer n)
{
    gd::type_info ret_ti = B.get_ti();
	return converter_deduce<ObjectMatrix>::eval(ret_ti,bdiags(B, d, m, n));
}


RealSparseMatrix speye(Integer r, Integer c)
{
    Integer m = (r < c) ? r : c, i;

    gd::type_info ret_ti = gd::get_raw_ti();
	details::spdat<Real> tmp(ret_ti,r, c, m);

	if (m == 0) return sparse_matrix_base<Real>(tmp);

	Real * ptr_x = tmp.ptr_x();
	for (Integer i = 0; i < m; ++i)
	{
		*(ptr_x++) = 1.;
	};

	Integer * ptr_c = tmp.ptr_c();
	Integer * ptr_r = tmp.ptr_r();
    for (i = 0; i < m; ++i)
    {
		*(ptr_c++) = i;
		*(ptr_r++) = i;
    }
    for (i = m; i <= c; ++i)
	{
		*(ptr_c++) = m;
	};

	RealSparseMatrix out = sparse_matrix_base<Real>(tmp);
    if (r == c)
    {
        out.get_struct().set_id_matrix();
    }
    else
    {
        out.get_struct().set_diag_matrix();
    };
    return out;
}
RealSparseMatrix speye(Integer n)
{
	return speye(n,n);
}

IntegerSparseMatrix speyei(Integer r, Integer c)
{
    Integer m = (r < c) ? r : c, i;

    gd::type_info ret_ti = gd::get_raw_ti();

    details::spdat<Integer> tmp(ret_ti,r, c, m);

	if (m == 0) return sparse_matrix_base<Integer>(tmp);

	Integer * ptr_x = tmp.ptr_x();
	for (Integer i = 0; i < m; ++i)
	{
		*(ptr_x++) = 1;
	};

	Integer * ptr_c = tmp.ptr_c();
	Integer * ptr_r = tmp.ptr_r();
    for (i = 0; i < m; ++i)
    {
		*(ptr_c++) = i;
		*(ptr_r++) = i;
    }
    for (i = m; i <= c; ++i)
	{
		*(ptr_c++) = m;
	};
	IntegerSparseMatrix out = sparse_matrix_base<Integer>(tmp);
    if (r == c)
    {
        out.get_struct().set_id_matrix();
    }
    else
    {
        out.get_struct().set_diag_matrix();
    };
    return out;
}
IntegerSparseMatrix speyei(Integer r)
{
	return speyei(r,r);
}
ComplexSparseMatrix speyec(Integer r, Integer c)
{
    Integer m = (r < c) ? r : c, i;

    gd::type_info ret_ti = gd::get_raw_ti();
    details::spdat<Complex> tmp(ret_ti,r, c, m);

	if (m == 0) return sparse_matrix_base<Complex>(tmp);

	Complex * ptr_x = tmp.ptr_x();
	for (Integer i = 0; i < m; ++i)
	{
		*(ptr_x++) = 1.;
	};

	Integer * ptr_c = tmp.ptr_c();
	Integer * ptr_r = tmp.ptr_r();
    for (i = 0; i < m; ++i)
    {
		*(ptr_c++) = i;
		*(ptr_r++) = i;
    }
    for (i = m; i <= c; ++i)
	{
		*(ptr_c++) = m;
	};

	ComplexSparseMatrix out = sparse_matrix_base<Complex>(tmp);
    if (r == c)
    {
        out.get_struct().set_id_matrix();
    }
    else
    {
        out.get_struct().set_diag_matrix();
    };
    return out;
}
ComplexSparseMatrix speyec(Integer r)
{
	return speyec(r,r);
};
ObjectSparseMatrix speye(gd::type_info ti, Integer r, Integer c)
{
    Integer m = (r < c) ? r : c, i;

    gd::type_info ret_ti = ti;
	details::spdat<Object> tmp(ret_ti,r, c, m);

	if (m == 0) return sparse_matrix_base<Object>(tmp);

	Object * ptr_x = tmp.ptr_x();
	for (Integer i = 0; i < m; ++i)
	{
		*(ptr_x++) = Object(ret_ti,1L);
	};

	Integer * ptr_c = tmp.ptr_c();
	Integer * ptr_r = tmp.ptr_r();
    for (i = 0; i < m; ++i)
    {
		*(ptr_c++) = i;
		*(ptr_r++) = i;
    }
    for (i = m; i <= c; ++i)
	{
		*(ptr_c++) = m;
	};

	ObjectSparseMatrix out = sparse_matrix_base<Object>(tmp);
    if (r == c)
    {
        out.get_struct().set_id_matrix();
    }
    else
    {
        out.get_struct().set_diag_matrix();
    };
    return out;
}
ObjectSparseMatrix speye(gd::type_info ti, Integer n)
{
	return speye(ti,n,n);
}

template<class V>
struct beye_helper
{
    typedef raw::Matrix<V,struct_banded>    BM;
    static BM eval(gd::type_info ti, Integer m, Integer n, Integer ld, Integer ud)
    {
        BM out(ti,m,n,ld,ud);        

        Integer out_size = std::min(m,n);
        if (out_size == 0)
        {
            return out;
        };

        V* ptr = out.rep_ptr() + out.udiags();
        Integer ldo = out.ld();
        V one = one_helper<V>(ti);

        for (Integer i = 0; i < out_size; ++i, ptr+= ldo)
        {
            *ptr = one;
        };
        if (m == n)
        {
            out.get_struct().set_id_matrix();
        }
        else
        {
            out.get_struct().set_diag_matrix();
        };
        return out;
    };
};
RealBandMatrix beye(Integer m, Integer n, Integer ld, Integer ud)
{
    return beye_helper<Real>::eval(gd::get_raw_ti(),m,n,ld,ud);
};
RealBandMatrix beye(Integer n, Integer ld, Integer ud)
{
    return beye(n,n,ld,ud);
};
ObjectBandMatrix beye(gd::type_info ti,Integer m, Integer n, Integer ld, Integer ud)
{
    return beye_helper<Object>::eval(ti,m,n,ld,ud);
};
ObjectBandMatrix beye(gd::type_info ti,Integer n, Integer ld, Integer ud)
{
    return beye(ti,n,n,ld,ud);
};
IntegerBandMatrix beyei(Integer m, Integer n, Integer ld, Integer ud)
{
    return beye_helper<Integer>::eval(gd::get_raw_ti(),m,n,ld,ud);
};
IntegerBandMatrix beyei(Integer n, Integer ld, Integer ud)
{
    return beyei(n,n,ld,ud);
};
ComplexBandMatrix beyec(Integer m, Integer n, Integer ld, Integer ud)
{
    return beye_helper<Complex>::eval(gd::get_raw_ti(),m,n,ld,ud);
};
ComplexBandMatrix beyec(Integer n, Integer ld, Integer ud)
{
    return beyec(n,n,ld,ud);
};

template<class V>
struct spdiag_helper
{
    typedef raw::Matrix<V,struct_dense>    DM;
    typedef raw::Matrix<V,struct_sparse>   SM;

    static SM eval(const DM &v0, Integer d)
    {
        DM v = v0.make_explicit();

	    error::check_bspdiag_1starg(v.rows(), v.cols());

        gd::type_info ret_ti = gd::get_raw_ti();

        Integer dl = v.size();
        if (dl == 0)
        {
            details::spdat<V> dat(ret_ti,0, 0, 0);
            SM out = sparse_matrix_base<V>(dat);
            return out;
        };

        Integer ldv = (v.rows() == 1)? v.ld() : 1;
        Integer n;

        if (d >= 0)
        {
            n = dl + d;
        }
        else
        {
            n = dl - d;
        };

        details::spdat<V> dat(ret_ti,n, n, dl);

        if (d >= 0)
        {
		    Integer * ptr_c = dat.ptr_c() + d+1;
		    Integer * ptr_r = dat.ptr_r();
		    V * ptr_x       = dat.ptr_x();
		    const V * ptr_v = v.ptr();
    		
            for (Integer j = d, i = 0; j < n; ++j, ++i)
            {
                *(ptr_c++) = i + 1;
                *(ptr_r++) = i;
                *(ptr_x++) = *ptr_v;
                ptr_v += ldv;
            }
        }
        else
        {
		    Integer * ptr_c = dat.ptr_c() + 1;
		    Integer * ptr_r = dat.ptr_r();
		    V * ptr_x       = dat.ptr_x();
		    const V * ptr_v = v.ptr();

            Integer j, i;
            for (j = 1, i = -d; j <= dl; ++j, ++i)
            {
                *(ptr_c++) = j;
                *(ptr_r++) = i;
                *(ptr_x++) = *ptr_v;
                ptr_v += ldv;
            }
            for (; j <= n; ++j, ++i)
		    {
			    *(ptr_c++) = dl;
		    };
        }

	    SM out = sparse_matrix_base<V>(dat);
        if (d == 0)     out.get_struct().set_diag_matrix();
        else if (d > 0) out.get_struct().set_triu_matrix();
        else            out.get_struct().set_tril_matrix();

        return out;
    }
};

IntegerSparseMatrix spdiag(const IntegerMatrix &v, Integer d)
{
    return spdiag_helper<Integer>::eval(v,d);
}

RealSparseMatrix spdiag(const RealMatrix &v, Integer d)
{
    return spdiag_helper<Real>::eval(v,d);
}
ComplexSparseMatrix spdiag(const ComplexMatrix &v, Integer d)
{
    return spdiag_helper<Complex>::eval(v,d);
}
ObjectSparseMatrix spdiag(const ObjectMatrix &v, Integer d)
{
    return spdiag_helper<Object>::eval(v,d);
}

IntegerSparseMatrix spdiags(const IntegerMatrix &B, const IntegerMatrix &d, Integer m,
               Integer n)
{
    return sparse(bdiags(B, d, m, n));
}

RealSparseMatrix spdiags(const RealMatrix &B, const IntegerMatrix &d, Integer m,
               Integer n)
{
    return sparse(bdiags(B, d, m, n));
}
ComplexSparseMatrix spdiags(const ComplexMatrix &B, const IntegerMatrix &d, Integer m,
               Integer n)
{
    return sparse(bdiags(B, d, m, n));
}
ObjectSparseMatrix spdiags(const ObjectMatrix &B, const IntegerMatrix &d, Integer m,
               Integer n)
{
    return sparse(bdiags(B, d, m, n));
}

RealSparseMatrix sprand(Integer r, Integer c, Real d)
{
    if (d < 0.) d = 0.;
    if (d > 1.) d = 1.;
    Integer i, nnz = icast_c(d * Real(r) * Real(c));

    gd::type_info ti_int = gd::get_raw_ti();
    gd::type_info ret_ti = gd::get_raw_ti();

	IntegerMatrix ri(ti_int,nnz,1), ci(ti_int,nnz,1);
    Integer* ptr_ri = ri.ptr();
    Integer* ptr_ci = ci.ptr();

    RealMatrix xv(ret_ti,nnz,1);
    for (i = 0; i < nnz; ++i)
    {
        ptr_ri[i] = 1 + icast(mmlib::details::genrand_real1() * Real(r));
        ptr_ci[i] = 1 + icast(mmlib::details::genrand_real1() * Real(c));
    }

    RealSparseMatrix tmp(ret_ti,ri.ptr(), ci.ptr(), xv.ptr(), r, c, nnz, nnz);

    Integer nz      = tmp.nnz();
    Real * ptr_x    = tmp.rep().ptr_x();

    for (i = 0; i < nz; ++i)
    {
        ptr_x[i] = mmlib::details::genrand_real1();
    };

    return tmp;
}
ComplexSparseMatrix sprandc(Integer r, Integer c, Real d)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    if (d < 0.) d = 0.;
    if (d > 1.) d = 1.;
    Integer i, nnz = icast_c(d * Real(r) * Real(c));

    gd::type_info ti_int = gd::get_raw_ti();

    IntegerMatrix ri(ti_int,nnz,1), ci(ti_int,nnz,1);
    Integer* ptr_ri = ri.ptr();
    Integer* ptr_ci = ci.ptr();

    ComplexMatrix xv(ret_ti,nnz,1);
    for (i = 0; i < nnz; ++i)
    {
        ptr_ri[i] = 1 + icast(mmlib::details::genrand_real1() * Real(r));
        ptr_ci[i] = 1 + icast(mmlib::details::genrand_real1() * Real(c));
    }

    ComplexSparseMatrix tmp(ret_ti,ri.ptr(), ci.ptr(), xv.ptr(), r, c, nnz, nnz);

    Integer nz      = tmp.nnz();
    Complex * ptr_x = tmp.rep().ptr_x();

    for (i = 0; i < nz; ++i)
    {
        ptr_x[i]    = Complex(mmlib::details::genrand_real1(),mmlib::details::genrand_real1());
    };

    return tmp;
}
IntegerSparseMatrix sprandi(Integer r, Integer c, Real d)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    if (d < 0.) d = 0.;
    if (d > 1.) d = 1.;
    Integer i, nnz = icast_c(d * Real(r) * Real(c));

    gd::type_info ti_int = gd::get_raw_ti();

    IntegerMatrix ri(ti_int,nnz,1), ci(ti_int,nnz,1);
    Integer* ptr_ri = ri.ptr();
    Integer* ptr_ci = ci.ptr();

    IntegerMatrix xv(ret_ti,nnz,1);
    for (i = 0; i < nnz; ++i)
    {
        ptr_ri[i] = 1 + icast(mmlib::details::genrand_real1() * Real(r));
        ptr_ci[i] = 1 + icast(mmlib::details::genrand_real1() * Real(c));
    }

    IntegerSparseMatrix tmp(ret_ti,ri.ptr(), ci.ptr(), xv.ptr(), r, c, nnz, nnz);

    Integer nz      = tmp.nnz();
    Integer * ptr_x = tmp.rep().ptr_x();

    for (i = 0; i < nz; ++i)
    {
        ptr_x[i]    = mmlib::details::genrand_int32();
    };

    return tmp;
}

RealSparseMatrix sprandn(Integer r, Integer c, Real d)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    if (d < 0.) d = 0.;
    if (d > 1.) d = 1.;
    Integer i, nnz = icast_c(d * Real(r) * Real(c));

    gd::type_info ti_int = gd::get_raw_ti();

    IntegerMatrix ri(ti_int,nnz,1), ci(ti_int,nnz,1);
    Integer* ptr_ri = ri.ptr();
    Integer* ptr_ci = ci.ptr();

    RealMatrix xv(ret_ti,nnz,1);
    for (i = 0; i < nnz; ++i)
    {
        ptr_ri[i] = 1 + icast(mmlib::details::genrand_real1() * Real(r));
        ptr_ci[i] = 1 + icast(mmlib::details::genrand_real1() * Real(c));
    }

    RealSparseMatrix tmp(ret_ti,ri.ptr(), ci.ptr(), xv.ptr(), r, c, nnz, nnz);

    Integer nz      = tmp.nnz();
    Real * ptr_x    = tmp.rep().ptr_x();

    for (i = 0; i < nz; ++i)
    {
        ptr_x[i]    = mmlib::details::gen_norm();
    };

    return tmp;
}
ComplexSparseMatrix sprandnc(Integer r, Integer c, Real d)
{
    gd::type_info ret_ti = gd::get_raw_ti();

    if (d < 0.) d = 0.;
    if (d > 1.) d = 1.;
    Integer i, nnz = icast_c(d * Real(r) * Real(c));

    gd::type_info ti_int = gd::get_raw_ti();

    IntegerMatrix ri(ti_int,nnz,1), ci(ti_int,nnz,1);
    Integer* ptr_ri = ri.ptr();
    Integer* ptr_ci = ci.ptr();

    ComplexMatrix xv(ret_ti,nnz,1);
    for (i = 0; i < nnz; ++i)
    {
        ptr_ri[i] = 1 + icast(mmlib::details::genrand_real1() * Real(r));
        ptr_ci[i] = 1 + icast(mmlib::details::genrand_real1() * Real(c));
    }

    ComplexSparseMatrix tmp(ret_ti,ri.ptr(), ci.ptr(), xv.ptr(), r, c, nnz, nnz);

    Integer nz      = tmp.nnz();
    Complex * ptr_x = tmp.rep().ptr_x();

    for (i = 0; i < nz; ++i)
    {
        ptr_x[i] = Complex(mmlib::details::gen_norm(),mmlib::details::gen_norm());
    };

    return tmp;
}

};};