/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/func/raw/converter.h"
#include "mmlib/container/raw/type_decl.h"
#include "mmlib/mp/instantiate.h"
#include "mmlib/error/error_check.h"
#include "mmlib/exception.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/details/matrix_func_unary.inl"
#include "mmlib/utils/utils.h"
#include <vector>

#pragma warning( push )
#pragma warning(disable:4127)	// conditional expression is constant

namespace mmlib { namespace raw
{

namespace gd = mmlib::details;

template<class val_type>
Matrix<val_type,struct_dense> full(const Matrix<val_type,struct_sparse>& A)
{
	typedef Matrix<val_type,struct_sparse> SparseMat;
	typedef Matrix<val_type,struct_dense> FullMat;
	return converter<FullMat,SparseMat>::eval(A.get_ti(),A);
};
template<class val_type>
Matrix<val_type,struct_sparse> sparse(const Matrix<val_type,struct_dense>& A)
{
	typedef Matrix<val_type,struct_sparse> SparseMat;
	typedef Matrix<val_type,struct_dense> FullMat;
	return converter<SparseMat,FullMat>::eval(A.get_ti(),A);
};

template<class val_type>
Matrix<val_type,struct_sparse> sparse(const Matrix<val_type,struct_banded>& A)
{
	typedef Matrix<val_type,struct_sparse> SparseMat;
	typedef Matrix<val_type,struct_banded> BandMat;
	return converter<SparseMat,BandMat>::eval(A.get_ti(),A);
};

template<class val_type>
Matrix<val_type,struct_banded> band(const Matrix<val_type,struct_dense>& A)
{
	typedef Matrix<val_type,struct_banded> BandMat;
	typedef Matrix<val_type,struct_dense> FullMat;
	return converter<BandMat,FullMat>::eval(A.get_ti(),A);
};

template<class val_type>
Matrix<val_type,struct_banded> band(const Matrix<val_type,struct_sparse>& A)
{
    typedef Matrix<val_type,struct_banded> BandMat;
	typedef Matrix<val_type,struct_sparse> SparseMat;	
	return converter<BandMat,SparseMat>::eval(A.get_ti(),A);
};

template<class ret_type,class M,class struct_type>
struct eval_reshape_helper
{};
template<class ret_type,class M>
struct eval_reshape_helper<ret_type,M,struct_dense>
{
	static ret_type eval(const M& A,Integer r, Integer c)
	{
        return A.reshape(r,c);
	};
};
template<class ret_type,class M>
struct eval_reshape_helper<ret_type,M,struct_sparse>
{
	static ret_type eval(const M& A,Integer r, Integer c)
	{
		typedef typename M::value_type value_type;

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();

		if ((Ar == r) && (Ac == c))
		{
			return A;
		};
		if ((double) Ar * (double) Ac != (double) r * (double) c)
		{
			throw error::error_reshape(Ar, Ac, r, c);
		};

		if (An == 0)
		{
			return ret_type(A.get_ti(),r,c);
		};

		ret_type res(A.get_ti(),r,c,An);

		details::spdat<value_type>& d = res.rep();
		const details::spdat<value_type>& Ad = A.rep();

		const Integer* Ad_r = Ad.ptr_r();
		const Integer* Ad_c = Ad.ptr_c();
		const value_type* Ad_x = Ad.ptr_x();
        Integer off         = Ad.offset();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();

		for (Integer Aj = 0, j = 1, i = 0, lastAi = 0; Aj < Ac; ++Aj)
		{
			for (Integer k = Ad_c[Aj]; k < Ad_c[Aj + 1]; ++k)
			{
				Integer Ai	= Ad_r[k];
				i			+= Ai - lastAi;
				lastAi		= Ai;
				if (i >= r)
				{ 
					j += i/r; 
					i %= r; 
				};
				d_x[k-off] = Ad_x[k];
				d_r[k-off] = i;
				++d_c[j];
			};
			lastAi	-= Ar;
			if (lastAi <= -r) 
			{ 
				j -= lastAi/r; 
				lastAi %= r; 
			};
		};

		for (Integer j = 2; j <= c; ++j)
		{
			d_c[j] += d_c[j - 1];
		};

		return res;
	};
};
template<class ret_type,class M>
struct eval_reshape_helper<ret_type,M,struct_banded>
{
	static ret_type eval(const M& A,Integer r, Integer c)
	{
		typedef typename M::value_type value_type;
        value_type Z = gd::default_value<value_type>(A.get_ti());

		Integer Ar = A.rows(), Ac = A.cols(), An = A.nnz();

		if ((Ar == r) && (Ac == c))
		{
			return converter<ret_type,M>::eval(A.get_ti(),A);
		};
		if ((double) Ar * (double) Ac != (double) r * (double) c)
		{
			throw error::error_reshape(Ar, Ac, r, c);
		};

		if (An == 0)
		{
			return ret_type(A.get_ti(),r,c);
		};

		ret_type res(A.get_ti(),r,c,An);

		details::spdat<value_type>& d = res.rep();

		Integer* d_r		= d.ptr_r();
		Integer* d_c		= d.ptr_c();
		value_type* d_x		= d.ptr_x();
		Integer nz			= 0;

        const value_type* ptr_A = A.rep_ptr();

		for (Integer Aj = 0, i = 0, j = 1, lastAi = 0; Aj < Ac; ++Aj)
		{
			Integer first_row = A.first_row(Aj);
			Integer last_row = A.last_row(Aj);
			Integer pos = A.first_elem_pos(Aj);

			for (Integer k = first_row; k <= last_row; ++k, ++pos)
			{
				Integer Ai	= k;
				i			+= Ai - lastAi;
				lastAi		= Ai;
				if (i >= r)
				{ 
					j += i/r; 
					i %= r; 
				};
				value_type tmp = ptr_A[pos];

				if (tmp != Z)
				{
					d_x[nz] = tmp;
					d_r[nz] = i;
					++d_c[j];
					++nz;
				};
			};
			lastAi	-= Ar;
			if (lastAi <= -r) 
			{ 
				j -= lastAi/r; 
				lastAi %= r; 
			};

            ptr_A += A.ld();
		};

		for (Integer j = 2; j <= c; ++j)
		{
			d_c[j] += d_c[j - 1];
		};

		d.memadd(-1);
		return res;
	};
};

template<class M>
typename details::manip_reshape_helper<M>::ret_type_reshape	details::manip_reshape_helper<M>::eval_reshape(const M& A, Integer m, Integer n)
{
	typedef typename M::struct_type struct_type;
	return eval_reshape_helper<ret_type_reshape,M,struct_type>::eval(A,m,n);
};

template<class ret_type,class M,class struct_type>
struct eval_vec_helper
{};
template<class ret_type,class M>
struct eval_vec_helper<ret_type,M,struct_dense>
{
	static ret_type eval(const M& A)
	{
        return A.reshape(A.size(),1);
	};
};
template<class ret_type,class M>
struct eval_vec_helper<ret_type,M,struct_sparse>
{
	static ret_type eval(const M& A)
	{
		typedef typename M::value_type value_type;

		Integer r = A.rows(), c = A.cols(), nnz = A.nnz();
		error::check_size(r,c);

		Integer size = imult(r,c);

		if (nnz == 0 || r == 0 || c == 0)
        {
            return ret_type(A.get_ti(),size,1,nnz);
        };

		const details::spdat<value_type>& Ad = A.rep();

		ret_type res(A.get_ti(),size,1,nnz);
		details::spdat<value_type>& d = res.rep();

		const Integer* Ad_r = Ad.ptr_r();
		const Integer* Ad_c = Ad.ptr_c();
		const value_type* Ad_x = Ad.ptr_x();
        Integer off         = Ad.offset();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();

		d_c[0] = 0;
		for (Integer j = 0, jj = 0; j < c; ++j, jj+=r)
		{
			for (Integer i = Ad_c[j]; i < Ad_c[j + 1]; ++i)
			{
				d_r[i-off] = Ad_r[i] + jj;
				d_x[i-off] = Ad_x[i];
			}
		};
		d_c[1] = nnz;

		return res;
	};
};
template<class ret_type,class M>
struct eval_vec_helper<ret_type,M,struct_banded>
{
	static ret_type eval(const M& A)
	{		
		typedef typename M::value_type value_type;
        value_type Z = gd::default_value<value_type>(A.get_ti());

		Integer r = A.rows(), c = A.cols(), nnz = A.nnz();
		error::check_size(r,c);

		Integer size = imult(r,c);

		if (nnz == 0 || r == 0 || c == 0)
		{
			return ret_type(A.get_ti(),size,1,nnz);
		};

		ret_type res(A.get_ti(),size,1,nnz);
		details::spdat<value_type>& d = res.rep();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();

		d_c[0] = 0;
		Integer nz = 0;

        const value_type* ptr_A = A.rep_ptr();

		if (A.ldiags() == 0 && A.udiags() == 0)
		{
			Integer rc = std::min(r,c);
			for (Integer j = 0, jj = 0; j < rc; ++j, jj += r + 1)
			{
				value_type tmp = ptr_A[0];
				if (tmp != Z)
				{
					d_r[nz] = jj;
					d_x[nz] = tmp;
					++nz;
				};
                ptr_A += A.ld();
			};
		}
		else
		{
			for (Integer j = 0, jj = 0; j < c; ++j, jj+=r)
			{
				Integer first_row   = A.first_row(j);
				Integer last_row    = A.last_row(j);
				Integer pos_A		= A.first_elem_pos(j);

				for (Integer i = first_row; i <= last_row; ++i, ++pos_A)
				{
					value_type tmp = ptr_A[pos_A];
					if (tmp != Z)
					{
						d_r[nz] = i + jj;
						d_x[nz] = tmp;
						++nz;
					};
				};

                ptr_A += A.ld();
			};
		};
		d_c[1] = nz;

		d.memadd(-1);
		return res;
	};
};

template<class M>
typename details::manip_reshape_helper<M>::ret_type_vec	details::manip_reshape_helper<M>::eval_vec(const M& m)
{
	typedef typename M::struct_type struct_type;
	return eval_vec_helper<ret_type_vec,M,struct_type>::eval(m);
};

template<class ret_type,class M,class struct_type>
struct eval_flipud_helper
{};
template<class ret_type,class M,class struct_type>
struct eval_fliplr_helper
{};
template<class ret_type,class M>
struct eval_flipud_helper<ret_type,M,struct_dense>
{
	static ret_type eval(const M& m)
	{
		Integer r = m.rows(), c = m.cols();

		if (r == 1)
        {
            return m;
        };

		ret_type res(m.get_ti(),r, c);

		if (res.size() == 0)
        {
            return res;
        };

        const M::value_type* ptr_m = m.ptr();
        ret_type::value_type* ptr_res = res.ptr();

		for (Integer j = 0; j < c; ++j)
		{
			for (Integer i = 0, k = r-1; i < r; ++i, --k)
            {
				ptr_res[i] = ptr_m[k];
            };
            ptr_res += res.ld();
            ptr_m += m.ld();
		}

		return res;
	};
};
template<class ret_type,class M>
struct eval_fliplr_helper<ret_type,M,struct_dense>
{
	static ret_type eval(const M& m)
	{
		Integer r = m.rows(), c = m.cols();        

		if (c == 1)
        {
            return m;
        };

		ret_type res(m.get_ti(),r, c);
        const M::value_type* ptr_m = m.ptr() + imult(c-1,m.ld());
        ret_type::value_type* ptr_res = res.ptr();

		if (res.size() == 0)
        {
            return res;
        };

		for (Integer j = 0; j < c; ++j)
		{
			for (Integer i = 0; i < r; ++i)
            {
				ptr_res[i] = ptr_m[i];
            };
            ptr_res += res.ld();
            ptr_m -= m.ld();
		}

		return res;
	};
};
template<class ret_type,class M>
struct eval_fliplr_helper<ret_type,M,struct_sparse>
{
	static ret_type eval(const M& A)
	{
		typedef typename M::value_type value_type;

		Integer r = A.rows(), c = A.cols(), nnz = A.nnz();

		if (nnz == 0 || r == 0 || c == 0)
        {
            return ret_type(A.get_ti(),r,c,nnz);
        };
		if (c == 1) return A;

		const details::spdat<value_type>& Ad = A.rep();

		ret_type res(A.get_ti(),r,c,nnz);
		details::spdat<value_type>& d = res.rep();

		const Integer* Ad_r = Ad.ptr_r();
		const Integer* Ad_c = Ad.ptr_c();
		const value_type* Ad_x = Ad.ptr_x();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();

		d_c[0] = 0;
		for (Integer j = c - 1, pos_r = 0, pos_c = 1; j >= 0; --j, ++pos_c)
		{
			for (Integer i = Ad_c[j]; i < Ad_c[j+1]; ++i)
			{
				d_r[pos_r] = Ad_r[i];
				d_x[pos_r] = Ad_x[i];
				++pos_r;
			}
			d_c[pos_c] = pos_r;
		};
		d_c[c] = nnz;

		return res;
	};
};
template<class ret_type,class M>
struct eval_fliplr_helper<ret_type,M,struct_banded>
{
	static ret_type eval(const M& A)
	{
		typedef typename M::value_type value_type;
        value_type Z = gd::default_value<value_type>(A.get_ti());

		Integer r = A.rows(), c = A.cols(), nnz = A.nnz();

		if (nnz == 0 || r == 0 || c == 0)
		{
			return ret_type(A.get_ti(),r,c);
		};

		ret_type res(A.get_ti(),r,c,nnz);
		details::spdat<value_type>& d = res.rep();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();

		d_c[0] = 0;
		Integer nz = 0;

        const value_type* ptr_A = A.rep_ptr();

		if (A.ldiags() == 0 && A.udiags() == 0)
		{
			Integer pos_c = 1;
			Integer rc = std::min(r,c);
			for (Integer j = c; j > rc; --j, ++pos_c)
			{
				d_c[pos_c] = 0;
			};

            ptr_A += (rc-1)*A.ld();
			for (Integer j = rc; j >= 1; --j, ++pos_c)
			{
				value_type tmp = ptr_A[0];
				if (tmp != Z)
				{
					d_r[nz] = j-1;
					d_x[nz] = tmp;
					++nz;				
				};
				d_c[pos_c] = nz;
                ptr_A -= A.ld();
			};
		}
		else
		{
            ptr_A += imult(c-1,A.ld());

			for (Integer j = c-1, pos_c = 1; j >= 0; --j, ++pos_c)
			{
				Integer first_row = A.first_row(j);
				Integer last_row = A.last_row(j);
				Integer pos = A.first_elem_pos(j);

				for (Integer i = first_row; i <= last_row; ++i, ++pos)
				{
					value_type tmp = ptr_A[pos];
					if (tmp != Z)
					{
						d_r[nz] = i;
						d_x[nz] = tmp;
						++nz;				
					};
				};
				d_c[pos_c] = nz;
                ptr_A -= A.ld();
			};
		};
		d_c[c] = nz;

		d.memadd(-1);
		return res;
	};
};
template<class ret_type,class M>
struct eval_flipud_helper<ret_type,M,struct_sparse>
{
	static ret_type eval(const M& A)
	{
		typedef typename M::value_type value_type;

		Integer r = A.rows(), c = A.cols(), nnz = A.nnz();

		if (nnz == 0|| r == 0 || c == 0)
        {
            return ret_type(A.get_ti(), r,c,nnz);
        };
		if (r == 1) return A;

		const details::spdat<value_type>& Ad = A.rep();

		ret_type res(A.get_ti(),r,c,nnz);
		details::spdat<value_type>& d = res.rep();

		const Integer* Ad_r = Ad.ptr_r();
		const Integer* Ad_c = Ad.ptr_c();
		const value_type* Ad_x = Ad.ptr_x();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();

		d_c[0] = 0;
		for (Integer j = 0, pos_r = 0, pos_c = 1; j < c; ++j, ++pos_c)
		{
			for (Integer i = Ad_c[j+1]-1; i >= Ad_c[j]; --i)
			{
				d_r[pos_r] = r - 1 - Ad_r[i];
				d_x[pos_r] = Ad_x[i];
				++pos_r;
			}
			d_c[pos_c] = pos_r;
		};
		d_c[c] = nnz;

		return res;
	};
};
template<class ret_type,class M>
struct eval_flipud_helper<ret_type,M,struct_banded>
{
	static ret_type eval(const M& A)
	{
		typedef typename M::value_type value_type;
        value_type Z = gd::default_value<value_type>(A.get_ti());

		Integer r = A.rows(), c = A.cols(), nnz = A.nnz();

		if (nnz == 0|| r == 0 || c == 0)
		{
			return ret_type(A.get_ti(),r,c,nnz);
		};

		ret_type res(A.get_ti(),r,c,nnz);
		details::spdat<value_type>& d = res.rep();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();

		Integer nz	= 0;
		d_c[0]		= 0;

        const value_type* ptr_A = A.rep_ptr();

		if (A.ldiags() == 0 && A.udiags() == 0)
		{
			Integer rc = std::min(r,c);
			for (Integer j = 0; j < rc; ++j)
			{
                d_c[j] = nz;

				value_type tmp = ptr_A[0];
				if (tmp != Z)
				{
					d_r[nz]		= r - j - 1;
					d_x[nz]		= tmp;
					++nz;
				};				
                ptr_A += A.ld();
			};
			for (Integer j = rc; j <= c; ++j)
			{
				d_c[j] = nz;
			};
		}
		else
		{
			for (Integer j = 0; j < c; ++j)
			{
                d_c[j] = nz;

				Integer first_row	= A.first_row(j);
				Integer last_row	= A.last_row(j);
				Integer pos			= A.first_elem_pos(j) + last_row - first_row;

				for (Integer i = last_row; i >= first_row; --i, --pos)
				{
					value_type tmp = ptr_A[pos];
					if (tmp != Z)
					{
						d_r[nz]		= r - i - 1;
						d_x[nz]		= tmp;
						++nz;
					};
				}				
                ptr_A += A.ld();
			};
            d_c[c] = nz;
		};

		d.memadd(-1);
		return res;
	}; 
};
template<class M>
typename details::manip_reshape_helper<M>::ret_type_flip	details::manip_reshape_helper<M>::eval_flipud(const M& m)
{
	typedef typename M::struct_type struct_type;
	return eval_flipud_helper<ret_type_vec,M,struct_type>::eval(m);
};

template<class M>
typename details::manip_reshape_helper<M>::ret_type_flip	details::manip_reshape_helper<M>::eval_fliplr(const M& m)
{
	typedef typename M::struct_type struct_type;
	return eval_fliplr_helper<ret_type_vec,M,struct_type>::eval(m);
};
template<class ret_type,class M,class struct_type>
struct eval_repmat_helper
{};
template<class ret_type,class M>
struct eval_repmat_helper<ret_type,M,struct_dense>
{
	static ret_type eval(const M& mat,Integer m, Integer n)
	{		
		Integer matr = mat.rows(), matc = mat.cols();
		error::check_size(m,matr);
		error::check_size(n,matc);
		Integer resr = imult(m,matr);
        Integer resc = imult(n,matc);
	 
        typedef M::value_type val_in;
        typedef ret_type::value_type val_ret;

		ret_type res(mat.get_ti(),resr, resc);
	 
		if (!res.size())
        {
            return res; 
        };

        const val_in* ptr_mat = mat.ptr();
        val_ret* ptr_res = res.ptr();
	 
		if (matr == 1 && n == 1) 
		{
			for (Integer j = 0; j < matc; ++j, ptr_mat += mat.ld())
			{
                val_in val = ptr_mat[0];
				for (Integer i = 0; i < m; ++i)
                {
					ptr_res[i] = val;
                };
                ptr_res += res.ld();
			}
	
			return res;
		};

		for (Integer j = 0; j < n; ++j)
		{
            ptr_mat = mat.ptr();
		    for (Integer matj = 0; matj < matc; ++matj)
		    {
			    for (Integer i = 0, pos_res = 0; i < m; ++i)
			    {
					for (Integer mati = 0; mati < matr; ++mati, ++pos_res)
                    {
						ptr_res[pos_res] = ptr_mat[mati];
                    };
				};

                ptr_mat += mat.ld();
                ptr_res += res.ld();
			};
		};
	 
		return res;
	};
};
template<class ret_type,class M>
struct eval_repmat_helper<ret_type,M,struct_sparse>
{
	static ret_type eval(const M& mat,Integer m, Integer n)
	{
		Integer matr = mat.rows(), matc = mat.cols();
		
		error::check_size(m,matr);
		error::check_size(n,matc);

		Integer resr = imult(m,matr), resc = imult(n,matc);
        Integer resnnz = imult(imult(mat.nnz(),m),n);
        
		if (m == 1 && n == 1)
		{
			return mat;
		};
		ret_type res(mat.get_ti(),resr, resc,resnnz);

		if (resnnz == 0 || resr == 0 || resc == 0)
		{
			return res;
		};

		typedef M::value_type value_type;
        value_type Z = gd::default_value<value_type>(mat.get_ti());

		details::spdat<value_type>& rep	= res.rep();
		const details::spdat<value_type>& Arep	= mat.rep();

		Integer* d_c			= rep.ptr_c();
		Integer* d_r			= rep.ptr_r();
		value_type* d_x			= rep.ptr_x();

		const Integer* Ad_c		= Arep.ptr_c();
		const Integer* Ad_r		= Arep.ptr_r();
		const value_type* Ad_x	= Arep.ptr_x();

		d_c[0] = 0;
		Integer nz = 0;

		for (Integer j = 0; j < matc; ++j)
		{
			for (Integer k = 1, pos_r = 0; k <= m; ++k, pos_r+= matr)
			{
				for (Integer i = Ad_c[j]; i < Ad_c[j+1]; ++i)
				{
					Integer p = Ad_r[i];
					value_type val = Ad_x[i];
					if (val == Z)
					{
						continue;
					};

					d_r[nz] = pos_r + p;
					d_x[nz] = val;
					++nz;
				};

				d_c[j+1] = nz;
			};
		};

		for (Integer k = 2, col = matc + 1; k<= n; ++k)
		{
			for (Integer j = 0; j < matc; ++j, ++col)
			{
				for (Integer i = d_c[j]; i < d_c[j+1]; ++i)
				{
					Integer p = d_r[i];
					value_type val = d_x[i];

					d_r[nz] = p;
					d_x[nz] = val;
					++nz;
				};

				d_c[col] = nz;
			};
		};

		rep.memadd(-1);
		return res;
	};
};
template<class ret_type,class M>
struct eval_repmat_helper<ret_type,M,struct_banded>
{
	static ret_type eval(const M& mat,Integer m, Integer n)
	{
		Integer matr = mat.rows(), matc = mat.cols();
		error::check_size(m,matr);
		error::check_size(n,matc);
		Integer resr = imult(m,matr), resc = imult(n,matc);
		Integer resnnz = imult(imult(mat.nnz(),m),n); 

		if (m == 1 && n == 1)
		{
			return converter<ret_type,M>::eval(mat.get_ti(),mat);
		};

		ret_type res(mat.get_ti(),resr, resc,resnnz);

		if (resr == 0 || resc == 0 || resnnz == 0)
		{
			return res;
		};

		typedef M::value_type value_type;
        value_type Z = gd::default_value<value_type>(mat.get_ti());

		details::spdat<value_type>& rep	= res.rep();

		Integer* d_c			= rep.ptr_c();
		Integer* d_r			= rep.ptr_r();
		value_type* d_x			= rep.ptr_x();

		d_c[0] = 0;
		Integer nz = 0;

        const value_type* ptr_mat = mat.rep_ptr();

		if (mat.ldiags() == 0 && mat.udiags() == 0)
		{
			Integer s = std::min(matc,matr);
			for (Integer j = 0; j < s; ++j, ptr_mat+= mat.ld())
			{
				value_type val = ptr_mat[0];
				if (val == Z)
				{
					d_c[j+1] = nz;
					continue;
				};
				for (Integer k = 1, pos_r = j; k <= m; ++k, pos_r+= matr)
				{
					d_r[nz] = pos_r;
					d_x[nz] = val;
					++nz;					
				};
				d_c[j+1] = nz;
			};
			for (Integer j = s+1; j <= matc; ++j)
			{
				d_c[j] = nz;
			};
		}
		else
		{
			for (Integer j = 0; j < matc; ++j)
			{
                d_c[j] = nz;

				for (Integer k = 1, pos_r = 0; k <= m; ++k, pos_r+= matr)
				{
					Integer first_row = mat.first_row(j);
					Integer last_row = mat.last_row(j);
					Integer pos_A = mat.first_elem_pos(j);
					for (Integer i = first_row; i <= last_row; ++i, ++pos_A)
					{
						Integer p = i;
						value_type val = ptr_mat[pos_A];
						if (val == Z)
						{
							continue;
						};

						d_r[nz] = pos_r + p;
						d_x[nz] = val;
						++nz;
					};					
				};				
                ptr_mat += mat.ld();
			};

            d_c[matc] = nz;
		};

		for (Integer k = 2, col = matc + 1; k<= n; ++k)
		{
			for (Integer j = 0; j < matc; ++j, ++col)
			{
				for (Integer i = d_c[j]; i < d_c[j+1]; ++i)
				{
					Integer p = d_r[i];
					value_type val = d_x[i];

					d_r[nz] = p;
					d_x[nz] = val;
					++nz;
				};

				d_c[col] = nz;
			};
		};

		rep.memadd(-1);
		return res;
	};
};
template<class M>
typename details::manip_reshape_helper<M>::ret_type_repmat	
details::manip_reshape_helper<M>::eval_repmat(const M& A, Integer m, Integer n)
{
	typedef typename M::struct_type struct_type;
	return eval_repmat_helper<ret_type_repmat,M,struct_type>::eval(A,m,n);
};

template<class ret_type,class M, class struct_type>
struct eval_trans_helper
{};
template<class ret_type,class M>
struct eval_trans_helper<ret_type,M,struct_dense>
{
	static ret_type eval(const M& m)
	{
        if (m.get_struct().is_trans_id() && m.rows() == m.cols())
        {
            return m;
        };

		Integer r = m.rows(), c = m.cols();		

		if (r <= 1 || c <= 1)
		{
            ret_type out = m.reshape(c,r);
            out.set_struct(m.get_struct().get_trans());
            return out;
		}

        ret_type res(m.get_ti());
		res.reset_unique(c, r);

        const M::value_type* ptr_m = m.ptr();
        ret_type::value_type* ptr_res = res.ptr();

		for (Integer j = 0; j < r; ++j)
		{
            ptr_m = m.ptr() + j;
			for (Integer i = 0; i < c; ++i, ptr_m += m.ld())
            {
				ptr_res[i] = ptr_m[0];
            };
            ptr_res += res.ld();
		}

        res.set_struct(m.get_struct().get_trans());
		return res;
	};
};
template<class ret_type,class M>
struct eval_trans_helper<ret_type,M,struct_banded>
{
	static ret_type eval(const M& A)
	{
        if (A.get_struct().is_trans_id()  && A.rows() == A.cols())
        {
            return A;
        };

		Integer r = A.rows(), c = A.cols(), kl = A.ldiags(), ku = A.udiags();

        typedef typename M::value_type value_type;
        typedef typename ret_type::value_type value_type_ret;

        const value_type* ptr_A = A.rep_ptr();

		if (kl == 0 && ku == 0)
		{
            if (r==c)
            {
                return A;
            };

            ret_type res(A.get_ti(),c, r, 0, 0);
			Integer rc = std::min(r,c);

            value_type_ret* ptr_res = res.rep_ptr();

			for (Integer i = 0; i < rc; ++i)
			{
				ptr_res[i] = ptr_A[0];
                ptr_A += A.ld();
			};

            res.set_struct(A.get_struct().get_trans());
            return res;
		};

		Integer lu = kl + ku;
		ret_type res(A.get_ti(),c, r, ku, kl);

        value_type_ret* ptr_res = res.rep_ptr();

		// subdiagonals
		for (Integer d = 1, ist = lu + kl, jst = ku + 1; d <= kl; ++d, ++jst, ist += lu)
		{
			Integer s = (r - d < c) ? r - d : c;
			for (Integer i = 1, ii = ist, jj = jst; i <= s; ++i, ii += res.ld(), jj += A.ld())
            {
				ptr_res[ii] = ptr_A[jj];
            };
		}

		// main & superdiagonals
		for (Integer d = 0, ist = kl, jst = ku ; d <= ku; ++d, jst += A.ld() - 1, ++ist)
		{
			Integer s = (c - d < r) ? c - d : r;
			for (Integer i = 1, ii = ist, jj = jst; i <= s; ++i, ii += res.ld(), jj += A.ld())
            {
				ptr_res[ii] = ptr_A[jj];
            }
		}

        res.set_struct(A.get_struct().get_trans());
		return res;
	};
};
template<class ret_type,class M>
struct eval_trans_helper<ret_type,M,struct_sparse>
{
	static ret_type eval(const M& A)
	{
        if (A.get_struct().is_trans_id()  && A.rows() == A.cols())
        {
            return A;
        };

		typedef M::value_type value_type;

		Integer i, j, k, r = A.rows(), c = A.cols(), n = A.nnz();

		details::spdat<value_type> d(A.get_ti(),c, r, n);
		if (n == 0 || r == 0 || c == 0)
		{
			return sparse_matrix_base<value_type>(d);
		};

		const details::spdat<value_type>& Ad = A.rep();
        const Integer * Ad_c = Ad.ptr_c();
		const Integer * Ad_r = Ad.ptr_r() + Ad.offset();		
		const value_type * Ad_x = Ad.ptr_x() + Ad.offset();

		Integer * d_r = d.ptr_r();
		Integer * d_c = d.ptr_c();
		value_type * d_x = d.ptr_x();

		std::vector<Integer> p(r + 1, 0);

		for (i = 0; i < n; ++i)
        {
            ++p[Ad_r[i] + 1];
        };

		for (k = 0, i = 1; i <= r; ++i)
		{
			p[i]    += k;
            k       = p[i];
            d_c[i]  = p[i];
		}

		Ad_r = Ad.ptr_r();
		Ad_x = Ad.ptr_x();

		for (j = 0; j < c; ++j)
        {
			for (i = Ad_c[j]; i < Ad_c[j + 1]; ++i)
			{
				k = p[Ad_r[i]]++;
				d_r[k] = j;
				d_x[k] = Ad_x[i];
			}
        };

		ret_type res = sparse_matrix_base<value_type>(d);
        res.set_struct(A.get_struct().get_trans());
        return res;
	};
};

template<class ret_type,class M, bool is_complex, class struct_type>
struct eval_ctrans_helper
{};
template<class ret_type,class M, class struct_type>
struct eval_ctrans_helper<ret_type,M,false,struct_type>
{
	static ret_type eval(const M& m)
	{
		return eval_trans_helper<ret_type,M,struct_type>::eval(m);
	};
};
template<class ret_type,class M>
struct eval_ctrans_helper<ret_type,M,true,struct_dense>
{
	static ret_type eval(const M& m)
	{
        if (m.get_struct().is_ctrans_id() && m.rows() == m.cols())
        {
            return m;
        };

		Integer r = m.rows(), c = m.cols();

		ret_type res(m.get_ti(),c, r);

		if (m.size() == 0)
        {
            return res;
        };

        const M::value_type* ptr_m = m.ptr();
        ret_type::value_type* ptr_res = res.ptr();

		for (Integer j = 0; j < r; ++j)
		{
            ptr_m = m.ptr() + j;
			for (Integer i = 0; i < c; ++i, ptr_m += m.ld())
            {
				ptr_res[i] = conj(ptr_m[0]);
            };
            ptr_res += res.ld();
		}

        res.set_struct(m.get_struct().get_ctrans());
		return res;
	};
};
template<class ret_type,class M>
struct eval_ctrans_helper<ret_type,M,true,struct_banded>
{
	static ret_type eval(const M& A)
	{
        if (A.get_struct().is_ctrans_id() && A.rows() == A.cols())
        {
            return A;
        };

		Integer r = A.rows(), c = A.cols(), kl = A.ldiags(), ku = A.udiags();

        typedef typename M::value_type value_type;
        typedef typename ret_type::value_type value_type_ret;

        const value_type* ptr_A = A.rep_ptr();

		if (kl == 0 && ku == 0)
		{
			typedef typename M::value_type value_type;			

			if (gd::is_equal<value_type,Complex>::value)
			{
                ret_type res(A.get_ti(),c, r, 0, 0);
				Integer rc = std::min(r,c);
                value_type_ret* ptr_res = res.rep_ptr();

				for (Integer i = 0; i < rc; ++i)
				{
					ptr_res[i] = conj(ptr_A[0]);
                    ptr_A += A.ld();
				};
                res.set_struct(A.get_struct().get_ctrans());
                return res;
			}
			else
			{
                if (r==c)
                {
                    return A;
                };
                ret_type res(A.get_ti(),c, r, 0, 0);
				Integer rc = std::min(r,c);

                value_type_ret* ptr_res = res.rep_ptr();

				for (Integer i = 0; i < rc; ++i)
				{
					ptr_res[i] = ptr_A[0];
                    ptr_A += A.ld();
				};
                res.set_struct(A.get_struct().get_ctrans());
                return res;
			};			
		};
		
		Integer lu = kl + ku;
		ret_type res(A.get_ti(),c, r, ku, kl);

        value_type_ret* ptr_res = res.rep_ptr();

		// subdiagonals
		for (Integer d = 1, ist = lu + kl, jst = ku + 1; d <= kl; ++d, jst++, ist += lu)
		{
			Integer s = (r - d < c) ? r - d : c;
			for (Integer i = 1, ii = ist, jj = jst; i <= s; ++i, ii += res.ld(), jj += A.ld())
            {
				ptr_res[ii] = conj(ptr_A[jj]);
            }
		}

		// main & superdiagonals
		for (Integer d = 0, ist = kl, jst = ku; d <= ku; ++d, jst += A.ld() - 1, ++ist)
		{
			Integer s = (c - d < r) ? c - d : r;
			for (Integer i = 1, ii = ist, jj = jst; i <= s; ++i, ii += res.ld(), jj += A.ld())
            {
				ptr_res[ii] = conj(ptr_A[jj]);
            };
		}

        res.set_struct(A.get_struct().get_ctrans());
		return res;
	};
};
template<class ret_type,class M>
struct eval_ctrans_helper<ret_type,M,true,struct_sparse>
{
	static ret_type eval(const M& A)
	{
        if (A.get_struct().is_ctrans_id() && A.rows() == A.cols())
        {
            return A;
        };

		typedef M::value_type value_type;

		Integer i, j, k, r = A.rows(), c = A.cols(), n = A.nnz();

		details::spdat<value_type> d(A.get_ti(),c, r, n);
		if (n == 0|| r == 0 || c == 0) 
		{
			return sparse_matrix_base<value_type>(d);
		};
		const details::spdat<value_type>& Ad = A.rep();

		std::vector<Integer> p(r + 1, 0);

        const Integer* Ad_c = Ad.ptr_c();
		const Integer* Ad_r = Ad.ptr_r() + Ad.offset();		
		const value_type* Ad_x = Ad.ptr_x() + Ad.offset();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();

		for (i = 0; i < n; ++i)
        {
            ++p[Ad_r[i] + 1];
        };

		for (k = 0, i = 1; i <= r; ++i)
		{
			p[i]    += k;
            d_c[i]  = p[i];
			k       = p[i];
		};

		Ad_r = Ad.ptr_r();
		Ad_x = Ad.ptr_x();

		for (j = 0; j < c; ++j)
        {
			for (i = Ad_c[j]; i < Ad_c[j + 1]; ++i)
			{
				k = p[Ad_r[i]]++;
				d_r[k] = j;
				d_x[k] = conj(Ad_x[i]);
			}
        };

		ret_type res = sparse_matrix_base<value_type>(d);
        res.set_struct(A.get_struct().get_ctrans());
        return res;
	};
};


template<class M>
typename details::manip_trans_helper<M>::ret_type	details::manip_trans_helper<M>::eval_trans(const M& m)
{
	typedef typename M::struct_type struct_type;
	return eval_trans_helper<ret_type,M,struct_type>::eval(m);
};
template<class M>
typename details::manip_trans_helper<M>::ret_type	details::manip_trans_helper<M>::eval_ctrans(const M& m)
{
	typedef typename M::struct_type struct_type;
	static const bool is_compl = gd::is_equal<M::value_type,Complex>::value;
	return eval_ctrans_helper<ret_type,M,is_compl,struct_type>::eval(m);
};

template<class ret_type,class M,class struct_type>
struct eval_tril_helper
{};
template<class ret_type,class M,class struct_type>
struct eval_triu_helper
{};


template<class ret_type,class M>
struct eval_tril_helper<ret_type,M,struct_dense>
{
	static ret_type eval(const M& A, Integer d)
	{
		Integer r = A.rows(), c = A.cols();		

        if (r == 0 || c == 0)
        {
            return A;
        };

        if (d >= 0 && A.get_struct().is_tril_id())
        {
            return A;
        };

		ret_type res(A.get_ti(),r, c);

		typedef ret_type::value_type value_type;
        typedef M::value_type value_type_in;
        value_type Z = gd::default_value<value_type>(A.get_ti());

        value_type* ptr_res = res.ptr();
        const value_type_in* ptr_A = A.ptr();

		for (Integer j = 0; j < c; ++j)
		{
			Integer mjmdrp1 = (j - d < r) ? j - d : r;
            Integer i;
			for (i = 0; i < mjmdrp1; ++i)
			{
				ptr_res[i] = Z;
			};
			for (; i < r; ++i)
			{
				ptr_res[i] = ptr_A[i];
			};

            ptr_A += A.ld();
            ptr_res += res.ld();
		}

        res.set_struct(A.get_struct().get_tril(d));
		return res;
	};
};
template<class ret_type,class M>
struct eval_triu_helper<ret_type,M,struct_dense>
{
	static ret_type eval(const M& A, Integer d)
	{
		Integer r = A.rows(), c = A.cols();		
    
        if (r == 0 || c == 0)
        {
            return A;
        };

        if (d <= 0 && A.get_struct().is_triu_id())
        {
            return A;
        };        

		ret_type res(A.get_ti(),r, c);
		typedef ret_type::value_type value_type;
        typedef M::value_type value_type_in;
        value_type Z = gd::default_value<value_type>(A.get_ti());

        value_type* ptr_res = res.ptr();
        const value_type_in* ptr_A = A.ptr();

		for (Integer j = 0; j < c; ++j)
		{
			Integer mjmdr = (j - d < r - 1) ? j - d : r - 1;
            Integer i;
			for (i = 0; i <= mjmdr; ++i)
			{
				ptr_res[i] = ptr_A[i];
			};
			for (; i < r; ++i)
			{
				ptr_res[i] = Z;
			};

            ptr_A += A.ld();
            ptr_res += res.ld();
		}

        res.set_struct(A.get_struct().get_triu(d));
		return res;
	};
};

template<class ret_type,class M>
struct eval_tril_helper<ret_type,M,struct_sparse>
{
	static ret_type eval(const M& A, Integer D)
	{
		typedef typename M::value_type value_type;

		Integer Ar = A.rows(), Ac = A.cols(), nnz = A.nnz();		

        if (D >= 0 && A.get_struct().is_tril_id())
        {
            return A;
        };        

		if (nnz == 0 || Ar == 0 || Ac == 0)
		{
			return ret_type(A.get_ti(),Ar,Ac,nnz);
		};
		
		const details::spdat<value_type>& Ad = A.rep();

		ret_type res(A.get_ti(),Ar,Ac,nnz);
		details::spdat<value_type>& d = res.rep();

		const Integer* Ad_r = Ad.ptr_r();
		const Integer* Ad_c = Ad.ptr_c();
		const value_type* Ad_x = Ad.ptr_x();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();		

		Integer pos_r = 0;

		for (Integer j = 0; j < Ac; ++j)
		{
			d_c[j] = pos_r;
			Integer row_start = j - D;
			for (Integer i = Ad_c[j]; i < Ad_c[j+1]; ++i)
			{
				Integer p = Ad_r[i];

				if (p < row_start)
				{
					continue;
				};

				d_r[pos_r] = p;
				d_x[pos_r] = Ad_x[i];
				++pos_r;
			}
		};
		d_c[Ac] = pos_r;

		d.memadd(-1);
        res.set_struct(A.get_struct().get_tril(D));
		return res;
	};
};
template<class ret_type,class M>
struct eval_triu_helper<ret_type,M,struct_sparse>
{
	static ret_type eval(const M& A, Integer D)
	{
		typedef typename M::value_type value_type;

		Integer Ar = A.rows(), Ac = A.cols(), nnz = A.nnz();		

        if (D <= 0 && A.get_struct().is_triu_id())
        {
            return A;
        };

		if (nnz == 0 || Ar == 0 || Ac == 0)
		{
			return A;
		};
		
		const details::spdat<value_type>& Ad = A.rep();

		ret_type res(A.get_ti(),Ar,Ac,nnz);
		details::spdat<value_type>& d = res.rep();

		const Integer* Ad_r = Ad.ptr_r();
		const Integer* Ad_c = Ad.ptr_c();
		const value_type* Ad_x = Ad.ptr_x();

		Integer* d_r = d.ptr_r();
		Integer* d_c = d.ptr_c();
		value_type* d_x = d.ptr_x();		

		Integer pos_r = 0;

		for (Integer j = 0; j < Ac; ++j)
		{
			d_c[j] = pos_r;
			Integer row_start = j - D;
			for (Integer i = Ad_c[j]; i < Ad_c[j+1]; ++i)
			{
				Integer p = Ad_r[i];

				if (p > row_start)
				{
					break;
				};

				d_r[pos_r] = p;
				d_x[pos_r] = Ad_x[i];
				++pos_r;
			}
		};
		d_c[Ac] = pos_r;

		d.memadd(-1);
        res.set_struct(A.get_struct().get_triu(D));
		return res;
	};
};


template<class ret_type,class M>
struct eval_tril_helper<ret_type,M,struct_banded>
{
	static ret_type eval(const M& A, Integer D)
	{
        if (A.rows() == 0 || A.cols() == 0)
        {
            return A;
        };
        if (D >= 0)
        {
		    if (D >= A.udiags())
		    {
			    return A;
		    };
            if (A.get_struct().is_tril_id() || (A.ldiags() == 0 && A.udiags() == 0))
            {
                return A;
            };

            D = std::min(D,A.udiags());
            return A.make_view(1,A.rows(),A.cols(),A.ldiags(),D);
        };

        typedef typename M::value_type val_type_in;
        typedef typename ret_type::value_type val_type;

        val_type Z = gd::default_value<val_type>(A.get_ti());        

		if (D < -A.ldiags())
		{
			ret_type res(A.get_ti(),A.rows(), A.cols(), 0, 0);

            val_type* ptr_res = res.rep_ptr();

			Integer s = res.size();
			for (Integer i = 0; i < s; ++i)
			{
                ptr_res[i] = Z;
			};
            res.set_struct(A.get_struct().get_tril(D));
			return res;
		};

		Integer ret_ldiags = A.ldiags();
		Integer ret_udiags = ((D >= 0)? D: 0 );
        ret_udiags = std::min(ret_udiags, A.udiags());
		ret_type res(A.get_ti(),A.rows(), A.cols(), ret_ldiags, ret_udiags);

        val_type* ptr_res = res.rep_ptr();
        const val_type_in* ptr_A = A.rep_ptr();

		for (Integer i = 1; i <= ret_udiags; ++i)
		{
			Integer A_st	= imult(i,A.ld()) + A.first_elem_pos(i);
			Integer ret_st	= imult(i,res.ld()) + res.first_elem_pos(i);
			Integer s		= std::min(A.cols() - i, A.rows());

			for (Integer i = 1, ii = A_st, jj = ret_st; i <= s; ++i, ii += A.ld(), jj += res.ld())
			{
				ptr_res[jj] = ptr_A[ii];
			};
		};
		for (Integer i = 0; i <= ret_ldiags; ++i)
		{
			Integer A_st	= A.udiags() + i;
			Integer ret_st	= ret_udiags + i;
			Integer s		= std::min(A.rows() - i, A.cols());

			if (i < -D)
			{
				for (Integer i = 1, jj = ret_st; i <= s; ++i, jj += res.ld())
				{
					ptr_res[jj] = Z;
				};
			}
			else
			{
				for (Integer i = 1, ii = A_st, jj = ret_st; i <= s; ++i, ii += A.ld(), jj += res.ld())
				{
					ptr_res[jj] = ptr_A[ii];
				};
			};
		};

        res.set_struct(A.get_struct().get_tril(D));
		return res;
	};
};
template<class ret_type,class M>
struct eval_triu_helper<ret_type,M,struct_banded>
{
	static ret_type eval(const M& A, Integer D)
	{	
        if (A.rows() == 0 || A.cols() == 0)
        {
            return A;
        };

        if (D <= 0 && A.get_struct().is_triu_id())
        {
            return A;
        };

        if (D <= 0)
        {
		    if (D <= -A.ldiags())
		    {
			    return A;
		    };
            if (A.get_struct().is_triu_id() || (A.ldiags() == 0 && A.udiags() == 0))
            {
                return A;
            };

            D = std::min(-D,A.ldiags());

            return A.make_view(1,A.rows(),A.cols(),D,A.udiags());
        };


        typedef typename ret_type::value_type val_type;
        typedef typename M::value_type val_type_in;
        val_type Z = gd::default_value<val_type>(A.get_ti());

		if (D > A.udiags())
		{
			ret_type res(A.get_ti(),A.rows(), A.cols(), 0, 0);
			Integer s = res.size();
            val_type* ptr_res = res.rep_ptr();

			for (Integer i = 0; i < s; ++i)
			{
				ptr_res[i] = Z;
			};
            res.set_struct(A.get_struct().get_triu(D));
			return res;
		};

		Integer ret_udiags = A.udiags();
		Integer ret_ldiags = ((D < 0)? -D: 0 );
        ret_ldiags = std::min(ret_ldiags,A.ldiags());

		ret_type res(A.get_ti(),A.rows(), A.cols(), ret_ldiags, ret_udiags);
        val_type* ptr_res = res.rep_ptr();
        const val_type_in* ptr_A = A.rep_ptr();

		for (Integer i = 0; i <= ret_udiags; ++i)
		{
			Integer A_st	= imult(i,A.ld()) + A.first_elem_pos(i);
			Integer ret_st	= imult(i,res.ld()) + res.first_elem_pos(i);
			Integer s		= std::min(A.cols() - i, A.rows());

			if (i < D)
			{
				for (Integer i = 1, jj = ret_st; i <= s; ++i, jj += res.ld())
				{
					ptr_res[jj] = Z;
				};
			}
			else
			{
				for (Integer i = 1, ii = A_st, jj = ret_st; i <= s; ++i, ii += A.ld(), jj += res.ld())
				{
					ptr_res[jj] = ptr_A[ii];
				};
			};
		};
		for (Integer i = 1; i <= ret_ldiags; ++i)
		{
			Integer A_st	= A.udiags() + i;
			Integer ret_st	= ret_udiags + i;
			Integer s		= std::min(A.rows() - i, A.cols());

			for (Integer i = 1, ii = A_st, jj = ret_st; i <= s; ++i, ii += A.ld(), jj += res.ld())
			{
				ptr_res[jj] = ptr_A[ii];
			};
		};

        res.set_struct(A.get_struct().get_triu(D));
		return res;
	};
};

template<class M>
typename details::manip_tr_helper<M>::ret_type_tril	
details::manip_tr_helper<M>::eval_tril(const M& A, Integer d)
{
	typedef typename M::struct_type struct_type;
	return eval_tril_helper<ret_type_tril,M,struct_type>::eval(A,d);
};

template<class M>
typename details::manip_tr_helper<M>::ret_type_triu	
details::manip_tr_helper<M>::eval_triu(const M& A, Integer d)
{
	typedef typename M::struct_type struct_type;
	return eval_triu_helper<ret_type_triu,M,struct_type>::eval(A,d);
};

template<class V>
Integer raw::get_ld(const Matrix<V,struct_sparse>& A, Integer min, bool use_flag)
{
	if (A.nnz() == 0)
	{
		return 0;
	};
    //struct switch
    if (use_flag == true)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::zero:
            case struct_flag::id:
            case struct_flag::diag:
            case struct_flag::triu:     
                return 0;
        };
    };

    Integer r = A.rows(), c = A.cols();
	typedef V val_type;

    const details::spdat<val_type>& Ad = A.rep();
	const Integer * Ad_c = Ad.ptr_c();
	const Integer * Ad_r = Ad.ptr_r();
	const val_type* Ad_x = Ad.ptr_x();

	Integer ld = 0;
	for (Integer j = 0; j < c; ++j)
	{
		Integer k = Ad_c[j+1]-1;
		while(k >= Ad_c[j])
		{
            if (mmlib::details::is_zero(Ad_x[k]))
			{
				--k;
				continue;
			};
			Integer pos = Ad_r[k] - j;
			ld = std::max(ld,pos);

            if (r - 1 - j <= ld)
            {
                return ld;
            };
			break;
		};
        if (min >= 0 && ld > min)
        {
            return ld;
        };
	};
	return ld;
};

template<class V>
Integer raw::get_ud(const Matrix<V,struct_sparse>& A, Integer min, bool use_flag)
{
	Integer c = A.cols();
	if (A.nnz() == 0)
	{
		return 0;
	};

    if (use_flag)
    {
        //struct switch
        switch(A.get_struct().get())
        {
            case struct_flag::zero:
            case struct_flag::id:
            case struct_flag::diag:
            case struct_flag::tril:
                return 0;
        };
    };

	typedef V val_type;

    const details::spdat<val_type>& Ad = A.rep();
	const Integer * Ad_c = Ad.ptr_c();
	const Integer * Ad_r = Ad.ptr_r();
	const val_type* Ad_x = Ad.ptr_x();

	Integer ud = 0;
	for (Integer j = c-1; j >= 0; --j)
	{
		Integer k = Ad_c[j];
		while(k < Ad_c[j+1])
		{
            if (mmlib::details::is_zero(Ad_x[k]))
			{
				++k;
				continue;
			};
			Integer pos = j - Ad_r[k];
			ud = std::max(ud,pos);

            if (j <= ud)
            {
                return ud;
            };
			break;
		};
        if (min >= 0 && ud > min)
        {
            return ud;
        };
	};
	return ud;
};

template<class V>
Integer raw::get_ld(const Matrix<V,struct_dense>& A, Integer min, bool use_flag)
{
    Integer r = A.rows(), c = A.cols();
	typedef V val_type;

    bool isq = false;

    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::zero:
            case struct_flag::id:
            case struct_flag::diag:
            case struct_flag::triu:     
                return 0;
            case struct_flag::qtriu:
                isq = true;
                break;
        };
    };

	const val_type* ptr = A.ptr();

    if (isq)
    {
        if (min >= 1)
        {
            return 1;
        };

	    for (Integer j = 0; j < c; ++j)
	    {
            Integer i = j+1;
            if (i >= r)
            {
                return 0;
            };
            if (mmlib::details::is_zero(ptr[i]) == false)
		    {
			    return 1;
		    };
            ptr += A.ld();
	    };
	    return 0;
    };

	Integer ld = 0;
	for (Integer j = 0; j < c; ++j)
	{
		Integer k = r-1;
		while(k >= 0)
		{
            if (mmlib::details::is_zero(ptr[k]))
			{
				--k;
				continue;
			};
			Integer pos = k - j;
			ld = std::max(ld,pos);

            if (r - 1 - j <= ld)
            {
                return ld;
            };
			break;
		};
        ptr += A.ld();

        if (min >= 0 && ld > min)
        {
            return ld;
        };
	};
	return ld;
};

template<class V>
Integer raw::get_ud(const Matrix<V,struct_dense>& A, Integer min, bool use_flag)
{
	Integer r = A.rows(), c = A.cols();
    bool isq = false;

	typedef V val_type;

    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::zero:
            case struct_flag::id:
            case struct_flag::diag:
            case struct_flag::tril:
                return 0;
            case struct_flag::qtril:
            {
                isq = true;
                break;
            };
        };
    };

    if (isq)
    {
        if (min >= 1)
        {
            return 1;
        };

        const val_type* ptr = A.ptr() + A.ld();

	    for (Integer j = 1; j < c; ++j)
	    {
            Integer i = j-1;
            if (i >= r)
            {
                return 0;
            };
            if (mmlib::details::is_zero(ptr[i]) == false)
		    {
			    return 1;
		    };
            ptr += A.ld();
	    };
	    return 0;
    };

	const val_type* ptr = A.ptr() + imult(c-1,A.ld());

	Integer ud = 0;
	for (Integer j = c-1; j >= 0; --j)
	{
		Integer k = 0;
		while(k < r)
		{
            if (mmlib::details::is_zero(ptr[k]))
			{
				++k;
				continue;
			};
			Integer pos = j - k;
			ud = std::max(ud,pos);

            if (j <= ud)
            {
                return ud;
            };
			break;
		};
        ptr -= A.ld();
        if (min >= 0 && ud > min)
        {
            return ud;
        };
	};
	return ud;
};

template<class V>
Integer raw::get_ld(const Matrix<V,struct_banded>& A, Integer min, bool use_flag)
{
    Integer ld = A.ldiags();
    Integer r = A.rows(), c = A.cols();

    if (ld == 0 || r == 0 || c == 0)
    {
        return 0;
    };

    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::zero:
            case struct_flag::id:
            case struct_flag::diag:
            case struct_flag::triu:     
                return 0;
            case struct_flag::qtriu:
            {
                ld = 1;
                break;
            }
        };
    };
   
    min = std::max(min,0L);    

    while(ld > min)
    {
		Integer fc = A.first_col(ld);
        Integer	s = std::min(r-ld,c);

        const V* ptr = A.rep_ptr() + A.udiags() + ld + fc*A.ld();

        for (Integer i = 0; i < s; ++i)
        {
            if (mmlib::details::is_zero(ptr[0]) == false)
            {
                return ld;
            };
            ptr += A.ld();
        };
        --ld;
        if (min >= 0 && ld <= min)
        {
            return ld;
        };
    };

    return ld;
};
template<class V>
Integer raw::get_ud(const Matrix<V,struct_banded>& A, Integer min, bool use_flag)
{
    Integer ud = A.udiags();
    Integer r = A.rows(), c = A.cols();

    if (ud == 0 || r == 0 || c == 0)
    {
        return 0;
    };

    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::zero:
            case struct_flag::id:
            case struct_flag::diag:
            case struct_flag::tril:
                return 0;
            case struct_flag::qtril:
            {
                ud = 1;
                break;
            }
        };
    };

    min = std::max(min,0L);    

    while(ud > min)
    {
        Integer	s = std::min(r,c-ud);

        const V* ptr = A.rep_ptr() + A.first_elem_pos(ud) + ud*A.ld();

        for (Integer i = 0; i < s; ++i)
        {
            if (mmlib::details::is_zero(ptr[0]) == false)
            {
                return ud;
            };
            ptr += A.ld();
        };
        --ud;
        if (min >= 0 && ud <= min)
        {
            return ud;
        };
    };

    return ud;
};

template<class V> struct is_real_type   { static const bool value = false; };
template<> struct is_real_type<Integer> { static const bool value = true; };
template<> struct is_real_type<Real>    { static const bool value = true; };

template<class V>
bool raw::is_sym(const Matrix<V,struct_dense>& A, bool use_flag)
{
    if (A.rows() != A.cols())
    {
        return false;
    };
    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::id:
            case struct_flag::zero:
            case struct_flag::diag:
            case struct_flag::sym:
            {
                return true;
            }            
            case struct_flag::her:
            {
                bool is_real = is_real_type<V>::value;
                if (is_real == true)
                {
                    return true;
                };
            }
        };
    };

    Integer s = A.rows();
    const V* ptr_0 = A.ptr();
    const V* ptr = ptr_0;

    for (Integer i = 0; i < s; ++i)
    {
        const V* ptr_s = ptr_0 + i + i*A.ld();
        for (Integer k = i; k < s; ++k)
        {
            V val1 = ptr[k];
            V val2 = ptr_s[0];

            if (val1 != val2 && is_nan(val1) == false)
            {
                return false;
            };

            ptr_s += A.ld();
        };

        ptr += A.ld();
    };
    return true;
};
template<class V>
bool raw::is_her(const Matrix<V,struct_dense>& A, bool use_flag)
{
    if (A.rows() != A.cols())
    {
        return false;
    };
    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::id:
            case struct_flag::zero:
            case struct_flag::her:
                return true;
            case struct_flag::diag:
            case struct_flag::sym:
            {
                bool is_real = is_real_type<V>::value;
                if (is_real == true)
                {
                    return true;
                };
            }            
        };
    };

    Integer s = A.rows();
    const V* ptr_0 = A.ptr();
    const V* ptr = ptr_0;

    for (Integer i = 0; i < s; ++i)
    {
        const V* ptr_s = ptr_0 + i + i*A.ld();
        for (Integer k = i; k < s; ++k)
        {
            V val1 = ptr[k];
            V val2 = ptr_s[0];

            if (val1 != conj(val2) && is_nan(val1) == false)
            {
                return false;
            };

            ptr_s += A.ld();
        };

        ptr += A.ld();
    };
    return true;
};

template<class V>
bool raw::is_sym(const Matrix<V,struct_banded>& A, bool use_flag)
{
    if (A.rows() != A.cols())
    {
        return false;
    };
    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::id:
            case struct_flag::zero:
            case struct_flag::diag:
            case struct_flag::sym:
            {
                return true;
            }            
            case struct_flag::her:
            {
                bool is_real = is_real_type<V>::value;
                if (is_real == true)
                {
                    return true;
                };
            }
        };
    };

    Integer ld = raw::get_ld(A,-1,use_flag);
    Integer ud = raw::get_ud(A,-1,use_flag);

    Integer r = A.rows();

    if (ld != ud)
    {
        return false;
    };

    for (Integer i = 1; i < ld; ++i)
    {
        Integer s = r-i;
        const V* ptr_l = A.rep_ptr() + A.udiags() + i;
        const V* ptr_u = A.rep_ptr() + A.udiags() - i + i * A.ld();

        for (Integer j = 0; j < s; ++j)
        {
            V val1 = ptr_l[0];
            V val2 = ptr_u[0];

            if (val1 != val2 && is_nan(val1) == false)
            {
                return false;
            };

            ptr_l += A.ld();
            ptr_u += A.ld();
        };
    };

    return true;
};
template<class V>
bool raw::is_her(const Matrix<V,struct_banded>& A, bool use_flag)
{
    if (A.rows() != A.cols())
    {
        return false;
    };
    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::id:
            case struct_flag::zero:
            case struct_flag::her:
                return true;
            case struct_flag::diag:
            case struct_flag::sym:
            {
                bool is_real = is_real_type<V>::value;
                if (is_real == true)
                {
                    return true;
                };
            }            
        };
    };

    Integer ld = raw::get_ld(A,-1,use_flag);
    Integer ud = raw::get_ud(A,-1,use_flag);

    Integer r = A.rows();

    if (ld != ud)
    {
        return false;
    };

    for (Integer i = 0; i < ld; ++i)
    {
        Integer s = r-i;
        const V* ptr_l = A.rep_ptr() + A.udiags() + i;
        const V* ptr_u = A.rep_ptr() + A.udiags() - i + i * A.ld();

        for (Integer j = 0; j < s; ++j)
        {
            V val1 = ptr_l[0];
            V val2 = ptr_u[0];

            if (val1 != conj(val2) && is_nan(val1) == false)
            {
                return false;
            };

            ptr_l += A.ld();
            ptr_u += A.ld();
        };
    };

    return true;
};

template<class V>
bool raw::is_sym(const Matrix<V,struct_sparse>& A, bool use_flag)
{
    if (A.rows() != A.cols())
    {
        return false;
    };
    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::id:
            case struct_flag::zero:
            case struct_flag::diag:
            case struct_flag::sym:
            {
                return true;
            }            
            case struct_flag::her:
            {
                bool is_real = is_real_type<V>::value;
                if (is_real == true)
                {
                    return true;
                };
            }
        };
    };
    if (A.nnz() == 0)
    {
        return true;
    };

    Integer ld = raw::get_ld(A,-1,use_flag);
    Integer ud = raw::get_ud(A,-1,use_flag);

    if (ld != ud)
    {
        return false;
    };

    const Integer* ptr_c    = A.rep().ptr_c();
    const Integer* ptr_r    = A.rep().ptr_r();
    const V* ptr_x          = A.rep().ptr_x();

    for (Integer j = 0; j < A.cols(); ++j)
    {
        for (Integer k = ptr_c[j]; k < ptr_c[j+1]; ++k)
        {
            Integer r = ptr_r[k];
            if (r <= j)
            {
                continue;
            };

            V val1 = ptr_x[k];
            V val2 = A.rep().get_elem(j,r);

            if (val1 != val2 && is_nan(val1) == false)
            {
                return false;
            };
        };
    };

    return true;
};
template<class V>
bool raw::is_her(const Matrix<V,struct_sparse>& A, bool use_flag)
{
    if (A.rows() != A.cols())
    {
        return false;
    };
    //struct switch
    if (use_flag)
    {
        switch(A.get_struct().get())
        {
            case struct_flag::id:
            case struct_flag::zero:
            case struct_flag::her:
                return true;
            case struct_flag::diag:
            case struct_flag::sym:
            {
                bool is_real = is_real_type<V>::value;
                if (is_real == true)
                {
                    return true;
                };
            }            
        };
    };
    if (A.nnz() == 0)
    {
        return true;
    };

    Integer ld = raw::get_ld(A,-1,use_flag);
    Integer ud = raw::get_ud(A,-1,use_flag);

    if (ld != ud)
    {
        return false;
    };

    const Integer* ptr_c    = A.rep().ptr_c();
    const Integer* ptr_r    = A.rep().ptr_r();
    const V* ptr_x          = A.rep().ptr_x();

    for (Integer j = 0; j < A.cols(); ++j)
    {
        for (Integer k = ptr_c[j]; k < ptr_c[j+1]; ++k)
        {
            Integer r = ptr_r[k];
            if (r < j)
            {
                continue;
            };

            V val1 = ptr_x[k];

            if (r == j)
            {
                if (val1 != conj(val1) && is_nan(val1) == false)
                {
                    return false;
                };
                continue;
            };
            
            V val2 = A.rep().get_elem(j,r);

            if (val1 != conj(val2))
            {
                return false;
            };
        };
    };

    return true;
};

template mmlib::raw::IntegerMatrix mmlib::raw::full(const mmlib::raw::IntegerSparseMatrix&);
template mmlib::raw::RealMatrix mmlib::raw::full(const mmlib::raw::RealSparseMatrix&);
template mmlib::raw::ComplexMatrix mmlib::raw::full(const mmlib::raw::ComplexSparseMatrix&);
template mmlib::raw::ObjectMatrix mmlib::raw::full(const mmlib::raw::ObjectSparseMatrix&);

template Matrix<Integer,struct_sparse> sparse(const Matrix<Integer,struct_dense>&);
template Matrix<Real,struct_sparse> sparse(const Matrix<Real,struct_dense>&);
template Matrix<Complex,struct_sparse> sparse(const Matrix<Complex,struct_dense>&);
template Matrix<Object,struct_sparse> sparse(const Matrix<Object,struct_dense>&);

template Matrix<Integer,struct_sparse> sparse(const Matrix<Integer,struct_banded>&);
template Matrix<Real,struct_sparse> sparse(const Matrix<Real,struct_banded>&);
template Matrix<Complex,struct_sparse> sparse(const Matrix<Complex,struct_banded>&);
template Matrix<Object,struct_sparse> sparse(const Matrix<Object,struct_banded>&);

template Matrix<Integer,struct_banded> band(const Matrix<Integer,struct_dense>&);
template Matrix<Real,struct_banded> band(const Matrix<Real,struct_dense>&);
template Matrix<Complex,struct_banded> band(const Matrix<Complex,struct_dense>&);
template Matrix<Object,struct_banded> band(const Matrix<Object,struct_dense>&);

template Matrix<Integer,struct_banded> band(const Matrix<Integer,struct_sparse>&);
template Matrix<Real,struct_banded> band(const Matrix<Real,struct_sparse>&);
template Matrix<Complex,struct_banded> band(const Matrix<Complex,struct_sparse>&);
template Matrix<Object,struct_banded> band(const Matrix<Object,struct_sparse>&);

};};

MACRO_INSTANTIATE_G_1(mmlib::raw::details::manip_reshape_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::manip_reshape_helper)

MACRO_INSTANTIATE_G_1(mmlib::raw::details::manip_trans_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::manip_trans_helper)

MACRO_INSTANTIATE_G_1(mmlib::raw::details::manip_tr_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::manip_tr_helper)

template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::IntegerSparseMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::RealSparseMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::ComplexSparseMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::ObjectSparseMatrix&, Integer, bool);

template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::IntegerSparseMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::RealSparseMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::ComplexSparseMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::ObjectSparseMatrix&, Integer, bool);

template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::IntegerMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::RealMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::ComplexMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::ObjectMatrix&, Integer, bool);

template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::IntegerMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::RealMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::ComplexMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::ObjectMatrix&, Integer, bool);

template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::IntegerBandMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::RealBandMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::ComplexBandMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ld(const mmlib::raw::ObjectBandMatrix&, Integer, bool);

template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::IntegerBandMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::RealBandMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::ComplexBandMatrix&, Integer, bool);
template mmlib::Integer mmlib::raw::get_ud(const mmlib::raw::ObjectBandMatrix&, Integer, bool);


template bool mmlib::raw::is_sym(const mmlib::raw::IntegerSparseMatrix&, bool);
template bool mmlib::raw::is_sym(const mmlib::raw::RealSparseMatrix&, bool);
template bool mmlib::raw::is_sym(const mmlib::raw::ComplexSparseMatrix&, bool);
template bool mmlib::raw::is_sym(const mmlib::raw::ObjectSparseMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::IntegerSparseMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::RealSparseMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::ComplexSparseMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::ObjectSparseMatrix&, bool);

template bool mmlib::raw::is_sym(const mmlib::raw::IntegerMatrix&, bool);
template bool mmlib::raw::is_sym(const mmlib::raw::RealMatrix&, bool);
template bool mmlib::raw::is_sym(const mmlib::raw::ComplexMatrix&, bool);
template bool mmlib::raw::is_sym(const mmlib::raw::ObjectMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::IntegerMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::RealMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::ComplexMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::ObjectMatrix&, bool);

template bool mmlib::raw::is_sym(const mmlib::raw::IntegerBandMatrix&, bool);
template bool mmlib::raw::is_sym(const mmlib::raw::RealBandMatrix&, bool);
template bool mmlib::raw::is_sym(const mmlib::raw::ComplexBandMatrix&, bool);
template bool mmlib::raw::is_sym(const mmlib::raw::ObjectBandMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::IntegerBandMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::RealBandMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::ComplexBandMatrix&, bool);
template bool mmlib::raw::is_her(const mmlib::raw::ObjectBandMatrix&, bool);

#pragma warning( pop )