/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <iostream>
#include "mmlib/container/raw/type_decl.h"
#include "mmlib/disp_stream.h"

namespace mmlib { namespace raw
{

namespace details
{
    template<class V, class S>
    struct disp_helper
    {
        typedef raw::Matrix<V,S> matrix_type;
        static void eval(disp_stream& os, const matrix_type& mat);
    };
};

output_stream& get_console_output();

void disp(disp_stream& os, char* v);
inline void disp(char* v)		
{ 
	disp_stream tmp(get_console_output());
	return raw::disp(tmp,v); 
};

void disp(disp_stream& os, const std::string& v);
inline void disp(const std::string& v)
{
	disp_stream tmp(get_console_output());
	return raw::disp(tmp,v); 
};

void disp(disp_stream& os, Integer v);
inline void disp(Integer v)
{
	disp_stream tmp(get_console_output());
	return raw::disp(tmp,v); 
};

inline void disp(disp_stream& os, int i) 
{ 
	raw::disp(os,(Integer) i); 
}
inline void disp(int i) 
{ 
	disp_stream tmp(get_console_output());
	raw::disp(tmp,(Integer) i); 
}

void disp(disp_stream & os, const Real& v);
inline void disp(const Real& v)
{
	disp_stream tmp(get_console_output());
	return raw::disp(tmp,v); 
};

void disp(disp_stream &os, const Complex& v);
inline void disp(const Complex& v)
{
	disp_stream tmp(get_console_output());
	return raw::disp(tmp,v); 
};

void disp(disp_stream &os, const Object& v);
inline void disp(const Object& v)
{
	disp_stream tmp(get_console_output());
	return raw::disp(tmp,v); 
};

template<class value_type>
inline void disp(disp_stream& os, const Matrix<value_type,struct_dense>& m)
{
    details::disp_helper<value_type,struct_dense>::eval(os,m);
};

template<class value_type>
inline void disp(disp_stream& os, const Matrix<value_type,struct_sparse>& m)
{
    details::disp_helper<value_type,struct_sparse>::eval(os,m);
};

template<class value_type>
inline void disp(disp_stream& os, const Matrix<value_type,struct_banded>& m)
{
    details::disp_helper<value_type,struct_banded>::eval(os,m);
};


template<class value_type>
inline void disp(const Matrix<value_type,struct_dense>& v)
{
	return raw::disp(disp_stream(std::cout),v); 
};

template<class value_type>
inline void disp(const Matrix<value_type,struct_sparse>& v)
{
	return raw::disp(disp_stream(std::cout),v); 
};

template<class value_type>
inline void disp(const Matrix<value_type,struct_banded>& v)
{
	return raw::disp(disp_stream(std::cout),v); 
};

}};