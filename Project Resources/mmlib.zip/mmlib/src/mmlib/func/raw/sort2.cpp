/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/sort2.h"
#include "mmlib/mp/instantiate.h"
#include <vector>
#include "mmlib/constants.h"
#include <boost/iterator/iterator_facade.hpp>
#include <algorithm>
#include "mmlib/error/error_check.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/base/sort_iterator.h"
#include "mmlib/func/raw/eval_vec_functor2.h"
#include "mmlib/base/colon_info.h"
#include "mmlib/func/raw/scalfunc.h"
#include "mmlib/algs/sparse_algs.h"
#include "mmlib/utils/utils.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/manip.h"

namespace mmlib { namespace raw { namespace details
{

template<class T> struct min_value {};
template<> struct min_value<Integer> { static Integer eval() {return constants::MinInt;};	};
template<> struct min_value<Real>	 { static Real eval()	 {return -constants::Inf;};	};
template<> struct min_value<Complex> { static Complex eval() {return 0.;};		};

template<class T>
struct greater_nan
{
	static bool eval(T A, T B)
	{
        gd::type_info ti = gd::get_raw_ti();

		if (isnan_helper<T>::eval(ti,B))
		{
			return false;
		};
		if (isnan_helper<T>::eval(ti,A))
		{
			return true;
		};
		return gt_helper<T,T>::eval(ti,A,B);
	};
};
template<class T>
struct less_nan
{
	static bool eval(T A, T B)
	{
        gd::type_info ti = gd::get_raw_ti();

		if (isnan_helper<T>::eval(ti,A))
		{
			return false;
		};
		if (isnan_helper<T>::eval(ti,B))
		{
			return true;
		};
		return lt_helper<T,T>::eval(ti,A,B);
	};
};
template<class T>
struct leq_nan
{
	static bool eval(T A, T B)
	{
        gd::type_info ti = gd::get_raw_ti();

		if (isnan_helper<T>::eval(ti,A))
		{
			if (isnan_helper<T>::eval(ti,B))
			{
				return true;
			}
			else
			{
				return false;
			};
		};
		if (isnan_helper<T>::eval(ti,B))
		{
			return true;
		};
		return leq_helper<T,T>::eval(ti,A,B);
	};
};

template<class T>
class iterator_helper_1 : public boost::iterator_facade
								<	iterator_helper_1<T>,
									T,
								  	boost::random_access_traversal_tag
								>
{
	private:
		T*			x_ptr;
		Integer		ld;

	public:
		iterator_helper_1()						:x_ptr(NULL),ld(0){};
		iterator_helper_1(T* x_ptr, Integer ld) :x_ptr(x_ptr),ld(ld)
		{
		};

	private:
		friend class boost::iterator_core_access;

		void increment() 
		{ 
			x_ptr += ld; 
		};
		void decrement() 
		{ 
			x_ptr -= ld; 
		};
		bool equal(iterator_helper_1 const& other) const
		{
			return this->x_ptr == other.x_ptr;
		}
		T& dereference() const 
		{ 
			return *x_ptr; 
		};
		difference_type distance_to(iterator_helper_1 j) const
		{
			return (j.x_ptr - this->x_ptr)/ld;
		}
		void advance(difference_type n)
		{
			this->x_ptr	+= imult(ld,n);
		};
};

template<class value_type>
struct value_compare
{
	bool operator()(value_type A, value_type B)
	{
		return less_nan<value_type>::eval(A,B);
	};
};

template<class ret_type, class in_type, class struct_type>
struct sort_impl{};

template<class ret_type, class in_type>
struct sort_impl<ret_type,in_type,struct_dense>
{
    static ret_type eval(gd::type_info ret_ti,const in_type& m, Integer dim)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_ret;

		error::check_dim(dim);

		Integer r = m.rows(), c = m.cols();

		if (r == 0 || c == 0) 
		{
			return ret_type(ret_ti,r, c);
		};

		ret_type tmp = copy(m);
        tmp.get_struct().reset(true);

        value_type_ret* ptr_tmp = tmp.ptr();

		if (dim == 1)
		{
			for (Integer i = 0; i < c; ++i)
			{
				std::stable_sort(ptr_tmp, ptr_tmp + r,value_compare<value_type>());
                ptr_tmp += tmp.ld();
			};
		}
		else
		{
			Integer lda = tmp.ld();
			for (Integer i = 0; i < r; ++i)
			{
				iterator_helper_1<value_type> it_begin(ptr_tmp+i,lda);
				iterator_helper_1<value_type> it_end(ptr_tmp+i+imult(c,lda),lda);
				std::stable_sort(it_begin, it_end,value_compare<value_type>());
			};
		};

		return tmp;
	};
	static ret_type eval(gd::type_info ret_ti,const in_type& m, Integer dim, IntegerMatrix& ind)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_ret;

		Integer r = m.rows(), c = m.cols();
		error::check_dim(dim);

		ind.reset_unique(r,c);

		if (r == 0 || c == 0) 
		{
			return ret_type(ret_ti,r, c);
		};

		ret_type tmp = copy(m);
        tmp.get_struct().reset(true);

        Integer* ptr_ind = ind.ptr();
        value_type_ret* ptr_tmp = tmp.ptr();

		if (dim == 1)
		{
			for (Integer j = 0; j < c; ++j)
			{
				for (Integer i = 0; i < r; ++i)
				{
					ptr_ind[i] = i+1;
				};
                ptr_ind += ind.ld();
			};
            ptr_ind = ind.ptr();

			for (Integer i = 0; i < c; ++i)
			{
                typedef mmlib::details::iterator_helper_2<value_type,Integer> iterator;
				iterator it_begin(ptr_tmp,ptr_ind,1);
				iterator it_end(ptr_tmp + r,ptr_ind + r,1);
				std::stable_sort(it_begin, it_end,mmlib::details::value_ind_compare<value_type,Integer>());

                ptr_tmp += tmp.ld();
                ptr_ind += ind.ld();
			};
		}
		else
		{
			for (Integer j = 0; j < c; ++j)
			{
				for (Integer i = 0; i < r; ++i)
				{
					ptr_ind[i] = j+1;
				};
                ptr_ind += ind.ld();
			};
            ptr_ind = ind.ptr();

            //ind and tmp are fresh and have ld == r
			Integer ld = r;
			for (Integer i = 0; i < r; ++i)
			{
                typedef mmlib::details::iterator_helper_2<value_type,Integer> iterator;
				iterator it_begin(ptr_tmp+i,ptr_ind+i,ld);
				iterator it_end(ptr_tmp+i+imult(c,ld),ptr_ind+i+imult(c,ld), ld);
				std::stable_sort(it_begin, it_end,mmlib::details::value_ind_compare<value_type,Integer>());
			};
		};

		return tmp;
	};
};
template<class ret_type, class in_type>
struct sort_impl<ret_type,in_type,struct_sparse>
{
	static ret_type eval(gd::type_info ,const in_type& m, Integer dim)
	{
		Integer nz = m.nnz();

		error::check_dim(dim);

		if (nz == 0)
		{
			return m;
		};
		
		if (dim == 2)
		{
			in_type tmp = trans(m);
            if (tmp.is_unique() == false)
            {
                tmp.assign(tmp.copy());
            };
			eval_inplace(tmp);
			return trans(tmp);
		};
		in_type tmp = copy(m);
        tmp.get_struct().reset(true);
		eval_inplace(tmp);
		return tmp;
	};
	static void eval_inplace(in_type& m)
	{
		Integer r = m.rows(), c = m.cols(), nz = m.nnz();

		if (nz == 0)
		{
			return;
		};
		typedef in_type::value_type val_type;
        const val_type Z = gd::default_value<val_type>(gd::get_ti(m));

        m.get_struct().reset(true);

		spdat<val_type>& d = m.rep();

		const Integer* d_c	= d.ptr_c();
		Integer* d_r		= d.ptr_r();
		val_type* d_x		= d.ptr_x();

		for (Integer j = 0; j < c; ++j)
		{
			Integer start = d_c[j];
			Integer end = d_c[j+1];
			Integer nz = end - start;
			if (nz == 0)
			{
				continue;
			}
			if (nz == 1)
			{
				val_type tmp = d_x[start];
				if(less_nan<val_type>::eval(tmp,Z))
				{
					d_r[start] = 0;
				}
				else
				{
					d_r[start] = r-1;
				};
				
				continue;
			};

			std::stable_sort(d_x+start,d_x+start + nz,value_compare<val_type>());

			Integer k = start, pos = 0;
			for (; k < end; ++k)
			{
				if (leq_nan<val_type>::eval(d_x[k],Z))
				{
					d_r[k] = pos;
					++pos;
				}
				else
				{
					break;
				};
			};
			if (k == end)
			{
				continue;
			};

			pos += (r-nz);

			for (; k < end; ++k)
			{
				d_r[k] = pos;
				++pos;
			};
		};
		return;
	};
	static ret_type eval(gd::type_info ,const in_type& m, Integer dim, IntegerMatrix& ind)
	{
		Integer r = m.rows(), c = m.cols(), nz = m.nnz();

		error::check_dim(dim);

		if (nz == 0)
		{
			ind.reset_unique(r,c);
            Integer* ptr_ind = ind.ptr();

			if (dim == 1)
			{
				for (Integer j = 0; j < c; ++j)
				{
					for (Integer i = 0; i < r; ++i)
					{
						ptr_ind[i] = i+1;
					};
                    ptr_ind += ind.ld();
				};
			}
			else
			{
				for (Integer j = 0; j < c; ++j)
				{
					for (Integer i = 0; i < r; ++i)
					{
						ptr_ind[i] = j+1;
					};
                    ptr_ind += ind.ld();
				};
			};
			return m;
		};

		if (dim == 2)
		{
			in_type tmp = trans(m);
            if (tmp.is_unique() == false)
            {
                tmp.assign(tmp.copy());
            };
			eval_inplace(tmp,ind,true);
			return trans(tmp);
		};
		in_type tmp = copy(m);
        tmp.get_struct().reset(true);
		eval_inplace(tmp,ind,false);
		return tmp;
	};
	static void eval_inplace(in_type& m, IntegerMatrix& ind, bool trans)
	{
		Integer r = m.rows(), c = m.cols(), nz = m.nnz();

		if (nz == 0)
		{			
			if (trans == false)
			{
				ind.reset_unique(r,c);
                Integer* ptr_ind = ind.ptr();
				for (Integer j = 0; j < c; ++j)
				{
					for (Integer i = 0; i < r; ++i)
					{
						ptr_ind[i] = i+1;
					};
                    ptr_ind += ind.ld();
				};
			}
			else
			{
				ind.reset_unique(c,r);
                Integer* ptr_ind = ind.ptr();

				for (Integer j = 0; j < r; ++j)
				{
					for (Integer i = 0; i < c; ++i)
					{
						ptr_ind[i] = j+1;
					};
                    ptr_ind += ind.ld();
				};
			};
			return;
		};

		if (trans == false)
		{
			ind.reset_unique(r,c);
		}
		else
		{
			ind.reset_unique(c,r);
		};

		typedef in_type::value_type val_type;
        const val_type Z = gd::default_value<val_type>(gd::get_ti(m));

		spdat<val_type>& d = m.rep();

        m.get_struct().reset(true);

		const Integer* d_c	= d.ptr_c();
		Integer* d_r		= d.ptr_r();
		val_type* d_x		= d.ptr_x();

		std::vector<Integer> flags(r,-1);
        Integer* ptr_ind = ind.ptr();
		
		for (Integer j = 0; j < c; ++j)
		{
			Integer start = d_c[j];
			Integer end = d_c[j+1];
			Integer nz = end - start;

			if (nz == 0)
			{
				if (trans == false)
				{
					Integer pos = imult(j,r);
					for (Integer i = 0; i < r; ++i, ++pos)
					{
						ptr_ind[pos] = i+1;
					};
				}
				else
				{
					Integer pos = j;
					for (Integer i = 0; i < r; ++i, pos += c)
					{
						ptr_ind[pos] = i+1;
					};
				};
				continue;
			}
			if (nz > 1)
			{
                typedef mmlib::details::iterator_helper_2<val_type,Integer> iterator;
				iterator it_begin(&d_x[start],&d_r[start],1);
				iterator it_end(&d_x[start] + nz,&d_r[start] + nz,1);
				std::stable_sort(it_begin, it_end,mmlib::details::value_ind_compare<val_type,Integer>());
			};			

			for (Integer p = start; p < end; ++p)
			{
				flags[d_r[p]] = j;
			};

			Integer k = start, pos = 0, pos_ind, dpos_ind;
			if (trans == false)
			{
				pos_ind = imult(j,r);
				dpos_ind = 1;
			}
			else
			{
				pos_ind = j;
				dpos_ind = c;
			};
			for (; k < end; ++k)
			{
				if (less_nan<val_type>::eval(d_x[k],Z))
				{
					ptr_ind[pos_ind] = d_r[k]+1;
					d_r[k] = pos;
					++pos;
					pos_ind += dpos_ind;
				}
				else if (d_x[k] == Z)
				{
					flags[d_r[k]] = j-1;
					d_r[k] = pos;
					++pos;
				}
				else
				{
					break;
				};
			};

			for (Integer i = 0; i < r; ++i)
			{
				if (flags[i] < j)
				{
					ptr_ind[pos_ind] = i+1;
					pos_ind += dpos_ind;
				};
			};

			pos += (r-nz);

			for (; k < end; ++k)
			{
				ptr_ind[pos_ind] = d_r[k]+1;
				d_r[k] = pos;
				++pos;
				pos_ind += dpos_ind;
			};
		};
		return;
	};
};

template<class T>
struct row_info
{
	private:
		const T*	ptr;
		Integer		ld;
		Integer		cols;
		Integer		pos;

	public:
		row_info(const T* ptr, Integer ld, Integer cols)	
			:ptr(ptr),ld(ld),cols(cols),pos(0)
		{};
		row_info(const T* ptr, Integer ld, Integer cols, Integer pos)	
			:ptr(ptr),ld(ld),cols(cols),pos(pos)
		{};
		row_info()
			:ptr(0),ld(0),cols(0),pos(0) 
		{};

		bool	operator<(const row_info& other)
		{
			for (Integer i = 0, pos = 0; i < cols; ++i, pos += ld)
			{
				if (less_nan<T>::eval(ptr[pos],other.ptr[pos]))
				{
					return true;
				};
				if (greater_nan<T>::eval(ptr[pos],other.ptr[pos]))
				{
					return false;
				};
			};
			return false;
		};

		const T* get_ptr() const
		{
			return ptr;
		};
		Integer get_pos() const
		{
			return pos;
		};
};
template<class T>
struct row_info_dim
{
	private:
		const T*				ptr;
		Integer					ld;
		Integer					pos;
		const IntegerMatrix*	dims;   //must be continuous

	public:
		row_info_dim(const T* ptr, Integer ld, const IntegerMatrix* dims)	
			:ptr(ptr),ld(ld),pos(0), dims(dims)
		{};
		row_info_dim(const T* ptr, Integer ld, const IntegerMatrix* dims, Integer pos)	
			:ptr(ptr),ld(ld),pos(pos),dims(dims)
		{};
		row_info_dim()
			:ptr(0),ld(0),pos(0),dims(0)
		{};

		bool operator<(const row_info_dim& other)
		{
            Integer dims_size = dims->size();
            const Integer* ptr_dims = dims->ptr();
			for (Integer i = 0; i < dims_size; ++i)
			{
				Integer dim = ptr_dims[i];                
				if (dim > 0)
				{
					Integer pos = imult(dim-1,ld);
					if (less_nan<T>::eval(ptr[pos],other.ptr[pos]))
					{
						return true;
					};
					if (greater_nan<T>::eval(ptr[pos],other.ptr[pos]))
					{
						return false;
					};
				}
				else
				{
					Integer pos = imult(-dim-1,ld);
					if (greater_nan<T>::eval(ptr[pos], other.ptr[pos]))
					{
						return true;
					};
					if (less_nan<T>::eval(ptr[pos],other.ptr[pos]))
					{
						return false;
					};
				};
			};
			return false;
		};

		const T* get_ptr() const
		{
			return ptr;
		};
		Integer get_pos() const
		{
			return pos;
		};
};
template<class T>
bool row_vec_comparer(row_info<T>* ptr1, row_info<T>* ptr2)
{
	return *ptr1 < * ptr2;
};
template<class T>
static bool row_vec_dim_comparer(row_info_dim<T>* ptr1, row_info_dim<T>* ptr2)
{
	return *ptr1 < * ptr2;
};

template<class T>
struct row_info_sparse
{
	private:
		const Integer *	d_r;
		const T*		d_x;
		Integer			first;
		Integer			last;
		Integer			col;
        T               Z;

	public:
        row_info_sparse(gd::type_info ti, const Integer *	d_r, const T* d_x, 
                        Integer f, Integer l, Integer col )	
			:d_r(d_r),d_x(d_x), first(f), last(l), col(col)
            ,Z(gd::default_value<T>(ti))
		{};
		row_info_sparse()
			:d_r(0),d_x(0),first(0),last(0),col(0)
            ,Z(gd::default_value<T>(gd::get_raw_ti()))
		{};

		bool operator<(const row_info_sparse& other)
		{
			Integer k1 = first, k2 = other.first;

			while (k1 < last && k2 < other.last)
			{
				if (d_r[k1] < other.d_r[k2])
				{
					if (less_nan<T>::eval(d_x[k1], Z))
					{
						return true;
					};
					if (greater_nan<T>::eval(d_x[k1], Z))
					{
						return false;
					};
					++k1;
				}
				else if (d_r[k1] > other.d_r[k2])
				{
					if (less_nan<T>::eval(Z,other.d_x[k2]))
					{
						return true;
					};
					if (greater_nan<T>::eval(Z,other.d_x[k2]))
					{
						return false;
					};
					++k2; 
				}
				else
				{ 
					if (less_nan<T>::eval(d_x[k1],other.d_x[k2]))
					{
						return true;
					};
					if (greater_nan<T>::eval(d_x[k1],other.d_x[k2]))
					{
						return false;
					};
					++k1; 
					++k2;
				};
			};
			while (k1 < last)
			{
				if (less_nan<T>::eval(d_x[k1],Z))
				{
					return true;
				};
				if (greater_nan<T>::eval(d_x[k1], Z))
				{
					return false;
				};
				++k1;
			};
			while (k2 < other.last)
			{				
				if (less_nan<T>::eval(Z,other.d_x[k2]))
				{
					return true;
				};
				if (greater_nan<T>::eval(Z, other.d_x[k2]))
				{
					return false;
				};
				++k2; 
			};
			return false;
		};

		Integer	get_pos() const
		{
			return col;
		};
};
template<class T>
struct row_info_sparse_dims
{
	private:
		const Integer *			d_r;
		const T*				d_x;
		Integer					first;
		Integer					last;
		Integer					col;
		const IntegerMatrix*	dims;   //must be continuous
        T                       Z;

	public:
		row_info_sparse_dims(gd::type_info ti,const Integer * d_r,const T* d_x,
                            Integer f,Integer l,Integer col,const IntegerMatrix* dims)	
			:d_r(d_r),d_x(d_x), first(f), last(l), col(col), dims(dims)
            ,Z(gd::default_value<T>(ti))
		{};
		row_info_sparse_dims()
			:d_r(0),d_x(0),first(0),last(0),col(0),dims(0)
            ,Z(gd::default_value<T>(gd::get_raw_ti()))
		{};

		bool operator<(const row_info_sparse_dims& other)
		{
			Integer k1 = first, k2 = other.first;

			while (k1 < last && k2 < other.last)
			{
				if (d_r[k1] < other.d_r[k2])
				{
					if (less(d_x[k1],Z,is_increasing(d_r[k1])))
					{
						return true;
					};
					if (greater(d_x[k1],Z,is_increasing(d_r[k1])))
					{
						return false;
					};
					++k1;
				}
				else if (d_r[k1] > other.d_r[k2])
				{
					if (less(Z,other.d_x[k2],is_increasing(other.d_r[k2])))
					{
						return true;
					};
					if (greater(Z,other.d_x[k2],is_increasing(other.d_r[k2])))
					{
						return false;
					};
					++k2; 
				}
				else
				{ 
					if (less(d_x[k1], other.d_x[k2],is_increasing(d_r[k1])))
					{
						return true;
					};
					if (greater(d_x[k1], other.d_x[k2],is_increasing(d_r[k1])))
					{
						return false;
					};
					++k1; 
					++k2;
				};
			};
			while (k1 < last)
			{
				if (less(d_x[k1], Z,is_increasing(d_r[k1])))
				{
					return true;
				};
				if (greater(d_x[k1], Z,is_increasing(d_r[k1])))
				{
					return false;
				};
				++k1;
			};
			while (k2 < other.last)
			{				
				if (less(Z, other.d_x[k2],is_increasing(other.d_r[k2])))
				{
					return true;
				};
				if (greater(Z, other.d_x[k2],is_increasing(other.d_r[k2])))
				{
					return false;
				};
				++k2; 
			};
			return false;
		};

		bool is_increasing(Integer pos)
		{
			return dims->ptr()[pos] > 0;
		};
		bool less(T x1, T x2,bool is_increase)
		{
			if (is_increase)
			{
				return less_nan<T>::eval(x1,x2);
			}
			else
			{
				return greater_nan<T>::eval(x1, x2);
			};
		};
		bool greater(T x1, T x2,bool is_increase)
		{
			if (is_increase)
			{
				return greater_nan<T>::eval(x1,x2);
			}
			else
			{
				return less_nan<T>::eval(x1,x2);
			};
		};

		Integer	get_pos() const
		{
			return col;
		};
};
template<class T>
static bool row_vec_sparse_comparer(row_info_sparse<T>* ptr1, row_info_sparse<T>* ptr2)
{
	return *ptr1 < * ptr2;
};
template<class T>
static bool row_vec_sparse_dims_comparer(row_info_sparse_dims<T>* ptr1, row_info_sparse_dims<T>* ptr2)
{
	return *ptr1 < * ptr2;
};

static void check_dims(const IntegerMatrix& dims,Integer c)
{
	error::chect_col_indices_sortrows(dims.size(),c);
    const Integer* ptr_dims = dims.ptr();

	for (Integer j = 0; j < dims.cols(); ++j)
	{
        for (Integer i = 0; i < dims.cols(); ++i)
        {
		    error::chect_col_indices_elem_sortrows(ptr_dims[i],c);
        };
        ptr_dims += dims.ld();
	};
};
static void check_dims_col(const IntegerMatrix& dims,Integer c)
{
	error::chect_row_indices_sortcols(dims.size(),c);

    const Integer* ptr_dims = dims.ptr();

	for (Integer j = 0; j < dims.cols(); ++j)
	{
        for (Integer i = 0; i < dims.cols(); ++i)
        {
		    error::chect_row_indices_elem_sortcols(ptr_dims[i],c);
        };
        ptr_dims += dims.ld();
	};
};

template<class ret_type, class in_type, class struct_type>
struct sortrows_impl{};

template<class ret_type, class in_type>
struct sortrows_impl<ret_type,in_type,struct_dense>
{
    typedef std::pair<ret_type,IntegerMatrix> ret_2;

	static ret_type eval(gd::type_info ret_ti,const in_type& m)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_ret;

		Integer r = m.rows(), c = m.cols();

		if (r == 0 || c == 0) 
		{
			return ret_type(ret_ti,r, c);
		};

		std::vector<row_info<value_type>>  row_vec(r);
		std::vector<row_info<value_type>*> row_vec_ptr(r);

        const value_type* ptr_m = m.ptr();

		for (Integer i = 0; i < r; ++i)
		{
			row_vec[i] = row_info<value_type>(ptr_m+i,m.ld(),c);
			row_vec_ptr[i] = &row_vec[i];
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_comparer<value_type>);

		ret_type res(ret_ti,r,c);
        
        value_type_ret* ptr_res = res.ptr();

		for (Integer i = 0; i < r; ++i)
		{
			const value_type* ptr	= row_vec_ptr[i]->get_ptr();
			for (Integer j = 0, pos = i, pos_p = 0; j < c; ++j, pos += res.ld(), pos_p += m.ld())
			{
				ptr_res[pos] = ptr[pos_p];
			};
		};
		return res;
	};
	static ret_type eval_col(gd::type_info ret_ti,const in_type& m)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_ret;

		Integer r = m.rows(), c = m.cols();

		if (r == 0 || c == 0) 
		{
			return ret_type(ret_ti,r, c);
		};

		std::vector<row_info<value_type>>  row_vec(c);
		std::vector<row_info<value_type>*> row_vec_ptr(c);
        const value_type* ptr_m = m.ptr();

		for (Integer i = 0; i < c; ++i)
		{
			row_vec[i] = row_info<value_type>(ptr_m,1,r);
			row_vec_ptr[i] = &row_vec[i];
            ptr_m += m.ld();
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_comparer<value_type>);

		ret_type res(ret_ti,r,c);
        value_type_ret* ptr_res = res.ptr();

		for (Integer i = 0; i < c; ++i)
		{
			const value_type* ptr	= row_vec_ptr[i]->get_ptr();
			for (Integer j = 0; j < r; ++j)
			{
				ptr_res[j] = ptr[j];
			};
            ptr_res += res.ld();
		};
		return res;
	};
	static ret_2 eval2(gd::type_info ret_ti,const in_type& m)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_res;

		Integer r = m.rows(), c = m.cols();
		IntegerMatrix ind(gd::get_raw_ti(),r,1);

		if (r == 0 || c == 0) 
		{
            Integer* ptr_ind = ind.ptr();
			for (Integer i = 0; i < r; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(ret_type(ret_ti,r, c),ind);
		};

		std::vector<row_info<value_type>>  row_vec(r);
		std::vector<row_info<value_type>*> row_vec_ptr(r);
        const value_type* ptr_m = m.ptr();

		for (Integer i = 0; i < r; ++i)
		{
			row_vec[i] = row_info<value_type>(ptr_m + i,m.ld(),c,i+1);
			row_vec_ptr[i] = &row_vec[i];
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_comparer<value_type>);

		ret_type res(ret_ti,r,c);
        value_type_res* ptr_res = res.ptr();

        Integer* ptr_ind = ind.ptr();

		for (Integer i = 0; i < r; ++i)
		{
			const value_type* ptr	= row_vec_ptr[i]->get_ptr();
			for (Integer j = 0, pos = i, pos_p = 0; j < c; ++j, pos += res.ld(), pos_p += m.ld())
			{
				ptr_res[pos] = ptr[pos_p];
			};

			ptr_ind[i] = row_vec_ptr[i]->get_pos();
		};
		return ret_2(res,ind);
	};
	static ret_2 eval_col2(gd::type_info ret_ti,const in_type& m)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_ret;

		Integer r = m.rows(), c = m.cols();
		IntegerMatrix ind(gd::get_raw_ti(),1,c);

        Integer* ptr_ind = ind.ptr();

		if (r == 0 || c == 0) 
		{            
			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(ret_type(ret_ti,r, c),ind);
		};

        const value_type* ptr_m = m.ptr();

		std::vector<row_info<value_type>>  row_vec(c);
		std::vector<row_info<value_type>*> row_vec_ptr(c);
		for (Integer i = 0, pos = 0; i < c; ++i, pos += m.ld())
		{
			row_vec[i] = row_info<value_type>(ptr_m+pos,1,r,i+1);
			row_vec_ptr[i] = &row_vec[i];
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_comparer<value_type>);

		ret_type res(ret_ti,r,c);
        value_type_ret* ptr_res = res.ptr();

		for (Integer i = 0; i < c; ++i)
		{
			const value_type* ptr	= row_vec_ptr[i]->get_ptr();
			for (Integer j = 0, pos_p = 0; j < r; ++j, ++pos_p)
			{
				ptr_res[j] = ptr[pos_p];
			};
            ptr_res += res.ld();
			ptr_ind[i] = row_vec_ptr[i]->get_pos();
		};
		return ret_2(res,ind);
	};
	static ret_type eval_dim(gd::type_info ret_ti,const in_type& m,const IntegerMatrix& dims)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_ret;

		Integer r = m.rows(), c = m.cols();

		check_dims(dims,c);

		if (r == 0 || c == 0) 
		{
			return ret_type(ret_ti,r, c);
		};

		if (dims.size() == 0)
		{
			return m;
		};

        IntegerMatrix dims2 = dims.make_explicit();
        const value_type* ptr_m = m.ptr();        

		std::vector<row_info_dim<value_type>>  row_vec(r);
		std::vector<row_info_dim<value_type>*> row_vec_ptr(r);
		for (Integer i = 0; i < r; ++i)
		{
			row_vec[i] = row_info_dim<value_type>(ptr_m+i,m.ld(),&dims2);
			row_vec_ptr[i] = &row_vec[i];
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_dim_comparer<value_type>);

		ret_type res(ret_ti,r,c);
        value_type_ret* ptr_res = res.ptr();

		for (Integer i = 0; i < r; ++i)
		{
			const value_type* ptr	= row_vec_ptr[i]->get_ptr();
			for (Integer j = 0, pos = i, pos_p = 0; j < c; ++j, pos += res.ld(), pos_p += m.ld())
			{
				ptr_res[pos] = ptr[pos_p];
			};
		};
		return res;
	};
	static ret_type eval_dim_col(gd::type_info ret_ti,const in_type& m,const IntegerMatrix& dims)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_ret;

		Integer r = m.rows(), c = m.cols();
		check_dims_col(dims,r);

		if (r == 0 || c == 0) 
		{
			return ret_type(ret_ti,r, c);
		};
		if (dims.size() == 0)
		{
			return m;
		};

        IntegerMatrix dims2 = dims.make_explicit();

		std::vector<row_info_dim<value_type>>  row_vec(c);
		std::vector<row_info_dim<value_type>*> row_vec_ptr(c);
        const value_type* ptr_m = m.ptr();
		for (Integer i = 0, pos = 0; i < c; ++i, pos += m.ld())
		{
			row_vec[i] = row_info_dim<value_type>(ptr_m+pos,1,&dims2);
			row_vec_ptr[i] = &row_vec[i];
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_dim_comparer<value_type>);

		ret_type res(ret_ti,r,c);
        value_type_ret* ptr_res = res.ptr();

		for (Integer i = 0; i < c; ++i)
		{
			const value_type* ptr	= row_vec_ptr[i]->get_ptr();
			for (Integer j = 0; j < r; ++j)
			{
				ptr_res[j] = ptr[j];
			};
            ptr_res += res.ld();
		};
		return res;
	};
	static ret_2 eval_dim2(gd::type_info ret_ti,const in_type& m,const IntegerMatrix& dims)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_ret;

		Integer r = m.rows(), c = m.cols();

		check_dims(dims,c);

        IntegerMatrix ind(gd::get_raw_ti(),r,1);
        Integer* ptr_ind = ind.ptr();
        const value_type* ptr_m = m.ptr();

		if (r == 0 || c == 0) 
		{
			for (Integer i = 0; i < r; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(ret_type(ret_ti,r, c),ind);
		};

		if (dims.size() == 0)
		{
			for (Integer i = 0; i < r; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(m,ind);
		};

        IntegerMatrix dims2 = dims.make_explicit();

		std::vector<row_info_dim<value_type>>  row_vec(r);
		std::vector<row_info_dim<value_type>*> row_vec_ptr(r);
		for (Integer i = 0; i < r; ++i)
		{
			row_vec[i] = row_info_dim<value_type>(ptr_m+i,m.ld(),&dims2,i+1);
			row_vec_ptr[i] = &row_vec[i];
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_dim_comparer<value_type>);

		ret_type res(ret_ti,r,c);
        value_type_ret* ptr_res = res.ptr();

		for (Integer i = 0; i < r; ++i)
		{
			const value_type* ptr	= row_vec_ptr[i]->get_ptr();
			for (Integer j = 0, pos = i, pos_p = 0; j < c; ++j, pos += res.ld(), pos_p += m.ld())
			{
				ptr_res[pos] = ptr[pos_p];
			};

			ptr_ind[i] = row_vec_ptr[i]->get_pos();
		};
		return ret_2(res,ind);
	};
	static ret_2 eval_dim_col2(gd::type_info ret_ti,const in_type& m,const IntegerMatrix& dims)
	{
		typedef in_type::value_type value_type;
        typedef ret_type::value_type value_type_ret;

		Integer r = m.rows(), c = m.cols();
		check_dims_col(dims,r);

        IntegerMatrix ind(gd::get_raw_ti(),1,c);
        Integer* ptr_ind = ind.ptr();

		if (r == 0 || c == 0) 
		{
			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(ret_type(ret_ti,r, c),ind);
		};

		if (dims.size() == 0)
		{
			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(m,ind);
		};

        IntegerMatrix dims2 = dims.make_explicit();

		std::vector<row_info_dim<value_type>>  row_vec(c);
		std::vector<row_info_dim<value_type>*> row_vec_ptr(c);
        const value_type* ptr_m = m.ptr();
		for (Integer i = 0, pos = 0; i < c; ++i, pos += m.ld())
		{
			row_vec[i] = row_info_dim<value_type>(ptr_m+pos,1,&dims2,i+1);
			row_vec_ptr[i] = &row_vec[i];
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_dim_comparer<value_type>);

		ret_type res(ret_ti,r,c);
        value_type_ret* ptr_res = res.ptr();

		for (Integer i = 0; i < c; ++i)
		{
			const value_type* ptr	= row_vec_ptr[i]->get_ptr();
			for (Integer j = 0; j < r; ++j)
			{
				ptr_res[j] = ptr[j];
			};
			ptr_ind[i] = row_vec_ptr[i]->get_pos();
            ptr_res += res.ld();
		};
		return ret_2(res,ind);
	};
};
template<class ret_type, class in_type>
struct sortrows_impl<ret_type,in_type,struct_sparse>
{
    typedef std::pair<ret_type,IntegerMatrix> ret_2;

	static ret_type eval(gd::type_info ret_ti,const in_type& A)
	{
		if (A.nnz() == 0)
		{
			return A;
		};
		in_type tmp = eval_impl(ret_ti,trans(A)).first;
		return trans(tmp);
	};
	static ret_type eval_col(gd::type_info ret_ti,const in_type& A)
	{
		if (A.nnz() == 0)
		{
			return A;
		};
		ret_type out = eval_impl(ret_ti,A).first;
		return out;
	};
	static ret_2 eval2(gd::type_info ret_ti,const in_type& A)
	{
		if (A.nnz() == 0)
		{
			Integer r = A.rows();
			IntegerMatrix ind(gd::get_raw_ti(),r,1);
            Integer* ptr_ind = ind.ptr();
			for (Integer i = 0; i < r; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(A,ind);
		};
        ret_2 out = eval_impl2(ret_ti,trans(A));
        return ret_2(trans(out.first),trans(out.second));
	};
	static ret_2 eval_col2(gd::type_info ret_ti,const in_type& A)
	{
		if (A.nnz() == 0)
		{
			Integer c = A.cols();
            IntegerMatrix ind(gd::get_raw_ti(),1,c);
            Integer* ptr_ind = ind.ptr();
			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(A,ind);
		};
		ret_2 out = eval_impl2(ret_ti,A);		
		return out;
	};
	static ret_type eval_dim(gd::type_info ret_ti,const in_type& A,const IntegerMatrix& dims)
	{
		Integer c = A.cols(), nz = A.nnz();
		check_dims(dims,c);

		if (nz == 0 || dims.size() == 0)
		{
			return A;
		};

		in_type A_selected = select_cols(A,dims);
		in_type tmp = eval_impl(ret_ti,trans(A),trans(A_selected),dims);
		return trans(tmp);
	};
	static ret_type eval_dim_col(gd::type_info ret_ti,const in_type& A,const IntegerMatrix& dims)
	{
		Integer r = A.rows(), nz = A.nnz();
		check_dims_col(dims,r);

		if (nz == 0 || dims.size() == 0)
		{
			return A;
		};

		in_type A_selected =select_rows(A,dims);
		in_type out = eval_impl(ret_ti,A,A_selected, dims);		
		return out;
	};
	static ret_2 eval_dim2(gd::type_info ret_ti,const in_type& A,const IntegerMatrix& dims)
	{
		Integer c = A.cols(), nz = A.nnz();
		check_dims(dims,c);

		if (nz == 0 || dims.size() == 0)
		{
			Integer r = A.rows();
            IntegerMatrix ind(gd::get_raw_ti(),r,1);
            Integer* ptr_ind = ind.ptr();
			for (Integer i = 0; i < r; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(A,ind);
		};

		in_type A_selected = select_cols(A,dims);	
		ret_2 tmp = eval_impl2(ret_ti,trans(A),trans(A_selected),dims);
		return ret_2(trans(tmp.first),trans(tmp.second));
	};
	static ret_2 eval_dim_col2(gd::type_info ret_ti,const in_type& A,const IntegerMatrix& dims)
	{
		Integer r = A.rows(), c = A.cols();
		check_dims_col(dims,r);

		if (A.nnz() == 0 || dims.size() == 0)
		{
            IntegerMatrix ind(gd::get_raw_ti(),1,c);
            Integer* ptr_ind = ind.ptr();
			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(A,ind);
		};
		in_type A_selected = select_rows(A,dims);
		ret_2 out = eval_impl2(ret_ti,A,A_selected,dims);
		return out;
	};
	static ret_2 eval_impl(gd::type_info ret_ti,const in_type& A)
	{
		return eval_impl2(ret_ti,A);
	};
	static ret_type eval_impl(gd::type_info ret_ti,const in_type& A,const in_type& Asel,
                                const IntegerMatrix& dims)
	{
		return eval_impl2(ret_ti,A,Asel,dims).first;
	};
	static ret_2 eval_impl2(gd::type_info ret_ti,const in_type& A)
	{
		typedef in_type::value_type value_type;

		Integer r = A.rows(), c = A.cols();

		ret_type res(ret_ti,r,c,A.nnz());
        IntegerMatrix ind(gd::get_raw_ti(),1,c);
        Integer* ptr_ind = ind.ptr();

		if (A.nnz() == 0)
		{
			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = i+1;
			};
			return ret_2(res,ind);
		};

		const spdat<value_type>& Ad	= A.rep();
		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const value_type* Ad_x		= Ad.ptr_x();

		spdat<value_type>& d		= res.rep();
		Integer* d_c				= d.ptr_c();
		Integer* d_r				= d.ptr_r();
		value_type* d_x				= d.ptr_x();

		std::vector<row_info_sparse<value_type>>  row_vec(c);
		std::vector<row_info_sparse<value_type>*> row_vec_ptr(c);

		for (Integer i = 0; i < c; ++i)
		{
			row_vec[i] = row_info_sparse<value_type>(ret_ti,Ad_r,Ad_x,Ad_c[i],Ad_c[i+1],i);
			row_vec_ptr[i] = &row_vec[i];
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_sparse_comparer<value_type>);		

		Integer nz = 0;
		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;
			Integer col				= row_vec_ptr[j]->get_pos();

			for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
			{
				d_r[nz]				= Ad_r[k];
				d_x[nz]				= Ad_x[k];
				++nz;
			};

			ptr_ind[j]			    = col + 1;
		};
		d_c[c]						= nz;
		return ret_2(res,ind);
	};
	static ret_2 eval_impl2(gd::type_info ret_ti,const in_type& A,const in_type& A_sub, 
                                const IntegerMatrix& dims)
	{
		typedef in_type::value_type value_type;

		Integer r = A.rows(), c = A.cols();

		const spdat<value_type>& Ad	= A.rep();
		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const value_type* Ad_x		= Ad.ptr_x();

		const spdat<value_type>& Ads= A_sub.rep();
		const Integer* Ads_c		= Ads.ptr_c();
		const Integer* Ads_r		= Ads.ptr_r();
		const value_type* Ads_x		= Ads.ptr_x();

		ret_type res(ret_ti,r,c,A.nnz());
        IntegerMatrix ind(gd::get_raw_ti(),1,c);
        Integer* ptr_ind = ind.ptr();

		spdat<value_type>& d		= res.rep();
		Integer* d_c				= d.ptr_c();
		Integer* d_r				= d.ptr_r();
		value_type* d_x				= d.ptr_x();

		std::vector<row_info_sparse_dims<value_type>>  row_vec(c);
		std::vector<row_info_sparse_dims<value_type>*> row_vec_ptr(c);

        IntegerMatrix dims2 = dims.make_explicit();

		for (Integer i = 0; i < c; ++i)
		{
			row_vec[i] = row_info_sparse_dims<value_type>(ret_ti,Ads_r,Ads_x,Ads_c[i],Ads_c[i+1],i,&dims2);
			row_vec_ptr[i] = &row_vec[i];
		};

		std::stable_sort(row_vec_ptr.begin(), row_vec_ptr.end(), row_vec_sparse_dims_comparer<value_type>);		

		Integer nz = 0;
		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;
			Integer col				= row_vec_ptr[j]->get_pos();

			for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
			{
				d_r[nz]				= Ad_r[k];
				d_x[nz]				= Ad_x[k];
				++nz;
			};

			ptr_ind[j]			    = col + 1;
		};
		d_c[c]						= nz;

		return ret_2(res,ind);
	};
	static in_type select_cols(const in_type& A, const IntegerMatrix& cols)
	{
		Integer r = A.rows();

		mmlib::details::colon_info ci;

		ci.r_flag = 1;		
		ci.r_start = 1;
		ci.r_step  = 1;
		ci.r_end   = r;
		ci.r_size  = r;
		ci.c_flag  = 0;
		ci.set_ci(abs(cols));

		return mmlib::algorithm::get_submatrix(A,ci);
	};
	static in_type select_rows(const in_type& A, const IntegerMatrix& ri)
	{
		Integer c = A.cols();

		mmlib::details::colon_info ci;

		ci.r_flag = 0;
		ci.set_ri(abs(ri));
		ci.c_start = 1;
		ci.c_step  = 1;
		ci.c_end   = c;
		ci.c_size  = c;
		ci.c_flag  = 1;

		return mmlib::algorithm::get_submatrix(A,ci);
	};
};

template<class ret_type, class in_type>
struct sort_impl<ret_type,in_type,struct_banded>
{
	static ret_type eval(gd::type_info ret_ti,const in_type& A, Integer dim)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);

		if (dim == 1)
		{
			sort_impl<ret_type,sparse_matrix_type,struct_sparse>::eval_inplace(tmp);
			return tmp;
		};
		return sort_impl<ret_type,sparse_matrix_type,struct_sparse>::eval(ret_ti,tmp,dim);
	};
	static ret_type eval(gd::type_info ret_ti,const in_type& A, Integer dim, IntegerMatrix& ind)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);

		if (dim == 1)
		{
			sort_impl<ret_type,sparse_matrix_type,struct_sparse>::eval_inplace(tmp,ind,false);
			return tmp;
		};
		return sort_impl<ret_type,sparse_matrix_type,struct_sparse>::eval(ret_ti,tmp,dim,ind);
	};
};
template<class ret_type, class in_type>
struct sortrows_impl<ret_type,in_type,struct_banded>
{
    typedef std::pair<ret_type,IntegerMatrix> ret_2;

	static ret_type eval(gd::type_info ret_ti,const in_type& A)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);
		return sortrows_impl<ret_type,sparse_matrix_type,struct_sparse>::eval(ret_ti,tmp);
	};
	static ret_2 eval2(gd::type_info ret_ti,const in_type& A)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);
		return sortrows_impl<ret_type,sparse_matrix_type,struct_sparse>::eval2(ret_ti,tmp);
	};
	static ret_type eval_dim(gd::type_info ret_ti,const in_type& A,const IntegerMatrix& dims)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);
		return sortrows_impl<ret_type,sparse_matrix_type,struct_sparse>::eval_dim(ret_ti,tmp,dims);
	};
	static ret_2 eval_dim2(gd::type_info ret_ti,const in_type& A,const IntegerMatrix& dims)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);
		return sortrows_impl<ret_type,sparse_matrix_type,struct_sparse>::eval_dim2(ret_ti,tmp,dims);
	};

	static ret_type eval_col(gd::type_info ret_ti,const in_type& A)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);
		return sortrows_impl<ret_type,sparse_matrix_type,struct_sparse>
                    ::eval_impl(ret_ti,tmp).first;
	};
	static ret_2 eval_col2(gd::type_info ret_ti,const in_type& A)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);
		return sortrows_impl<ret_type,sparse_matrix_type,struct_sparse>::eval_impl2(ret_ti,tmp);
	};
	static ret_type eval_dim_col(gd::type_info ret_ti,const in_type& A,const IntegerMatrix& dims)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		Integer r = A.rows();
		check_dims_col(dims,r);

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);
		return sortrows_impl<ret_type,sparse_matrix_type,struct_sparse>::eval_dim_col(ret_ti,tmp,dims);
	};
	static ret_2 eval_dim_col2(gd::type_info ret_ti,const in_type& A,const IntegerMatrix& dims)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_sparse> sparse_matrix_type;

		Integer r = A.rows();
		check_dims_col(dims,r);

		sparse_matrix_type tmp = converter<sparse_matrix_type,in_type>::eval(ret_ti,A);
		return sortrows_impl<ret_type,sparse_matrix_type,struct_sparse>::eval_dim_col2(ret_ti,tmp,dims);
	};
};

template<class MP>	
typename  sort_helper<MP>::ret_type_sort 
sort_helper<MP>::eval_sort(const MP& m,Integer dim)
{
	typedef MP::struct_type str_type;
    return sort_impl<ret_type_sort,MP,str_type>::eval(gd::get_ti(m),m,dim);
};
template<class MP>
typename sort_helper<MP>::ret_type_sort 
sort_helper<MP>::eval_sort_2(const MP& m,Integer dim, IntegerMatrix& ind)
{
	typedef MP::struct_type str_type;
	return sort_impl<ret_type_sort,MP,str_type>::eval(gd::get_ti(m),m,dim,ind);
};

template<class MP>
typename sort_helper<MP>::ret_type_sortrows 
sort_helper<MP>::eval_sortrows(const MP& m)
{
	typedef MP::struct_type str_type;
	return sortrows_impl<ret_type_sort,MP,str_type>::eval(gd::get_ti(m),m);
};
template<class MP>
typename sort_helper<MP>::ret_type_sortrows_2 
sort_helper<MP>::eval_sortrows_2(const MP& m)
{
	typedef MP::struct_type str_type;
	return sortrows_impl<ret_type_sort,MP,str_type>::eval2(gd::get_ti(m),m);
};

template<class MP>
typename sort_helper<MP>::ret_type_sortrows 
sort_helper<MP>::eval_sortrows(const MP& m, const IntegerMatrix& dims)
{
	typedef MP::struct_type str_type;
	return sortrows_impl<ret_type_sort,MP,str_type>::eval_dim(gd::get_ti(m),m,dims);
};
template<class MP>
typename sort_helper<MP>::ret_type_sortrows_2 
sort_helper<MP>::eval_sortrows_2(const MP& m, const IntegerMatrix& dims)
{
	typedef MP::struct_type str_type;
	return sortrows_impl<ret_type_sort,MP,str_type>::eval_dim2(gd::get_ti(m),m,dims);
};



template<class MP>
typename sort_helper<MP>::ret_type_sortcols 
sort_helper<MP>::eval_sortcols(const MP& m)
{
	typedef MP::struct_type str_type;
	return sortrows_impl<ret_type_sort,MP,str_type>::eval_col(gd::get_ti(m),m);
};
template<class MP>
typename sort_helper<MP>::ret_type_sortrows_2
sort_helper<MP>::eval_sortcols_2(const MP& m)
{
	typedef MP::struct_type str_type;
	return sortrows_impl<ret_type_sort,MP,str_type>::eval_col2(gd::get_ti(m),m);
};

template<class MP>
typename sort_helper<MP>::ret_type_sortcols
sort_helper<MP>::eval_sortcols(const MP& m, const IntegerMatrix& dims)
{
	typedef MP::struct_type str_type;
	return sortrows_impl<ret_type_sort,MP,str_type>::eval_dim_col(gd::get_ti(m),m,dims);
};
template<class MP>
typename sort_helper<MP>::ret_type_sortrows_2 
sort_helper<MP>::eval_sortcols_2(const MP& m, const IntegerMatrix& dims)
{
	typedef MP::struct_type str_type;
	return sortrows_impl<ret_type_sort,MP,str_type>::eval_dim_col2(gd::get_ti(m),m,dims);
};

template<class M, class struct_type>
struct is_sortedcols_helper {};
template<class M, class struct_type>
struct is_sortedrows_helper {};
template<class in_type>
struct is_sortedcols_helper<in_type,struct_dense> 
{
	static bool eval(const in_type& m)
	{
		typedef in_type::value_type value_type;

		Integer r = m.rows(), c = m.cols();

		if (r == 0 || c == 0) 
		{
			return true;
		};

		Integer pos_c = m.ld();
		Integer pos_cl = 0;
        const value_type* ptr_m = m.ptr();

		for (Integer j = 1; j < c; ++j)
		{
			Integer pos = pos_c;
			Integer pos_l = pos_cl;

			for (Integer i = 0; i < r; ++i)
			{
				if (greater_nan<value_type>::eval(ptr_m[pos],ptr_m[pos_l]))
				{
					break;
				}
				else if (less_nan<value_type>::eval(ptr_m[pos],ptr_m[pos_l]))
				{
					return false;
				};
				++pos;
				++pos_l;
			};
			pos_c += m.ld();
			pos_cl += m.ld();

		};
		return true;
	};
};
template<class in_type>
struct is_sortedrows_helper<in_type,struct_dense> 
{
	static bool eval(const in_type& m)
	{
		typedef in_type::value_type value_type;

		Integer r = m.rows(), c = m.cols();

		if (r == 0 || c == 0) 
		{
			return true;
		};

        const value_type* ptr_m = m.ptr();

		for (Integer i = 1; i < r; ++i)
		{
			Integer pos = i;
			Integer pos_l = i - 1;

			for (Integer j = 0; j < c; ++j)
			{
				if (greater_nan<value_type>::eval(ptr_m[pos],ptr_m[pos_l]))
				{
					break;
				}
				else if (less_nan<value_type>::eval(ptr_m[pos],ptr_m[pos_l]))
				{
					return false;
				};
				pos += m.ld();
				pos_l += m.ld();
			};
		};
		return true;
	};
};
template<class in_type>
struct is_sortedcols_helper<in_type,struct_sparse> 
{
	static bool eval(const in_type& A)
	{
		typedef in_type::value_type value_type;

        const value_type Z = gd::default_value<value_type>(gd::get_ti(A));

		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0 || A.nnz() == 0)
		{
			return true;
		};

		const spdat<value_type>& Ad	= A.rep();
		const Integer* Ad_c			= Ad.ptr_c();
		const Integer* Ad_r			= Ad.ptr_r();
		const value_type* Ad_x		= Ad.ptr_x();

		for (Integer i = 1; i < c; ++i)
		{
			Integer k1 = Ad_c[i],	k2 = Ad_c[i-1];
			Integer l1 = Ad_c[i+1], l2 = k1;

			while (k1 < l1 && k2 < l2)
			{
				if (Ad_r[k1] < Ad_r[k2])
				{
					if (less_nan<value_type>::eval(Ad_x[k1],Z))
					{
						return false;
					};
					if (greater_nan<value_type>::eval(Ad_x[k1],Z))
					{
						goto label_exis_row;
					};
					++k1;
				}
				else if (Ad_r[k1] > Ad_r[k2])
				{
					if (less_nan<value_type>::eval(Z, Ad_x[k2]))
					{
						return false;
					};
					if (greater_nan<value_type>::eval(Z,Ad_x[k2]))
					{
						goto label_exis_row;
					};
					++k2; 
				}
				else
				{ 
					if (less_nan<value_type>::eval(Ad_x[k1], Ad_x[k2]))
					{
						return false;
					};
					if (greater_nan<value_type>::eval(Ad_x[k1], Ad_x[k2]))
					{
						goto label_exis_row;
					};
					++k1; 
					++k2;
				};
			};
			while (k1 < l1)
			{
				if (less_nan<value_type>::eval(Ad_x[k1], Z))
				{
					return false;
				};
				if (greater_nan<value_type>::eval(Ad_x[k1], Z))
				{
					goto label_exis_row;
				};
				++k1;
			};
			while (k2 < l2)
			{				
				if (less_nan<value_type>::eval(Z, Ad_x[k2]))
				{
					return false;
				};
				if (greater_nan<value_type>::eval(Z, Ad_x[k2]))
				{
					goto label_exis_row;
				};
				++k2; 
			};

			label_exis_row:
				(void)0;
		};

		return true;
	};
};
template<class in_type>
struct is_sortedrows_helper<in_type,struct_sparse> 
{
	static bool eval(const in_type& A)
	{
		return is_sortedcols_helper<in_type,struct_sparse>::eval(trans(A));
	};
};
template<class in_type>
struct is_sortedcols_helper<in_type,struct_banded> 
{
	static bool eval(const in_type& A)
	{
		typedef in_type::value_type value_type;
        const value_type Z = gd::default_value<value_type>(gd::get_ti(A));

		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0) 
		{
			return true;
		};

		Integer pos_c = A.ld();
		Integer pos_cl = 0;
        const value_type* ptr_A = A.rep_ptr();

		for (Integer i = 1; i < c; ++i)
		{
			Integer k1 = A.first_row(i),	k2 = A.first_row(i-1);
			Integer l1 = A.last_row(i)+1,   l2 = A.last_row(i-1)+1;

			Integer pos_1 = A.first_elem_pos(i) + pos_c;
			Integer pos_2 = A.first_elem_pos(i-1) + pos_cl;

			while (k1 < l1 && k2 < l2)
			{
				if (k1 < k2)
				{
					if (less_nan<value_type>::eval(ptr_A[pos_1], Z))
					{
						return false;
					};
					if (greater_nan<value_type>::eval(ptr_A[pos_1], Z))
					{
						goto label_exit_col;
					};
					++k1;
					++pos_1;
				}
				else if (k1 > k2)
				{
					if (less_nan<value_type>::eval(Z, ptr_A[pos_2]))
					{
						return false;
					};
					if (greater_nan<value_type>::eval(Z, ptr_A[pos_2]))
					{
						goto label_exit_col;
					};
					++k2; 
					++pos_2;
				}
				else
				{ 
					if (less_nan<value_type>::eval(ptr_A[pos_1], ptr_A[pos_2]))
					{
						return false;
					};
					if (greater_nan<value_type>::eval(ptr_A[pos_1], ptr_A[pos_2]))
					{
						goto label_exit_col;
					};
					++k1; 
					++k2;
					++pos_1;
					++pos_2;
				};
			};
			while (k1 < l1)
			{
				if (less_nan<value_type>::eval(ptr_A[pos_1],Z))
				{
					return false;
				};
				if (greater_nan<value_type>::eval(ptr_A[pos_1], Z))
				{
					goto label_exit_col;
				};
				++k1;
				++pos_1;
			};
			while (k2 < l2)
			{				
				if (less_nan<value_type>::eval(Z,ptr_A[pos_2]))
				{
					return false;
				};
				if (greater_nan<value_type>::eval(Z,ptr_A[pos_2]))
				{
					goto label_exit_col;
				};
				++k2; 
				++pos_2;
			};

			label_exit_col:

			pos_c += A.ld();
			pos_cl += A.ld();
		};

		return true;
	};
};
template<class in_type>
struct is_sortedrows_helper<in_type,struct_banded> 
{
	static bool eval(const in_type& A)
	{
		typedef in_type::value_type value_type;
        const value_type Z = gd::default_value<value_type>(gd::get_ti(A));

		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0) 
		{
			return true;
		};

		Integer dpos = A.ld() - 1;

        const value_type* ptr_A = A.rep_ptr();

		for (Integer i = 1; i < r; ++i)
		{
			Integer k1 = A.first_col(i),	k2 = A.first_col(i-1);
			Integer l1 = A.last_col(i)+1,   l2 = A.last_col(i-1)+1;

			Integer pos_1 = A.first_elem_pos_row(i);
			Integer pos_2 = A.first_elem_pos_row(i-1);

			while (k1 < l1 && k2 < l2)
			{
				if (k1 < k2)
				{
					if (less_nan<value_type>::eval(ptr_A[pos_1],Z))
					{
						return false;
					};
					if (greater_nan<value_type>::eval(ptr_A[pos_1],Z))
					{
						goto label_exit_row;
					};
					++k1;
					pos_1+= dpos;
				}
				else if (k1 > k2)
				{
					if (less_nan<value_type>::eval(Z,ptr_A[pos_2]))
					{
						return false;
					};
					if (greater_nan<value_type>::eval(Z,ptr_A[pos_2]))
					{
						goto label_exit_row;
					};
					++k2; 
					pos_2+= dpos;
				}
				else
				{ 
					if (less_nan<value_type>::eval(ptr_A[pos_1],ptr_A[pos_2]))
					{
						return false;
					};
					if (greater_nan<value_type>::eval(ptr_A[pos_1],ptr_A[pos_2]))
					{
						goto label_exit_row;
					};
					++k1; 
					++k2;
					pos_1+= dpos;
					pos_2+= dpos;
				};
			};
			while (k1 < l1)
			{
				if (less_nan<value_type>::eval(ptr_A[pos_1],Z))
				{
					return false;
				};
				if (greater_nan<value_type>::eval(ptr_A[pos_1],Z))
				{
					goto label_exit_row;
				};
				++k1;
				pos_1+= dpos;
			};
			while (k2 < l2)
			{				
				if (less_nan<value_type>::eval(Z,ptr_A[pos_2]))
				{
					return false;
				};
				if (greater_nan<value_type>::eval(Z,ptr_A[pos_2]))
				{
					goto label_exit_row;
				};
				++k2; 
				pos_2+= dpos;
			};

			label_exit_row:
				(void)0;
		};

		return true;
	};
};

template<class in_type>
struct issorted_accumulator
{
	private:
		enum state_t { false_s, true_s,  uninitialized };

		state_t					state;
		in_type					current_value;
        const in_type           Z;
		Integer					pos;
		std::vector<state_t>	st_array;
		std::vector<Integer>	st_pos;
		gd::vector<in_type>	    st_current_value;
        gd::type_info           m_ti;

		Integer					size;		

        issorted_accumulator&   operator=(const issorted_accumulator&);

	public:
        issorted_accumulator(gd::type_info ti)	
            :current_value(gd::default_value<in_type>(ti))
            ,Z(gd::default_value<in_type>(ti))
            ,m_ti(ti),st_current_value(ti)
        {};

		void set_size(Integer r, Integer , Integer )	
		{ 
			size = r;
		};
		void reset()						
		{ 
			state = uninitialized;
			pos   = 0;
		};
		void reset_array(Integer s)			
		{ 
			st_array.clear(); 
			st_pos.clear(); 
			st_current_value.clear(); 

			st_array.resize(s,uninitialized);	
			st_pos.resize(s,0);	
			st_current_value.resize(s);
		};
		void current_vector(Integer )	{};
		bool add(Integer v, in_type val)
		{ 
			if (state == uninitialized)
			{				
				pos = v + 1;
				current_value = val;

				if ( v > 0 && less_nan<in_type>::eval(val,Z))
				{
					state = false_s;
				}
				else
				{
					state = true_s;
				};
				return false;
			};
			if (state == true_s)
			{
				if ( v == pos )
				{
					if ( less_nan<in_type>::eval(val,current_value))
					{
						state = false_s;
					};
				}
				else
				{
					if ( less_nan<in_type>::eval(Z,current_value))
					{
						state = false_s;
					};
					if ( less_nan<in_type>::eval(val,Z))
					{
						state = false_s;
					};
				};
				pos = v + 1;
				current_value = val;
			};
			return !(state==true_s);
		};
		void add(Integer p,Integer v, in_type val)		
		{ 
			if (st_array[p] == uninitialized)
			{				
				st_pos[p] = v + 1;
				st_current_value[p] = val;

				if ( v > 0 && less_nan<in_type>::eval(val,Z))
				{
					st_array[p] = false_s;
				}
				else
				{
					st_array[p] = true_s;
				};

				return;
			};
			if (st_array[p] == true_s)
			{
				if ( v == st_pos[p] )
				{
					if ( less_nan<in_type>::eval(val,st_current_value[p]))
					{
						st_array[p] = false_s;
					};
				}
				else
				{
					if ( less_nan<in_type>::eval(Z,st_current_value[p]))
					{
						st_array[p] = false_s;
					};
					if ( less_nan<in_type>::eval(val,Z))
					{
						st_array[p] = false_s;
					};
				};
				st_pos[p] = v + 1;
				st_current_value[p] = val;
			};
		};
		bool add_zero(Integer )				{ return false;};
		void add_zero(Integer ,Integer )	{};

		bool value()					
		{ 
			if (state == uninitialized)
			{
				return true;
			};
			if (pos < size)
			{
				if ( less_nan<in_type>::eval(Z,current_value))
				{
					return false;
				};
			};
			return state == true_s;
		};
		bool value(Integer p)			
		{ 
			if (st_array[p] == uninitialized)
			{
				return true;
			};
			if (st_pos[p] < size)
			{
				if ( less_nan<in_type>::eval(Z,st_current_value[p]))
				{
					return false;
				};
			};
			return st_array[p]==true_s;
		};
};


template<class MP>
struct is_sorted_helper
{
	static IntegerMatrix eval(const MP& A, Integer dim)
	{
		typedef MP::value_type				in_type;

		typedef issorted_accumulator<in_type> accum;
		return eval_vec_functor2<IntegerMatrix,MP, accum>::eval(A,dim);
	};
};

template<class MP>
typename sort_helper<MP>::ret_type_issorted 
sort_helper<MP>::eval_issorted(const MP& m, Integer dim)
{
	return is_sorted_helper<MP>::eval(m,dim);
};
template<class MP>
bool 
sort_helper<MP>::eval_issorted_rows(const MP& m)
{
	return is_sortedrows_helper<MP,typename MP::struct_type>::eval(m);
};		
template<class MP>
bool 
sort_helper<MP>::eval_issorted_cols(const MP& m)
{
	return is_sortedcols_helper<MP,typename MP::struct_type>::eval(m);
};		

};};};

MACRO_INSTANTIATE_G_1(mmlib::raw::details::sort_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::sort_helper)
