/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/scalfunc.h"
#include "mmlib/mp/instantiate.h"
#include "mmlib/details/mpl.h"
#include "mmlib/func/raw/eval_functor.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/details/matrix_func_binary.inl"

namespace mmlib { namespace raw 
{

template<class T> struct correct_complex_scalar		{ typedef T type; };
template<> struct correct_complex_scalar<Complex>	{ typedef const Complex& type; };

template<class ret_type,class M,bool is_int>
struct eval_is_nan_helper
{
	static ret_type eval(const M& m)
	{
		return eval_functor<ret_type,M>::eval(m,details::isnan_helper<M::value_type>());
	};
};
template<class ret_type,class M>
struct eval_is_nan_helper<ret_type,M,true>
{
	static ret_type eval(const M& m)
	{
        gd::type_info ret_ti = gd::get_raw_ti();
		IntegerSparseMatrix out(ret_ti,m.rows(),m.cols());
        return out;
	};
};

template<class ret_type,class M,bool is_int>
struct eval_is_inf_helper
{
	static ret_type eval(const M& m)
	{
		return eval_functor<ret_type,M>::eval(m,details::isinf_helper<M::value_type>());
	};
};
template<class ret_type,class M>
struct eval_is_inf_helper<ret_type,M,true>
{
	static ret_type eval(const M& m)
	{
        gd::type_info ret_ti = gd::get_raw_ti();
		IntegerSparseMatrix out(ret_ti,m.rows(),m.cols());
        return out;
	};
};

template<class ret_type,class M,bool is_int>
struct eval_is_finite_helper
{
	static ret_type eval(const M& m)
	{
		return eval_functor<ret_type,M>::eval(m,details::isfinite_helper<M::value_type>());
	};
};
template<class ret_type,class M>
struct eval_is_finite_helper<ret_type,M,true>
{
	static ret_type eval(const M& m)
	{
        gd::type_info ret_ti = gd::get_raw_ti();
		return IntegerMatrix(ret_ti,1,m.rows(),m.cols());
	};
};

template<class M>
typename details::mappers_isa_helper<M>::ret_type_nan
details::mappers_isa_helper<M>::eval_is_nan(const M& m)
{
	static const bool is_integer = gd::is_equal<M::value_type,Integer>::value;
	return eval_is_nan_helper<ret_type_nan,M,is_integer>::eval(m);
};

template<class M>
typename details::mappers_isa_helper<M>::ret_type_inf
details::mappers_isa_helper<M>::eval_is_inf(const M& m)
{
	static const bool is_integer = gd::is_equal<M::value_type,Integer>::value;
	return eval_is_inf_helper<ret_type_inf,M,is_integer>::eval(m);
};

template<class M>
typename details::mappers_isa_helper<M>::ret_type_finite
details::mappers_isa_helper<M>::eval_is_finite(const M& m)
{
	static const bool is_integer = gd::is_equal<M::value_type,Integer>::value;
	return eval_is_finite_helper<ret_type_finite,M,is_integer>::eval(m);
};

template<class ret_type,class M,bool is_compl>
struct eval_real_helper
{
	static ret_type eval(const M& m)
	{
		return m;
	};
};
template<class ret_type,class M>
struct eval_real_helper<ret_type,M,true>
{
	static ret_type eval(const M& m)
	{
		ret_type out = eval_functor<ret_type,M>::eval(m,details::real_helper<M::value_type>());
        out.get_struct().link_struct(m.get_struct().get_real());
        return out;
	};
};

template<class ret_type,class M,bool is_compl>
struct eval_imag_helper
{
	static ret_type eval(const M& m)
	{
        typedef typename M::value_type val_type;
		typedef Matrix<val_type,struct_sparse> SparseMatrix;
        SparseMatrix out(gd::raw_type_info<val_type>::eval(),m.rows(),m.cols());
        return out;
	};
};
template<class ret_type,class M>
struct eval_imag_helper<ret_type,M,true>
{
	static ret_type eval(const M& m)
	{
		return eval_functor<ret_type,M>::eval(m,details::imag_helper<M::value_type>());
	};
};

template<class ret_type,class M,bool is_compl>
struct eval_conj_helper
{
	static ret_type eval(const M& m)
	{
		return m;
	};
};
template<class ret_type,class M>
struct eval_conj_helper<ret_type,M,true>
{
	static ret_type eval(const M& m)
	{
		ret_type out = eval_functor<ret_type,M>::eval(m,details::conj_helper<M::value_type>());
        out.get_struct().link_struct(m.get_struct().get_conj());
        return out;
	};
};

template<class ret_type,class M,class value_type>
struct eval_abs_helper
{
	static ret_type eval(const M& m)
	{
		ret_type out = eval_functor<ret_type,M>::eval(m,details::abs_helper<M::value_type>());
        out.get_struct().link_struct(m.get_struct().get_abs());
        return out;
	};
};

template<class ret_type,class M>
struct eval_arg_helper
{
	static ret_type eval(const M& m)
	{
		return eval_functor<ret_type,M>::eval(m,details::arg_helper<M::value_type>());
	};
};

template<class M>
typename details::mappers_real_helper<M>::ret_type
details::mappers_real_helper<M>::eval_real(const M& m)
{
	static const bool is_complex = gd::is_equal<M::value_type,Complex>::value
                                    ||gd::is_equal<M::value_type,Object>::value;
	return eval_real_helper<ret_type,M,is_complex>::eval(m);
};

template<class M>
typename details::mappers_real_helper<M>::ret_type_imag
details::mappers_real_helper<M>::eval_imag(const M& m)
{
	static const bool is_complex = gd::is_equal<M::value_type,Complex>::value
                                    ||gd::is_equal<M::value_type,Object>::value;
	return eval_imag_helper<ret_type_imag,M,is_complex>::eval(m);
};

template<class M>
typename details::mappers_real_helper<M>::ret_type_conj
details::mappers_real_helper<M>::eval_conj(const M& m)
{
	static const bool is_complex = gd::is_equal<M::value_type,Complex>::value;
	return eval_conj_helper<ret_type_conj,M,is_complex>::eval(m);
};

template<class M>
typename details::mappers_real_helper<M>::ret_type
details::mappers_real_helper<M>::eval_abs(const M& m)
{
	return eval_abs_helper<ret_type,M,M::value_type>::eval(m);
};
template<class M>
typename details::mappers_real_helper<M>::ret_type_arg
details::mappers_real_helper<M>::eval_arg(const M& m)
{
	return eval_arg_helper<ret_type_arg,M>::eval(m);
};

template<class M>
typename details::mappers_func_helper<M>::ret_type_sqrt
details::mappers_func_helper<M>::eval_sqrt(const M& m)
{
	return eval_functor<ret_type_sqrt,M>::eval(m,sqrt_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_pow2
details::mappers_func_helper<M>::eval_pow2(const M& m)
{
	return eval_functor<ret_type_pow2,M>::eval(m,pow2_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_log
details::mappers_func_helper<M>::eval_log(const M& m)
{
	return eval_functor<ret_type_log,M>::eval(m,log_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_log2
details::mappers_func_helper<M>::eval_log2(const M& m)
{
	return eval_functor<ret_type_log2,M>::eval(m,log2_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_log10
details::mappers_func_helper<M>::eval_log10(const M& m)
{
	return eval_functor<ret_type_log10,M>::eval(m,log10_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_exp
details::mappers_func_helper<M>::eval_exp(const M& m)
{
	return eval_functor<ret_type_exp,M>::eval(m,exp_helper<M::value_type>());
};

template<class M>
typename details::mappers_func_helper<M>::ret_type_sin
details::mappers_func_helper<M>::eval_sin(const M& m)
{
	return eval_functor<ret_type_sin,M>::eval(m,sin_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_cos
details::mappers_func_helper<M>::eval_cos(const M& m)
{
	return eval_functor<ret_type_cos,M>::eval(m,cos_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_tan
details::mappers_func_helper<M>::eval_tan(const M& m)
{
	return eval_functor<ret_type_tan,M>::eval(m,tan_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_cot
details::mappers_func_helper<M>::eval_cot(const M& m)
{
	return eval_functor<ret_type_cot,M>::eval(m,cot_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_sec
details::mappers_func_helper<M>::eval_sec(const M& m)
{
	return eval_functor<ret_type_sec,M>::eval(m,sec_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_csc
details::mappers_func_helper<M>::eval_csc(const M& m)
{
	return eval_functor<ret_type_csc,M>::eval(m,csc_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_asin
details::mappers_func_helper<M>::eval_asin(const M& m)
{
	return eval_functor<ret_type_asin,M>::eval(m,asin_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_acos
details::mappers_func_helper<M>::eval_acos(const M& m)
{
	return eval_functor<ret_type_acos,M>::eval(m,acos_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_atan
details::mappers_func_helper<M>::eval_atan(const M& m)
{
	return eval_functor<ret_type_atan,M>::eval(m,atan_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_acot
details::mappers_func_helper<M>::eval_acot(const M& m)
{
	return eval_functor<ret_type_acot,M>::eval(m,acot_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_asec
details::mappers_func_helper<M>::eval_asec(const M& m)
{
	return eval_functor<ret_type_asec,M>::eval(m,asec_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_acsc
details::mappers_func_helper<M>::eval_acsc(const M& m)
{
	return eval_functor<ret_type_acsc,M>::eval(m,acsc_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_sinh
details::mappers_func_helper<M>::eval_sinh(const M& m)
{
	return eval_functor<ret_type_sinh,M>::eval(m,sinh_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_cosh
details::mappers_func_helper<M>::eval_cosh(const M& m)
{
	return eval_functor<ret_type_cosh,M>::eval(m,cosh_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_tanh
details::mappers_func_helper<M>::eval_tanh(const M& m)
{
	return eval_functor<ret_type_tanh,M>::eval(m,tanh_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_coth
details::mappers_func_helper<M>::eval_coth(const M& m)
{
	return eval_functor<ret_type_coth,M>::eval(m,coth_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_sech
details::mappers_func_helper<M>::eval_sech(const M& m)
{
	return eval_functor<ret_type_sech,M>::eval(m,sech_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_csch
details::mappers_func_helper<M>::eval_csch(const M& m)
{
	return eval_functor<ret_type_csch,M>::eval(m,csch_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_asinh
details::mappers_func_helper<M>::eval_asinh(const M& m)
{
	return eval_functor<ret_type_asinh,M>::eval(m,asinh_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_acosh
details::mappers_func_helper<M>::eval_acosh(const M& m)
{
	return eval_functor<ret_type_acosh,M>::eval(m,acosh_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_atanh
details::mappers_func_helper<M>::eval_atanh(const M& m)
{
	return eval_functor<ret_type_atanh,M>::eval(m,atanh_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_acoth
details::mappers_func_helper<M>::eval_acoth(const M& m)
{
	return eval_functor<ret_type_acoth,M>::eval(m,acoth_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_asech
details::mappers_func_helper<M>::eval_asech(const M& m)
{
	return eval_functor<ret_type_asech,M>::eval(m,asech_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_acsch
details::mappers_func_helper<M>::eval_acsch(const M& m)
{
	return eval_functor<ret_type_acsch,M>::eval(m,acsch_helper<M::value_type>());
};

template<class ret_type,class in_type,class value_type>
struct eval_floor_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::floor_helper<value_type>());
	};
};

template<class ret_type,class in_type>
struct eval_floor_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};
template<class ret_type,class in_type,class value_type>
struct eval_ceil_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::ceil_helper<value_type>());
	};
};
template<class ret_type,class in_type>
struct eval_ceil_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};
template<class ret_type,class in_type,class value_type>
struct eval_round_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::round_helper<value_type>());
	};
};
template<class ret_type,class in_type>
struct eval_round_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};
template<class ret_type,class in_type,class value_type>
struct eval_fix_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::fix_helper<value_type>());
	};
};
template<class ret_type,class in_type>
struct eval_fix_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};
template<class ret_type,class in_type,class value_type>
struct eval_trunc_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::trunc_helper<value_type>());
	};
};
template<class ret_type,class in_type>
struct eval_trunc_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};

template<class ret_type,class in_type,class value_type>
struct eval_ifloor_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::ifloor_helper<value_type>());
	};
};

template<class ret_type,class in_type>
struct eval_ifloor_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};
template<class ret_type,class in_type,class value_type>
struct eval_iceil_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::iceil_helper<value_type>());
	};
};
template<class ret_type,class in_type>
struct eval_iceil_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};
template<class ret_type,class in_type,class value_type>
struct eval_iround_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::iround_helper<value_type>());
	};
};
template<class ret_type,class in_type>
struct eval_iround_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};
template<class ret_type,class in_type,class value_type>
struct eval_ifix_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::ifix_helper<value_type>());
	};
};
template<class ret_type,class in_type>
struct eval_ifix_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};
template<class ret_type,class in_type,class value_type>
struct eval_itrunc_helper
{
	static ret_type eval(const in_type& m)
	{
		return eval_functor<ret_type,in_type>::eval(m,details::itrunc_helper<value_type>());
	};
};
template<class ret_type,class in_type>
struct eval_itrunc_helper<ret_type,in_type,Integer>
{
	static ret_type eval(const in_type& mat)
	{
		return mat;
	};
};

template<class M>
typename details::mappers_func_helper<M>::ret_type_floor
details::mappers_func_helper<M>::eval_floor(const M& m)
{
	return eval_floor_helper<ret_type_floor,M,M::value_type>::eval(m);
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_ceil
details::mappers_func_helper<M>::eval_ceil(const M& m)
{
	return eval_ceil_helper<ret_type_ceil,M,M::value_type>::eval(m);
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_round
details::mappers_func_helper<M>::eval_round(const M& m)
{
	return eval_round_helper<ret_type_round,M,M::value_type>::eval(m);
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_fix
details::mappers_func_helper<M>::eval_fix(const M& m)
{
	return eval_fix_helper<ret_type_fix,M,M::value_type>::eval(m);
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_trunc
details::mappers_func_helper<M>::eval_trunc(const M& m)
{
	return eval_trunc_helper<ret_type_trunc,M,M::value_type>::eval(m);
};

template<class M>
typename details::mappers_func_helper<M>::ret_type_ifloor
details::mappers_func_helper<M>::eval_ifloor(const M& m)
{
	return eval_ifloor_helper<ret_type_ifloor,M,M::value_type>::eval(m);
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_iceil
details::mappers_func_helper<M>::eval_iceil(const M& m)
{
	return eval_iceil_helper<ret_type_iceil,M,M::value_type>::eval(m);
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_iround
details::mappers_func_helper<M>::eval_iround(const M& m)
{
	return eval_iround_helper<ret_type_iround,M,M::value_type>::eval(m);
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_ifix
details::mappers_func_helper<M>::eval_ifix(const M& m)
{
	return eval_ifix_helper<ret_type_ifix,M,M::value_type>::eval(m);
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_itrunc
details::mappers_func_helper<M>::eval_itrunc(const M& m)
{
	return eval_itrunc_helper<ret_type_itrunc,M,M::value_type>::eval(m);
};

template<class M>
typename details::mappers_func_helper<M>::ret_type_sign
details::mappers_func_helper<M>::eval_sign(const M& m)
{
	return eval_functor<ret_type_sign,M>::eval(m,sign_helper<M::value_type>());
};
template<class M>
typename details::mappers_func_helper<M>::ret_type_isign
details::mappers_func_helper<M>::eval_isign(const M& m)
{
	return eval_functor<ret_type_isign,M>::eval(m,isign_helper<M::value_type>());
};

template<class M>
typename details::unary_helper<M>::ret_type_minus
details::unary_helper<M>::eval_minus(const M& m)
{
	return eval_functor<ret_type_minus,M>::eval(m,uminus_helper<M::value_type>());

};

template<class M>
typename details::unary_helper<M>::ret_type_neg
details::unary_helper<M>::eval_neg(const M& m)
{
	return eval_functor<ret_type_neg,M>::eval(m,op_neg_helper<M::value_type>());

};
template<class M>
typename details::unary_helper<M>::ret_type_is_true
details::unary_helper<M>::eval_is_true(const M& m)
{
	return eval_functor<ret_type_is_true,M>::eval(m,is_true_helper<M::value_type>());
};

};};

MACRO_INSTANTIATE_G_1(mmlib::raw::details::mappers_isa_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::mappers_isa_helper)

MACRO_INSTANTIATE_G_1(mmlib::raw::details::mappers_real_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::mappers_real_helper)

MACRO_INSTANTIATE_G_1(mmlib::raw::details::mappers_func_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::mappers_func_helper)

MACRO_INSTANTIATE_G_1(mmlib::raw::details::unary_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::unary_helper)
