/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/enablers.h"
#include "mmlib/base/return_types.h"
#include "mmlib/mp/promote_type.h"
#include "mmlib/details/scalfunc_helpers.h"

namespace mmlib { namespace raw
{

namespace gd = mmlib::details;

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::isnan>>::type
isnan(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_isa_helper<MP>::eval_is_nan(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::isnan>>::type
isnan(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_isnan>::eval(m);
	return details::isnan_helper<MP>::eval(ret_ti,m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::isinf>>::type
isinf(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_isa_helper<MP>::eval_is_inf(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::isinf>>::type
isinf(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_isinf>::eval(m);
	return details::isinf_helper<MP>::eval(ret_ti,m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::isfinite>>::type
isfinite(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_isa_helper<MP>::eval_is_finite(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::isfinite>>::type
isfinite(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_isfinite>::eval(m);
	return details::isfinite_helper<MP>::eval(ret_ti,m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::real>>::type
real(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_real_helper<MP>::eval_real(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::real>>::type
real(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_real>::eval(m);
	return details::real_helper<MP>::eval(ret_ti,m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::abs>>::type
abs(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_real_helper<MP>::eval_abs(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::abs>>::type
abs(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_abs>::eval(m);
	return details::abs_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::conj>>::type
conj(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_real_helper<MP>::eval_conj(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::conj>>::type
conj(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_conj>::eval(m);
	return details::conj_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::imag>>::type
imag(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_real_helper<MP>::eval_imag(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::imag>>::type
imag(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_imag>::eval(m);
	return details::imag_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::arg>>::type
arg(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_real_helper<MP>::eval_arg(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::arg>>::type
arg(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_arg>::eval(m);
	return details::arg_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::angle>>::type
angle(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_real_helper<MP>::eval_arg(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::angle>>::type
angle(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::angle_helper<MP>::eval(m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::sqrt>>::type
sqrt(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_sqrt(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::sqrt>>::type
sqrt(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_sqrt>::eval(m);
	return details::sqrt_helper<MP>::eval(ret_ti,m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::pow2>>::type
pow2(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_pow2(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::pow2>>::type
pow2(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::pow2_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::log>>::type
log(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_log(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::log>>::type
log(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_log>::eval(m);
	return details::log_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::exp>>::type
exp(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_exp(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::exp>>::type
exp(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::exp_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::log2>>::type
log2(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_log2(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::log2>>::type
log2(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_log2>::eval(m);
	return details::log2_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::log10>>::type
log10(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_log10(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::log10>>::type
log10(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_log10>::eval(m);
	return details::log10_helper<MP>::eval(ret_ti,m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::floor>>::type
floor(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_floor(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::floor>>::type
floor(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_floor>::eval(m);
	return details::floor_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::ifloor>>::type
ifloor(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_ifloor(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::ifloor>>::type
ifloor(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_ifloor>::eval(m);
	return details::ifloor_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::ceil>>::type
ceil(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_ceil(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::ceil>>::type
ceil(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_ceil>::eval(m);
	return details::ceil_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::iceil>>::type
iceil(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_iceil(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::iceil>>::type
iceil(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_iceil>::eval(m);
	return details::iceil_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::round>>::type
round(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_round(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::round>>::type
round(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_round>::eval(m);
	return details::round_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::iround>>::type
iround(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_iround(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::iround>>::type
iround(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_iround>::eval(m);
	return details::iround_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::fix>>::type
fix(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_fix(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::fix>>::type
fix(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_fix>::eval(m);
	return details::fix_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::ifix>>::type
ifix(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_ifix(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::ifix>>::type
ifix(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_ifix>::eval(m);
	return details::ifix_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::trunc>>::type
trunc(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_trunc(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::trunc>>::type
trunc(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_trunc>::eval(m);
	return details::trunc_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::itrunc>>::type
itrunc(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_itrunc(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::itrunc>>::type
itrunc(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_itrunc>::eval(m);
	return details::itrunc_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::sign>>::type
sign(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_sign(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::sign>>::type
sign(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_sign>::eval(m);
	return details::sign_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::isign>>::type
isign(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_isign(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::isign>>::type
isign(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_sign>::eval(m);
	return details::isign_helper<MP>::eval(ret_ti,m);
};


template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::sin>>::type
sin(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_sin(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::sin>>::type
sin(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::sin_helper<MP>::eval(m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::cos>>::type
cos(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_cos(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::cos>>::type
cos(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::cos_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::tan>>::type
tan(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_tan(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::tan>>::type
tan(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::tan_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::cot>>::type
cot(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_cot(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::cot>>::type
cot(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::cot_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::sec>>::type
sec(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_sec(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::sec>>::type
sec(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::sec_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::csc>>::type
csc(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_csc(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::csc>>::type
csc(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::csc_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::asin>>::type
asin(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_asin(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::asin>>::type
asin(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_asin>::eval(m);
	return details::asin_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::acos>>::type
acos(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_acos(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::acos>>::type
acos(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_acos>::eval(m);
	return details::acos_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::atan>>::type
atan(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_atan(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::atan>>::type
atan(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::atan_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::acot>>::type
acot(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_acot(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::acot>>::type
acot(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::acot_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::asec>>::type
asec(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_asec(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::asec>>::type
asec(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_asec>::eval(m);
	return details::asec_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::acsc>>::type
acsc(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_acsc(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::acsc>>::type
acsc(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_acsc>::eval(m);
	return details::acsc_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::sinh>>::type
sinh(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_sinh(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::sinh>>::type
sinh(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::sinh_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::cosh>>::type
cosh(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_cosh(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::cosh>>::type
cosh(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::cosh_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::tanh>>::type
tanh(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_tanh(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::tanh>>::type
tanh(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::tanh_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::coth>>::type
coth(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_coth(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::coth>>::type
coth(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::coth_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::sech>>::type
sech(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_sech(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::sech>>::type
sech(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::sech_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::csch>>::type
csch(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_csch(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::csch>>::type
csch(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::csch_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::asinh>>::type
asinh(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_asinh(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::asinh>>::type
asinh(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::asinh_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::acosh>>::type
acosh(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_acosh(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::acosh>>::type
acosh(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_acosh>::eval(m);
	return details::acosh_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::atanh>>::type
atanh(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_atanh(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::atanh>>::type
atanh(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_atanh>::eval(m);
	return details::atanh_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::acoth>>::type
acoth(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_acoth(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::acoth>>::type
acoth(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_acoth>::eval(m);
	return details::acoth_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::asech>>::type
asech(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_asech(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::asech>>::type
asech(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_asech>::eval(m);
	return details::asech_helper<MP>::eval(ret_ti,m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::acsch>>::type
acsch(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::mappers_func_helper<MP>::eval_acsch(promote_type::eval(m));
};
template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::acsch>>::type
acsch(const M& m)
{
	typedef gd::promote_scalar<M>::type MP;
	return details::acsch_helper<MP>::eval(m);
};
template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::op_unary_minus>>::type
operator-(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::unary_helper<promote_type::type>::eval_minus(promote_type::eval(arg_1));
};
inline Complex operator-(const Complex& m)
{
    return details::uminus_helper<Complex>::eval(gd::get_raw_ti(),m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::op_neg>>::type
operator!(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::unary_helper<promote_type::type>::eval_neg(promote_type::eval(arg_1));
};
inline bool operator!(const Complex& m)
{
	return details::op_neg_helper<Complex>::eval(gd::get_raw_ti(),m);
};

template<class M>
inline typename gd::enable_if_matrix<M,return_type<M,raw_functions::is_true>>::type
is_true(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::unary_helper<promote_type::type>::eval_is_true(promote_type::eval(arg_1));
};

template<class M>
inline typename gd::enable_if_scalar<M,return_type_scalar<M,raw_functions::is_true>>::type
is_true(const M& arg_1)
{
	typedef gd::promote_scalar<M>::type MP;
    gd::type_info ret_ti = gd::return_scal<M,gd::ti_func::func_istrue>::eval(arg_1);
	return details::is_true_helper<MP>::eval(ret_ti,arg_1);
};

}};