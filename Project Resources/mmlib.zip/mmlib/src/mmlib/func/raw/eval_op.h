/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/func/raw/eval_bin_functor.h"
#include "mmlib/func/raw/eval_functor.h"
#include "mmlib/details/scalfunc_helpers.h"
#include "mmlib/utils/utils.h"

#pragma warning( push )
#pragma warning(disable:4127)	// conditional expression is constant

namespace mmlib { namespace raw { namespace details
{

template<class ret_type,class in_type,class functor,bool is_scal_str>
struct eval_scalar
{
	template<class T>
    static ret_type eval(const in_type& A,bool is_rev,T val)
	{
        gd::type_info ret_ti = gd::return_func_ti<functor,in_type,T>::eval(A,val);
		if (is_rev)
		{
			return eval_functor_2<ret_type,in_type>
                    ::eval(ret_ti,A,functor::get_scalar_functor<T,true>(val));
		}
		else
		{
			return eval_functor_2<ret_type,in_type>
                    ::eval(ret_ti,A,functor::get_scalar_functor<T,false>(val));
		};
	};
};
template<class ret_type,class in_type,class functor>
struct eval_scalar<ret_type,in_type,functor, true>
{
	template<class T>
	static ret_type eval(const in_type& A,bool is_rev,T val)
	{
        gd::type_info ret_ti = gd::return_func_ti<functor,in_type,T>::eval(A,val);

		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_dense> FullMatrix;

		FullMatrix out = eval_scalar<FullMatrix,in_type,functor,false>::eval(A,is_rev,val);
		return converter<ret_type,FullMatrix>::eval(ret_ti,out);
	};
};

template<class ret_type,class in_type,class functor,bool is_scal_str>
struct eval_scalar2
{
	template<class T>
	static ret_type eval(const in_type& A,bool is_rev,T val, const functor& func)
	{
        gd::type_info ret_ti = gd::return_func_ti<functor,in_type,T>::eval(A,val);

		if (is_rev)
		{
			return eval_functor_2<ret_type,in_type>
                            ::eval(ret_ti,A,func.get_scalar_functor<T,true>(val));
		}
		else
		{
			return eval_functor_2<ret_type,in_type>
                            ::eval(ret_ti,A,func.get_scalar_functor<T,false>(val));
		};
	};
};
template<class ret_type,class in_type,class functor>
struct eval_scalar2<ret_type,in_type,functor, true>
{
	template<class T>
	static ret_type eval(const in_type& A,bool is_rev,T val, const functor& func)
	{
		typedef ret_type::value_type val_type;
		typedef Matrix<val_type,struct_dense> FullMatrix;

        gd::type_info ret_ti = gd::return_func_ti<functor,in_type,T>::eval(A,val);

		FullMatrix out = eval_scalar2<FullMatrix,in_type,functor,false>::eval(A,is_rev,val,func);
		return converter<ret_type,FullMatrix>::eval(ret_ti,out);
	};
};

template<class ret_type,class M1,class M2,class functor>
struct eval_op
{
    static ret_type eval(const M1& A, const M2& B)
	{
		typedef ret_type::value_type ret_val_type;
		typedef M1::value_type val_type_1;
		typedef M2::value_type val_type_2;

		if (A.rows() == 1 && A.cols() == 1)
		{		
			static const bool is_str = !gd::is_equal<M1::struct_type,struct_dense>::value;
			val_type_1 s1 = A(1,1);
			if (gd::is_equal<val_type_1,Complex>::value 
                    && imag_helper<val_type_1>::eval(gd::get_raw_ti(),s1) == 0.)
			{
				typedef gd::min_type<val_type_1,Real>::type val_type;				
				return eval_scalar<ret_type,M2,functor,is_str>
                            ::eval(B,true,real_helper<val_type_1>::eval(gd::get_raw_ti(),s1) );
			}
			else
			{
				return eval_scalar<ret_type,M2,functor,is_str>::eval(B,true,s1);
			};
		};
		if (B.rows() == 1 && B.cols() == 1)
		{
			static const bool is_str = !gd::is_equal<M2::struct_type,struct_dense>::value;
			val_type_2 s2 = B(1,1);

			if (gd::is_equal<val_type_2,Complex>::value 
                        && imag_helper<val_type_2>::eval(gd::get_raw_ti(),s2) == 0.)
			{
				typedef gd::min_type<val_type_2,Real>::type val_type;
				return eval_scalar<ret_type,M1,functor,is_str>
                            ::eval(A,false,real_helper<val_type_2>::eval(gd::get_raw_ti(),s2));
			}
			else
			{
				return eval_scalar<ret_type,M1,functor,is_str>::eval(A,false,s2);
			};
		};

		static const bool ZZ = functor::ZZ;
		static const bool ZN = functor::ZN;
		static const bool NZ = functor::NZ;
		ret_type out = eval_bin_functor<ret_type,functor,M1,M2,ZZ,ZN,NZ>::eval(A,B);

        struct_flag so = functor::op_struct(A.get_struct(),B.get_struct());
        out.get_struct().link_struct(so);
        return out;
	};
};


};};};

#pragma warning( pop )