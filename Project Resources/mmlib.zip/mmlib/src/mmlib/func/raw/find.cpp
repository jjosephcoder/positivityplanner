/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/find.h"
#include "mmlib/mp/instantiate.h"
#include <vector>
#include "mmlib/eval_functors.h"
#include "mmlib/error/error_check.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/utils/utils.h"
#include "mmlib/base/integer.h"

namespace mmlib { namespace raw { namespace details 
{
	 
template<class in, class functor, class str>
struct find_impl
{};

template<class in, class functor>
struct find_impl<in,functor,struct_dense>
{
	static void eval(const in& A, functor& func)
	{
		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0)
		{
			return;
		};

        const in::value_type* ptr_A = A.ptr();

		for (Integer j = 0; j < c; ++j)
		{
			for (Integer i = 0; i < r; ++i)
			{
				func.add(i+1,j+1,ptr_A[i]);
			};
            ptr_A += A.ld();
		};
		return;
	};
};
template<class in, class functor>
struct find_impl<in,functor,struct_banded>
{
	static void eval(const in& A, functor& func)
	{
		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0)
		{
			return;
		};

        typedef typename in::value_type val_type;

		if (A.ldiags() == 0 && A.udiags() == 0)
		{
            const val_type* ptr_A = A.rep_ptr();

			for (Integer j = 0; j < c; ++j)
			{
				if (j > 0)
				{
					func.add_zero(1,j,j+1);
				};

				if (j < r)
				{
					func.add(j+1,j+1,ptr_A[0]);
				};

				if (j < r-1)
				{
					func.add_zero(j + 2,r,j+1);
				};

                ptr_A += A.ld();
			};
		}
		else
		{
            const val_type* ptr_A = A.rep_ptr();

			for (Integer j = 0; j < c; ++j)
			{
				Integer first_row = A.first_row(j);
				Integer last_row = A.last_row(j);

				if (first_row > 0)
				{
					func.add_zero(1,first_row,j+1);
				};

				Integer pos = A.first_elem_pos(j);
				for (Integer i = first_row; i <= last_row; ++i, ++pos)
				{
					func.add(i+1,j+1,ptr_A[pos]);
				};

				if (last_row < r-1)
				{
					func.add_zero(last_row + 2,r,j+1);
				};

                ptr_A += A.ld();
			};
		};
		return;
	};
};
template<class in, class functor>
struct find_impl<in,functor,struct_sparse>
{
	static void eval(const in& A, functor& func)
	{
		Integer r = A.rows(), c = A.cols();

		if (r == 0 || c == 0)
		{
			return;
		};

		typedef in::value_type val_type;

		const spdat<val_type>& Ad		= A.rep();
		const Integer* Ad_c		= Ad.ptr_c();
		const Integer* Ad_r		= Ad.ptr_r();
		const val_type* Ad_x	= Ad.ptr_x();

		for (Integer j = 0; j < c; ++j)
		{
			Integer cr = 0;
			for (Integer i = Ad_c[j]; i < Ad_c[j+1]; ++i)
			{
				Integer k = Ad_r[i];
				if (k > cr)
				{
					func.add_zero(cr+1,k,j+1);
				};

				func.add(k+1,j+1,Ad_x[i]);
				cr = k;
			};

			if (cr < r - 1)
			{
				func.add_zero(cr+1,r,j+1);
			};
		};
		return;
	};
};
template<class T, int type>
class find_functor_base
{};
template<class T>
class find_functor_base<T,1>
{
	protected:
		Integer r;
		Integer c;

		std::vector<Integer> indices;

	public:
		find_functor_base(Integer r, Integer c)
			:r(r), c(c) 
		{};
		void add_index(Integer i, Integer j, T )
		{
			error::check_linear_index(i,j,r);

			Integer pos = imult(j-1,r) + i;
			indices.push_back(pos);
		};
		IntegerMatrix	get_return() const
		{
			Integer rc = indices.size();
            IntegerMatrix res(mmlib::details::get_raw_ti(),rc,1);
            Integer * ptr_res = res.ptr();
			
			for (Integer i = 0; i < rc; ++i)
			{
				ptr_res[i] = indices[i];
			};

			return res;
		};
};
template<class T>
class find_functor_base<T,2>
{
	protected:
		Integer r;
		Integer c;

		std::vector<Integer> indices[2];

	public:
		find_functor_base(Integer r, Integer c)
			:r(r), c(c) 
		{};
		void add_index(Integer i, Integer j, T )
		{
			indices[0].push_back(i);
			indices[1].push_back(j);
		};
		IntegerMatrix	get_return(int type) const
		{
			Integer rc = indices[0].size();
			IntegerMatrix res(mmlib::details::get_raw_ti(),rc,1);
            Integer * ptr_res = res.ptr();
			
			for (Integer i = 0; i < rc; ++i)
			{
				ptr_res[i] = indices[type][i];
			};

			return res;
		};
};
template<class T>
class find_functor_base<T,3>
{
	protected:
		Integer r;
		Integer c;

		std::vector<Integer> indices[2];
		std::vector<T>		 indices_x;

		typedef Matrix<T,struct_dense> ValueMatrix;

	public:
		find_functor_base(Integer r, Integer c)
			:r(r), c(c) 
		{};
		void add_index(Integer i, Integer j, T val)
		{
			indices[0].push_back(i);
			indices[1].push_back(j);
			indices_x.push_back(val);
		};
		IntegerMatrix	get_return(int type) const
		{
			Integer rc = indices[0].size();
			IntegerMatrix res(mmlib::details::get_raw_ti(),rc,1);
            Integer * ptr_res = res.ptr();
			
			for (Integer i = 0; i < rc; ++i)
			{
				ptr_res[i] = indices[type][i];
			};

			return res;
		};
		ValueMatrix	get_return_x() const
		{
			Integer rc = indices[0].size();
			ValueMatrix res(mmlib::details::get_raw_ti(),rc,1);
            T * ptr_res = res.ptr();
			
			for (Integer i = 0; i < rc; ++i)
			{
				ptr_res[i] = indices_x[i];
			};

			return res;
		};
};
template<class T,int type>
class find_functor : public find_functor_base<T,type>
{
	public:
		find_functor(Integer r, Integer c)
			:find_functor_base(r,c) 
		{};
		void add(Integer i, Integer j, T val)
		{
            if (mmlib::details::is_zero(val))
			{
				return;
			};
			add_index(i,j,val);
		};
		void add_zero(Integer , Integer , Integer )
		{};
};
template<class T,int type>
class find_functor_t: public find_functor_base<T,type>
{
	private:
		const test_function& test;

	public:
		find_functor_t(const test_function& test, Integer r, Integer c)
			:find_functor_base(r,c), test(test) 
		{};
		void add(Integer i, Integer j, T val)
		{
			if (test.eval(val) == false)
			{
				return;
			};
			add_index(i,j,val);
		};
		void add_zero(Integer , Integer , Integer )
		{};

	private:
		find_functor_t(const find_functor_t&);
		find_functor_t& operator=(const find_functor_t&);
};
template<class T,int type>
class find_functor_t0: public find_functor_base<T,type>
{
    private:
        typedef mmlib::details::type_info type_info;

	private:
		const test_function& test;
        type_info ti;

	public:
		find_functor_t0(type_info ti, const test_function& test, Integer r, Integer c)
			:find_functor_base(r,c), test(test), ti(ti)
		{};
		void add(Integer i, Integer j, T val)
		{
			if (test.eval(val) == false)
			{
				return;
			};
			add_index(i,j,val);
		};
		void add_zero(Integer r_start, Integer r_end, Integer col)
		{
            T zero = mmlib::details::default_value<T>(ti);
			for (Integer i = r_start; i <= r_end; ++i)
			{
				add_index(i,col,zero);
			};
		};

	private:
		find_functor_t0(const find_functor_t0&);
		find_functor_t0& operator=(const find_functor_t0&);
};

template<class MP>
typename find_helper<MP>::ret_type_find 
find_helper<MP>::eval_find(const MP& m)
{
	typedef MP::struct_type str_type;
	typedef MP::value_type val_type;

	find_functor<val_type,1> ff(m.rows(),m.cols());
	find_impl<MP,find_functor<val_type,1>,str_type>::eval(m,ff);
	return ff.get_return();
};
template<class MP>
typename find_helper<MP>::ret_type_find 
find_helper<MP>::eval_find(const MP& m, const test_function& t)
{
	typedef MP::struct_type str_type;
	typedef MP::value_type val_type;

    val_type Z = mmlib::details::default_value<val_type>(m.get_ti());
	if (t.eval(Z))
	{
		find_functor_t0<val_type,1> ff(m.get_ti(),t,m.rows(),m.cols());
		find_impl<MP,find_functor_t0<val_type,1>,str_type>::eval(m,ff);
		return ff.get_return();
	}
	else
	{
		find_functor_t<val_type,1> ff(t,m.rows(),m.cols());
		find_impl<MP,find_functor_t<val_type,1>,str_type>::eval(m,ff);
		return ff.get_return();
	};
};
template<class MP>
typename find_helper<MP>::ret_type_find2
find_helper<MP>::eval_find_2(const MP& m)
{
	typedef MP::struct_type str_type;
	typedef MP::value_type val_type;

	find_functor<val_type,2> ff(m.rows(),m.cols());
	find_impl<MP,find_functor<val_type,2>,str_type>::eval(m,ff);

    return ret_type_find2(ff.get_return(0),ff.get_return(1));
};
template<class MP>
typename find_helper<MP>::ret_type_find2
find_helper<MP>::eval_find_2(const MP& m, const test_function& t)
{
	typedef MP::struct_type str_type;
	typedef MP::value_type val_type;

    val_type Z = mmlib::details::default_value<val_type>(m.get_ti());

	if (t.eval(Z))
	{
		find_functor_t0<val_type,2> ff(m.get_ti(),t,m.rows(),m.cols());
		find_impl<MP,find_functor_t0<val_type,2>,str_type>::eval(m,ff);

		return ret_type_find2(ff.get_return(0),ff.get_return(1));
	}
	else
	{
		find_functor_t<val_type,2> ff(t,m.rows(),m.cols());
		find_impl<MP,find_functor_t<val_type,2>,str_type>::eval(m,ff);

        return ret_type_find2(ff.get_return(0),ff.get_return(1));
	};
};
template<class MP>
typename find_helper<MP>::ret_type_find3
find_helper<MP>::eval_find_3(const MP& m)
{
	typedef MP::struct_type str_type;
	typedef MP::value_type val_type;

	find_functor<val_type,3> ff(m.rows(),m.cols());
	find_impl<MP,find_functor<val_type,3>,str_type>::eval(m,ff);

    typedef ret_type_find2 ret_2;
    return ret_type_find3(ret_2(ff.get_return(0),ff.get_return(1)),ff.get_return_x());
};
template<class MP>
typename find_helper<MP>::ret_type_find3
find_helper<MP>::eval_find_3(const MP& m, const test_function& t)
{
	typedef MP::struct_type str_type;
	typedef MP::value_type val_type;

    val_type Z = mmlib::details::default_value<val_type>(m.get_ti());

	if (t.eval(Z))
	{
		find_functor_t0<val_type,3> ff(m.get_ti(),t,m.rows(),m.cols());
		find_impl<MP,find_functor_t0<val_type,3>,str_type>::eval(m,ff);

        typedef ret_type_find2 ret_2;
		return ret_type_find3(ret_2(ff.get_return(0),ff.get_return(1)),ff.get_return_x());
	}
	else
	{
		find_functor_t<val_type,3> ff(t,m.rows(),m.cols());
		find_impl<MP,find_functor_t<val_type,3>,str_type>::eval(m,ff);

        typedef ret_type_find2 ret_2;
		return ret_type_find3(ret_2(ff.get_return(0),ff.get_return(1)),ff.get_return_x());
	};
};

};};};

MACRO_INSTANTIATE_G_1(mmlib::raw::details::find_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::find_helper)
