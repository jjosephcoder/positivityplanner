/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/vecfunc.h"
#include <vector>
#include "mmlib/constants.h"
#include "mmlib/details/scalfunc_helpers.h"
#include "mmlib/mp/instantiate.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/func/raw/eval_vec_functor.h"
#include "mmlib/func/raw/eval_vec_functor2.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/details/matrix_func_unary.inl"
#include "mmlib/utils/utils.h"

namespace mmlib { namespace raw 
{

namespace gd = mmlib::details;

template<class val_type> 
struct istrue {}; 
template<>	struct istrue<Integer>	{	static bool eval(Integer val)		{	return val != 0; };		}; 
template<>	struct istrue<Real>		{	static bool eval(Real val)			{	return val != 0.; };	}; 
template<>	struct istrue<Complex>	{	static bool eval(const Complex& val){	return val != 0.; };	}; 
template<>	struct istrue<Object>	{	static bool eval(const Object& val) {	return val.is_true();   };	}; 

template<class val_type> 
struct isfalse {}; 
template<>	struct isfalse<Integer>	{	static bool eval(Integer val)		{	return val == 0; };		}; 
template<>	struct isfalse<Real>	{	static bool eval(Real val)			{	return val == 0.; };	}; 
template<>	struct isfalse<Complex>	{	static bool eval(const Complex& val){	return val == 0.; };	}; 
template<>	struct isfalse<Object>	{	static bool eval(const Object& val) {	return !val.is_true();  };	}; 
template<class T1, class T2>
inline bool less(T1 A, T2 B)		
{   
	if (is_nan(A))
	{
		return false;
	};
	if (is_nan(B))
	{
		return true;
	};
    return details::lt_helper<T1,T2>::eval(gd::get_raw_ti(),A,B); 
};
template<class T1, class T2>
inline bool greater(T1 A, T2 B)		
{   
	if (is_nan(A))
	{
		return false;
	};
	if (is_nan(B))
	{
		return true;
	};
	return details::gt_helper<T1,T2>::eval(gd::get_raw_ti(),A,B); 
};
template<class in_type, class value_type>
class nnz_accumulator 
{
	private:
		value_type				state;
		gd::vector<value_type>	state_array;
        const value_type		Z;

        nnz_accumulator&    operator=(const nnz_accumulator&);

	public:
        nnz_accumulator(gd::type_info ti)
            :state(gd::default_value<value_type>(ti))
            ,Z(gd::default_value<value_type>(ti))
            ,state_array(ti)
        {};

		void set_size(Integer ) 			{};
		void reset()						{ state = Z;	        						};
		void reset_array(Integer s)			{ state_array.clear(); 
                                              state_array.resize(s,Z);                      };	
		bool add(in_type value)				{ state += (value==Z?0:1); return false;		};
		void add(Integer p,in_type val)		{ state_array[p] += (val==Z?0:1);				};
		bool add_zero()						{ return false;									};
		void add_zero(Integer ) 			{												};

		value_type value()					{ return state;									};		
		value_type value(Integer p)			{ return state_array[p];						};		
};
template<class in_type, class value_type>
class sum_accumulator 
{
	private:
		value_type				state;
		gd::vector<value_type>	state_array;
        const value_type		Z;

        sum_accumulator&    operator=(const sum_accumulator&);

	public:
        sum_accumulator(gd::type_info ti)
            :state(gd::default_value<value_type>(ti))
            ,Z(gd::default_value<value_type>(ti))
            ,state_array(ti)
        {};

		void set_size(Integer ) 			{};
		void reset()						{ state = Z;	        						};
		void reset_array(Integer s)			{ state_array.clear(); 
                                              state_array.resize(s,Z);                      };	
		bool add(in_type value)				{ state += value; return false;					};
		void add(Integer p,in_type val)		{ state_array[p] += val;						};
		bool add_zero()						{ return false;									};
		void add_zero(Integer ) 			{												};

		value_type value()					{ return state;									};		
		value_type value(Integer p)			{ return state_array[p];						};		
};
template<class in_type, class value_type>
class sumsq_accumulator 
{
	private:
		value_type				state;
		gd::vector<value_type>	state_array;
        const value_type		Z;

        sumsq_accumulator&    operator=(const sumsq_accumulator&);

	public:
		sumsq_accumulator(gd::type_info ti)	
            : state(gd::default_value<value_type>(ti)) 
            , Z(gd::default_value<value_type>(ti))
            , state_array(ti)
        {};

		void set_size(Integer )				{};
		void reset()						{ state = Z;	        						};
		void reset_array(Integer s)			{ state_array.clear(); 
                                              state_array.resize(s,Z);                      };	
		bool add(in_type value)				{ state += value*value; return false;			};
		void add(Integer p,in_type val)		{ state_array[p] += val*val;					};
		bool add_zero()						{ return false;									};
		void add_zero(Integer ) 			{												};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return state_array[p];						};		
};

template<class in_type, class value_type>
struct prod_accumulator 
{
	private:
		value_type				state;
		gd::vector<value_type>	state_array;
        const value_type		Z;
        const value_type		one;

        prod_accumulator&    operator=(const prod_accumulator&);

	public:
		prod_accumulator(gd::type_info ti)
            :state(gd::default_value<value_type>(ti)) 
            , Z(gd::default_value<value_type>(ti))
            , state_array(ti)
            , one(converter<value_type,Integer>::eval(ti,1))
        {};

		void set_size(Integer )				{};
		void reset()						{ state = one;				                    };
		void reset_array(Integer s)			{ state_array.clear(); 
                                              state_array.resize(s,one);                    };	
		bool add(in_type value)				{ state *= value;return state == Z;	            };
		void add(Integer p,in_type val)		{ state_array[p] *= val;						};
		bool add_zero()						{ state = Z; return true;			            };
		void add_zero(Integer p)			{ state_array[p] = Z;	            			};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return state_array[p];						};		
};
template<class in_type, class value_type>
struct min_accumulator 
{
	private:
		value_type				state;
		bool added;
		gd::vector<value_type>	st_array;
		std::vector<bool>		st_array_flag;
		const value_type		Z;		

        min_accumulator&    operator=(const min_accumulator&);

	public:
        min_accumulator(gd::type_info ti)
            :Z(gd::default_value<value_type>(ti)) 
            ,state(gd::default_value<value_type>(ti))
            ,st_array(ti)
        {};

		void set_size(Integer) 				{ };
		void reset()						{ added = false;				};
		bool add(in_type val)				
		{ 
			if (added)						{ state = min_nan(val,state);	}
			else							{ state = val; added = true;	};

			return false;		
		};
		bool add_zero()						
		{ 
			if (added)						{ state = min_nan(Z,state); }
			else							{ state = Z; added = true;  }
			
			return false;		
		};

		void reset_array(Integer s)			
		{ 
			st_array.clear();		
			st_array.resize(s);	
			st_array_flag.clear();	
			st_array_flag.resize(s,false);	
		};			
		void add(Integer p,in_type val)		
		{ 
			if (st_array_flag[p])			{ st_array[p] = min_nan(val,st_array[p]); }
			else							{ st_array[p] = val; st_array_flag[p] = true; };
		};		
		void add_zero(Integer p)			
		{ 
			if (st_array_flag[p])			{ st_array[p] = min_nan(Z,st_array[p]); }
			else							{ st_array[p] = Z; st_array_flag[p] = true; };		
		};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};		

	private:
		value_type min_nan(value_type a, value_type b)
		{
			if (is_nan(a))
			{
				return b;
			};
			if (is_nan(b))
			{
				return a;
			};
			return std::min(a,b);
		};
};
template<class in_type, class value_type>
struct min_abs_accumulator 
{
	private:
		value_type				state;
		bool added;
		gd::vector<value_type>	st_array;
		std::vector<bool>		st_array_flag;
		const value_type		Z;		

        min_abs_accumulator&    operator=(const min_abs_accumulator&);

	public:
        min_abs_accumulator(gd::type_info ti)
            :Z(gd::default_value<value_type>(ti)) 
            ,state(gd::default_value<value_type>(ti))
            ,st_array(ti)
        {};

		void set_size(Integer) 				{ };
		void reset()						{ added = false;				};
		bool add(in_type val)				
		{ 
			if (added)						{ state = min_nan(abs(val),state);	}
			else							{ state = abs(val); added = true;	};

			return false;
		};
		bool add_zero()						
		{ 
			if (added)						{ state = min_nan(Z,state); }
			else							{ state = Z; added = true;  }
			
			return true;
		};

		void reset_array(Integer s)
		{ 
			st_array.clear();
			st_array.resize(s);	
			st_array_flag.clear();
			st_array_flag.resize(s,false);
		};			
		void add(Integer p,in_type val)	
		{ 
			if (st_array_flag[p])			{ st_array[p] = min_nan(abs(val),st_array[p]); }
			else							{ st_array[p] = abs(val); st_array_flag[p] = true; };
		};		
		void add_zero(Integer p)
		{ 
			if (st_array_flag[p])			{ st_array[p] = min_nan(Z,st_array[p]); }
			else							{ st_array[p] = Z; st_array_flag[p] = true; };
		};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};		

	private:
		value_type min_nan(value_type a, value_type b)
		{
			if (is_nan(a))
			{
				return b;
			};
			if (is_nan(b))
			{
				return a;
			};
			return std::min(a,b);
		};
};

template<class in_type, class value_type>
struct min_accumulator2
{
	private:
		value_type				state;
        gd::vector<value_type>	st_array;
		IntegerMatrix			ind_array;
		Integer					vec_pos;
		const value_type		Z;

        min_accumulator2&    operator=(const min_accumulator2&);

	public:
        min_accumulator2(gd::type_info ti)		
            : Z(gd::default_value<value_type>(ti)) 
            ,state(gd::default_value<value_type>(ti)) 
            ,ind_array(gd::get_raw_ti())
            ,st_array(ti)
        {};

		void set_size(Integer , Integer c, Integer dim)	
		{ 
			Integer mr = 1, mc = 1;
			if (dim == 1)	mc = c;
			else			mr = c;

			ind_array.reset_unique(mr,mc);
            Integer* ptr_ind = ind_array.ptr();

			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = 0;
			};
		};
		void reset()						{ };
		void reset_array(Integer s)			{ st_array.clear(); st_array.resize(s);	};	
		void current_vector(Integer vec)	{ vec_pos = vec;					    };
		bool add(Integer v, in_type val)
		{ 
			if (ind_array.ptr()[vec_pos] == 0 || less(val,state))
			{
				state = val;
				ind_array.ptr()[vec_pos] = v+1;
			}
			return false;
		};
		bool add_zero(Integer v)
		{ 
			if (ind_array.ptr()[vec_pos] == 0 || less(Z,state))
			{
				state = Z;
				ind_array.ptr()[vec_pos] = v+1;
			}
			else if (Z == state)
			{
				ind_array.ptr()[vec_pos] = std::min(v+1,ind_array.ptr()[vec_pos]);
			};
			return false;		
		};

		void add(Integer p,Integer v, in_type val)		
		{ 
			if (ind_array.ptr()[p] == 0 || less(val,st_array[p]))
			{
				st_array[p] = val;		
				ind_array.ptr()[p] = v+1;
			};
		};
		void add_zero(Integer p,Integer v)			
		{ 
			if (ind_array.ptr()[p] == 0 || less(Z,st_array[p]))
			{
				st_array[p] = Z;
				ind_array.ptr()[p] = v+1;
			}
			else if(Z == st_array[p])
			{
				ind_array.ptr()[p] = std::min(v+1,ind_array.ptr()[p]);
			};
		}		

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};		
		IntegerMatrix index_matrix() const	{ return ind_array;								};
};
template<class in_type, class value_type>
struct min_abs_accumulator2
{
	private:
		value_type				state;
        gd::vector<value_type>	st_array;
		IntegerMatrix			ind_array;
		Integer					vec_pos;
		const value_type		Z;

        min_abs_accumulator2&    operator=(const min_abs_accumulator2&);

	public:
        min_abs_accumulator2(gd::type_info ti)		
            : Z(gd::default_value<value_type>(ti)) 
            ,state(gd::default_value<value_type>(ti)) 
            ,ind_array(gd::get_raw_ti())
            ,st_array(ti)
        {};

		void set_size(Integer , Integer c, Integer dim)	
		{ 
			Integer mr = 1, mc = 1;
			if (dim == 1)	mc = c;
			else			mr = c;

			ind_array.reset_unique(mr,mc);			
            Integer* ptr_ind = ind_array.ptr();

			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = 0;
			};
		};
		void reset()						{ };
		void reset_array(Integer s)			{ st_array.clear(); st_array.resize(s);	};	
		void current_vector(Integer vec)	{ vec_pos = vec;	    				};
		bool add(Integer v, in_type val)
		{ 
            value_type aval = abs(val);
			if (ind_array.ptr()[vec_pos] == 0 || less(aval,state))
			{
				state = aval;
				ind_array.ptr()[vec_pos] = v+1;
			}
			return false;
		};
		bool add_zero(Integer v)
		{ 
			if (ind_array.ptr()[vec_pos] == 0 || less(Z,state))
			{
				state = Z;
				ind_array.ptr()[vec_pos] = v+1;
			}
			else if (Z == state)
			{
				ind_array.ptr()[vec_pos] = std::min(v+1,ind_array.ptr()[vec_pos]);
			};
			return true;	
		};

		void add(Integer p,Integer v, in_type val)		
		{ 
            value_type aval = abs(val);

			if (ind_array.ptr()[p] == 0 || less(aval,st_array[p]))
			{
				st_array[p] = aval;		
				ind_array.ptr()[p] = v+1;
			};
		};
		void add_zero(Integer p,Integer v)			
		{ 
			if (ind_array.ptr()[p] == 0 || less(Z,st_array[p]))
			{
				st_array[p] = Z;
				ind_array.ptr()[p] = v+1;
			}
			else if(Z == st_array[p])
			{
				ind_array.ptr()[p] = std::min(v+1,ind_array.ptr()[p]);
			};
		}		

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};		
		IntegerMatrix index_matrix() const	{ return ind_array;								};
};

template<class in_type, class value_type>
struct max_accumulator 
{
	private:
		value_type				state;
		bool					added;
		gd::vector<value_type>	st_array;
		std::vector<bool>		st_array_flag;
		const value_type		Z;

        max_accumulator&    operator=(const max_accumulator&);

	public:
        max_accumulator(gd::type_info ti)	
            : Z(gd::default_value<value_type>(ti)) 
            ,state(gd::default_value<value_type>(ti))
            ,st_array(ti)
        {};

		void set_size(Integer ) 			{};
		void reset()						{ added = false;				};
		bool add(in_type val)				
		{ 
			if (added)						{ state = max_nan(val,state);	}
			else							{ state = val; added = true;	};

			return false;		
		};
		bool add_zero()						
		{ 
			if (added)						{ state = max_nan(Z,state); }
			else							{ state = Z; added = true;  }
			
			return false;		
		};

		void reset_array(Integer s)			
		{ 
			st_array.clear();		
			st_array.resize(s);	
			st_array_flag.clear();	
			st_array_flag.resize(s,false);	
		};			
		void add(Integer p,in_type val)		
		{ 
			if (st_array_flag[p])			{ st_array[p] = max_nan(val,st_array[p]); }
			else							{ st_array[p] = val; st_array_flag[p] = true; };
		};		
		void add_zero(Integer p)			
		{ 
			if (st_array_flag[p])			{ st_array[p] = max_nan(Z,st_array[p]); }
			else							{ st_array[p] = Z; st_array_flag[p] = true; };		
		};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};

	private:
		value_type max_nan(value_type a, value_type b)
		{
			if (is_nan(a))
			{
				return b;
			};
			if (is_nan(b))
			{
				return a;
			};
			return std::max(a,b);
		};
};
template<class in_type, class value_type>
struct max_abs_accumulator 
{
	private:
		value_type				state;
		bool					added;
		gd::vector<value_type>	st_array;
		std::vector<bool>		st_array_flag;
		const value_type		Z;

        max_abs_accumulator&    operator=(const max_abs_accumulator&);

	public:
        max_abs_accumulator(gd::type_info ti)	
            : Z(gd::default_value<value_type>(ti)) 
            ,state(gd::default_value<value_type>(ti))
            ,st_array(ti)
        {};

		void set_size(Integer ) 			{};
		void reset()						{ added = false;				};
		bool add(in_type val)				
		{ 
			if (added)						{ state = max_nan(abs(val),state);	}
			else							{ state = abs(val); added = true;	};

			return false;
		};
		bool add_zero()						
		{
			if (added)						{ state = max_nan(Z,state); }
			else							{ state = Z; added = true;  }
			
			return false;
		};

		void reset_array(Integer s)			
		{ 
			st_array.clear();		
			st_array.resize(s);	
			st_array_flag.clear();	
			st_array_flag.resize(s,false);	
		};			
		void add(Integer p,in_type val)		
		{ 
			if (st_array_flag[p])			{ st_array[p] = max_nan(abs(val),st_array[p]); }
			else							{ st_array[p] = abs(val); st_array_flag[p] = true; };
		};		
		void add_zero(Integer p)
		{
			if (st_array_flag[p])			{ st_array[p] = max_nan(Z,st_array[p]); }
			else							{ st_array[p] = Z; st_array_flag[p] = true; };		
		};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};

	private:
		value_type max_nan(value_type a, value_type b)
		{
			if (is_nan(a))
			{
				return b;
			};
			if (is_nan(b))
			{
				return a;
			};
			return std::max(a,b);
		};
};

template<class in_type, class value_type>
struct max_accumulator2
{
	private:
		value_type				state;
		gd::vector<value_type>	st_array;
		IntegerMatrix			ind_array;
		Integer					vec_pos;
		const value_type		Z;

        max_accumulator2&    operator=(const max_accumulator2&);

	public:
        max_accumulator2(gd::type_info ti)	
            : Z(gd::default_value<value_type>(ti)) 
            ,state(gd::default_value<value_type>(ti)) 
            ,ind_array(gd::get_raw_ti())
            ,st_array(ti)
        {};

		void set_size(Integer , Integer c, int dim)	
		{ 
			Integer mr = 1, mc = 1;
			if (dim == 1)	mc = c;
			else			mr = c;

			ind_array.reset_unique(mr,mc);
            Integer* ptr_ind = ind_array.ptr();

			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = 0;
			};
		};
		void reset()						{ };
		void reset_array(Integer s)			{ st_array.clear(); st_array.resize(s);			};	
		void current_vector(Integer vec)	{ vec_pos = vec;							    };
		bool add(Integer v, in_type val)
		{ 
			if (ind_array.ptr()[vec_pos] == 0 || greater(val,state))
			{
				state = val;
				ind_array.ptr()[vec_pos] = v+1;				
			}
			return false;
		};
		void add(Integer p,Integer v, in_type val)		
		{ 
			if (ind_array.ptr()[p] == 0 || greater(val,st_array[p]))
			{
				st_array[p] = val;		
				ind_array.ptr()[p] = v+1;
			}
		};
		bool add_zero(Integer v)
		{ 
			if (ind_array.ptr()[vec_pos] == 0 || greater(Z,state))
			{
				state = Z;
				ind_array.ptr()[vec_pos] = v+1;
			}
			else if( state == Z)
			{
				ind_array.ptr()[vec_pos] = std::min(v+1,ind_array.ptr()[vec_pos]);
			};
			return false;		
		};
		void add_zero(Integer p,Integer v)			
		{ 
			if (ind_array.ptr()[p] == 0 || greater(Z,st_array[p]))
			{
				st_array[p] = Z;
				ind_array.ptr()[p] = v+1;
			}
			else if( st_array[p] == Z)
			{
				ind_array.ptr()[p] = std::min(v+1,ind_array.ptr()[p]);
			};
		};

		value_type value()					{ return state;	        };
		value_type value(Integer p)			{ return st_array[p];	};		
		IntegerMatrix index_matrix() const	{ return ind_array;		};
};
template<class in_type, class value_type>
struct max_abs_accumulator2
{
	private:
		value_type				state;
		gd::vector<value_type>	st_array;
		IntegerMatrix			ind_array;
		Integer					vec_pos;
		const value_type		Z;

        max_abs_accumulator2&    operator=(const max_abs_accumulator2&);

	public:
        max_abs_accumulator2(gd::type_info ti)	
            : Z(gd::default_value<value_type>(ti)) 
            ,state(gd::default_value<value_type>(ti)) 
            ,ind_array(gd::get_raw_ti())
            ,st_array(ti)
        {};

		void set_size(Integer , Integer c, int dim)	
		{ 
			Integer mr = 1, mc = 1;
			if (dim == 1)	mc = c;
			else			mr = c;

			ind_array.reset_unique(mr,mc);
            Integer* ptr_ind = ind_array.ptr();

			for (Integer i = 0; i < c; ++i)
			{
				ptr_ind[i] = 0;
			};
		};
		void reset()						{ };
		void reset_array(Integer s)			{ st_array.clear(); st_array.resize(s);			};	
		void current_vector(Integer vec)	{ vec_pos = vec;							    };
		bool add(Integer v, in_type val)
		{ 
            value_type aval = abs(val);
			if (ind_array.ptr()[vec_pos] == 0 || greater(aval,state))
			{
				state = aval;
				ind_array.ptr()[vec_pos] = v+1;				
			}
			return false;
		};
		void add(Integer p,Integer v, in_type val)		
		{ 
            value_type aval = abs(val);
			if (ind_array.ptr()[p] == 0 || greater(aval,st_array[p]))
			{
				st_array[p] = aval;		
				ind_array.ptr()[p] = v+1;
			}
		};
		bool add_zero(Integer v)
		{ 
			if (ind_array.ptr()[vec_pos] == 0 || greater(Z,state))
			{
				state = Z;
				ind_array.ptr()[vec_pos] = v+1;
			}
			else if( state == Z)
			{
				ind_array.ptr()[vec_pos] = std::min(v+1,ind_array.ptr()[vec_pos]);
			};
			return false;		
		};
		void add_zero(Integer p,Integer v)			
		{ 
			if (ind_array.ptr()[p] == 0 || greater(Z,st_array[p]))
			{
				st_array[p] = Z;
				ind_array.ptr()[p] = v+1;
			}
			else if( st_array[p] == Z)
			{
				ind_array.ptr()[p] = std::min(v+1,ind_array.ptr()[p]);
			};
		};

		value_type value()					{ return state;	        };
		value_type value(Integer p)			{ return st_array[p];	};		
		IntegerMatrix index_matrix() const	{ return ind_array;		};
};

template<class in_type, class value_type>
class mean_accumulator 
{
	private:
		Integer					size;
		value_type				state;
		gd::vector<value_type>	st_array;
        const value_type		Z;

        mean_accumulator&    operator=(const mean_accumulator&);

	public:
		mean_accumulator(gd::type_info ti)	
            :state(gd::default_value<value_type>(ti)) 
            ,Z(gd::default_value<value_type>(ti))
            ,st_array(ti)
        {};

		void set_size(Integer r)			{ size = r;										};
		void reset()						{ state = Z;	        						};
		void reset_array(Integer s)			{ st_array.clear(); 
                                              st_array.resize(s,Z);	            	        };	
		bool add(in_type value)				{ state += value;return false;					};
		void add(Integer p,in_type val)		{ st_array[p] += val;							};
		bool add_zero()						{ return false;									};
		void add_zero(Integer )				{												};

		value_type value()					{ return state/Real(size);                      };
		value_type value(Integer p)			{ return st_array[p]/Real(size);                };		
};
template<class in_type, class value_type>
class std_accumulator 
{
	private:
		struct state
		{
			value_type	sum, sum_sq;

			state(gd::type_info ti) 
                : sum(gd::default_value<value_type>(ti))
                , sum_sq(gd::default_value<value_type>(ti)) 
            {};
		};

		Integer				size;
		state				m_state;
		gd::vector<state>	st_array;
        const value_type	Z;
        const state	        ZS;

        std_accumulator&    operator=(const std_accumulator&);

	public:
		std_accumulator(gd::type_info ti)
            : Z(gd::default_value<value_type>(ti)) 
            , ZS(ti), m_state(ti), st_array(ti)
        {};

		void set_size(Integer r)			{ size = r;										};
		void reset()						{ m_state = ZS;							        };
		void reset_array(Integer s)			{ st_array.clear(); st_array.resize(s,ZS);	    };	
		bool add(in_type val)				{ m_state.sum += val; m_state.sum_sq+= val*val;	
                                              return false;
                                            };
		void add(Integer p,in_type val)		{ st_array[p].sum += val;
                                              st_array[p].sum_sq += val*val;	
                                            };
		bool add_zero()						{ return false;									};
		void add_zero(Integer )				{												};

		value_type value() 		
		{ 
			if (size <= 1)
			{
				return Z;
			}
			return sqrt_nc((m_state.sum_sq - m_state.sum*m_state.sum/Real(size))/(size - 1.));	
		};
		value_type value(Integer p)		
		{ 
			if (size <= 1)
			{
				return Z;
			}
			return sqrt_nc((st_array[p].sum_sq - st_array[p].sum*st_array[p].sum/Real(size))/(size - 1.));	
		};		
};
template<class in_type, class value_type>
struct any_accumulator 
{
	private:
		bool					state;
		std::vector<bool>		st_array;

	public:
		any_accumulator(gd::type_info )	    {};

		void set_size(Integer ) 			{};
		void reset()						{ state = false;								};
		void reset_array(Integer s)			{ st_array.clear(); st_array.resize(s,false);	};	
		bool add(in_type val)				{ state = or_helper(state,val);	return state;	};
		void add(Integer p,in_type val)		{ st_array[p] = or_helper(st_array[p],val);		};
		bool add_zero()						{ return false;									};
		void add_zero(Integer ) 			{												};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};

		template<class in_type>
		bool or_helper(bool state,in_type val)
		{
			return state || istrue<in_type>::eval(val);
		};
};
template<class in_type, class value_type>
struct any_accumulator_t 
{
	private:
		bool					state;
		std::vector<bool>		st_array;
		const test_function&	test;
        const in_type		    Z;		

	public:
		any_accumulator_t(gd::type_info ti,const test_function& t)
            : test(t) 
            , Z(gd::default_value<in_type>(ti)) 
        {};

		void set_size(Integer ) 			{};
		void reset()						{ state = false;								};
		void reset_array(Integer s)			{ st_array.clear(); st_array.resize(s,false);	};	
		bool add(in_type val)				{ state = (state||test.eval(val));return state;	};
		void add(Integer p,in_type val)		{ st_array[p] = (st_array[p] || test.eval(val));};
		bool add_zero()						{ return add(Z);        						};
		void add_zero(Integer p)			{ return add(p,Z);      						};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};

	private:
		any_accumulator_t(const any_accumulator_t&);
		any_accumulator_t& operator=(const any_accumulator_t&);
};

template<class in_type, class value_type>
struct all_accumulator 
{
	private:
		bool					state;
		std::vector<bool>		st_array;

	public:
		all_accumulator(gd::type_info )	    {};

		void set_size(Integer )				{};
		void reset()						{ state = true;									};
		void reset_array(Integer s)			{ st_array.clear(); st_array.resize(s,true);	};	
		bool add(in_type val)				{ state = and_helper(state,val); return !state;	};
		void add(Integer p,in_type val)		{ st_array[p] = and_helper(st_array[p],val);	};
		bool add_zero()						{ state = false; return true;					};
		void add_zero(Integer p)			{ st_array[p] = false;							};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};

		template<class in_type>
		bool and_helper(bool state,in_type val)
		{
			return state && istrue<in_type>::eval(val);
		};
};
template<class in_type, class value_type>
struct all_accumulator_t
{
	private:
		bool					state;
		std::vector<bool>		st_array;
		const test_function&	test;
        const in_type		    Z;		

	public:
		all_accumulator_t(gd::type_info ti,const test_function& t)
            : test(t)
            , Z(gd::default_value<in_type>(ti)) 
        {};

		void set_size(Integer ) 			{};
		void reset()						{ state = true;									};
		void reset_array(Integer s)			{ st_array.clear(); st_array.resize(s,true);	};	
		bool add(in_type val)				{ state = (state&&test.eval(val)); return !state;};
		void add(Integer p,in_type val)		{ st_array[p] = (st_array[p] && test.eval(val));};
		bool add_zero()						{ return add(Z);        						};
		void add_zero(Integer p)			{ return add(p,Z);      						};

		value_type value()					{ return state;									};
		value_type value(Integer p)			{ return st_array[p];							};

	private:
		all_accumulator_t(const all_accumulator_t&);
		all_accumulator_t& operator=(const all_accumulator_t&);
};

template<class T> struct min_value {};
template<> struct min_value<Integer> { static Integer eval() {return constants::MinInt;};	};
template<> struct min_value<Real>	 { static Real eval()	 {return -constants::Inf;};	};
template<> struct min_value<Complex> { static Complex eval() {return -constants::Inf;};	};

template<class T> struct max_value {};
template<> struct max_value<Integer> { static Integer eval() {return constants::MaxInt;};	};
template<> struct max_value<Real>	 { static Real eval()	 {return constants::Inf;};		};
template<> struct max_value<Complex> { static Complex eval() {return constants::Inf;};		};

template<class M>
typename details::vec_manip_helper<M>::ret_type_sum
details::vec_manip_helper<M>::eval_sum(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_sum::value_type	out_type;
	return eval_vec_functor<ret_type_sum,M, sum_accumulator<in_type,out_type>>::eval(m,dim);
};

template<class M>
typename details::vec_manip_helper<M>::ret_type_nnz
details::vec_manip_helper<M>::eval_nnz(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_nnz::value_type	out_type;

	return eval_vec_functor<ret_type_nnz,M, nnz_accumulator<in_type,out_type>>::eval(m,dim);
};

template<class M>
typename details::vec_manip_helper<M>::ret_type_prod
details::vec_manip_helper<M>::eval_prod(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_prod::value_type	out_type;
	return eval_vec_functor<ret_type_prod, M, prod_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_cumsum
details::vec_manip_helper<M>::eval_cumsum(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_cumsum::value_type	out_type;
	return eval_vec_functor<ret_type_cumsum,M, sum_accumulator<in_type,out_type>>::eval_cum(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_cumprod
details::vec_manip_helper<M>::eval_cumprod(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_cumprod::value_type	out_type;
	return eval_vec_functor<ret_type_cumprod,M, prod_accumulator<in_type,out_type>>::eval_cum(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_sumsq
details::vec_manip_helper<M>::eval_sumsq(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_sumsq::value_type	out_type;
	return eval_vec_functor<ret_type_sumsq,M, sumsq_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_min
details::vec_manip_helper<M>::eval_min(const M& m, int dim)
{
	Integer r = m.rows(), c = m.cols();

    gd::type_info ret_ti = m.get_ti();

	if (r == 0 || c == 0)
	{
		error::check_dim(dim);
		if (dim == 1)
		{
			return ret_type_min(ret_ti,std::min(r,1L),c);
		}
		else
		{
			return ret_type_min(ret_ti,r,std::min(c,1L));
		};
	};
	typedef M::value_type				in_type;
	typedef ret_type_min::value_type	out_type;
	return eval_vec_functor<ret_type_min,M, min_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_min_abs
details::vec_manip_helper<M>::eval_min_abs(const M& m, int dim)
{
	Integer r = m.rows(), c = m.cols();

    gd::type_info ret_ti = m.get_ti();

	if (r == 0 || c == 0)
	{
		error::check_dim(dim);
		if (dim == 1)
		{
			return ret_type_min_abs(ret_ti,std::min(r,1L),c);
		}
		else
		{
			return ret_type_min_abs(ret_ti,r,std::min(c,1L));
		};
	};
	typedef M::value_type				    in_type;
	typedef ret_type_min_abs::value_type	out_type;
	return eval_vec_functor<ret_type_min_abs,M, min_abs_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_max
details::vec_manip_helper<M>::eval_max(const M& m, int dim)
{
	Integer r = m.rows(), c = m.cols();

    gd::type_info ret_ti = m.get_ti();

	if (r == 0 || c == 0)
	{
		error::check_dim(dim);
		if (dim == 1)
		{
			return ret_type_max(ret_ti,std::min(r,1L),c);
		}
		else
		{
			return ret_type_max(ret_ti,r,std::min(c,1L));
		};
	};
	typedef M::value_type				in_type;
	typedef ret_type_max::value_type	out_type;
	return eval_vec_functor<ret_type_max,M, max_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_max_abs
details::vec_manip_helper<M>::eval_max_abs(const M& m, int dim)
{
	Integer r = m.rows(), c = m.cols();

    gd::type_info ret_ti = m.get_ti();

	if (r == 0 || c == 0)
	{
		error::check_dim(dim);
		if (dim == 1)
		{
			return ret_type_max_abs(ret_ti,std::min(r,1L),c);
		}
		else
		{
			return ret_type_max_abs(ret_ti,r,std::min(c,1L));
		};
	};
	typedef M::value_type				    in_type;
	typedef ret_type_max_abs::value_type	out_type;
	return eval_vec_functor<ret_type_max_abs,M, max_abs_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_min_2
details::vec_manip_helper<M>::eval_min2(const M& m, int dim)
{
	Integer r = m.rows(), c = m.cols();

    gd::type_info ti_int = gd::get_raw_ti();
    gd::type_info ret_ti = m.get_ti();

	if (r == 0 || c == 0)
	{
		error::check_dim(dim);
		if (dim == 1)
		{
			IntegerMatrix ind(ti_int,std::min(r,1L),c);
            ret_type_min x(ret_ti,std::min(r,1L),c);
            return ret_type_min_2(x,ind);
		}
		else
		{
			IntegerMatrix ind(ti_int,r,std::min(c,1L));
			ret_type_min x(ret_ti,r,std::min(c,1L));
            return ret_type_min_2(x,ind);
		};
	};
	typedef M::value_type				in_type;
	typedef ret_type_min::value_type	out_type;

	typedef min_accumulator2<in_type,out_type> accum_type;
	accum_type accum(ret_ti);
	ret_type_min ret = eval_vec_functor2<ret_type_min,M, accum_type>::eval(m,dim,accum);
	IntegerMatrix ind = accum.index_matrix();
	return ret_type_min_2(ret,ind);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_min_abs2
details::vec_manip_helper<M>::eval_min_abs2(const M& m, int dim)
{
	Integer r = m.rows(), c = m.cols();

    gd::type_info ti_int = gd::get_raw_ti();
    gd::type_info ret_ti = m.get_ti();

	if (r == 0 || c == 0)
	{
		error::check_dim(dim);
		if (dim == 1)
		{
			IntegerMatrix ind(ti_int,std::min(r,1L),c);
            ret_type_min_abs x(ret_ti,std::min(r,1L),c);
            return ret_type_min_abs2(x,ind);
		}
		else
		{
			IntegerMatrix ind(ti_int,r,std::min(c,1L));
			ret_type_min_abs x(ret_ti,r,std::min(c,1L));
            return ret_type_min_abs2(x,ind);
		};
	};
	typedef M::value_type				    in_type;
	typedef ret_type_min_abs::value_type	out_type;

	typedef min_abs_accumulator2<in_type,out_type> accum_type;
	accum_type accum(ret_ti);
	ret_type_min_abs ret = eval_vec_functor2<ret_type_min_abs,M, accum_type>::eval(m,dim,accum);
	IntegerMatrix ind = accum.index_matrix();
	return ret_type_min_abs2(ret,ind);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_max_2
details::vec_manip_helper<M>::eval_max2(const M& m, int dim)
{
	Integer r = m.rows(), c = m.cols();

    gd::type_info ti_int = gd::get_raw_ti();
    gd::type_info ret_ti = m.get_ti();

	if (r == 0 || c == 0)
	{
		error::check_dim(dim);
		if (dim == 1)
		{
			IntegerMatrix ind(ti_int,std::min(r,1L),c);
			ret_type_max x(ret_ti,std::min(r,1L),c);
            return ret_type_max_2(x,ind);
		}
		else
		{
			IntegerMatrix ind(ti_int,r,std::min(c,1L));
			ret_type_max x(ret_ti,r,std::min(c,1L));
            return ret_type_max_2(x,ind);
		};
	};
	typedef M::value_type				in_type;
	typedef ret_type_max::value_type	out_type;

	typedef max_accumulator2<in_type,out_type> accum_type;
	accum_type accum(ret_ti);

	ret_type_max ret = eval_vec_functor2<ret_type_max,M, accum_type>::eval(m,dim,accum);
	IntegerMatrix ind = accum.index_matrix();
	return ret_type_max_2(ret,ind);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_max_abs2
details::vec_manip_helper<M>::eval_max_abs2(const M& m, int dim)
{
	Integer r = m.rows(), c = m.cols();

    gd::type_info ti_int = gd::get_raw_ti();
    gd::type_info ret_ti = m.get_ti();

	if (r == 0 || c == 0)
	{
		error::check_dim(dim);
		if (dim == 1)
		{
			IntegerMatrix ind(ti_int,std::min(r,1L),c);
			ret_type_max_abs x(ret_ti,std::min(r,1L),c);
            return ret_type_max_abs2(x,ind);
		}
		else
		{
			IntegerMatrix ind(ti_int,r,std::min(c,1L));
			ret_type_max_abs x(ret_ti,r,std::min(c,1L));
            return ret_type_max_abs2(x,ind);
		};
	};
	typedef M::value_type				    in_type;
	typedef ret_type_max_abs::value_type	out_type;

	typedef max_abs_accumulator2<in_type,out_type> accum_type;
	accum_type accum(ret_ti);

	ret_type_max_abs ret = eval_vec_functor2<ret_type_max_abs,M, accum_type>::eval(m,dim,accum);
	IntegerMatrix ind = accum.index_matrix();
	return ret_type_max_abs2(ret,ind);
};

template<class M>
typename details::vec_manip_helper<M>::ret_type_mean
details::vec_manip_helper<M>::eval_mean(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_mean::value_type	out_type;
	return eval_vec_functor<ret_type_mean,M, mean_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_std
details::vec_manip_helper<M>::eval_std(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_std::value_type	out_type;
	return eval_vec_functor<ret_type_std,M, std_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_any
details::vec_manip_helper<M>::eval_any(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_any::value_type	out_type;
	return eval_vec_functor<ret_type_any,M, any_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_any
details::vec_manip_helper<M>::eval_any(const M& m, const test_function& t, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_any::value_type	out_type;
	typedef any_accumulator_t<in_type,out_type> accum;
    accum a(gd::get_raw_ti(),t);
	return eval_vec_functor<ret_type_any,M,accum>::eval(m,dim,a);
};

template<class M>
typename details::vec_manip_helper<M>::ret_type_all
details::vec_manip_helper<M>::eval_all(const M& m, int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_all::value_type	out_type;
	return eval_vec_functor<ret_type_all,M, all_accumulator<in_type,out_type>>::eval(m,dim);
};
template<class M>
typename details::vec_manip_helper<M>::ret_type_all
details::vec_manip_helper<M>::eval_all(const M& m, const test_function& t,int dim)
{
	typedef M::value_type				in_type;
	typedef ret_type_all::value_type	out_type;

	typedef all_accumulator_t<in_type,out_type> accum;
    accum a(gd::get_raw_ti(),t);
	return eval_vec_functor<ret_type_all,M, accum>::eval(m,dim,a);
};

};};

MACRO_INSTANTIATE_G_1(mmlib::raw::details::vec_manip_helper)
MACRO_INSTANTIATE_S_1(mmlib::raw::details::vec_manip_helper)
