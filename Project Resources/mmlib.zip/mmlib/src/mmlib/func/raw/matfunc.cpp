/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/matfunc.h"
#include "mmlib/mp/instantiate.h"
#include "mmlib/func/raw/eval_op.h"
#include "mmlib/func/raw/mmul.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/utils/utils.h"
#include "mmlib/details/type_info_utils.h"

#pragma warning( push )
#pragma warning(disable:4127)	// conditional expression is constant
#pragma warning(disable:4723)	// potential divide by 0

namespace mmlib { namespace raw { namespace details
{

using mmlib::Integer;
using mmlib::Real;
using mmlib::Complex;

namespace gd = mmlib::details;

template<class matrix_type,class struct_type>
struct create_matrix_impl
{};

template<class matrix_type>
struct create_matrix_impl<matrix_type,struct_dense>
{
    static matrix_type eval(gd::type_info ti, Integer rows, Integer cols)
	{
		typedef matrix_type::value_type value_type;

		matrix_type out(ti,rows,cols);
        value_type Z = gd::default_value<value_type>(ti);
        value_type* ptr_out = out.ptr();

		Integer s = out.size();
		for (Integer i = 0; i < s; ++i)
		{
			ptr_out[i] = Z;
		};

        out.get_struct().set_zero_matrix();
		return out;
	};
};
template<class matrix_type>
struct create_matrix_impl<matrix_type,struct_banded>
{
	static matrix_type eval(gd::type_info ti, Integer rows, Integer cols)
	{
		matrix_type out(ti,rows,cols,0,0);
        out.get_struct().set_zero_matrix();
        return out;
	};
};
template<class matrix_type>
struct create_matrix_impl<matrix_type,struct_sparse>
{
	static matrix_type eval(gd::type_info ti, Integer rows, Integer cols)
	{
		return matrix_type(ti,rows,cols);
	};
};

template<class matrix_type,class struct_type>
struct create_matrix2_impl
{};
template<class matrix_type>
struct create_matrix2_impl<matrix_type,struct_dense>
{
	typedef typename matrix_type::value_type value_type;
    static matrix_type eval(gd::type_info ti, value_type val, Integer rows, Integer cols)
	{
		matrix_type out(ti, val,rows,cols);
        if (val == gd::default_value<value_type>(ti))
        {
            out.get_struct().set_zero_matrix();
        };
        return out;
	};
};
template<class matrix_type>
struct create_matrix2_impl<matrix_type,struct_banded>
{
	typedef typename matrix_type::value_type value_type;
	static matrix_type eval(gd::type_info ti, value_type val, Integer rows, Integer cols)
	{
		Integer diag_u = (cols == 0)? 0 : 1;
		Integer diag_l = (rows == 0)? 0 : 1;
		matrix_type out(ti, rows,cols,rows-diag_l,cols-diag_u);

        Integer out_size = out.size();

        value_type* ptr_out = out.rep_ptr();

		for (Integer i = 0; i< out_size; ++i)
		{
			ptr_out[i] = val;
		}
        if (val == gd::default_value<value_type>(ti))
        {
            out.get_struct().set_zero_matrix();
        };
		return out;
	};
};

template<class matrix_type>
struct create_matrix2_impl<matrix_type,struct_sparse>
{
	typedef typename matrix_type::value_type value_type;
	static matrix_type eval(gd::type_info ti, value_type val, Integer rows, Integer cols)
	{
		typedef Matrix<value_type,struct_dense> full_matrix;
		return sparse(full_matrix(ti,val,rows,cols));
	};
};


template<class matrix_type>
inline matrix_type create_matrix(gd::type_info ti, Integer rows, Integer cols)
{
	return create_matrix_impl<matrix_type,matrix_type::struct_type>::eval(ti,rows,cols);
};

template<class matrix_type>
matrix_type create_matrix(gd::type_info ti, typename matrix_type::value_type val,Integer rows, Integer cols)
{
	return create_matrix2_impl<matrix_type,matrix_type::struct_type>::eval(ti,val,rows,cols);
};


template<class arg_type, bool rev>
class or_functor
{
	private:
		arg_type	arg;

	public:
		or_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		
		{ 
            return is_true_helper<arg_type>::eval(gd::get_ti(arg),arg); 
		};

		template<class ret_type, class in_type>
        ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
			return create_matrix<ret_type>(ret_ti,1,x.rows(), x.cols());
		};
		template<class val_type>
		Integer eval(gd::type_info ti, val_type val) const
		{
			return is_true_helper<val_type>::eval(ti,val);
                        //|| is_true_helper<arg_type>::eval(ti,arg);
		}
};
template<class arg_type, bool rev>
class and_functor
{
	private:
		arg_type	arg;

	public:
		and_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		
		{ 
            return is_false_helper<arg_type>::eval(gd::get_ti(arg),arg); 
		};

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
			return create_matrix<ret_type>(ret_ti,x.rows(), x.cols());
		};
		template<class val_type>
		Integer eval(gd::type_info ti, val_type val) const
		{
			return is_true_helper<val_type>::eval(ti,val);
                //&& is_true_helper<arg_type>::eval(ti,arg);
		}
};
template<class arg_type, bool rev>
class xor_functor
{
	private:
		arg_type	arg;

	public:
		xor_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		{ return false; };

		template<class ret_type, class in_type>
        ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
            return ret_type(ret_ti);
		};

		template<class val_type>
		Integer eval(gd::type_info ti, val_type val) const
		{
			return is_true_helper<val_type>::eval(ti,val) ^ is_true_helper<arg_type>::eval(ti,arg);
		};
};
template<class arg_type, bool rev>
class eeq_functor
{
	private:
		arg_type	arg;

	public:
		eeq_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		{ return false; };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
            return ret_type(ret_ti);
		};

		template<class val_type>
		Integer eval(gd::type_info , val_type val) const
		{
			return (val == arg);
		};
};
template<class arg_type, bool rev>
class neq_functor
{
	private:
		arg_type	arg;

	public:
		neq_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		{ return false; };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
            return ret_type(ret_ti);
		};
		template<class val_type>
		Integer eval(gd::type_info , val_type val) const
		{
			return (val != arg);
		};
};
template<class arg_type, bool rev>
class leq_functor
{
	private:
		arg_type	arg;

	public:
		leq_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const	{ return false; };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
			return ret_type(ret_ti);
		};
		template<class val_type>
		Integer eval(gd::type_info ti, val_type val) const
		{
			return eval_impl<val_type,rev>::eval(ti,val,arg);
		};

		template<class val_type, bool rev>
		struct eval_impl
		{
			static Integer eval(gd::type_info , val_type val, arg_type arg)
			{
				return (val <= arg);
			};
		};
		template<class val_type>
		struct eval_impl<val_type,true>
		{
			static Integer eval(gd::type_info , val_type val, arg_type arg)
			{
				return (val >= arg);
			};
		};
};
template<class arg_type, bool rev>
class geq_functor
{
	private:
		arg_type	arg;

	public:
		geq_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		{ return false; };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
            return ret_type(ret_ti);
		};
		template<class val_type>
		Integer eval(gd::type_info ti, val_type val) const
		{
			return eval_impl<val_type,rev>::eval(ti,val,arg);
		};

		template<class val_type, bool rev>
		struct eval_impl
		{
			static Integer eval(gd::type_info , val_type val, arg_type arg)
			{
				return (val >= arg);
			};
		};
		template<class val_type>
		struct eval_impl<val_type,true>
		{
			static Integer eval(gd::type_info , val_type val, arg_type arg)
			{
				return (val <= arg);
			};
		};
};
template<class arg_type, bool rev>
class lt_functor
{
	private:
		arg_type	arg;

	public:
		lt_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		{ return false; };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
			return ret_type(ret_ti);
		};

		template<class val_type>
		Integer eval(gd::type_info ti, val_type val) const
		{
			return eval_impl<val_type,rev>::eval(ti,val,arg);
		};

		template<class val_type, bool rev>
		struct eval_impl
		{
			static Integer eval(gd::type_info , val_type val, arg_type arg)
			{
				return (val < arg);
			};
		};
		template<class val_type>
		struct eval_impl<val_type,true>
		{
			static Integer eval(gd::type_info , val_type val, arg_type arg)
			{
				return (val > arg);
			};
		};
};
template<class arg_type, bool rev>
class gt_functor
{
	private:
		arg_type	arg;

	public:
		gt_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const { return false; };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
			return ret_type(ret_ti);
		};

		template<class val_type>
		Integer eval(gd::type_info ti, val_type val) const
		{
			return eval_impl<val_type,rev>::eval(ti,val,arg);
		};

		template<class val_type, bool rev>
		struct eval_impl
		{
			static Integer eval(gd::type_info , val_type val, arg_type arg)
			{
				return (val > arg);
			};
		};
		template<class val_type>
		struct eval_impl<val_type,true>
		{
			static Integer eval(gd::type_info , val_type val, arg_type arg)
			{
				return (val < arg);
			};
		};
};
template<class arg_type, bool rev>
class mul_functor
{
	private:
		arg_type	arg;

	public:
		mul_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const
		{
			return true;
		};

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
			return converter_deduce<ret_type>::eval(ret_ti,raw::operator*(x,arg));
		};

		template<class val_type>
		typename gd::max_type<val_type,arg_type>::type
		eval(gd::type_info ti, val_type val) const
		{
			typedef typename gd::max_type<val_type,arg_type>::type ret_type;
			return mul_helper<val_type,arg_type>::eval(ti,val,arg);
		};
};
template<class arg_type, bool rev>
class div_functor
{
	private:
		arg_type	arg;

	public:
		div_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const
		{
			return (arg == 1 && rev == false);
		};

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
			return converter<ret_type,in_type>::eval(ret_ti,x);
		};

		template<class val_type>
		typename gd::max_type2<val_type,arg_type,Real>::type
		eval(gd::type_info ti, val_type val) const
		{
			typedef gd::max_type<val_type,arg_type>::type ret_type_0;
			typedef gd::max_type<ret_type_0,Real>::type ret_type;
			return eval_impl<ret_type,val_type,rev>::eval(ti,val,arg);
		};

		template<class ret_type, class val_type, bool rev>
		struct eval_impl
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return div_helper<val_type,arg_type>::eval(ti,val,arg);
			};
		};
		template<class ret_type, class val_type>
		struct eval_impl<ret_type,val_type,true>
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return div_helper<arg_type,val_type>::eval(ti,arg,val);
			};
		};
};
template<class arg_type, bool rev>
class idiv_functor
{
	private:
		arg_type	arg;

	public:
		idiv_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const
		{
			return (arg == 1 && rev == false);
		};

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
			return converter<ret_type,in_type>::eval(ret_ti,x);
		};

		template<class val_type>
		typename gd::max_type<val_type,arg_type>::type
		eval(gd::type_info ti, val_type val) const
		{
			typedef gd::max_type<val_type,arg_type>::type ret_type;
			return eval_impl<ret_type,val_type,rev>::eval(ti,val,arg);
		};

		template<class ret_type, class val_type, bool rev>
		struct eval_impl
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return idiv_helper<val_type,arg_type>::eval(ti,val,arg);
			};
		};
		template<class ret_type, class val_type>
		struct eval_impl<ret_type,val_type,true>
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return idiv_helper<arg_type,val_type>::eval(ti,arg,val);
			};
		};
};

#pragma warning(push)
#pragma warning(disable:4189) // local variable is initialized but not referenced

template<class arg_type, bool rev>
class pow_functor
{
	private:
		arg_type	arg;

	public:
		pow_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const
		{
            arg_type zero = gd::default_value<arg_type>(gd::get_ti(arg));
			return ( rev == false && (arg == zero || arg == 1)); 
		};

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
            if (arg == gd::default_value<arg_type>(gd::get_ti(arg)))
			{
                typedef typename ret_type::value_type val_type;
                val_type one = converter<val_type,Integer>::eval(ret_ti,1);
				return create_matrix<ret_type>(ret_ti,one,x.rows(),x.cols());
			}
			else
			{
				return converter<ret_type,in_type>::eval(ret_ti,x);
			};
		};

		template<class val_type>
		typename gd::max_type2<Real,val_type,arg_type>::type
		eval(gd::type_info ti, val_type val) const
		{
			typedef gd::max_type2<Real,val_type,arg_type>::type ret_type;
			return eval_impl<ret_type,val_type,rev>::eval(ti,val,arg);
		};

		template<class ret_type, class val_type, bool rev>
		struct eval_impl
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return pow_helper<val_type,arg_type>::eval(ti,val,arg);
			};
		};
		template<class ret_type, class val_type>
		struct eval_impl<ret_type,val_type,true>
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return pow_helper<arg_type,val_type>::eval(ti,arg,val);
			};
		};
};
#pragma warning(pop)

template<class arg_type, bool rev>
class min_functor
{
	private:
		arg_type	arg;

	public:
		min_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		{return false; };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
			return ret_type(ret_ti);
		};

		template<class val_type>
		typename gd::max_type<val_type,arg_type>::type
		eval(gd::type_info ti, val_type val) const
		{
			typedef typename gd::max_type<val_type,arg_type>::type ret_type;
			return min_helper<val_type,arg_type>::eval(ti,val,arg);
		};
};
template<class arg_type, bool rev>
class max_functor
{
	private:
		arg_type	arg;

	public:
		max_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		{ return false; };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
			return ret_type(ret_ti);
		};

		template<class val_type>
		typename gd::max_type<val_type,arg_type>::type
		eval(gd::type_info ti, val_type val) const
		{
			typedef typename gd::max_type<val_type,arg_type>::type ret_type;
			return max_helper<val_type,arg_type>::eval(ti,val,arg);
		};
};
template<class arg_type, bool rev>
class plus_functor
{
	private:
		arg_type	arg;

	public:
		plus_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const			
        { 
            return arg == gd::default_value<arg_type>(gd::get_ti(arg)); 
        };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
			return converter<ret_type,in_type>::eval(ret_ti,x);
		};

		template<class val_type>
		typename gd::max_type<val_type,arg_type>::type
		eval(gd::type_info ti, val_type val) const
		{
			return plus_helper<val_type,arg_type>::eval(ti,val,arg);
		};
};
template<class arg_type, bool rev>
class minus_functor
{
	private:
		arg_type	arg;

	public:
		minus_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		
        { 
            return arg == gd::default_value<arg_type>(gd::get_ti(arg)) && rev == false; 
        };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
			return converter<ret_type,in_type>::eval(ret_ti,x);
		};

		template<class val_type>
		typename gd::max_type<val_type,arg_type>::type
		eval(gd::type_info ti, val_type val) const
		{
			typedef gd::max_type<val_type,arg_type>::type ret_type;
			return eval_impl<ret_type,val_type,rev>::eval(ti,val,arg);
		};

		template<class ret_type, class val_type, bool rev>
		struct eval_impl
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return minus_helper<val_type,arg_type>::eval(ti,val,arg);
			};
		};
		template<class ret_type, class val_type>
		struct eval_impl<ret_type,val_type,true>
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return minus_helper<arg_type,val_type>::eval(ti,arg,val);
			};
		};
};
template<class arg_type, bool rev>
class mod_functor
{
	private:
		arg_type	arg;

	public:
		mod_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		
        { 
            return arg == gd::default_value<arg_type>(gd::get_ti(arg)); 
        };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
			return create_matrix<ret_type>(ret_ti,x.rows(), x.cols());
		};

		template<class val_type>
		typename gd::max_type<val_type,arg_type>::type
		eval(gd::type_info ti, val_type val) const
		{
			typedef gd::max_type<val_type,arg_type>::type ret_type;
			return eval_impl<ret_type,val_type,rev>::eval(ti,val,arg);
		};

		template<class ret_type, class val_type, bool rev>
		struct eval_impl
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return mod_helper<val_type,arg_type>::eval(ti,val,arg);
			};
		};
		template<class ret_type, class val_type>
		struct eval_impl<ret_type,val_type,true>
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return mod_helper<arg_type,val_type>::eval(ti,arg,val);
			};
		};
};
template<class arg_type, bool rev>
class rem_functor
{
	private:
		arg_type	arg;

	public:
		rem_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		
        { 
            return arg == gd::default_value<arg_type>(gd::get_ti(arg)); 
        };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &x) const
		{
			return create_matrix<ret_type>(ret_ti,x.rows(),x.cols());
		};

		template<class val_type>
		typename gd::max_type<val_type,arg_type>::type
		eval(gd::type_info ret_ti, val_type val) const
		{
			typedef gd::max_type<val_type,arg_type>::type ret_type;
			return eval_impl<ret_type,val_type,rev>::eval(ret_ti,val,arg);
		};

		template<class ret_type, class val_type, bool rev>
		struct eval_impl
		{
			static ret_type eval(gd::type_info ret_ti, val_type val, arg_type arg)
			{
				return rem_helper<val_type,arg_type>::eval(ret_ti,val,arg);
			};
		};
		template<class ret_type, class val_type>
		struct eval_impl<ret_type,val_type,true>
		{
			static ret_type eval(gd::type_info ret_ti, val_type val, arg_type arg)
			{
				return rem_helper<arg_type,val_type>::eval(ret_ti,arg,val);
			};
		};
};
template<class arg_type, bool rev>
class atan2_functor
{
	private:
		arg_type	arg;

	public:
		atan2_functor(arg_type arg) : arg(arg) {};

		bool is_special_case() const		{ return false; };

		template<class ret_type, class in_type>
		ret_type eval_special_case(gd::type_info ret_ti, const in_type &) const
		{
			return ret_type(ret_ti);
		};

		template<class val_type>
		typename gd::max_type2<Real,val_type,arg_type>::type
		eval(gd::type_info ti, val_type val) const
		{
			typedef gd::max_type2<Real,val_type,arg_type>::type ret_type;
			return eval_impl<ret_type,val_type,rev>::eval(ti,val,arg);
		};

		template<class ret_type, class val_type, bool rev>
		struct eval_impl
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return atan2_helper<val_type,arg_type>::eval(ti,val,arg);
			};
		};
		template<class ret_type, class val_type>
		struct eval_impl<ret_type,val_type,true>
		{
			static ret_type eval(gd::type_info ti, val_type val, arg_type arg)
			{
				return atan2_helper<arg_type,val_type>::eval(ti,arg,val);
			};
		};
};
struct eval_or_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return is_true_helper<T1>::eval(ti,arg1) || is_true_helper<T2>::eval(ti,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 arg1)
	{
		return is_true_helper<T1>::eval(ti,arg1);
	};

	template<class T, bool is_rev>
	static or_functor<T,is_rev> get_scalar_functor(T val)
	{
		return or_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag , struct_flag )
    {
        return struct_flag();
    };    
};

struct eval_and_functor
{
	static const bool ZZ = true;
	static const bool ZN = true;
	static const bool NZ = true;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return is_true_helper<T1>::eval(ti,arg1) && is_true_helper<T2>::eval(ti,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info , T1 )
	{
		return 0;
	};

	template<class T, bool is_rev>
	static and_functor<T,is_rev> get_scalar_functor(T val)
	{
		return and_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag )
    {
        return struct_flag();
    };
};

struct eval_xor_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return is_true_helper<T1>::eval(ti,arg1) ^ is_true_helper<T2>::eval(ti,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 arg1)
	{
		return is_true_helper<T1>::eval(ti,arg1);
	};

	template<class T, bool is_rev>
	static xor_functor<T,is_rev> get_scalar_functor(T val)
	{
		return xor_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};
struct eval_eeq_functor
{
	static const bool ZZ = false;
	static const bool ZN = true;
	static const bool NZ = true;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info , T1 arg1, T2 arg2)
	{
		return (arg1 == arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info , T1 arg1)
	{
        return (gd::is_zero(arg1));
	};

	template<class T, bool is_rev>
	static eeq_functor<T,is_rev> get_scalar_functor(T val)
	{
		return eeq_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag )
    {
        return struct_flag();
    };
};
struct eval_neq_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info , T1 arg1, T2 arg2)
	{
		return (arg1 != arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info , T1 arg1)
	{
        return (!gd::is_zero(arg1));
	};

	template<class T, bool is_rev>
	static neq_functor<T,is_rev> get_scalar_functor(T val)
	{
		return neq_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};

struct eval_leq_functor
{
	static const bool ZZ = false;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info , T1 arg1, T2 arg2)
	{
		return (arg1 <= arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info , T1 arg1)
	{
        T1 zero = gd::default_value<T1>(gd::get_ti(arg1));
		return zero_on_right? (arg1 <= zero) : (zero <= arg1);
	};

	template<class T, bool is_rev>
	static leq_functor<T,is_rev> get_scalar_functor(T val)
	{
		return leq_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};

struct eval_geq_functor
{
	static const bool ZZ = false;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info , T1 arg1, T2 arg2)
	{
		return (arg1 >= arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info , T1 arg1)
	{
        T1 zero = gd::default_value<T1>(gd::get_ti(arg1));
		return zero_on_right? (arg1 >= zero) : (zero >= arg1);
	};

	template<class T, bool is_rev>
	static geq_functor<T,is_rev> get_scalar_functor(T val)
	{
		return geq_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};

struct eval_lt_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info , T1 arg1, T2 arg2)
	{
		return (arg1 < arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info , T1 arg1)
	{
        T1 zero = gd::default_value<T1>(gd::get_ti(arg1));
		return zero_on_right? (arg1 < zero) : (zero < arg1);
	};

	template<class T, bool is_rev>
	static lt_functor<T,is_rev> get_scalar_functor(T val)
	{
		return lt_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};

struct eval_gt_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info , T1 arg1, T2 arg2)
	{
		return (arg1 > arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info , T1 arg1)
	{
        T1 zero = gd::default_value<T1>(gd::get_ti(arg1));
		return zero_on_right? (arg1 > zero) : (zero > arg1);
	};

	template<class T, bool is_rev>
	static gt_functor<T,is_rev> get_scalar_functor(T val)
	{
		return gt_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};

struct eval_mult_functor
{
	static const bool ZZ = true;
	static const bool ZN = true;
	static const bool NZ = true;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return mul_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 )
	{
        return gd::default_value<ret>(ti);
	};

	template<class T, bool is_rev>
	static mul_functor<T,is_rev> get_scalar_functor(T val)
	{
		return mul_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag f1, struct_flag f2)
    {
        return struct_flag::dmult_struct(f1,f2);
    };
};
struct eval_div_functor
{
	static const bool ZZ = false;
	static const bool ZN = true;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return div_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 arg1)
	{
        T1 zero = gd::default_value<T1>(gd::get_ti(arg1));
		return zero_on_right? ret(div_helper<T1,T1>::eval(ti,T1(arg1),zero)) 
                            : ret(div_helper<T1,T1>::eval(ti,zero,T1(arg1)));
	};

	template<class T, bool is_rev>
	static div_functor<T,is_rev> get_scalar_functor(T val)
	{
		return div_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};
struct eval_idiv_functor
{
	static const bool ZZ = false;
	static const bool ZN = true;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return idiv_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 arg1)
	{
        ret zero = gd::default_value<ret>(gd::get_ti(arg1));
		return zero_on_right? idiv_helper<T1,ret>::eval(ti,arg1,zero) 
                            : idiv_helper<ret,T1>::eval(ti,zero,arg1);
	};

	template<class T, bool is_rev>
	static idiv_functor<T,is_rev> get_scalar_functor(T val)
	{
		return idiv_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};
struct eval_pow_functor
{
	static const bool ZZ = false;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return pow_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 arg1)
	{
        ret zero = gd::default_value<ret>(gd::get_ti(arg1));
        ret val = converter<ret,T1>::eval(ti,arg1);
		return zero_on_right? pow_helper<ret,ret>::eval(ti,val,zero) 
                            : pow_helper<ret,ret>::eval(ti,zero,val);
	};

	template<class T, bool is_rev>
	static pow_functor<T,is_rev> get_scalar_functor(T val)
	{
		return pow_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};
struct eval_plus_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return plus_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info , T1 arg1)
	{
		return ret(arg1);
	};

	template<class T, bool is_rev>
	static plus_functor<T,is_rev> get_scalar_functor(T val)
	{
		return plus_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag f1, struct_flag f2)
    {
        return struct_flag::plus_struct(f1,f2);
    };
};
struct eval_minus_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return minus_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 arg1)
	{
        return zero_on_right? ret(arg1) : uminus_helper<ret>::eval(ti,arg1);
	};

	template<class T, bool is_rev>
	static minus_functor<T,is_rev> get_scalar_functor(T val)
	{
		return minus_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag f1, struct_flag f2)
    {
        return struct_flag::minus_struct(f1,f2);
    };
};
struct eval_min_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return min_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 arg1)
	{
        T1 zero = gd::default_value<T1>(gd::get_ti(arg1));
		return ret(min_helper<T1,T1>::eval(ti,T1(arg1),zero));
	};

	template<class T, bool is_rev>
	static min_functor<T,is_rev> get_scalar_functor(T val)
	{
		return min_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};
struct eval_max_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return max_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 arg1)
	{
        T1 zero = gd::default_value<T1>(gd::get_ti(arg1));
		return ret(max_helper<T1,T1>::eval(ti,T1(arg1),zero));
	};

	template<class T, bool is_rev>
	static max_functor<T,is_rev> get_scalar_functor(T val)
	{
		return max_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};
struct eval_mod_functor
{
	static const bool ZZ = true;
	static const bool ZN = true;
	static const bool NZ = true;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return mod_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 )
	{
		return gd::default_value<ret>(ti);;
	};

	template<class T, bool is_rev>
	static mod_functor<T,is_rev> get_scalar_functor(T val)
	{
		return mod_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};
struct eval_rem_functor
{
	static const bool ZZ = true;
	static const bool ZN = true;
	static const bool NZ = true;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return rem_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 )
	{
		return gd::default_value<ret>(ti);;
	};

	template<class T, bool is_rev>
	static rem_functor<T,is_rev> get_scalar_functor(T val)
	{
		return rem_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};
struct eval_atan2_functor
{
	static const bool ZZ = true;
	static const bool ZN = false;
	static const bool NZ = false;

	template<class ret, class T1, class T2>
	static ret eval(gd::type_info ti, T1 arg1, T2 arg2)
	{
		return atan2_helper<T1,T2>::eval(ti,arg1,arg2);
	};
	template<class ret, class T1, bool zero_on_right>
    static ret eval_zero(gd::type_info ti, T1 arg1)
	{
        T1 zero = gd::default_value<T1>(gd::get_ti(arg1));
		return zero_on_right? ret(atan2_helper<T1,T1>::eval(ti,arg1,zero))
							  :ret(atan2_helper<T1,T1>::eval(ti,zero,arg1));
	};

	template<class T, bool is_rev>
	static atan2_functor<T,is_rev> get_scalar_functor(T val)
	{
		return atan2_functor<T,is_rev>(val);
	};
    static struct_flag op_struct(struct_flag, struct_flag)
    {
        return struct_flag();
    };
};

template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_or 
mat_func_helper<M1,M2>::eval_or(const M1& A, const M2& B)
{
	return eval_op<ret_type_or,M1,M2,eval_or_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_and 
mat_func_helper<M1,M2>::eval_and(const M1& A, const M2& B)
{
	return eval_op<ret_type_and,M1,M2,eval_and_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_xor 
mat_func_helper<M1,M2>::eval_xor(const M1& A, const M2& B)
{
	return eval_op<ret_type_xor,M1,M2,eval_xor_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_eeq 
mat_func_helper<M1,M2>::eval_eeq(const M1& A, const M2& B)
{
	return eval_op<ret_type_eeq,M1,M2,eval_eeq_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_neq 
mat_func_helper<M1,M2>::eval_neq(const M1& A, const M2& B)
{
	return eval_op<ret_type_neq,M1,M2,eval_neq_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_leq 
mat_func_helper<M1,M2>::eval_leq(const M1& A, const M2& B)
{
	return eval_op<ret_type_leq,M1,M2,eval_leq_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_geq 
mat_func_helper<M1,M2>::eval_geq(const M1& A, const M2& B)
{
	typedef ret_type_geq ret_type;
	return eval_op<ret_type,M1,M2,eval_geq_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_lt 
mat_func_helper<M1,M2>::eval_lt(const M1& A, const M2& B)
{
	return eval_op<ret_type_lt,M1,M2,eval_lt_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_gt 
mat_func_helper<M1,M2>::eval_gt(const M1& A, const M2& B)
{
	return eval_op<ret_type_gt,M1,M2,eval_gt_functor>::eval(A,B);
};
template<class M1,class M2, class comparer>
typename mat_func_compare_helper<M1,M2,comparer>::ret_type_compare 
mat_func_compare_helper<M1,M2,comparer>::eval_compare(const M1& A, const M2& B,const comparer& func)
{
	return eval_op<ret_type_compare,M1,M2,eval_compare_functor>::eval(A,B,eval_compare_functor(func));
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_mul 
mat_func_helper<M1,M2>::eval_mul(const M1& A, const M2& B)
{
	return eval_op<ret_type_mul,M1,M2,eval_mult_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_div 
mat_func_helper<M1,M2>::eval_div(const M1& A, const M2& B)
{
	return eval_op<ret_type_div,M1,M2,eval_div_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_idiv 
mat_func_helper<M1,M2>::eval_idiv(const M1& A, const M2& B)
{
	return eval_op<ret_type_idiv,M1,M2,eval_idiv_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_pow 
mat_func_helper<M1,M2>::eval_pow(const M1& A, const M2& B)
{
	return eval_op<ret_type_pow,M1,M2,eval_pow_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_min 
mat_func_helper<M1,M2>::eval_min(const M1& A, const M2& B)
{
	return eval_op<ret_type_min,M1,M2,eval_min_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_max 
mat_func_helper<M1,M2>::eval_max(const M1& A, const M2& B)
{
	return eval_op<ret_type_max,M1,M2,eval_max_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_plus 
mat_func_helper<M1,M2>::eval_plus(const M1& A, const M2& B)
{
	return eval_op<ret_type_plus,M1,M2,eval_plus_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_minus 
mat_func_helper<M1,M2>::eval_minus(const M1& A, const M2& B)
{
	return eval_op<ret_type_minus,M1,M2,eval_minus_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_mod 
mat_func_helper<M1,M2>::eval_mod(const M1& A, const M2& B)
{
	return eval_op<ret_type_mod,M1,M2,eval_mod_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_rem 
mat_func_helper<M1,M2>::eval_rem(const M1& A, const M2& B)
{
	return eval_op<ret_type_rem,M1,M2,eval_rem_functor>::eval(A,B);
};
template<class M1,class M2>
typename mat_func_helper<M1,M2>::ret_type_atan2 
mat_func_helper<M1,M2>::eval_atan2(const M1& A, const M2& B)
{
	return eval_op<ret_type_atan2,M1,M2,eval_atan2_functor>::eval(A,B);
};




template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_or 
mat_func_scal_mat_helper<M1,M2>::eval_or(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_or,M2,eval_or_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_and 
mat_func_scal_mat_helper<M1,M2>::eval_and(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_and,M2,eval_and_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_xor 
mat_func_scal_mat_helper<M1,M2>::eval_xor(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_xor,M2,eval_xor_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_eeq 
mat_func_scal_mat_helper<M1,M2>::eval_eeq(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_eeq,M2,eval_eeq_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_neq 
mat_func_scal_mat_helper<M1,M2>::eval_neq(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_neq,M2,eval_neq_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_leq 
mat_func_scal_mat_helper<M1,M2>::eval_leq(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_leq,M2,eval_leq_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_geq 
mat_func_scal_mat_helper<M1,M2>::eval_geq(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_geq,M2,eval_geq_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_lt 
mat_func_scal_mat_helper<M1,M2>::eval_lt(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_lt,M2,eval_lt_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_gt 
mat_func_scal_mat_helper<M1,M2>::eval_gt(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_gt,M2,eval_gt_functor,false>::eval(B,true,A);
};

template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_mul 
mat_func_scal_mat_helper<M1,M2>::eval_mul(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_mul,M2,eval_mult_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_div 
mat_func_scal_mat_helper<M1,M2>::eval_div(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_div,M2,eval_div_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_idiv 
mat_func_scal_mat_helper<M1,M2>::eval_idiv(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_idiv,M2,eval_idiv_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_pow 
mat_func_scal_mat_helper<M1,M2>::eval_pow(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_pow,M2,eval_pow_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_min 
mat_func_scal_mat_helper<M1,M2>::eval_min(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_min,M2,eval_min_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_max 
mat_func_scal_mat_helper<M1,M2>::eval_max(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_max,M2,eval_max_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_plus 
mat_func_scal_mat_helper<M1,M2>::eval_plus(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_plus,M2,eval_plus_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_minus 
mat_func_scal_mat_helper<M1,M2>::eval_minus(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_minus,M2,eval_minus_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_mod 
mat_func_scal_mat_helper<M1,M2>::eval_mod(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_mod,M2,eval_mod_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_rem 
mat_func_scal_mat_helper<M1,M2>::eval_rem(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_rem,M2,eval_rem_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper<M1,M2>::ret_type_atan2 
mat_func_scal_mat_helper<M1,M2>::eval_atan2(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_atan2,M2,eval_atan2_functor,false>::eval(B,true,A);
};




template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_or 
mat_func_mat_scal_helper<M2,M1>::eval_or(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_or,M2,eval_or_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_and 
mat_func_mat_scal_helper<M2,M1>::eval_and(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_and,M2,eval_and_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_xor 
mat_func_mat_scal_helper<M2,M1>::eval_xor(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_xor,M2,eval_xor_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_eeq 
mat_func_mat_scal_helper<M2,M1>::eval_eeq(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_eeq,M2,eval_eeq_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_neq 
mat_func_mat_scal_helper<M2,M1>::eval_neq(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_neq,M2,eval_neq_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_leq 
mat_func_mat_scal_helper<M2,M1>::eval_leq(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_leq,M2,eval_leq_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_geq 
mat_func_mat_scal_helper<M2,M1>::eval_geq(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_geq,M2,eval_geq_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_lt 
mat_func_mat_scal_helper<M2,M1>::eval_lt(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_lt,M2,eval_lt_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_gt 
mat_func_mat_scal_helper<M2,M1>::eval_gt(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_gt,M2,eval_gt_functor,false>::eval(B,false,A);
};

template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_mul 
mat_func_mat_scal_helper<M2,M1>::eval_mul(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_mul,M2,eval_mult_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_div 
mat_func_mat_scal_helper<M2,M1>::eval_div(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_div,M2,eval_div_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_idiv 
mat_func_mat_scal_helper<M2,M1>::eval_idiv(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_idiv,M2,eval_idiv_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_pow 
mat_func_mat_scal_helper<M2,M1>::eval_pow(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_pow,M2,eval_pow_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_min 
mat_func_mat_scal_helper<M2,M1>::eval_min(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_min,M2,eval_min_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_max 
mat_func_mat_scal_helper<M2,M1>::eval_max(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_max,M2,eval_max_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_plus 
mat_func_mat_scal_helper<M2,M1>::eval_plus(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_plus,M2,eval_plus_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_minus 
mat_func_mat_scal_helper<M2,M1>::eval_minus(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_minus,M2,eval_minus_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_mod 
mat_func_mat_scal_helper<M2,M1>::eval_mod(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_mod,M2,eval_mod_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_rem 
mat_func_mat_scal_helper<M2,M1>::eval_rem(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_rem,M2,eval_rem_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper<M2,M1>::ret_type_atan2 
mat_func_mat_scal_helper<M2,M1>::eval_atan2(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_atan2,M2,eval_atan2_functor,false>::eval(B,false,A);
};


template<class M1,class M2>
typename mat_func_scal_mat_helper2<M1,M2>::ret_type_eeq 
mat_func_scal_mat_helper2<M1,M2>::eval_eeq(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_eeq,M2,eval_eeq_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper2<M1,M2>::ret_type_neq 
mat_func_scal_mat_helper2<M1,M2>::eval_neq(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_neq,M2,eval_neq_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper2<M1,M2>::ret_type_leq 
mat_func_scal_mat_helper2<M1,M2>::eval_leq(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_leq,M2,eval_leq_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper2<M1,M2>::ret_type_geq 
mat_func_scal_mat_helper2<M1,M2>::eval_geq(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_geq,M2,eval_geq_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper2<M1,M2>::ret_type_lt 
mat_func_scal_mat_helper2<M1,M2>::eval_lt(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_lt,M2,eval_lt_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper2<M1,M2>::ret_type_gt 
mat_func_scal_mat_helper2<M1,M2>::eval_gt(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_gt,M2,eval_gt_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper2<M1,M2>::ret_type_min 
mat_func_scal_mat_helper2<M1,M2>::eval_min(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_min,M2,eval_min_functor,false>::eval(B,true,A);
};
template<class M1,class M2>
typename mat_func_scal_mat_helper2<M1,M2>::ret_type_max 
mat_func_scal_mat_helper2<M1,M2>::eval_max(const M1& A, const M2& B)
{
	return eval_scalar<ret_type_max,M2,eval_max_functor,false>::eval(B,true,A);
};

template<class M2,class M1>
typename mat_func_mat_scal_helper2<M2,M1>::ret_type_eeq 
mat_func_mat_scal_helper2<M2,M1>::eval_eeq(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_eeq,M2,eval_eeq_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper2<M2,M1>::ret_type_neq 
mat_func_mat_scal_helper2<M2,M1>::eval_neq(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_neq,M2,eval_neq_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper2<M2,M1>::ret_type_leq 
mat_func_mat_scal_helper2<M2,M1>::eval_leq(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_leq,M2,eval_leq_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper2<M2,M1>::ret_type_geq 
mat_func_mat_scal_helper2<M2,M1>::eval_geq(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_geq,M2,eval_geq_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper2<M2,M1>::ret_type_lt 
mat_func_mat_scal_helper2<M2,M1>::eval_lt(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_lt,M2,eval_lt_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper2<M2,M1>::ret_type_gt 
mat_func_mat_scal_helper2<M2,M1>::eval_gt(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_gt,M2,eval_gt_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper2<M2,M1>::ret_type_min 
mat_func_mat_scal_helper2<M2,M1>::eval_min(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_min,M2,eval_min_functor,false>::eval(B,false,A);
};
template<class M2,class M1>
typename mat_func_mat_scal_helper2<M2,M1>::ret_type_max 
mat_func_mat_scal_helper2<M2,M1>::eval_max(const M2& B, const M1& A)
{
	return eval_scalar<ret_type_max,M2,eval_max_functor,false>::eval(B,false,A);
};

template<class T1, class T2>
struct expand_pow
{
    static void eval(const T1& A, const T2& B)
    {
        mat_func_helper<T1,T2>::eval_pow(A,B);
    };
};
template<class T1, class T2>
struct expand_pow_scal_mat
{
    static void eval(const T1& A, const T2& B)
    {
        mat_func_scal_mat_helper<T1,T2>::eval_pow(A,B);
    };
};
template<class T1, class T2>
struct expand_pow_mat_scal
{
    static void eval(const T1& A, const T2& B)
    {
        mat_func_mat_scal_helper<T1,T2>::eval_pow(A,B);
    };
};

};};};

MACRO_INSTANTIATE_GG_2(mmlib::raw::details::mat_func_helper)
MACRO_INSTANTIATE_GST_2(mmlib::raw::details::mat_func_helper)
MACRO_INSTANTIATE_STG_2(mmlib::raw::details::mat_func_helper)
MACRO_INSTANTIATE_STST_2(mmlib::raw::details::mat_func_helper)

MACRO_INSTANTIATE_SG_2(mmlib::raw::details::mat_func_scal_mat_helper)
MACRO_INSTANTIATE_SST_2(mmlib::raw::details::mat_func_scal_mat_helper)
MACRO_INSTANTIATE_GS_2(mmlib::raw::details::mat_func_mat_scal_helper)
MACRO_INSTANTIATE_STS_2(mmlib::raw::details::mat_func_mat_scal_helper)

MACRO_INSTANTIATE_SG_2(mmlib::raw::details::mat_func_scal_mat_helper2)
MACRO_INSTANTIATE_SST_2(mmlib::raw::details::mat_func_scal_mat_helper2)
MACRO_INSTANTIATE_GS_2(mmlib::raw::details::mat_func_mat_scal_helper2)
MACRO_INSTANTIATE_STS_2(mmlib::raw::details::mat_func_mat_scal_helper2)

MACRO_INSTANTIATE_GG_2_F(mmlib::raw::details::expand_pow)
MACRO_INSTANTIATE_GST_2_F(mmlib::raw::details::expand_pow)
MACRO_INSTANTIATE_STG_2_F(mmlib::raw::details::expand_pow)
MACRO_INSTANTIATE_STST_2_F(mmlib::raw::details::expand_pow)

MACRO_INSTANTIATE_SG_2_F(mmlib::raw::details::expand_pow_scal_mat)
MACRO_INSTANTIATE_SST_2_F(mmlib::raw::details::expand_pow_scal_mat)
MACRO_INSTANTIATE_GS_2_F(mmlib::raw::details::expand_pow_mat_scal)
MACRO_INSTANTIATE_STS_2_F(mmlib::raw::details::expand_pow_mat_scal)

#pragma warning( pop )