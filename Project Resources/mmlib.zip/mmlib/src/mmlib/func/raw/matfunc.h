/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/enablers.h"
#include "mmlib/base/return_types.h"
#include "mmlib/mp/promote_type.h"

namespace mmlib { namespace raw
{

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_or>>::type
operator|(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_or(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_or>>::type
operator|(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_or(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_or>>::type
operator|(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_or(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_or>>::type
or(const M1& A, const M2& B)
{
	return raw::operator|(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_or>>::type
or(const M1& A, const M2& B)
{
	return raw::operator|(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_or>>::type
or(const M1& A, const M2& B)
{
	return raw::operator|(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_and>>::type
operator&(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_and(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_and>>::type
operator&(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_and(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_and>>::type
operator&(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_and(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_and>>::type
and(const M1& A, const M2& B)
{
	return raw::operator&(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_and>>::type
and(const M1& A, const M2& B)
{
	return raw::operator&(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_and>>::type
and(const M1& A, const M2& B)
{
	return raw::operator&(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_eeq>>::type
operator==(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_eeq(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_eeq>>::type
operator==(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_eeq(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_eeq>>::type
operator==(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_eeq(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_eeq>>::type
eeq(const M1& A, const M2& B)
{
	return raw::operator==(A,B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,
			return_type_mat_scal<M1,M2,raw_functions::op_eeq,mmlib::details::bool_type<zero_ret_zero>>>::type
eeq(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_mat_scal_arg_helper<MP1,MP2,targ>::eval_eeq(promote_type_1::eval(A),B);
};
template<bool zero_ret_zero,class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,
			return_type_scal_mat<M1,M2,raw_functions::op_eeq,mmlib::details::bool_type<zero_ret_zero>>>::type
eeq(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_scal_mat_arg_helper<MP1,MP2,targ>::eval_eeq(A,promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_eeq>>::type
eeq(const M1& A, const M2& B)
{
	return raw::eeq<false,M1,M2>(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_eeq>>::type
eeq(const M1& A, const M2& B)
{
	return raw::eeq<false,M1,M2>(A,B);
};


template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_neq>>::type
operator!=(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_neq(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_neq>>::type
operator!=(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_neq(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_neq>>::type
operator!=(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_neq(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_neq>>::type
neq(const M1& A, const M2& B)
{
	return raw::operator!=(A,B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,
		return_type_mat_scal<M1,M2,raw_functions::op_neq,mmlib::details::bool_type<zero_ret_zero>>>::type
neq(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_mat_scal_arg_helper<MP1,MP2,targ>::eval_neq(promote_type_1::eval(A),B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,
		return_type_scal_mat<M1,M2,raw_functions::op_neq,mmlib::details::bool_type<zero_ret_zero>>>::type
neq(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_scal_mat_arg_helper<MP1,MP2,targ>::eval_neq(A,promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_neq>>::type
neq(const M1& A, const M2& B)
{
	return raw::neq<false,M1,M2>(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_neq>>::type
neq(const M1& A, const M2& B)
{
	return raw::neq<false,M1,M2>(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_gt>>::type
operator>(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_gt(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_gt>>::type
operator>(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_gt(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_gt>>::type
operator>(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_gt(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_gt>>::type
gt(const M1& A, const M2& B)
{
	return raw::operator>(A,B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,
	return_type_mat_scal<M1,M2,raw_functions::op_gt,mmlib::details::bool_type<zero_ret_zero>>>::type
gt(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_mat_scal_arg_helper<MP1,MP2,targ>::eval_gt(promote_type_1::eval(A),B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,
	return_type_scal_mat<M1,M2,raw_functions::op_gt,mmlib::details::bool_type<zero_ret_zero>>>::type
gt(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_scal_mat_arg_helper<MP1,MP2,targ>::eval_gt(A,promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_gt>>::type
gt(const M1& A, const M2& B)
{
	return raw::gt<false,M1,M2>(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_gt>>::type
gt(const M1& A, const M2& B)
{
	return raw::gt<false,M1,M2>(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_lt>>::type
operator<(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_lt(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_lt>>::type
operator<(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_lt(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_lt>>::type
operator<(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_lt(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_lt>>::type
lt(const M1& A, const M2& B)
{
	return raw::operator<(A,B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,
	return_type_mat_scal<M1,M2,raw_functions::op_lt,mmlib::details::bool_type<zero_ret_zero>>>::type
lt(const M1& A, const M2& B)
{
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_arg_helper<MP1,MP2,targ>::eval_lt(promote_type_1::eval(A),B);
};
template<bool zero_ret_zero,class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,
	return_type_scal_mat<M1,M2,raw_functions::op_lt,mmlib::details::bool_type<zero_ret_zero>>>::type
lt(const M1& A, const M2& B)
{
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_arg_helper<MP1,MP2,targ>::eval_lt(A,promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_lt>>::type
lt(const M1& A, const M2& B)
{
	return raw::lt<false,M1,M2>(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_lt>>::type
lt(const M1& A, const M2& B)
{
	return raw::lt<false,M1,M2>(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_geq>>::type
operator>=(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_geq(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_geq>>::type
operator>=(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_geq(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_geq>>::type
operator>=(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_geq(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_geq>>::type
geq(const M1& A, const M2& B)
{
	return raw::operator>=(A,B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,
	return_type_mat_scal<M1,M2,raw_functions::op_geq,mmlib::details::bool_type<zero_ret_zero>>>::type
geq(const M1& A, const M2& B)
{
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_arg_helper<MP1,MP2,targ>::eval_geq(promote_type_1::eval(A),B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,
	return_type_scal_mat<M1,M2,raw_functions::op_geq,mmlib::details::bool_type<zero_ret_zero>>>::type
geq(const M1& A, const M2& B)
{
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_arg_helper<MP1,MP2,targ>::eval_geq(A,promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_geq>>::type
geq(const M1& A, const M2& B)
{
	return raw::geq<false,M1,M2>(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_geq>>::type
geq(const M1& A, const M2& B)
{
	return raw::geq<false,M1,M2>(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_leq>>::type
operator<=(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_leq(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_leq>>::type
operator<=(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_leq(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_leq>>::type
operator<=(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_leq(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_leq>>::type
leq(const M1& A, const M2& B)
{
	return raw::operator<=(A,B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,
	return_type_mat_scal<M1,M2,raw_functions::op_leq,mmlib::details::bool_type<zero_ret_zero>>>::type
leq(const M1& A, const M2& B)
{
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_arg_helper<MP1,MP2,targ>::eval_leq(promote_type_1::eval(A),B);
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,
	return_type_scal_mat<M1,M2,raw_functions::op_leq,mmlib::details::bool_type<zero_ret_zero>>>::type
leq(const M1& A, const M2& B)
{
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_arg_helper<MP1,MP2,targ>::eval_leq(A,promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_leq>>::type
leq(const M1& A, const M2& B)
{
	return raw::leq<false,M1,M2>(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_leq>>::type
leq(const M1& A, const M2& B)
{
	return raw::leq<false,M1,M2>(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::xor>>::type
xor(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_xor(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::xor>>::type
xor(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_xor(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::xor>>::type
xor(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_xor(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::pow>>::type
pow(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_pow(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::pow>>::type
pow(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_pow(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::pow>>::type
pow(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_pow(A,promote_type_2::eval(B));
};


template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::mul>>::type
mul(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_mul(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::mul>>::type
mul(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_mul(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::mul>>::type
mul(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_mul(A,promote_type_2::eval(B));
};


template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::div>>::type
div(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_div(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::div>>::type
div(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_div(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::div>>::type
div(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_div(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::idiv>>::type
idiv(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_idiv(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::idiv>>::type
idiv(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_idiv(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::idiv>>::type
idiv(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_idiv(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::max2>>::type
max(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_max(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<bool zero_ret_zero, class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,
	return_type_mat_scal<M1,M2,raw_functions::max2,mmlib::details::bool_type<zero_ret_zero>>>::type
max(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_mat_scal_arg_helper<MP1,MP2,targ>::eval_max(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::max2>>::type
max(const M1& A, const M2& B)
{
	return raw::max<false,M1,M2>(A,B);
};
template<bool zero_ret_zero,class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,
	return_type_scal_mat<M1,M2,raw_functions::max2,mmlib::details::bool_type<zero_ret_zero>>>::type
max(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_scal_mat_arg_helper<MP1,MP2,targ>::eval_max(A,promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::max2>>::type
max(const M1& A, const M2& B)
{
	return raw::max<false,M1,M2>(A,B);
};


template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::min2>>::type
min(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_min(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<bool zero_ret_zero,class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,
			return_type_mat_scal<M1,M2,raw_functions::min2,mmlib::details::bool_type<zero_ret_zero>>>::type
min(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_mat_scal_arg_helper<MP1,MP2,targ>::eval_min(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::min2>>::type
min(const M1& A, const M2& B)
{
	return raw::min<false,M1,M2>(A,B);
};
template<bool zero_ret_zero,class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,
	return_type_scal_mat<M1,M2,raw_functions::min2,mmlib::details::bool_type<zero_ret_zero>>>::type
min(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	typedef mmlib::details::bool_type<zero_ret_zero> targ;
	return details::mat_func_scal_mat_arg_helper<MP1,MP2,targ>::eval_min(A,promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::min2>>::type
min(const M1& A, const M2& B)
{
	return raw::min<false,M1,M2>(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_plus>>::type
plus(const M1& A, const M2& B)
{
	return raw::operator+(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_plus>>::type
plus(const M1& A, const M2& B)
{
	return raw::operator+(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_plus>>::type
plus(const M1& A, const M2& B)
{
	return raw::operator+(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_minus>>::type
minus(const M1& A, const M2& B)
{
	return raw::operator-(A,B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_minus>>::type
minus(const M1& A, const M2& B)
{
	return raw::operator-(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_minus>>::type
minus(const M1& A, const M2& B)
{
	return raw::operator-(A,B);
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_plus>>::type
operator+(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_plus(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_plus>>::type
operator+(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_plus(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_plus>>::type
operator+(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_plus(A,promote_type_2::eval(B));
};


template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::op_minus>>::type
operator-(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_minus(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::op_minus>>::type
operator-(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_minus(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::op_minus>>::type
operator-(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_minus(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::mod>>::type
mod(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_mod(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::mod>>::type
mod(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_mod(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::mod>>::type
mod(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_mod(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::rem>>::type
rem(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_rem(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::rem>>::type
rem(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_rem(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::rem>>::type
rem(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_rem(A,promote_type_2::eval(B));
};

template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_mat<M1,M2,return_type_mat_mat<M1,M2,raw_functions::atan2>>::type
atan2(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;
	typedef promote_type<M2> promote_type_2;
	typedef promote_type_1::type MP1;
	typedef promote_type_2::type MP2;
	return details::mat_func_helper<MP1,MP2>::eval_atan2(promote_type_1::eval(A),promote_type_2::eval(B));
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_mat_scal<M1,M2,return_type_mat_scal<M1,M2,raw_functions::atan2>>::type
atan2(const M1& A, const M2& B)
{
	typedef promote_type<M1> promote_type_1;	
	typedef promote_type_1::type MP1;
	typedef mmlib::details::promote_scalar<M2>::type   MP2;
	return details::mat_func_mat_scal_helper<MP1,MP2>::eval_atan2(promote_type_1::eval(A),B);
};
template<class M1, class M2>
inline typename mmlib::details::enable_if_scal_mat<M1,M2,return_type_scal_mat<M1,M2,raw_functions::atan2>>::type
atan2(const M1& A, const M2& B)
{
	typedef promote_type<M2> promote_type_2;	
	typedef promote_type_2::type MP2;
	typedef mmlib::details::promote_scalar<M1>::type   MP1;
	return details::mat_func_scal_mat_helper<MP1,MP2>::eval_atan2(A,promote_type_2::eval(B));
};


};};