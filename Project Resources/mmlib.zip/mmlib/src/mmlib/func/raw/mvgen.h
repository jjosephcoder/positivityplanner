/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/container/raw/type_decl.h"
#include "mmlib/utils/utils.h"

namespace mmlib { namespace raw
{

namespace gd = mmlib::details;

IntegerMatrix rangei(Integer s, Integer i, Integer e);
inline IntegerMatrix rangei(Integer s, Integer e)
{
    return rangei(s, 1, e);
}
IntegerMatrix randperm(Integer n);

RealMatrix range(Real s, Real i, Real e);
inline RealMatrix range(Real s, Real e)
{
    return range(s, 1., e);
}

RealMatrix linspace(Real s, Real e, Integer n);
RealMatrix logspace(Real s, Real e, Integer n);

inline RealMatrix zeros(Integer r, Integer c)
{
    RealMatrix out(gd::get_raw_ti(), 0., r, c);
    out.get_struct().set_zero_matrix();
    return out;
}
inline RealMatrix zeros(Integer n)
{
    RealMatrix out(gd::get_raw_ti(),0., n, n);
    out.get_struct().set_zero_matrix();
    return out;
}
inline ObjectMatrix zeros(gd::type_info ti,Integer r, Integer c)
{
    ObjectMatrix out(ti, gd::default_value<Object>(ti), r, c);
    out.get_struct().set_zero_matrix();
    return out;
}
inline ObjectMatrix zeros(gd::type_info ti,Integer n)
{
    ObjectMatrix out(ti,gd::default_value<Object>(ti), n, n);
    out.get_struct().set_zero_matrix();
    return out;
}
inline RealMatrix ones(Integer r, Integer c)
{
    return RealMatrix(gd::get_raw_ti(),1., r, c);
}
inline RealMatrix ones(Integer n)
{
    return RealMatrix(gd::get_raw_ti(),1., n, n);
}
inline ObjectMatrix ones(gd::type_info ti,Integer r, Integer c)
{
    return ObjectMatrix(ti,Object(ti,1L), r, c);
}
inline ObjectMatrix ones(gd::type_info ti,Integer n)
{
    return ObjectMatrix(ti,Object(ti,1L), n, n);
}
inline IntegerMatrix zerosi(Integer r, Integer c)
{
    IntegerMatrix out(gd::get_raw_ti(),0l, r, c);
    out.get_struct().set_zero_matrix();
    return out;
}
inline IntegerMatrix zerosi(Integer n)
{
    IntegerMatrix out(gd::get_raw_ti(),0l, n, n);
    out.get_struct().set_zero_matrix();
    return out;
}
inline IntegerMatrix onesi(Integer r, Integer c)
{
    return IntegerMatrix(gd::get_raw_ti(),1l, r, c);
}
inline IntegerMatrix onesi(Integer n)
{
    return IntegerMatrix(gd::get_raw_ti(),1l, n, n);
}

inline ComplexMatrix zerosc(Integer r, Integer c)
{
    ComplexMatrix out(gd::get_raw_ti(),0., r, c);
    out.get_struct().set_zero_matrix();
    return out;
}
inline ComplexMatrix zerosc(Integer n)
{
    ComplexMatrix out(gd::get_raw_ti(), 0., n, n);
    out.get_struct().set_zero_matrix();
    return out;
}
inline ComplexMatrix onesc(Integer r, Integer c)
{
    return ComplexMatrix(gd::get_raw_ti(), 1., r, c);
}
inline ComplexMatrix onesc(Integer n)
{
    return ComplexMatrix(gd::get_raw_ti(), 1., n, n);
}

RealMatrix eye(Integer m, Integer n);
ObjectMatrix eye(gd::type_info ti, Integer m, Integer n);

inline RealMatrix  eye(Integer n)
{
    return raw::eye(n, n);
}
inline ObjectMatrix  eye(gd::type_info ti,Integer n)
{
    return raw::eye(ti, n, n);
}

IntegerMatrix eyei(Integer m, Integer n);
inline IntegerMatrix  eyei(Integer n)
{
    return eyei(n, n);
}
ComplexMatrix eyec(Integer m, Integer n); 
inline ComplexMatrix  eyec(Integer n)
{
    return eyec(n, n);
}

Real rand();
RealMatrix rand(Integer m, Integer n);
inline RealMatrix rand(Integer n)
{
    return rand(n, n);
}
IntegerMatrix randi(Integer m, Integer n);
inline IntegerMatrix randi(Integer n)
{
    return randi(n, n);
}
ComplexMatrix randc(Integer m, Integer n);
inline ComplexMatrix randc(Integer n)
{
    return randc(n, n);
}

Real randn();
RealMatrix randn(Integer m, Integer n);
inline RealMatrix randn(Integer n)
{
    return randn(n, n);
}
ComplexMatrix randnc(Integer m, Integer n);
inline ComplexMatrix randnc(Integer n)
{
    return randnc(n, n);
}

IntegerMatrix diag(const IntegerMatrix &v, Integer i = 0);
RealMatrix diag(const RealMatrix &v, Integer i = 0);
ComplexMatrix diag(const ComplexMatrix &v, Integer i = 0);
ObjectMatrix diag(const ObjectMatrix &v, Integer i = 0);


IntegerBandMatrix bdiag(const IntegerMatrix &v, Integer d = 0);
IntegerBandMatrix bdiag(const IntegerSparseMatrix &v, Integer d = 0);
RealBandMatrix bdiag(const RealMatrix &v, Integer d = 0);
RealBandMatrix bdiag(const RealSparseMatrix &v, Integer d = 0);
ComplexBandMatrix bdiag(const ComplexMatrix &v, Integer d = 0);
ComplexBandMatrix bdiag(const ComplexSparseMatrix &v, Integer d = 0);
ObjectBandMatrix bdiag(const ObjectMatrix &v, Integer d = 0);
ObjectBandMatrix bdiag(const ObjectSparseMatrix &v, Integer d = 0);
IntegerBandMatrix bdiags(const IntegerMatrix &B, const IntegerMatrix &d,
					  Integer m, Integer n);
RealBandMatrix bdiags(const RealMatrix &B, const IntegerMatrix &d,
                      Integer m, Integer n);
ComplexBandMatrix bdiags(const ComplexMatrix &B, const IntegerMatrix &d,
                         Integer m, Integer n);
ObjectBandMatrix bdiags(const ObjectMatrix &B, const IntegerMatrix &d,
                         Integer m, Integer n);

IntegerMatrix diags(const IntegerMatrix &B, const IntegerMatrix &d,
					  Integer m, Integer n);
RealMatrix diags(const RealMatrix &B, const IntegerMatrix &d,
                      Integer m, Integer n);
ComplexMatrix diags(const ComplexMatrix &B, const IntegerMatrix &d,
                         Integer m, Integer n);
ObjectMatrix diags(const ObjectMatrix &B, const IntegerMatrix &d,
                         Integer m, Integer n);

RealSparseMatrix speye(Integer m, Integer n);
RealSparseMatrix speye(Integer n);
ObjectSparseMatrix speye(gd::type_info ti,Integer m, Integer n);
ObjectSparseMatrix speye(gd::type_info ti,Integer n);
IntegerSparseMatrix speyei(Integer m, Integer n);
IntegerSparseMatrix speyei(Integer n);
ComplexSparseMatrix speyec(Integer m, Integer n);
ComplexSparseMatrix speyec(Integer n);

RealBandMatrix beye(Integer m, Integer n, Integer ld, Integer ud);
RealBandMatrix beye(Integer n, Integer ld, Integer ud);
ObjectBandMatrix beye(gd::type_info ti,Integer m, Integer n, Integer ld, Integer ud);
ObjectBandMatrix beye(gd::type_info ti,Integer n, Integer ld, Integer ud);
IntegerBandMatrix beyei(Integer m, Integer n, Integer ld, Integer ud);
IntegerBandMatrix beyei(Integer n, Integer ld, Integer ud);
ComplexBandMatrix beyec(Integer m, Integer n, Integer ld, Integer ud);
ComplexBandMatrix beyec(Integer n, Integer ld, Integer ud);

RealSparseMatrix sprand(Integer m, Integer n, Real d);
IntegerSparseMatrix sprandi(Integer m, Integer n, Real d);
ComplexSparseMatrix sprandc(Integer m, Integer n, Real d);
RealSparseMatrix sprandn(Integer m, Integer n, Real d);
ComplexSparseMatrix sprandnc(Integer m, Integer n, Real d);

IntegerSparseMatrix spdiag(const IntegerMatrix &v, Integer d = 0);
RealSparseMatrix spdiag(const RealMatrix &v, Integer d = 0);
ComplexSparseMatrix spdiag(const ComplexMatrix &v, Integer d = 0);
ObjectSparseMatrix spdiag(const ObjectMatrix &v, Integer d = 0);

IntegerSparseMatrix spdiags(const IntegerMatrix &B, const IntegerMatrix &d,
                      Integer m, Integer n);
RealSparseMatrix spdiags(const RealMatrix &B, const IntegerMatrix &d,
                      Integer m, Integer n);
ComplexSparseMatrix spdiags(const ComplexMatrix &B, const IntegerMatrix &d,
                         Integer m, Integer n);
ObjectSparseMatrix spdiags(const ObjectMatrix &B, const IntegerMatrix &d,
                         Integer m, Integer n);
};};