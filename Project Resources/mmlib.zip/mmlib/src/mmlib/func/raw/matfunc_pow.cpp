/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/details/matfunc_helpers.h"
#include <cfloat>
#include "mmlib/details/scalfunc_helpers.h"


namespace mmlib { namespace raw { namespace details
{

inline Complex exp_complex(const Complex& arg)
{
    return exp_helper<Complex>::eval(gd::get_raw_ti(),arg);
};

template<class T1,class T2,bool isc_1,bool isc_2>
struct pow_complex_helper{};

template<class T1,class T2>
struct pow_complex_helper<T1,T2,true,true>
{
    static Complex eval(const T1& arg1, const T2& arg2)
    {
        if (mmlib::complex::eeq_c(arg1, 0.) && mmlib::complex::eeq_c(arg2, 0.))
	    {
		    return Complex(1,0);
	    };
	    if (imag(arg2) == 0)
        {
            typedef typename T2::type ST2;
            return pow_complex_helper<T1,ST2,true,false>::eval(arg1, real(arg2));
        }
	    else if (imag(arg1) == 0)
        {
            typedef typename T1::type ST1;
            return pow_complex_helper<ST1,T2,false,true>::eval(real(arg1), arg2);
        }
	    else
        {
            Complex tmp = mul_c(arg2 , log_helper<T1>::eval(gd::get_raw_ti(),arg1));
            return exp_complex(tmp);
        };
    };
};
template<class T1,class T2>
struct pow_complex_helper<T1,T2,true,false>
{
    static Complex eval(const T1& arg1, const T2& arg2)
    {
        if (mmlib::complex::eeq_c(arg1, 0.) && (arg2 == T2()))
	    {
		    return Complex(1,0);
	    };
	    if (imag(arg1) == 0 && real(arg1) >= 0 )
        {
		    return Complex(std::pow(real(arg1), arg2));
        }
	    else
        {
            Complex tmp = mul_c(arg2 , log_helper<T1>::eval(gd::get_raw_ti(),arg1));
            return exp_complex(tmp);
        };
    };
};
template<class T1>
struct pow_complex_helper<T1,Integer,true,false>
{
    static Complex eval(const T1& arg1, Integer arg2)
    {
	    T1 tmp = arg1;
	    unsigned long count = arg2;

        if (mmlib::complex::eeq_c(arg1 , T1()))
        {
            if (arg2 == 0)
            {
                return Complex(1.,0.);
            }
            else if (arg2 > 0)
            {
                return Complex(0.,0.);
            }
            else
            {
                return Complex(constants::Inf,0.);
            };
        }
        if (mmlib::complex::eeq_c(arg1 , T1(1.,0.)))
        {
            return Complex(1.,0.);
        };
	    if (arg2 < 0)
        {
		    count = 0 - count;
        };

	    for (T1 value = T1(1); ; tmp *= tmp)
		{	// fold in _Left ^ (2 ^ count) as needed
		    if ((count & 1) != 0)
            {
			    value *= tmp;
            };
		    if ((count >>= 1) == 0)
            {
			    return (arg2 < 0 ? div_c(T1(1),value) : value);
            };
		};
    };
};
template<class T1,class T2>
struct pow_complex_helper<T1,T2,false,true>
{
    static Complex eval(const T1& arg1, const T2& arg2)
    {
        if ((arg1 == T1()) && mmlib::complex::eeq_c(arg2, 0.))
	    {
		    return Complex(1,0);
	    };
        if (imag(arg2) == 0 && arg1 >= 0)
        {
            return Complex(std::pow(arg1, real(arg2)));
        };

        if (arg1 > T1())
        {
            Complex tmp = mul_c(arg2 ,log_helper<T1>::eval(gd::get_raw_ti(),arg1));
            return exp_complex(tmp);
        }
        else
        {
            Complex tmp = log_helper<Complex>::eval(gd::get_raw_ti(),arg1);
            tmp         = mul_c(arg2 , tmp);
            return exp_complex(tmp);
        };
    };
};

template<class T1, class T2>
Complex pow_complex<T1,T2>::eval(const T1& arg1, const T2& arg2)
{
    static const bool isc_1 = mmlib::details::is_equal<T1,Complex>::value;
    static const bool isc_2 = mmlib::details::is_equal<T2,Complex>::value;

    return pow_complex_helper<T1,T2,isc_1,isc_2>::eval(arg1,arg2);
};


};};};

template struct mmlib::raw::details::pow_complex<mmlib::Complex,mmlib::Complex>;
template struct mmlib::raw::details::pow_complex<mmlib::Complex,mmlib::Real>;
template struct mmlib::raw::details::pow_complex<mmlib::Complex,mmlib::Integer>;
template struct mmlib::raw::details::pow_complex<mmlib::Real,mmlib::Complex>;
