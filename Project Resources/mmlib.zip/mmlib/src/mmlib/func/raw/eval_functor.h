/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/utils/utils.h"

#pragma warning( push )
#pragma warning(disable:4100)	// unreferenced formal parameter (strange warning)
#pragma warning(disable:4723)	// potential divide by 0

namespace mmlib { namespace raw 
{

namespace gd = mmlib::details;

template<	class ret_type, 
			class in_type
		>
struct eval_functor
{ 
	template<class Func>
	static ret_type eval(const in_type &x,const Func& f) 
	{
		typedef ret_type::struct_type ret_str;
		typedef in_type::struct_type in_str;
        typedef in_type::value_type in_val;

        gd::type_info ret_ti = gd::return_func_ti<Func,in_type>::eval(x);

		ret_type out = details::eval_functor_2_impl<ret_type,in_type,ret_str,in_str>::eval(ret_ti,x,f);

        in_val Z = gd::default_value<in_val>(x.get_ti());
        bool is_zero_id = (f.eval(ret_ti,Z) == 0)? true:false;
        struct_flag so = struct_flag::eval_struct(x.get_struct(),is_zero_id);
        out.get_struct().link_struct(so);
        return out;
	};
};

template<	class ret_type, 
			class in_type
		>
struct eval_functor_2
{ 
	template<class Func>
    static ret_type eval(gd::type_info ret_ti,const in_type &x,const Func& f) 
	{
		typedef ret_type::struct_type ret_str;
		typedef in_type::struct_type in_str;
        typedef in_type::value_type in_val;

		if (f.is_special_case())
		{
            //gd::type_info ret_ti = gd::return_func_ti<Func,in_type>::eval(x);
			ret_type out = f.eval_special_case<ret_type,in_type>(ret_ti,x);

            in_val Z = gd::default_value<in_val>(x.get_ti());
            bool is_zero_id = (f.eval(ret_ti,Z) == 0)? true:false;
            struct_flag so = struct_flag::eval_struct(x.get_struct(),is_zero_id);
            out.get_struct().link_struct(so);
            return out;
		};
		ret_type out = details::eval_functor_2_impl<ret_type,in_type,ret_str,in_str>::eval(ret_ti,x,f);

        in_val Z = gd::default_value<in_val>(x.get_ti());
        bool is_zero_id = (f.eval(ret_ti,Z) == 0)? true:false;
        struct_flag so = struct_flag::eval_struct(x.get_struct(),is_zero_id);
        out.get_struct().link_struct(so);
        return out;
	};
};

namespace details
{
template<	class ret_type, 
			class in_type, 
			class ret_str,
			class in_str
		>
struct eval_functor_2_impl {};


template<	class ret_type, 
			class in_type
		>
struct eval_functor_2_impl<ret_type,in_type,struct_dense,struct_dense> 
{
	template<class Func>
	static ret_type eval(gd::type_info ret_ti,const in_type &x, const Func& f)
	{		
        typedef typename ret_type::value_type val_type;
        typedef typename in_type::value_type in_val;

        if (x.get_struct().is_diag() == true)
        {
            in_val Z =  gd::default_value<in_val>(x.get_ti());
            val_type fZ = f.eval(ret_ti,Z);
            ret_type res(ret_ti,fZ,x.rows(), x.cols());

            Integer r = x.rows();
            Integer c = x.cols();
            Integer k = std::min(r,c);

            val_type* ptr_ret       = res.ptr();
            const in_val* ptr_x     = x.ptr();

            for (Integer i = 0; i < k; ++i)
            {
                ptr_ret[0]  = f.eval(ret_ti,ptr_x[0]);
                ptr_ret     += res.ld() + 1;
                ptr_x       += x.ld() + 1;
            };
            return res;
        }
        else
        {
            ret_type res(ret_ti,x.rows(), x.cols()); 

            val_type* ptr_res       = res.ptr();
            const in_val* ptr_x     = x.ptr();

            for(Integer j = 0; j < x.cols(); ++j)    
            {
                for(Integer i = 0; i < x.rows(); ++i)
                {
                    ptr_res[i] = val_type(f.eval(ret_ti,ptr_x[i])); 
                };
                ptr_x += x.ld();
                ptr_res += res.ld();
            };
            return res;
        };	    
	};
};

template<	class ret_type, 
			class in_type
		>
struct eval_functor_2_impl<ret_type,in_type,struct_dense,struct_sparse> 
{
	template<class Func>
	static ret_type eval(gd::type_info ret_ti,const in_type &mat, const Func& f)
	{
		typedef typename in_type::value_type value_type;
        typedef typename ret_type::value_type value_type_ret;
		Integer Ar = mat.rows(), Ac = mat.cols();

		if (Ar == 0 || Ac == 0)
		{
			return ret_type(ret_ti,Ar, Ac);
		};

        value_type Z_in = gd::default_value<value_type>(gd::get_ti(mat));
        value_type_ret tmp = converter_deduce<value_type_ret>::eval(ret_ti, f.eval(ret_ti,Z_in));

		ret_type res(ret_ti,tmp,mat.rows(), mat.cols());

		const spdat<value_type>& Ad = mat.rep();
		const Integer* Ad_c		= Ad.ptr_c();
		const Integer* Ad_r		= Ad.ptr_r();
		const value_type* Ad_x	= Ad.ptr_x();
        value_type_ret* ptr_res = res.ptr();

		for (Integer j = 0; j < Ac; ++j)
		{
			for (Integer k = Ad_c[j] ; k < Ad_c[j + 1] ; ++k)
			{
                value_type_ret tmp = converter_deduce<value_type_ret>::eval(ret_ti, f.eval(ret_ti,Ad_x[k]));
				ptr_res[Ad_r[k]] = tmp;
			};

			ptr_res += res.ld();
		};
 
	    return res;
	};
};

template<	class ret_type, 
			class in_type
		>
struct eval_functor_2_impl<ret_type,in_type,struct_dense,struct_banded> 
{
	template<class Func>
    static ret_type eval(gd::type_info ret_ti, const in_type& A, const Func& f)
	{
		typedef in_type::value_type value_type;
		typedef ret_type::value_type val_type_ret;

		Integer r = A.rows(), c = A.cols();
		if (r == 0 || c == 0)
		{
			return ret_type(ret_ti, r,c);
		};

        value_type Z_in = gd::default_value<value_type>(gd::get_ti(A));

		val_type_ret res_0(f.eval(ret_ti,Z_in));
		ret_type res(ret_ti,res_0, A.rows(),A.cols());
	
		if (A.ldiags() == 0 && A.udiags() == 0)
		{
            const value_type* ptr_A = A.rep_ptr();
            val_type_ret* ptr_res = res.ptr();

			Integer rc = std::min(r,c);
			for (Integer j = 0; j < rc; ++j) 
			{
				ptr_res[j] = val_type_ret(f.eval(ret_ti,ptr_A[0]));
                ptr_A   += A.ld();
                ptr_res += res.ld();
			};
			return res;
		};

        const value_type* ptr_A = A.rep_ptr();
        val_type_ret* ptr_res = res.ptr();

		for (Integer j = 0; j < c; ++j) 
		{
			Integer row_f = A.first_row(j);
			Integer row_l = A.last_row(j);
			Integer row_p = A.first_elem_pos(j);

			for (Integer i = row_f; i <= row_l; ++i, ++row_p)
			{
				ptr_res[i] = val_type_ret(f.eval(ret_ti,ptr_A[row_p]));
			};	

            ptr_res += res.ld();
            ptr_A += A.ld();
		};

		return res;
	};
};

template<	class ret_type, 
			class in_type
		>
struct eval_functor_2_impl<ret_type,in_type,struct_sparse,struct_dense> 
{
	template<class Func>
	static ret_type eval(gd::type_info ret_ti,const in_type &mat, const Func& f)
	{
		typedef typename in_type::value_type value_type;
		typedef typename ret_type::value_type val_type_ret;		

        value_type Z_in = gd::default_value<value_type>(gd::get_ti(mat));
        val_type_ret Z_ret = gd::default_value<val_type_ret>(ret_ti);

		Integer Ar = mat.rows(), Ac = mat.cols(), nz = 0;

		if (Ar == 0 || Ac == 0)
		{
			return ret_type(ret_ti,Ar,Ac);
		};

		val_type_ret res_0 = f.eval(ret_ti,Z_in);
		if (res_0 != Z_ret)
		{
			typedef Matrix<val_type_ret,struct_dense> FullMatrixRet;
			FullMatrixRet out = eval_functor_2_impl<FullMatrixRet,in_type,struct_dense,struct_dense>
                                            ::eval(ret_ti,mat,f);
			return converter<ret_type,FullMatrixRet>::eval(ret_ti,out);
		};

		ret_type res(ret_ti,mat.rows(), mat.cols(), Ar); 

		spdat<val_type_ret>& d = res.rep();;

		Integer * d_c		= d.ptr_c();
		Integer * d_r		= d.ptr_r();
		val_type_ret * d_x	= d.ptr_x();
        const value_type* ptr_mat = mat.ptr();

		for (Integer j = 0; j < Ac; ++j)
		{
    		if (nz + Ar > d.nzmax()) 
    		{
				d.memadd( d.nzmax() + Ar);

				d_r				= d.ptr_r();
				d_x				= d.ptr_x();
    		};

			d_c[j]  = nz;

    		for (Integer k = 0 ; k < Ar ; ++k)
    		{
				val_type_ret val = f.eval(ret_ti,ptr_mat[k]);
				if (val == Z_ret)
				{
					continue;
				};
				d_r[nz] = k;
				d_x[nz] = val;

				++nz;
    		};
            ptr_mat += mat.ld();
		};
		d_c[Ac] = nz;

		d.memadd(-1);
		return res;
	};
};

template<	class ret_type, 
			class in_type
		>
struct eval_functor_2_impl<ret_type,in_type,struct_sparse,struct_sparse> 
{
	template<class Func>
	static ret_type eval(gd::type_info ret_ti,const in_type & mat, const Func& f)  
	{ 
		typedef typename in_type::value_type value_type;
		typedef typename ret_type::value_type val_type_ret;		

		Integer Ar = mat.rows(), Ac = mat.cols(), nz = 0;
		if (Ar == 0 || Ac == 0)
		{
			return ret_type(ret_ti,Ar,Ac);
		};

        value_type Z_in = gd::default_value<value_type>(gd::get_ti(mat));
        val_type_ret Z_ret = gd::default_value<val_type_ret>(ret_ti);

		val_type_ret res_0(f.eval(ret_ti,Z_in));

		if (res_0 != Z_ret)
		{
			typedef Matrix<val_type_ret,struct_dense> FullMatrixRet;
			FullMatrixRet out = eval_functor_2_impl<FullMatrixRet,in_type,struct_dense,struct_sparse>
                                        ::eval(ret_ti,mat,f);
			return converter<ret_type,FullMatrixRet>::eval(ret_ti,out);
		};
		ret_type res(ret_ti,mat.rows(), mat.cols(), mat.nnz()); 		

		const spdat<value_type>& Ad = mat.rep();
		spdat<val_type_ret>& d = res.rep();;

		const Integer* Ad_c		= Ad.ptr_c();
		const Integer* Ad_r		= Ad.ptr_r();
		const value_type* Ad_x	= Ad.ptr_x();

		Integer* d_c			= d.ptr_c();
		Integer* d_r			= d.ptr_r();
		val_type_ret* d_x		= d.ptr_x();

		for (Integer j = 0; j < Ac; ++j)
		{
			d_c[j] = nz;

    		for (Integer k = Ad_c[j] ; k < Ad_c[j + 1] ; ++k)
    		{
				val_type_ret val(f.eval(ret_ti,Ad_x[k]));
				if (val == Z_ret)
				{
					continue;
				};
				d_r[nz] = Ad_r[k];
				d_x[nz] = val;

				++nz;
    		};
		}
		d_c[Ac] = nz;

		d.memadd(-1);
		return res;
	};
};

template<	class ret_type, 
			class in_type
		>
struct eval_functor_2_impl<ret_type,in_type,struct_sparse,struct_banded> 
{
	template<class Func>
	static ret_type eval(gd::type_info ret_ti,const in_type& A, const Func& f)
	{
		typedef typename in_type::value_type value_type;
		typedef typename ret_type::value_type val_type_ret;		

		if (A.rows() == 0 || A.cols() == 0)
		{
			return ret_type(ret_ti,A.rows(),A.cols());
		};

        value_type Z_in = gd::default_value<value_type>(gd::get_ti(A));
        val_type_ret Z_ret = gd::default_value<val_type_ret>(ret_ti);

		val_type_ret res_0(f.eval(ret_ti,Z_in));
		if (res_0 == Z_ret)
		{
			typedef Matrix<val_type_ret,struct_banded> band_matrix;
			band_matrix tmp = eval_functor_2_impl<band_matrix,in_type,struct_banded,struct_banded>
                                            ::eval(ret_ti,A,f);
			return sparse(tmp);
		}
		else
		{
			typedef Matrix<val_type_ret,struct_dense> general_matrix;
			general_matrix tmp = eval_functor_2_impl<general_matrix,in_type,struct_dense,struct_banded>
                                            ::eval(ret_ti,A,f);
			return sparse(tmp);
		};
	};
};

template<	class ret_type, 
			class in_type
		>
struct eval_functor_2_impl<ret_type,in_type,struct_banded,struct_dense> 
{};

template<	class ret_type, 
			class in_type
		>
struct eval_functor_2_impl<ret_type,in_type,struct_banded,struct_sparse> 
{};

template<	class ret_type, 
			class in_type
		>
struct eval_functor_2_impl<ret_type,in_type,struct_banded,struct_banded> 
{
	template<class Func>
	static ret_type eval(gd::type_info ret_ti,const in_type& A, const Func& f)
	{
		typedef typename in_type::value_type value_type;
		typedef typename ret_type::value_type val_type_ret;		

		if (A.rows() == 0 || A.cols() == 0)
		{
			return ret_type(ret_ti,A.rows(),A.cols(),0,0);
		};

        value_type Z_in = gd::default_value<value_type>(gd::get_ti(A));
        val_type_ret Z_ret = gd::default_value<val_type_ret>(ret_ti);

		val_type_ret res_0(f.eval(ret_ti,Z_in));
		if (res_0 != Z_ret)
		{
			typedef Matrix<val_type_ret,struct_dense> FullMatrixRet;
			FullMatrixRet out = eval_functor_2_impl<FullMatrixRet,in_type,struct_dense,struct_banded>
                                        ::eval(ret_ti,A,f);
			return converter<ret_type,FullMatrixRet>::eval(ret_ti,out);
		};

		ret_type res(ret_ti,A.rows(),A.cols(),A.ldiags(),A.udiags());
		Integer c = A.cols();

        const value_type* ptr_A = A.rep_ptr();
        val_type_ret* ptr_ret = res.rep_ptr();

		for (Integer j = 0; j < c; ++j) 
		{
			Integer row_f = A.first_row(j);
			Integer row_l = A.last_row(j);
			Integer row_p = A.first_elem_pos(j);

			for (Integer i = row_f; i <= row_l; ++i, ++row_p)
			{
				ptr_ret[row_p] = val_type_ret(f.eval(ret_ti,ptr_A[row_p]));
			};	

            ptr_A += A.ld();
            ptr_ret += res.ld();
		};

		return res;
	};
};

};};};

#pragma warning( pop )