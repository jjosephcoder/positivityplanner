/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/enablers.h"
#include "mmlib/base/return_types.h"
#include "mmlib/details/mpl.h"

namespace mmlib { namespace raw
{


template<class val_type>
Matrix<val_type,struct_dense> full(const Matrix<val_type,struct_sparse>& A);

template<class val_type>
Matrix<val_type,struct_sparse> sparse(const Matrix<val_type,struct_dense>& A);

template<class val_type>
Matrix<val_type,struct_sparse> sparse(const Matrix<val_type,struct_banded>& A);

template<class val_type>
Matrix<val_type,struct_banded> band(const Matrix<val_type,struct_dense>& A);

template<class val_type>
Matrix<val_type,struct_banded> band(const Matrix<val_type,struct_sparse>& A);

template<class M>
inline M copy(const M& A)
{
	M tmp = A.copy();
	return tmp;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::vec>>::type
vec(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::manip_reshape_helper<MP>::eval_vec(promote_type::eval(m));
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::vec>>::type
vec(const M& m)
{
	return m;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::reshape>>::type
reshape(const M& A, Integer m, Integer n)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::manip_reshape_helper<MP>::eval_reshape(promote_type::eval(A), m, n);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::reshape>>::type
reshape(const M& A, Integer m, Integer n)
{
	error::check_reshape(1, 1, m, n);
	return A;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::trans>>::type
trans(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::manip_trans_helper<MP>::eval_trans(promote_type::eval(m));
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::trans>>::type
trans(const M& m)
{
	return m;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::ctrans>>::type
ctrans(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::manip_trans_helper<MP>::eval_ctrans(promote_type::eval(m));
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::ctrans>>::type
ctrans(const M& m)
{
	return conj(m);
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::flipud>>::type
flipud(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::manip_reshape_helper<MP>::eval_flipud(promote_type::eval(m));
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::flipud>>::type
flipud(const M& m)
{
	return m;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::fliplr>>::type
fliplr(const M& m)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::manip_reshape_helper<MP>::eval_fliplr(promote_type::eval(m));
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::fliplr>>::type
fliplr(const M& m)
{
	return m;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::tril>>::type
tril(const M& A, Integer d = 0)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::manip_tr_helper<MP>::eval_tril(promote_type::eval(A), d);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::tril>>::type
tril(const M& m, Integer d = 0)
{
	if (d < 0)
	{
        return gd::default_value<M>(gd::get_ti(m));
	};
	return m;
};

template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::triu>>::type
triu(const M& A, Integer d = 0)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::manip_tr_helper<MP>::eval_triu(promote_type::eval(A), d);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::triu>>::type
triu(const M& m, Integer d = 0)
{
	if (d > 0)
	{
		return gd::default_value<M>(gd::get_ti(m));
	};
	return m;
};
template<class M>
inline typename mmlib::details::enable_if_matrix<M,return_type<M,raw_functions::repmat>>::type
repmat(const M& A, Integer m, Integer n)
{
	typedef promote_type<M> promote_type;
	typedef promote_type::type MP;
	return details::manip_reshape_helper<MP>::eval_repmat(promote_type::eval(A), m, n);
};
template<class M>
inline typename mmlib::details::enable_if_scalar<M,return_type_scalar<M,raw_functions::repmat>>::type
repmat(const M& A, Integer m, Integer n)
{
	typedef mmlib::details::promote_scalar<M>::type MP;
	typedef Matrix<MP,struct_dense> FullMatrix;
    return FullMatrix(gd::get_ti(A),A,m,n);
};

template<class V>
Integer get_ld(const Matrix<V,struct_dense>& A, Integer min, bool use_flag = true);

template<class V>
Integer get_ld(const Matrix<V,struct_sparse>& A, Integer min, bool use_flag = true);

template<class V>
Integer get_ld(const Matrix<V,struct_banded>& A, Integer min, bool use_flag = true);

template<class V>
Integer get_ud(const Matrix<V,struct_dense>& A, Integer min, bool use_flag = true);

template<class V>
Integer get_ud(const Matrix<V,struct_sparse>& A, Integer min, bool use_flag = true);

template<class V>
Integer get_ud(const Matrix<V,struct_banded>& A, Integer min, bool use_flag = true);

template<class V>
bool is_sym(const Matrix<V,struct_dense>& A, bool use_flag = true);

template<class V>
bool is_sym(const Matrix<V,struct_sparse>& A, bool use_flag = true);

template<class V>
bool is_sym(const Matrix<V,struct_banded>& A, bool use_flag = true);

template<class V>
bool is_her(const Matrix<V,struct_dense>& A, bool use_flag = true);

template<class V>
bool is_her(const Matrix<V,struct_sparse>& A, bool use_flag = true);

template<class V>
bool is_her(const Matrix<V,struct_banded>& A, bool use_flag = true);
};};