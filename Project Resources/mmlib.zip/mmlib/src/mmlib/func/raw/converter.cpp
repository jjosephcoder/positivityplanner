/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/func/raw/converter.h"
#include "mmlib/container/raw/type_decl.h"
#include "mmlib/details/isa.h"
#include "mmlib/details/mpl.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/utils/utils.h"
#include "mmlib/mp/instantiate.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/base/integer.h"

#pragma warning(push)
#pragma warning(disable:4127)   //conditional expression is constant

namespace mmlib { namespace raw 
{

namespace details
{
    struct warn_state 
    {
        bool allow_warn_real_compl;
        bool allow_warn_int_real;

        warn_state()
        {
            allow_warn_real_compl = true;
            allow_warn_int_real = true;
        };
        bool any_warnings() const
        {
            return allow_warn_real_compl == false || allow_warn_int_real == false;
        };
    };

    template<class ret, class in, bool isw>
    struct conver_scal_warn_impl
    {
        static ret eval(mmlib::details::type_info ti, warn_state& , const in& val)
        {
            return converter<ret,in>::eval(ti,val);
        };
    };
    template<class ret, class in>
    struct conver_scal_warn_impl<ret,in,true>
    {};
    template<>
    struct conver_scal_warn_impl<Integer,Real,true>
    {
        static Integer eval(mmlib::details::type_info , warn_state& w, const Real& val)
        {
            if (w.allow_warn_int_real && val - (Integer)val != 0)
            {
                w.allow_warn_int_real = false;
                error::get_global_messanger().warning_precision_lost_real_to_int(val);                    
            };
            return (Integer)val;
        };
    };
    template<>
    struct conver_scal_warn_impl<Real,Complex,true>
    {
        static Real eval(mmlib::details::type_info , warn_state& w, const Complex& val)
        {
            if (w.allow_warn_real_compl && imag(val) != 0)
            {
                w.allow_warn_real_compl = false;
                error::get_global_messanger().warning_precision_lost_compl_to_real(val);            
            };
            return real(val);
        };
    };
    template<>
    struct conver_scal_warn_impl<Integer,Complex,true>
    {
        static Integer eval(mmlib::details::type_info ti, warn_state& w, const Complex& val)
        {
            Real tmp = conver_scal_warn_impl<Real,Complex,true>::eval(ti, w, val);
            return conver_scal_warn_impl<Integer,Real,true>::eval(ti, w, tmp);
        };
    };
    template<>
    struct conver_scal_warn_impl<Integer,Object,true>
    {
        static Integer eval(mmlib::details::type_info , warn_state& , const Object& val)
        {            
            return val.to_integer();
        };
    };
    template<>
    struct conver_scal_warn_impl<Real,Object,true>
    {
        static Real eval(mmlib::details::type_info , warn_state& , const Object& val)
        {            
            return val.to_real();
        };
    };
    template<>
    struct conver_scal_warn_impl<Complex,Object,true>
    {
        static Complex eval(mmlib::details::type_info , warn_state& , const Object& val)
        {            
            return val.to_complex();
        };
    };

    template<class ret>
    struct conver_scal_warn
    {
	    template<class T>
	    static ret eval(mmlib::details::type_info ti, warn_state& warn, const T& val)
        {
            static const bool isw 
                = (mmlib::details::value_to_code<ret>::value < mmlib::details::value_to_code<T>::value);
            return conver_scal_warn_impl<ret,T,isw>::eval(ti,warn,val);
        };
    };

	template<class ret, class T>
	struct converter_scalars_impl
	{
		static ret eval(mmlib::details::type_info ti, const T& val)
		{
			return ret(val);
		};
	};
	template<class T>
	struct converter_scalars_impl<Object,T>
	{
		static Object eval(mmlib::details::type_info ti, const T& val)
		{
			return Object(ti,val);
		}; 
	};
    template<> struct converter_scalars_impl<Integer,Object>
    {
        static Integer eval(mmlib::details::type_info ,  const Object& val)  
        { 
            return val.to_integer(); 
        };
    };
    template<> struct converter_scalars_impl<Real,Object>
    {
        static Real eval(mmlib::details::type_info ,  const Object& val)  
        { 
            return val.to_real(); 
        };
    };
    template<> struct converter_scalars_impl<Complex,Object>
    {
        static Complex eval(mmlib::details::type_info , const Object& val)  
        { 
            return val.to_complex(); 
        };
    };
    template<> struct converter_scalars_impl<Object,Object>
    {
        static Object eval(mmlib::details::type_info ti, const Object& val)  
        { 
            return val.convert(ti); 
        };
    };


	template<class ret, class T>
	struct converter_sparse
	{
		static ret eval(mmlib::details::type_info ti, const T& val)
		{
			typedef typename mmlib::details::select_if
				<
					!mmlib::details::is_sparse<ret>::value,
					typename mmlib::details::select_if
						<
							mmlib::details::is_equal<ret::struct_type,struct_banded>::value,
							converter_sparse_band<ret,T>,
							converter_sparse_full<ret,T>
						>:: type,
					converter_sparse_sparse<ret,T>
				>
				:: type converter_type;

			return converter_type::eval(ti,val);
		};
	};
	template<class ret, class T>
	struct converter_sparse_full
	{
		static ret eval(mmlib::details::type_info ti, const T& mat)
		{
			typedef ret::value_type value_type;
			typedef T::value_type in_type;

			Integer j, k, c = mat.cols();
            value_type Z = mmlib::details::default_value<value_type>(ti);
			Matrix<value_type,struct_dense> tmp(ti,Z, mat.rows(), c);
			const spdat<in_type>& rep = mat.rep();
        
            warn_state warn;

			if (mat.nnz())
            {
                const Integer* rep_c = rep.ptr_c();
                const Integer* rep_r = rep.ptr_r();
                const in_type* rep_x = rep.ptr_x();
                value_type* ptr_tmp  = tmp.ptr();

				for (j = 0; j < c; ++j)
				{
					for (k = rep_c[j]; k < rep_c[j+1]; ++k)
                    {
                        value_type val = conver_scal_warn<value_type>::eval(ti,warn,rep_x[k]);
						ptr_tmp[rep_r[k]] = val;
                    };
                    ptr_tmp += tmp.ld();
				};
                tmp.set_struct(mat.get_struct());
                if (warn.any_warnings())
                {
                    tmp.get_struct().set_warnings();
                };
            }
            else
            {
                tmp.get_struct().set_zero_matrix();
            };

			return tmp;
		}
	};

	template<class ret, class T>
	struct converter_sparse_band
	{
		static ret eval(mmlib::details::type_info ti, const T& mat)
		{
			Integer r = mat.rows(), c = mat.cols();
            typedef typename ret::value_type val_type_ret;
            val_type_ret Z = mmlib::details::default_value<val_type_ret>(ti);
			if (mat.nnz() == 0)
			{
				ret out(ti,r,c,0,0);
                val_type_ret* ptr_out = out.rep_ptr();

				Integer s = std::min(r,c);
				for (Integer i = 0; i < s; ++i)
				{
                    ptr_out[i] = Z;
				};
                out.get_struct().set_zero_matrix();
				return out;
			};

			typedef T::value_type val_type;

            Integer ld = raw::get_ld(mat,-1);
            Integer ud = raw::get_ud(mat,-1);

			ret res(ti,r,c,ld,ud);

            val_type_ret* ptr_res = res.rep_ptr();

            Integer res_size = res.size();
			for (Integer i = 0; i < res_size; ++i)
			{
				ptr_res[i] = Z;
			};			

            warn_state warn;

			const spdat<val_type>& Ad = mat.rep();
			const Integer * Ad_c = Ad.ptr_c();
			const Integer * Ad_r = Ad.ptr_r();
			const val_type* Ad_x = Ad.ptr_x();

			for (Integer j = 0; j < c; ++j)
			{
				Integer first_row  = res.first_row(j);
				Integer first_pos  = res.first_elem_pos(j) - first_row;

				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
                    if (mmlib::details::is_zero(Ad_x[k]))
					{
						continue;
					};
                    ptr_res[first_pos+Ad_r[k]] = conver_scal_warn<val_type_ret>::eval(ti,warn,Ad_x[k]);
				};

                ptr_res += res.ld();
			};
            res.set_struct(mat.get_struct());
            if (warn.any_warnings())
            {
                res.get_struct().set_warnings();
            };
			return res;
		};
	};
	template<class ret, class T>
	struct converter_sparse_sparse
	{
		static ret eval(mmlib::details::type_info ti, const T& m)
		{
			static const bool ise = mmlib::details::is_equal<ret::value_type,T::value_type>::value;            
			return eval_impl<ise>(ti,m);
		};
		template<bool ise>
		static ret eval_impl(mmlib::details::type_info ti, const T& m)
		{
			Integer r = m.rows(), c = m.cols(), n = m.nnz();
            typedef typename ret::value_type val_type_ret;
            typedef typename T::value_type val_type_in;

			ret res(ti, r,c,n);
			spdat<val_type_ret>& d = res.rep();
			const spdat<val_type_in>& Ad = m.rep();

            warn_state warn;

			if (n == 0)
			{
				return res;
			};

            Integer* d_c            = d.ptr_c();
            Integer* d_r            = d.ptr_r();
            val_type_ret* d_x       = d.ptr_x();

            const Integer* Ad_c    = Ad.ptr_c();
            const Integer* Ad_r    = Ad.ptr_r() + Ad.offset();
            const val_type_in* Ad_x= Ad.ptr_x() + Ad.offset();


			for (Integer i = 1; i <= c; ++i)
			{
				d_c[i] = Ad_c[i] - Ad.offset();
			};
			for (Integer i = 0; i < n; ++i)
			{
				d_r[i] = Ad_r[i];
                d_x[i] = conver_scal_warn<val_type_ret>::eval(ti,warn,Ad_x[i]);
			};

            res.set_struct(m.get_struct());
            if (warn.any_warnings())
            {
                res.get_struct().set_warnings();
            };
			return res;
		}
		template<>
		static ret eval_impl<true>(mmlib::details::type_info ti, const T& m)
		{
            static const bool iso = mmlib::details::is_equal<ret::value_type,Object>::value;
            if (iso)
            {
                if (ti == m.get_ti())
                {
			        return m;
                }
                else
                {
                    return eval_impl<false>(ti,m);
                };
            }
            else
            {
			    return m;
            };
		};
	};

	template<class ret, class T>
	struct converter_dense_dense
	{
		static ret eval(mmlib::details::type_info ti, const T& m)
		{
			static const bool ise = mmlib::details::is_equal<ret::value_type,T::value_type>::value;
			return eval_impl<ise>(ti,m);
		};
		template<bool ise>
		static ret eval_impl(mmlib::details::type_info ti, const T& mat)
		{
			typedef ret::value_type ret_type;
			typedef T::value_type in_type;

			Matrix<ret_type,struct_dense> tmp(ti,mat.rows(),mat.cols());

            warn_state warn;

            Integer r = mat.rows();
            Integer c = mat.cols();

            ret_type* ptr_tmp = tmp.ptr();
            const in_type* ptr_mat = mat.ptr();

            for(Integer j = 0; j < c; ++j)
            {
                for(Integer i = 0; i < r; ++i)
                {
                    ptr_tmp[i] = conver_scal_warn<ret_type>::eval(ti,warn, ptr_mat[i]);
                };
                ptr_tmp += tmp.ld();
                ptr_mat += mat.ld();
            };

            tmp.set_struct(mat.get_struct());
            if (warn.any_warnings())
            {
                tmp.get_struct().set_warnings();
            };

			return tmp;
		};
		template<>
		static ret eval_impl<true>(mmlib::details::type_info ti, const T& m)
		{
            static const bool iso = mmlib::details::is_equal<ret::value_type,Object>::value;
            if (iso)
            {
                if (ti == m.get_ti())
                {
			        return m;
                }
                else
                {
                    return eval_impl<false>(ti,m);
                };
            }
            else
            {
			    return m;
            };
		};
	};

	template<class ret, class T>
	struct converter_dense_band
	{
		static ret eval(mmlib::details::type_info ti, const T& mat)
		{
			Integer r = mat.rows(), c = mat.cols();
            typedef typename ret::value_type val_type;

			if (r == 0 || c == 0)
			{
				return ret(ti,r,c,0,0);
			};

            Integer ld = raw::get_ld(mat,-1);
            Integer ud = raw::get_ud(mat,-1);

			ret res(ti,r,c,ld,ud);

            typedef typename ret::value_type val_type_ret;
            const typename T::value_type* ptr = mat.ptr();

            val_type_ret* ptr_ret = res.rep_ptr();

            warn_state warn;

			for (Integer j = 0; j < c; ++j)
			{
				Integer first_row  = res.first_row(j);
				Integer first_pos  = res.first_elem_pos(j) - first_row;
                Integer end = min(j+ld,r-1);

                for (Integer k = std::max(j-ud,0L); k <= end; ++k)
				{
                    ptr_ret[first_pos+k] = conver_scal_warn<val_type_ret>::eval(ti,warn,ptr[k]);
				};
                ptr += mat.ld();
                ptr_ret += res.ld();
			};
            res.set_struct(mat.get_struct());
            if (warn.any_warnings())
            {
                res.get_struct().set_warnings();
            };
			return res;
		};
	};

	template<class ret, class T>
	struct converter_dense_sparse
	{
		static ret eval(mmlib::details::type_info ti, const T& m)
		{
            Integer nnz = 0;
            Integer r = m.rows(), c = m.cols();

            if (m.get_struct().is_diag())
            {
                nnz = std::min(r,c);
            }
            else
            {
                const T::value_type* ptr_m = m.ptr();

			    for (Integer j = 0; j < c; ++j)
                {
				    for (Integer i = 0; i < r; ++i)
                    {
                        if (!mmlib::details::is_zero(ptr_m[i])) 
                        {
                            ++nnz;
                        };
                    };

                    ptr_m += m.ld();
                };
            };

			ret res(ti,r, c, nnz);
			if (nnz == 0)
            {
                return res;
            };

			typedef ret::value_type ret_val;
            warn_state warn;

			spdat<ret_val>& dat = res.rep();

            if (m.get_struct().is_diag())
            {
                Integer rc = std::min(r,c);

                typedef typename T::value_type V;
                const V* ptr = m.ptr();

                Integer nz = 0;

                Integer* dat_c  = dat.ptr_c();
                Integer* dat_r  = dat.ptr_r();
                ret_val* dat_x  = dat.ptr_x();

			    for (Integer j = 0; j < rc; ++j)
			    {
				    dat_c[j] = nz;
				    if (!mmlib::details::is_zero(ptr[0]))
				    {
                        dat_x[nz] = conver_scal_warn<ret_val>::eval(ti,warn,ptr[0]);
					    dat_r[nz] = j;
                        ++nz;
				    };
                    ptr += m.ld() + 1;
			    };
			    for (Integer j = rc; j <= c; ++j)
			    {
				    dat_c[j] = nz;
			    };
            }
            else
            {
                Integer* dat_c = dat.ptr_c();
                Integer* dat_r = dat.ptr_r();
                ret_val* dat_x = dat.ptr_x();

                typedef typename T::value_type V;
                const V* ptr_m = m.ptr();

                Integer k = 0;

			    for (Integer j = 0; j < c; ++j)
			    {
				    dat_c[j] = k;

				    for (Integer i = 0; i < r; ++i)
                    {
                        V val = ptr_m[i];
					    if (!mmlib::details::is_zero(val))
					    {
                            dat_x[k] = conver_scal_warn<ret_val>::eval(ti,warn,val);
						    dat_r[k] = i;
						    ++k;
					    };
                    };

                    ptr_m += m.ld();
			    };

                dat_c[c] = k;
            };
            res.set_struct(m.get_struct());
            if (warn.any_warnings())
            {
                res.get_struct().set_warnings();
            };
			return res;
		};
	};

	template<class ret, class T>
	struct converter_dense
	{
		typedef typename mmlib::details::select_if
		<
			mmlib::details::is_equal<typename ret::struct_type,struct_dense>::value,
			converter_dense_dense<ret,T>,
			typename mmlib::details::select_if
				<
					mmlib::details::is_equal<typename ret::struct_type,struct_banded>::value,
					converter_dense_band<ret,T>,
					converter_dense_sparse<ret,T>
				>::type
		>::type converter_type;

		static ret eval(mmlib::details::type_info ti, const T& mat)
		{
			return converter_type::eval(ti,mat);
		};
	};

	template<class ret_type,class T>
	struct converter_band_band
	{
		static ret_type eval(mmlib::details::type_info ti, const T& m)
		{
			static const bool ise = mmlib::details::is_equal<ret_type::value_type,T::value_type>::value;
			return eval_impl<ise>(ti,m);
		};
		template<bool ise>
		static ret_type eval_impl(mmlib::details::type_info ti, const T& m)
		{
			Integer r = m.rows(), c = m.cols();

			ret_type out(ti,r, c, m.ldiags(), m.udiags());

            typedef typename ret_type::value_type val_type;
            typedef typename T::value_type val_type_in;

            warn_state warn;

            const val_type_in* ptr_m = m.rep_ptr();
            val_type* ptr_out = out.rep_ptr();

			for (Integer j = 0; j < c; ++j)
            {
                Integer fr  = m.first_row(j);
                Integer lr  = m.last_row(j);
                Integer pos = m.first_elem_pos(j);
                for (Integer i = fr; i <= lr; ++i, ++pos)
                {
                    ptr_out[pos] = conver_scal_warn<val_type>::eval(ti, warn, ptr_m[pos]);
                };
                ptr_out += out.ld();
                ptr_m   += m.ld();
            };

            out.set_struct(m.get_struct());
            if (warn.any_warnings())
            {
                out.get_struct().set_warnings();
            };
			return out;
		};
		template<>
		static ret_type eval_impl<true>(mmlib::details::type_info ti, const T& m)
		{
            static const bool iso = mmlib::details::is_equal<ret_type::value_type,Object>::value;
            if (iso)
            {
                if (ti == m.get_ti())
                {
			        return m;
                }
                else
                {
                    return eval_impl<false>(ti,m);
                };
            }
            else
            {
			    return m;
            };
		};
	};

	template<class ret_type,class T>
	struct converter_band_dense
	{
		static ret_type eval(mmlib::details::type_info ti, const T& m)
		{
			typedef typename ret_type::value_type value_type_ret;
            typedef typename T::value_type value_type_in;

			Integer r = m.rows(), c = m.cols();

            ret_type out(ti,mmlib::details::default_value<value_type_ret>(ti),r, c);

            warn_state warn;

			if ( r == 0 || c == 0)
            {
                return out;
            };

            const value_type_in* ptr_m = m.rep_ptr();
            value_type_ret* ptr_out = out.ptr();

            for (Integer j = 0; j < c; ++j)
            {
                Integer fr = m.first_row(j);
                Integer lr = m.last_row(j);
                Integer pos = m.first_elem_pos(j);

                for (Integer k = fr; k <= lr; ++k, ++ pos)
                {
                    ptr_out[k] = conver_scal_warn<value_type_ret>::eval(ti,warn,ptr_m[pos]);
                };
                ptr_out += out.ld();
                ptr_m += m.ld();
            };

            out.set_struct(m.get_struct());
            if (warn.any_warnings())
            {
                out.get_struct().set_warnings();
            };
			return out;
		};
	};

	template<class ret_type,class T>
	struct converter_band_sparse
	{
		static ret_type eval(mmlib::details::type_info ti, const T& bm)
		{
			Integer j, k, r = bm.rows(), c = bm.cols(), kl = bm.ldiags(),
					ku = bm.udiags(), klup1 = ku + kl + 1, i, ist, iend, bi;

			typedef ret_type::value_type value_type_ret;
            typedef T::value_type value_type_in;

            warn_state warn;

			Integer nnz = imult(klup1,((r < c) ? r : c));
			ret_type res(ti,r, c, nnz);

			if (r == 0 || c == 0 || nnz == 0)
			{
				return res;
			};

			spdat<value_type_ret>& dat = res.rep();

            Integer* d_c    = dat.ptr_c();
            Integer* d_r    = dat.ptr_r();
            value_type_ret* d_x    = dat.ptr_x();

            const value_type_in* ptr_m = bm.rep_ptr();

			for (j = 0, k = 0; j < c; ++j)
			{
				d_c[j]  = k;

				ist     = (0 > j - ku) ? 0 : j - ku;
				bi      = (0 > ku - j) ? 0 : ku - j;
				iend    = (r - 1 < j + kl) ? r - 1 : j + kl;

				for (i = ist; i <= iend; ++i, ++bi)
				{
                    value_type_ret tmp = conver_scal_warn<value_type_ret> ::eval(ti,warn,ptr_m[bi]);

                    if (!mmlib::details::is_zero(tmp))
					{
						d_r[k] = i;
						d_x[k] = tmp;
						++k;
					};
				}

                ptr_m += bm.ld();
			};
            d_c[c] = k;

            res.set_struct(bm.get_struct());
            if (warn.any_warnings())
            {
                res.get_struct().set_warnings();
            };
			return res;
		};
	};	

	template<class ret, class T>
	struct converter_unknown
	{};

	template<class ret, class T>
	struct converter_band
	{
		typedef typename mmlib::details::select_if
		<
			mmlib::details::is_equal<typename ret::struct_type,struct_dense>::value,
			details::converter_band_dense<ret,T>,
			typename mmlib::details::select_if
			<
				mmlib::details::is_equal<typename ret::struct_type,struct_sparse>::value,
				details::converter_band_sparse<ret,T>,
				details::converter_band_band<ret,T>
			>::type
		>::type type;
	};

	template<class ret, class T>
	struct converter_selector_4
	{
		typedef typename mmlib::details::lazy_select_if
		<
			mmlib::details::is_equal<typename T::struct_type,struct_banded>::value,
			details::converter_band<ret,T>,
			details::converter_unknown<ret,T>
		>::type type;
	};

	template<class ret, class T>
	struct converter_selector_3
	{
		typedef typename mmlib::details::lazy_select_if
		<
			mmlib::details::is_equal<typename T::struct_type,struct_dense>::value,
			mmlib::details::lazy_type<details::converter_dense<ret,T>>,
			details::converter_selector_4<ret,T>
		>::type type;
	};

	template<class ret, class T>
	struct converter_selector_2
	{
		typedef typename mmlib::details::lazy_select_if
		<
			mmlib::details::is_sparse<T>::value,
			mmlib::details::lazy_type<details::converter_sparse<ret,T>>,
			details::converter_selector_3<ret,T>
		>::type type;
	};

	template<class ret, class T>
	struct converter_selector
	{
		typedef typename mmlib::details::lazy_select_if
		<
			mmlib::details::is_scalar<T>::value,
			mmlib::details::lazy_type<details::converter_scalars_impl<ret,T>>,
			details::converter_selector_2<ret,T>
		>::type type;
	};

    template<class ret, class T>
    ret 
    converter_impl<ret,T>::eval(mmlib::details::type_info ti, const T& val)
    {
	    typedef typename details::converter_selector<ret,T>::type converter_type;
	    return converter_type::eval(ti, val);
    };

MACRO_INSTANTIATE_GG_2_F(mmlib::raw::details::converter_impl)
MACRO_INSTANTIATE_GST_2_F(mmlib::raw::details::converter_impl)
MACRO_INSTANTIATE_STG_2_F(mmlib::raw::details::converter_impl)
MACRO_INSTANTIATE_STST_2_F(mmlib::raw::details::converter_impl)

template struct converter_impl<Integer,Object>;
template struct converter_impl<Real,Object>;
template struct converter_impl<Complex,Object>;

};

};};

#pragma warning(pop)