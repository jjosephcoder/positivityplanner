/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/func/raw/disp.h"
#include <iomanip>
#include "mmlib/details/scalfunc_helpers.h"
#include "mmlib/func/raw/io.h"
#include "mmlib/func/raw/converter.h"
#include "mmlib/base/integer.h"
#include "mmlib/matrix_traits.h"
#include "mmlib/utils/utils.h"

namespace mmlib { namespace raw
{
 
static output_stream os(std::cout);
output_stream& get_console_output()
{    
    return os;
};


namespace details
{
    template<class V>
    struct disp_helper<V,struct_banded>
    {
        typedef raw::Matrix<V,struct_banded> matrix_type;
        static void eval(disp_stream& os, const matrix_type& mat)
        {
            typedef raw::Matrix<V,struct_dense> DM;
            DM mat_d = converter<DM,matrix_type>::eval(mat.get_ti(),mat);
            return disp_helper<V,struct_dense>::eval(os,mat_d);
        };
    };

    template<class V>
    struct disp_helper<V,struct_dense>
    {
        typedef raw::Matrix<V,struct_dense> matrix_type;
        static void eval(disp_stream& os, const matrix_type& m)
        {
            Integer r = m.rows(), c = m.cols(), s = m.size();	        

	        os.start_display();	
            os.displaying_dense_matrix(m.rows(),m.cols(),matrix_traits::value_code<V>::value, 
                                m.get_struct().get());

            if (s == 0)
            {
		        os.display_empty_matrix(r,c);
		        os.end_display();
                return;
            }

            Integer mc = std::min(c,os.max_matrix_cols());
            Integer mr = std::min(r,os.max_matrix_rows());

            const V* ptr_m  = m.ptr();
            const V* ptr_r  = m.ptr();

            Integer csw     = os.get_col_separator_width();
            Integer rhw     = os.get_row_headers_width();
            Integer fcw     = os.get_first_col_separator_width();
            Integer pos0    = rhw + fcw + os.new_line_width();
            Integer pos     = pos0;

            Integer lc      = 1;
            Integer cc      = 1;
            bool b_new      = false;
            for (Integer j = 0; j < mc; ++j, ++cc)
            {
                Integer min_width = 0;
                for (Integer i = 0; i < mr; ++i)
                {
                    Integer w   = os.get_min_width(ptr_m[i]);
                    min_width   = std::max(min_width,w);
                };
                ptr_m += m.ld();
                os.set_column_min_width(j,min_width);

                pos += csw;
                pos += os.get_column_width(j);

                if (pos > os.get_ternimal_width())
                {
                    cc = std::max(cc-1,lc);
                    --j;
                    ptr_m -= m.ld();

                    if (b_new == true)
                    {
                        os.get_stream() << "\n";                        
                    }
                    else
                    {
                        b_new = true;
                    };

                    //column header
                    os.new_line(0);
                    Integer chw = rhw + fcw;
                    os.disp_col_header_row(rhw);
                    os.disp_col_header_1sep(fcw);
                    for (Integer i = lc; i < cc; ++i)
                    {
                        Integer cw = os.get_column_width(i-1);
                        os.disp_col_header_col(i-1,cw);
                        os.disp_col_header_col_separator(i-1,csw);

                        chw += csw + cw;
                    };
                    Integer cw = os.get_column_width(cc-1);
                    os.disp_col_header_col(cc-1,cw);
                    chw += cw;
                    os.end_line(0);

                    if (os.do_disp_first_row_separator())
                    {
                        os.new_line(0);
                        os.disp_first_row_separator(chw);
                        os.end_line(0);
                    };

                    //print matrix
                    for (Integer i = 0; i < mr; ++i)
                    {
			            os.new_line(i+1);
                        os.disp_row_header(i,rhw);
                        os.disp_first_col_separator(fcw);

                        for (Integer k = lc; k <= cc; ++k) 
			            {
                            Integer w = os.get_column_width(k-1);
                            os.disp_elem(w,ptr_r[i+(k-1)*m.ld()]);
                            if (k < cc)
                            {
                                os.disp_col_separator(csw,k-1);
                            };
			            };
                        os.end_line(i+1);
                    }
                    if (mr < r)
                    {
			            os.new_line(mr+1);
                        std::string cd_r(std::min(3L,rhw),'.');
                        os.disp_elem(rhw,cd_r);
                        os.disp_first_col_separator(fcw);

                        for (Integer k = lc; k <= cc; ++k) 
			            {
                            Integer w = os.get_column_width(k-1);
                            std::string cd_v(std::min(3L,w),'.');
                            os.disp_elem(w,cd_v);
                            if (k < cc)
                            {
                                os.disp_col_separator(csw,k-1);
                            };
			            };
                        os.end_line(mr+1);
                    };

                    lc      = cc + 1;
                    pos     = pos0;
                };
            };

            cc = mc;
            if (lc <= cc)
            {
                pos += csw;
                pos += 3;

                bool need_cont  = false;
                bool add_cont   = true;
                if (cc < c)
                {             
                    need_cont   = true;
                    if (pos > os.get_ternimal_width())
                    {
                        add_cont = false;
                    };
                };

                if (b_new == true)
                {
                    os.get_stream() << "\n";
                }

                //column header
                os.new_line(0);
                Integer chw = rhw + fcw;
                os.disp_col_header_row(rhw);
                os.disp_col_header_1sep(fcw);
                for (Integer i = lc; i < cc; ++i)
                {
                    Integer cw = os.get_column_width(i-1);
                    os.disp_col_header_col(i-1,cw);
                    os.disp_col_header_col_separator(i-1,csw);

                    chw += csw + cw;
                };
                if (need_cont == true && add_cont == false)
                {
                    os.disp_elem(3,"...");
                    chw += 3;
                }
                else
                {
                    Integer cw = os.get_column_width(cc-1);
                    os.disp_col_header_col(cc-1,cw);
                    chw += cw;                    
                };
                if (need_cont == true && add_cont == true)
                {
                    os.disp_col_header_col_separator(cc,csw);
                    os.disp_elem(3,"...");
                    chw += 3 + csw;
                }
                os.end_line(0);

                if (os.do_disp_first_row_separator())
                {
                    os.new_line(0);
                    os.disp_first_row_separator(chw);
                    os.end_line(0);
                };

                //print matrix
                for (Integer i = 0; i < mr; ++i)
                {
		            os.new_line(i+1);
                    os.disp_row_header(i,rhw);
                    os.disp_first_col_separator(fcw);

                    for (Integer k = lc; k < cc; ++k) 
		            {
                        Integer w = os.get_column_width(k-1);
                        os.disp_elem(w,ptr_r[i+(k-1)*m.ld()]);
                        os.disp_col_separator(csw,k-1);
		            };

                    if (need_cont == true && add_cont == false)
                    {
                        os.disp_elem(3,"...");
                    }
                    else
                    {
                        Integer w = os.get_column_width(cc-1);
                        os.disp_elem(w,ptr_r[i+(cc-1)*m.ld()]);
                    }
                    if (need_cont == true && add_cont == true)
                    {
                        os.disp_col_separator(csw,cc-1);
                        os.disp_elem(3,"...");
                    };

                    os.end_line(i+1);
                }
                if (mr < r)
                {
		            os.new_line(mr+1);
                    std::string cd_r(std::min(3L,rhw),'.');

                    os.disp_elem(rhw,cd_r);
                    os.disp_first_col_separator(fcw);

                    for (Integer k = lc; k < cc; ++k) 
		            {
                        Integer w = os.get_column_width(k-1);
                        std::string cd_v(std::min(3L,w),'.');
                        os.disp_elem(w,cd_v);
                        os.disp_col_separator(csw,k-1);
		            };
                    if (need_cont == true && add_cont == false)
                    {
                        os.disp_elem(3,"...");
                    }
                    else
                    {
                        Integer w = os.get_column_width(cc-1);
                        std::string cd_v(std::min(3L,w),'.');
                        os.disp_elem(w,cd_v);
                    }
                    if (need_cont == true && add_cont == true)
                    {
                        os.disp_col_separator(csw,cc-1);
                        os.disp_elem(3,"...");
                    };

                    os.end_line(mr+1);
                };
            };

            os.end_display();
        };
    };

    template<class V>
    struct disp_helper<V,struct_sparse>
    {
        typedef raw::Matrix<V,struct_sparse> matrix_type;
        static void eval(disp_stream& os, const matrix_type& m)
        {
            Integer r = m.rows(), c = m.cols(), n = m.nnz();
        	
	        os.start_display();	
            enums::value_type vt =  matrix_traits::value_code<V>::value;
	        os.displaying_sparse_matrix(r,c,n,vt,m.get_struct().get());

            if (n == 0)
	        {
		        os.display_empty_matrix(r,c);
		        os.end_display();
                return;
	        };

	        const details::spdat<V>& tmp = m.rep();

            const Integer* tmp_c    = tmp.ptr_c();
            Integer off             = tmp.offset();
            const Integer* tmp_r    = tmp.ptr_r();
            const V* tmp_x          = tmp.ptr_x();            

            Integer w_r             = os.get_min_width(r);
            Integer w_c             = os.get_min_width(c);
            w_r                     = std::max(w_r,os.get_preffered_width(enums::value_integer));
            w_c                     = std::max(w_c,os.get_preffered_width(enums::value_integer));
            Integer w_sep           = os.get_sparse_separator_width();

            Integer mc              = std::min(c,os.max_matrix_cols());
            Integer mr              = std::min(r,os.max_matrix_rows());

            Integer min_width       = os.get_preffered_width(vt);
            for (Integer i = 0; i < n; ++i)
	        {
                const V* tmp_x      = tmp.ptr_x() + off;
                Integer w           = os.get_min_width(tmp_x[i]);
                min_width           = std::max(min_width,w);
            };

            Integer pos             = 0;
            Integer tc              = 0;
            for (Integer i = 0; i < c; ++i)
	        {
		        Integer col = i+1;

                Integer tr          = 0;

                if (tc > mc)
                {
                    for (Integer k = tmp_c[i]; k < tmp_c[i + 1]; ++k)
                    {
                        if (gd::is_zero(tmp_x[k]) == true)
                        {
                            continue;
                        };

                        ++pos;

		                os.new_line(pos);
		                os.sparse_row(-1,-1,w_r,w_c);
                        os.disp_sparse_separator(w_sep);
                        os.disp_elem(min_width,"...");
		                os.end_line(pos);
                        break;
                    }
                    break;
                }
                else
                {
                    for (Integer k = tmp_c[i]; k < tmp_c[i + 1]; ++k)
                    {
                        if (gd::is_zero(tmp_x[k]) == true)
                        {
                            continue;
                        };

                        ++pos;
                        Integer row = tmp_r[k] + 1;

                        if (tr > mr)
                        {
			                os.new_line(pos);
			                os.sparse_row(-1,col,w_r,w_c);
                            os.disp_sparse_separator(w_sep);
                            os.disp_elem(min_width,"...");
			                os.end_line(pos);
                            break;
                        }
                        else
                        {			            
			                os.new_line(pos);
			                os.sparse_row(row,col,w_r,w_c);
                            os.disp_sparse_separator(w_sep);
                            os.disp_elem(min_width,tmp_x[k]);
			                os.end_line(pos);
                        };

                        ++tr;
                    }
                    if (tr > 0)
                    {
                        ++tc;
                    };
                };
	        };

	        os.end_display();
        };
    };

    template disp_helper<Integer,struct_dense>;
    template disp_helper<Real,struct_dense>;
    template disp_helper<Complex,struct_dense>;
    template disp_helper<Object,struct_dense>;

    template disp_helper<Integer,struct_banded>;
    template disp_helper<Real,struct_banded>;
    template disp_helper<Complex,struct_banded>;
    template disp_helper<Object,struct_banded>;

    template disp_helper<Integer,struct_sparse>;
    template disp_helper<Real,struct_sparse>;
    template disp_helper<Complex,struct_sparse>;
    template disp_helper<Object,struct_sparse>;
};

void disp(disp_stream& os,char *str)
{	
	os.start_display();	
	
    os.displaying_string();
	os.new_line(1);
    os.disp_elem(10,str);
	os.end_line(1);

	os.end_display();
}

void disp(disp_stream& os,const std::string& str)
{	
	os.start_display();	

	os.displaying_string();
	os.new_line(1);
    os.disp_elem(10,str);
	os.end_line(1);

	os.end_display();
}


void disp(disp_stream& os,Integer i)
{	
	os.start_display();	

	os.displaying_scalar(enums::value_integer);
	os.new_line(1);
    os.disp_elem(10,i);
	os.end_line(1);

	os.end_display();
}
void disp(disp_stream& os, const Real &r)
{	
	os.start_display();	

	os.displaying_scalar(enums::value_real);
	os.new_line(1);
    os.disp_elem(10,r);
    os.end_line(1);

	os.end_display();
};


void disp(disp_stream& os, const Complex &c)
{	
	os.start_display();	

	os.displaying_scalar(enums::value_complex);
	os.new_line(1);
    os.disp_elem(20,c);
    os.end_line(1);

	os.end_display();
};
void disp(disp_stream& os, const Object &c)
{	
	os.start_display();	

	os.displaying_scalar(enums::value_object);
	os.new_line(1);
    os.disp_elem(20,c);
    os.end_line(1);
	os.end_display();
};

};};