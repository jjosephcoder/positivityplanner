/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/enablers.h"
#include "mmlib/mp/promote_type.h"
#include "mmlib/base/return_types.h"

namespace mmlib { namespace raw
{

template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::find>>::type
find(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::find_helper<promote_type::type>::eval_find(promote_type::eval(arg_1));
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::find>>::type
find(const M& arg_1, const test_function& t)
{
	typedef promote_type<M> promote_type;
	return details::find_helper<promote_type::type>::eval_find(promote_type::eval(arg_1),t);
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::find2>>::type
find2(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::find_helper<promote_type::type>::eval_find_2(promote_type::eval(arg_1));
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::find2>>::type
find2(const M& arg_1, const test_function& t)
{
	typedef promote_type<M> promote_type;
	return details::find_helper<promote_type::type>::eval_find_2(promote_type::eval(arg_1),t);
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::find3>>::type
find3(const M& arg_1)
{
	typedef promote_type<M> promote_type;
	return details::find_helper<promote_type::type>::eval_find_3(promote_type::eval(arg_1));
};
template<class M>
inline typename mmlib::details::enable_if_matrix_or_scalar<M,return_type<M,raw_functions::find3>>::type
find3(const M& arg_1, const test_function& t)
{
	typedef promote_type<M> promote_type;
	return details::find_helper<promote_type::type>::eval_find_3(promote_type::eval(arg_1), t);
};

};};