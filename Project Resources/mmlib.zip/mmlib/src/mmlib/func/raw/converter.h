/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once
#include "mmlib/scalar_types.h"
#include "mmlib/details/mpl.h"
#include "mmlib/details/isa.h"
#include "mmlib/exception_message.h"

namespace mmlib { namespace raw
{

template<class V, class S> class Matrix;

namespace details
{
    template<class T> struct check_type     {};
    template<> struct check_type<Integer>   { typedef void type; };
    template<> struct check_type<Real>      { typedef void type; };
    template<> struct check_type<Complex>   { typedef void type; };
    template<> struct check_type<Object>    { typedef void type; };

    template<class V, class S> 
    struct check_type<Matrix<V,S>>          { typedef void type; };

    template<class T> struct promote_type
    {
	    typedef typename mmlib::details::lazy_select_if
	    <
		    mmlib::details::is_scalar<T>::value,
            mmlib::details::promote_scalar<T>,
		    mmlib::details::lazy_type<T>
	    >::type type;
    };

    template<class ret,class T>
    struct converter_scalars
    {
        static ret eval(mmlib::details::type_info , const T& val)
        {
            return val;
        };
    };
    template<>
    struct converter_scalars<Integer,Real>
    {
        static Integer eval(mmlib::details::type_info , const Real& val)
        {
            if (val - (Integer)val != 0)
            {
                mmlib::error::get_global_messanger().warning_precision_lost_real_to_int(val);                    
            };
            return (Integer)val;
        };
    };
    template<>
    struct converter_scalars<Real,Complex>
    {
        static Real eval(mmlib::details::type_info , const Complex& val)
        {
            if (imag(val) != 0)
            {
                mmlib::error::get_global_messanger().warning_precision_lost_compl_to_real(val);            
            };
            return real(val);
        };
    };
    template<>
    struct converter_scalars<Integer,Complex>
    {
        static Integer eval(mmlib::details::type_info ti, const Complex& val)
        {
            Real tmp = converter_scalars<Real,Complex>::eval(ti, val);
            return converter_scalars<Integer,Real>::eval(ti, tmp);
        };
    };
    template<class ret, class T>
    struct MMLIB_EXPORT converter_impl
    {
	    static ret eval(mmlib::details::type_info ti, const T& val);
    };
    template<class ret,class T>
    struct converter_base
    {
		typedef typename mmlib::details::select_if
		<
			mmlib::details::is_scalar<T>::value && mmlib::details::is_scalar<ret>::value
            && !mmlib::details::is_equal<T,Object>::value
            && !mmlib::details::is_equal<ret,Object>::value,
			converter_scalars<ret,T>,
			converter_impl<ret,T>
		>::type type;
    };
};

template<class ret, class T>
struct converter : details::converter_base<ret,T>::type
{
    typedef typename details::check_type<ret>::type dum_type_1;
    typedef typename details::check_type<T>::type dum_type_2;
};

template<class ret>
struct converter_deduce
{
	template<class T>
	static ret eval(mmlib::details::type_info ti, const T& val)
	{
        typedef typename details::promote_type<T>::type TP;
		return converter<ret,TP>::eval(ti, val);
	};
};

};};