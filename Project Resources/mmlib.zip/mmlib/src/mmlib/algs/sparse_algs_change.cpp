/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/algs/sparse_algs.h"
#include "mmlib/algs/sparse_algs_utils.h"
#include "mmlib/utils/sort.h"
#include "mmlib/error/error_check.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/details/matrix_func_unary.inl"
#include "mmlib/manip.h"

namespace mmlib { namespace algorithm { namespace details
{

class column_iterator
{
	private:
		Integer					m_flag;
		Integer					m_size;
		Integer					m_dpos;

		raw::IntegerMatrix		m_vec;
		Integer					m_pos;	

	public:
		column_iterator(const gd::colon_info& c_inf)
            :m_vec(gd::get_raw_ti())
		{
			m_flag = c_inf.c_flag;
			if (m_flag == 0)
			{
    		    m_vec.assign(c_inf.get_ci());
    
				sort_type s_type = is_sorted(m_vec);
				m_dpos	= 1;
				if (s_type == sorted_increasing)
				{
				}
				else if (s_type == sorted_decreasing)
				{
					m_dpos = -1;
				} 
				else
				{
					raw::IntegerMatrix ci2 = m_vec.copy();
                    ci2.get_struct().reset(false);
					utils::sort_q(ci2.ptr(),ci2.size());
					m_vec.assign(ci2);
				};
				if (m_dpos > 0)
				{
					m_pos = 1;
				}
				else
				{
					m_pos = m_vec.size();
				};
			}
			else
			{
				m_dpos = c_inf.c_step;
				if (m_dpos > 0)
				{
					m_pos = c_inf.c_start;
				}
				else
				{
					m_dpos = -m_dpos;
					m_pos = c_inf.c_end;
				};
			};
			m_size = c_inf.cols();
		};

		bool valid() const
		{
			return m_size > 0;
		};

		Integer get() const
		{
			if (m_flag == 0)
			{
				return m_vec.ptr()[m_pos-1];
			}
			else
			{
				return m_pos;
			};
		};

		void next()
		{
			m_pos += m_dpos;
			--m_size;
		};
};

template<class SM>
struct change_entries_impl
{
	typedef typename SM::value_type value_type;
	static SM eval_0(const SM& A,const gd::colon_info& ci, value_type val)
	{
		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		raw::IntegerMatrix ri = ci.get_ri();        

		sort_type s_type = is_sorted(ri);
		bool incr = true;
		if (s_type == sorted_increasing)
		{
		}
		else if (s_type == sorted_decreasing)
		{
			incr = false;
		} 
		else
		{
			raw::IntegerMatrix ri2 = ri.copy();
            ri2.get_struct().reset(false);
			utils::sort_q(ri2.ptr(),ri2.size());
			ri.assign(ri2);
		};

        const Integer* ptr_ri = ri.ptr();

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + ri.size());

		Integer nz				= 0;

		Integer * d_c			= d.ptr_c();
		Integer * d_r			= d.ptr_r();
		value_type * d_x		= d.ptr_x();

		const Integer * Ad_c	= Ad.ptr_c();
		const Integer * Ad_r	= Ad.ptr_r();
		const value_type * Ad_x	= Ad.ptr_x();

		Integer step_ri;
		Integer pos, pos_row, pos_col;
		if (incr)
		{
			pos = 1;
			step_ri = 1;
		}
		else
		{
			pos = ri.size();
			step_ri = -1;
		};
		Integer or = ri.size();
		Integer old_pos = ptr_ri[pos-1];
		gd::pos2ind(old_pos,r,pos_row,pos_col);

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j] = nz;

			if (j < pos_col)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer i;
			for (i = Ad_c[j]; i < Ad_c[j+1];)
			{
				Integer p = Ad_r[i];
				if (p < pos_row)
				{
					d_r[nz] = p;
					d_x[nz] = Ad_x[i];
					++nz;
					++i;
					continue;
				};
				while (p > pos_row)
				{
					d_r[nz] = pos_row;
					d_x[nz] = val;
					++nz;

					do
					{
						pos+=step_ri;
						if (pos > or || pos < 1)
						{
							pos_row = r;
							pos_col = c;
							goto exit_row_flag;
						};
						gd::pos2ind(ptr_ri[pos-1],r,pos_row,pos_col);
						if (j != pos_col)
						{
                            old_pos = ptr_ri[pos-1];
							goto exit_row_flag;
						};
					}
                    while (ptr_ri[pos-1] == old_pos);
					old_pos = ptr_ri[pos-1];
				};
				if ( p == pos_row)
				{
					d_r[nz] = pos_row;
					d_x[nz] = val;
					++nz;
					++i;

					do
					{
						pos+=step_ri;
						if (pos > or || pos < 1)
						{
							pos_row = r;
							pos_col = c;
							goto exit_row_flag;
						};
						gd::pos2ind(ptr_ri[pos-1],r,pos_row,pos_col);
						if (j != pos_col)
						{
                            old_pos = ptr_ri[pos-1];
							goto exit_row_flag;
						};
					}
                    while ( p == pos_row);
					old_pos = ptr_ri[pos-1];
				};
			};

			while (j == pos_col)
			{
				d_r[nz] = pos_row;
				d_x[nz] = val;
				++nz;

				do
				{
					pos+=step_ri;
					if (pos > or || pos < 1)
					{
						pos_row = r;
						pos_col = c;
						goto exit_row_flag;
					};
					gd::pos2ind(ptr_ri[pos-1],r,pos_row,pos_col);
				}
                while (ptr_ri[pos-1] == old_pos);
				old_pos = ptr_ri[pos-1];
			};

			continue;

			exit_row_flag:

			for (; i < Ad_c[j+1];++i)
			{
				d_r[nz] = Ad_r[i];
				d_x[nz] = Ad_x[i];
				++nz;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM eval_1(const SM& A,const gd::colon_info& ci, value_type val)
	{
		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		Integer rs = ci.r_step,rf,rl;
		if (rs < 0)
		{
			rs = -rs;
			rf = ci.r_end;
			rl = ci.r_start;
		}
		else
		{
			rl = ci.r_end;
			rf = ci.r_start;
		};

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + ci.rows());

		Integer nz				= 0;

		Integer * d_c			= d.ptr_c();
		Integer * d_r			= d.ptr_r();
		value_type * d_x		= d.ptr_x();

		const Integer * Ad_c	= Ad.ptr_c();
		const Integer * Ad_r	= Ad.ptr_r();
		const value_type * Ad_x	= Ad.ptr_x();

		Integer pos_row, pos_col, pos = rf;
		gd::pos2ind(rf,r,pos_row,pos_col);

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j] = nz;

			if (j < pos_col)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer i;
			for (i = Ad_c[j]; i < Ad_c[j+1];)
			{
				Integer p = Ad_r[i];
				if (p < pos_row)
				{
					d_r[nz] = p;
					d_x[nz] = Ad_x[i];
					++nz;
					++i;
					continue;
				};
				while (p > pos_row)
				{
					d_r[nz] = pos_row;
					d_x[nz] = val;
					++nz;

					pos+=rs;
					if (pos > rl)
					{
						pos_row = r;
						pos_col = c;
						goto exit_row_flag;
					};
					gd::pos2ind(pos,r,pos_row,pos_col);
					if (j != pos_col)
					{
						goto exit_row_flag;
					};
				};
				if ( p == pos_row)
				{
					d_r[nz] = pos_row;
					d_x[nz] = val;
					++nz;
					++i;

					do
					{
						pos+=rs;
						if (pos > rl)
						{
							pos_row = r;
							pos_col = c;
							goto exit_row_flag;
						};
						gd::pos2ind(pos,r,pos_row,pos_col);
						if (j != pos_col)
						{
							goto exit_row_flag;
						};
					}
                    while(p == pos_row);
				};
			};

			while (j == pos_col)
			{
				d_r[nz] = pos_row;
				d_x[nz] = val;
				++nz;

				pos+= rs;
				if (pos > rl)
				{
					pos_row = r;
					pos_col = c;
					goto exit_row_flag;
				};
				gd::pos2ind(pos,r,pos_row,pos_col);
			};

			continue;

			exit_row_flag:

			for (; i < Ad_c[j+1];++i)
			{
				d_r[nz] = Ad_r[i];
				d_x[nz] = Ad_x[i];
				++nz;
			};
		};

		d_c[c] = nz;
		return raw::sparse_matrix_base<value_type>(d);
	};	
	static SM eval_02(const SM& A,const gd::colon_info& c_in, value_type val)
	{
		if (imult(c_in.rows(),c_in.cols()) < A.rows())
		{
			return eval_02w(A,c_in,val);
		}
		else
		{
			return eval_02s(A,c_in,val);
		};
	};
	static SM eval_02s(const SM& A,const gd::colon_info& c_in, value_type val)
	{
		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

        gd::type_info ti = A.get_ti();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

        Integer nzA = icast_c(Real(A.nnz()) + Real(c_in.rows())*Real(c_in.cols()));
		raw::details::spdat<value_type> d(A.get_ti(),r, c, nzA);

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();

		column_iterator c_it(c_in);

        typedef gd::vector<value_type> value_vector;

        value_vector                work_x(ti,r);
		std::vector<Integer>        work_ind(r,-1);
		raw::IntegerMatrix ri       = c_in.get_ri();
        const Integer* ptr_ri       = ri.ptr();

		Integer nz = 0;

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j] = nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			while (c_it.valid() && c_it.get() == j+1)
			{
				c_it.next();
			};

			Integer nz_old		= nz;
			bool b_added		= false;

			for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
			{
				Integer p		= Ad_r[k];
				work_ind[p]		= j;			// p is new entry in column j //
				d_r[nz++]		= p;			// add p to pattern of d(:,j) //
				work_x[p]		= Ad_x[k] ;		// x(p) = A(p,j) //
			};
            Integer ri_size = ri.size();
			for (Integer k = 0; k < ri_size; ++k)
			{
				Integer p		= ptr_ri[k]-1;
    			if (work_ind[p] < j)
    			{
    				d_r[nz++]	= p;		// add p to pattern of d(:,j) //
					work_x[p]	= val;		// x(p) = val //
					work_ind[p] = j;
					b_added		= true;
    			}
				else
				{
					work_x[p]	= val;		// p exists in d(:,j) //
				};
			};
			Integer nz_new		= nz - nz_old;
			if (b_added)
			{
				utils::sort_q(d_r+nz_old,nz_new);
			};
			for (Integer k = nz_old; k < nz ; ++k) 
			{
				d_x[k]			= work_x[d_r[k]] ;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM eval_02w(const SM& A,const gd::colon_info& c_in, value_type val)
	{
		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

        Integer nzA = icast_c(Real(A.nnz()) + Real(c_in.rows())*Real(c_in.cols()));
		raw::details::spdat<value_type> d(A.get_ti(),r, c, nzA);

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();

		column_iterator c_it(c_in);

		Integer nz					= 0;

		raw::IntegerMatrix ri		= c_in.get_ri();        
		sort_type rs_type			= is_sorted(ri);
		if (rs_type != sorted_increasing)
		{
			raw::IntegerMatrix ri2 = ri.copy();
            ri2.get_struct().reset(false);
			utils::sort_q(ri2.ptr(),ri2.size());
			ri.assign(ri2);
		};
        const Integer* ptr_ri       = ri.ptr();
		Integer n					= ri.size();

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			while (c_it.valid() && c_it.get() == j+1)
			{
				c_it.next();
			};

			Integer la			= Ad_c[j+1];
			Integer i			= Ad_c[j];

			Integer k = 0;
			while(i < la && k < n)
			{
				Integer p		= Ad_r[i];
				Integer pr		= ptr_ri[k]-1;

				if (p < pr)
				{
					d_r[nz]		= Ad_r[i];
					d_x[nz]		= Ad_x[i];
					++nz;
					++i;
				}
				else 
				{	
					if (p > pr)
					{
						d_r[nz]		= pr;
						d_x[nz]		= val;
						++nz;
						++k;
					}
					else
					{
						d_r[nz]		= pr;
						d_x[nz]		= val;
						++nz;
						++k;
						++i;
					};
					while ( k < n && ptr_ri[k] == ptr_ri[k-1])
					{
						++k;
					};
				};
			};
			while(i < la)
			{
				d_r[nz]			= Ad_r[i];
				d_x[nz]			= Ad_x[i];
				++nz;
				++i;
			};
			while(k < n)
			{
				Integer pr		= ptr_ri[k]-1;

				d_r[nz]			= pr;
				d_x[nz]			= val;
				++nz;
				++k;

				while ( k < n && ptr_ri[k] == ptr_ri[k-1])
				{
					++k;
				};
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM eval_12(const SM& A,const gd::colon_info& c_in, value_type val)
	{
		if (c_in.r_start == 1 && c_in.r_end == A.rows() && c_in.r_step == 1)
		{
			return change_cols(A,c_in,val);
		};

		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

        Integer nzA = icast_c(Real(A.nnz()) + Real(c_in.rows())*Real(c_in.cols()));
		raw::details::spdat<value_type> d(A.get_ti(),r, c, nzA);

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();

		column_iterator c_it(c_in);

		Integer nz					= 0;

		Integer rs = c_in.r_step, rf, rl;
		if (rs < 0)
		{
			rs = -rs;
			rf = c_in.r_end;
			rl = c_in.r_start;
		}
		else
		{
			rf = c_in.r_start;		
			rl = c_in.r_end;
		};
		--rf;
		--rl;
		
		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			while (c_it.valid() && c_it.get() == j+1)
			{
				c_it.next();
			};

			Integer la			= Ad_c[j+1];
			Integer i			= Ad_c[j];

			Integer k = rf;
			while(i < la && k <= rl)
			{
				Integer p		= Ad_r[i];

				if (p < k)
				{
					d_r[nz]		= Ad_r[i];
					d_x[nz]		= Ad_x[i];
					++nz;
					++i;
				}
				else if (p > k)
				{
					d_r[nz]		= k;
					d_x[nz]		= val;
					++nz;
					k			+= rs;
				}
				else
				{
					d_r[nz]		= k;
					d_x[nz]		= val;
					++nz;
					k			+= rs;
					++i;
				};
			};
			while(i < la)
			{
				d_r[nz]			= Ad_r[i];
				d_x[nz]			= Ad_x[i];
				++nz;
				++i;
			};
			while(k <= rl)
			{
				d_r[nz]			= k;
				d_x[nz]			= val;
				++nz;
				k				+= rs;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM change_cols(const SM& A,const gd::colon_info& c_in, value_type val)
	{
		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

        Integer nzA = icast_c(Real(A.nnz()) + Real(c_in.rows())*Real(c_in.cols()));
		raw::details::spdat<value_type> d(A.get_ti(),r, c, nzA);

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();

		column_iterator c_it(c_in);

		Integer nz					= 0;
		
		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			while (c_it.valid() && c_it.get() == j+1)
			{
				c_it.next();
			};

			for (Integer i = 0; i < r; ++i)
			{
				d_r[nz] = i;
				d_x[nz] = val;
				++nz;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
};

template<class SM>
SM change_entries_functor<SM>::eval(SM& A, const gd::colon_info& ci, value_type val)
{
	if (ci.rows() == 0 || ci.cols() == 0)
	{
		return A;
	};
    if (gd::is_zero(val))
	{
		return drop_entries_functor<SM>::eval(A,ci);
	};


	if (ci.r_flag == 0)
	{
		return change_entries_impl<SM>::eval_02(A,ci,val);
	}
	else
	{
		return change_entries_impl<SM>::eval_12(A,ci,val);
	};
};

template<class SM>
SM change_entries_functor_2<SM>::eval(SM& A,const gd::colon_info& ci, value_type val)
{
	if (ci.rows() == 0)
	{
		return A;
	};
	if (gd::is_zero(val))
	{
		return drop_entries_functor<SM>::eval(A,ci);
	};

	if (ci.r_flag == 0)
	{
		return change_entries_impl<SM>::eval_0(A,ci,val);
	}
	else
	{
		return change_entries_impl<SM>::eval_1(A,ci,val);
	};
};

template<class V>
raw::Matrix<V,struct_sparse> sparse_change_diag_functor<V>::eval(SM& mat, Integer d, const DM& B)
{
    Integer r = mat.rows();
    Integer c = mat.cols();

    error::check_diag(d,r,c);

    Integer s, r1, c1;
    if (d >= 0)
    {
        s = (r + d >= c) ? c - d : r;
        r1 = 0;
        c1 = d;
    }
    else
    {
        s = (r + d >= c) ? c : r + d;
        c1 = 0;
        r1 = -d;
    }

    error::check_assign(s,1,B.size(),1);

	if (s == 0)
	{
		return mat;
	};

    raw::details::spdat<V>& rep = mat.rep();

    const Integer* d_c      = rep.ptr_c();
    const Integer* d_r      = rep.ptr_r();    
	V * d_x		            = rep.ptr_x();
    Integer off             = rep.offset();
    DM B_tmp                = B.make_explicit();
    const V* ptr_val        = B_tmp.ptr();

    bool modif_needed       = false;

    for (Integer i = 0; i < s; ++i, ++c1, ++r1, ++ptr_val)
    {        
        V val = *ptr_val;

        Integer pos;
        if (rep.isentry(r1,c1,pos))
        {
            d_x[pos] = val;
        }
        else
        {
            if (gd::is_zero(val))
            {
                continue;
            }
            else
            {
                modif_needed = true;
                break;
            };
        };
    };

    struct_flag::value_type vt = struct_flag::v_general;

    if (modif_needed == false)
    {
        SM out = mat;
        out.set_struct(mat.get_struct().get_set_diag(d,vt));
        return out;        
    };

    raw::details::spdat<V> out(mat.get_ti(),r, c, mat.nnz() + s);

    Integer* out_r          = out.ptr_r();
    Integer* out_c          = out.ptr_c();
    V * out_x		        = out.ptr_x();

    d_r                     = rep.ptr_r() + off;
	d_x		                = rep.ptr_x() + off;

    Integer nz = d_c[c1] - off;
    for (Integer i = 0; i < c1; ++i)
    {
        out_c[i] = d_c[i] - off;
    };
    for (Integer i = 0; i < nz; ++i)
    {
        out_r[i] = d_r[i];
        out_x[i] = d_x[i];
    };

    d_r                     = rep.ptr_r();
	d_x		                = rep.ptr_x();

    for (Integer i = c1; i < c; ++i, ++r1)
    {
        out_c[i]			= nz;

        Integer k           = d_c[i];
        Integer k2          = d_c[i+1];
        for (; k < k2; ++k)
        {
            Integer row = d_r[k];
            if (row >= r1)
            {
                if (row == r1)
                {
                    ++k;
                };
                break;
            };
            out_r[nz] = row;
            out_x[nz] = d_x[k];
            ++nz;
        };

        V val = *ptr_val;
        ++ptr_val;

        if (r1 < r && !gd::is_zero(val))
        {
            out_r[nz] = r1;
            out_x[nz] = val;
            ++nz;
        };
        for (; k < k2; ++k)
        {
            out_r[nz] = d_r[k];
            out_x[nz] = d_x[k];
            ++nz;
        };
    };
    out_c[c] = nz;

    out.get_struct() = mat.get_struct().get_set_diag(d,vt);

    return raw::sparse_matrix_base<V>(out);
};
template<class V>
raw::Matrix<V,struct_sparse> sparse_change_diag_functor<V>::eval(SM& mat, Integer d, const V& val)
{
    Integer r = mat.rows();
    Integer c = mat.cols();

    error::check_diag(d,r,c);

    Integer s, r1, c1;
    if (d >= 0)
    {
        s = (r + d >= c) ? c - d : r;
        r1 = 0;
        c1 = d;
    }
    else
    {
        s = (r + d >= c) ? c : r + d;
        c1 = 0;
        r1 = -d;
    }

	if (s == 0)
	{
        error::check_assign(s,1,1,1);
		return mat;
	};

    raw::details::spdat<V>& rep = mat.rep();

    const Integer* d_c      = rep.ptr_c();
    const Integer* d_r      = rep.ptr_r();
	V * d_x		            = rep.ptr_x();
    Integer off             = rep.offset();

    bool modif_needed       = false;

    for (Integer i = 0; i < s; ++i, ++c1, ++r1)
    {
        Integer pos;
        if (rep.isentry(r1,c1,pos))
        {
            d_x[pos] = val;
        }
        else
        {
            if (gd::is_zero(val))
            {
                continue;
            }
            else
            {
                modif_needed = true;
                break;
            };
        };
    };

    struct_flag::value_type vt = struct_flag::get_value_type(val);

    if (modif_needed == false)
    {
        SM out = mat;
        out.set_struct(mat.get_struct().get_set_diag(d,vt));
        return out;        
    };

    raw::details::spdat<V> out(mat.get_ti(),r, c, mat.nnz() + s);

    Integer* out_r          = out.ptr_r();
    Integer* out_c          = out.ptr_c();
    V * out_x		        = out.ptr_x();

    d_r                     = rep.ptr_r() + off;
	d_x		                = rep.ptr_x() + off;

    Integer nz = d_c[c1] - off;
    for (Integer i = 0; i < c1; ++i)
    {
        out_c[i] = d_c[i] - off;
    };
    for (Integer i = 0; i < nz; ++i)
    {
        out_r[i] = d_r[i];
        out_x[i] = d_x[i];
    };

    d_r                     = rep.ptr_r();
	d_x		                = rep.ptr_x();

    for (Integer i = c1; i < c; ++i, ++r1)
    {
        out_c[i]			= nz;

        Integer k           = d_c[i];
        Integer k2          = d_c[i+1];
        for (; k < k2; ++k)
        {
            Integer row = d_r[k];
            if (row >= r1)
            {
                if (row == r1)
                {
                    ++k;
                };
                break;
            };
            out_r[nz] = row;
            out_x[nz] = d_x[k];
            ++nz;
        };
        if (r1 < r && !gd::is_zero(val))
        {
            out_r[nz] = r1;
            out_x[nz] = val;
            ++nz;
        };
        for (; k < k2; ++k)
        {
            out_r[nz] = d_r[k];
            out_x[nz] = d_x[k];
            ++nz;
        };
    };
    out_c[c] = nz;

    out.get_struct() = mat.get_struct().get_set_diag(d,vt);

    return raw::sparse_matrix_base<V>(out);
};

};};};

template struct mmlib::algorithm::details::change_entries_functor<mmlib::raw::IntegerSparseMatrix>;
template struct mmlib::algorithm::details::change_entries_functor<mmlib::raw::RealSparseMatrix>;
template struct mmlib::algorithm::details::change_entries_functor<mmlib::raw::ComplexSparseMatrix>;
template struct mmlib::algorithm::details::change_entries_functor<mmlib::raw::ObjectSparseMatrix>;

template struct mmlib::algorithm::details::change_entries_functor_2<mmlib::raw::IntegerSparseMatrix>;
template struct mmlib::algorithm::details::change_entries_functor_2<mmlib::raw::RealSparseMatrix>;
template struct mmlib::algorithm::details::change_entries_functor_2<mmlib::raw::ComplexSparseMatrix>;
template struct mmlib::algorithm::details::change_entries_functor_2<mmlib::raw::ObjectSparseMatrix>;

template struct mmlib::algorithm::details::sparse_change_diag_functor<mmlib::Integer>;
template struct mmlib::algorithm::details::sparse_change_diag_functor<mmlib::Real>;
template struct mmlib::algorithm::details::sparse_change_diag_functor<mmlib::Complex>;
template struct mmlib::algorithm::details::sparse_change_diag_functor<mmlib::Object>;
