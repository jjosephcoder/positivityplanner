/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/algs/dense_algs.h"
#include <mmlib/utils/sort.h>
#include "mmlib/error/error_check.h"
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/details/matrix_func_unary.inl"
#include "mmlib/utils/utils.h"

namespace mmlib { namespace algorithm { namespace details
{

namespace gr = mmlib::raw;

template<class DM>
void dense_change_entries_functor<DM>::eval(DM& mat,const mmlib::details::colon_info& ci, 
                                            value_type val)
{
	Integer nr = ci.rows(), nc = ci.cols();
	if (nr == 0 && nc == 0)
	{
		return;
	};	

    bool is_zero = gd::is_zero(val);

    gr::IntegerMatrix ci_ci = ci.get_ci();
    gr::IntegerMatrix ci_ri = ci.get_ri();

    const Integer* ptr_ci = ci_ci.ptr();
    const Integer* ptr_ri = ci_ri.ptr();

    typedef typename DM::value_type value_type;

	if (ci.r_flag == 0 && ci.c_flag == 0)
	{			
		for (Integer j = 0; j < nc; ++j)
		{
			Integer pos_c = imult(ptr_ci[j] - 1,mat.ld());

            value_type* ptr_mat = mat.ptr() + pos_c - 1;

			for (Integer i = 0; i < nr; ++i)
			{
				ptr_mat[ptr_ri[i]] = val;
			};
		};
        mat.get_struct().reset(is_zero);
		return;
	};
	if (ci.r_flag == 0 && ci.c_flag == 1)
	{			
		Integer pos_c = imult(ci.c_start - 1,mat.ld());
		Integer dpos_c = imult(ci.c_step,mat.ld());

        value_type* ptr_mat = mat.ptr() + pos_c - 1;

		for (Integer j = 0; j < ci.c_size; ++j)
		{			
			for (Integer i = 0; i < nr; ++i)
			{
				ptr_mat[ptr_ri[i]] = val;
			};
			ptr_mat += dpos_c;
		};

        mat.get_struct().reset(is_zero);
		return;
	};
	if (ci.r_flag == 1 && ci.c_flag == 0)
	{
		for (Integer j = 0; j < nc; ++j)
		{
			Integer pos_c = imult(ptr_ci[j] - 1, mat.ld());

            value_type* ptr_mat = mat.ptr() + pos_c - 1;

			for (Integer i = 0, ii = ci.r_start; i < ci.r_size; ++i, ii+= ci.r_step)
			{
				ptr_mat[ii] = val;
			};
		};
        mat.get_struct().reset(is_zero);
		return;
	};
	if (ci.r_flag == 1 && ci.c_flag == 1)
	{
		Integer pos_c = imult(ci.c_start - 1,mat.ld());
		Integer dpos_c = imult(ci.c_step,mat.ld());

        value_type* ptr_mat = mat.ptr() + pos_c - 1;

		for (Integer j = 0; j < ci.c_size; ++j)
		{			
			for (Integer i = 0, ii = ci.r_start; i < ci.r_size; ++i, ii+=ci.r_step)
			{
				ptr_mat[ii] = val;
			};
			ptr_mat += dpos_c;
		};
        mat.get_struct().reset(is_zero);
		return;
	};
};
template<class DM>
void dense_change_entries_functor_2<DM>::eval(DM& mat,const mmlib::details::colon_info& ci, 
                                              value_type val)
{
	Integer s = ci.rows();

    gr::IntegerMatrix ci_ri = ci.get_ri();
    const Integer* ptr_ri = ci_ri.ptr();

	if (s == 0)
	{
		return;
	};

    bool is_zero = gd::is_zero(val);

    value_type* ptr_mat = mat.ptr();

	if (ci.r_flag == 0)
	{
        if (mat.ld() == mat.rows())
        {
		    for (Integer i = 0; i < s; ++i)
		    {
			    ptr_mat[ptr_ri[i]-1] = val;
		    };
        }
        else
        {
		    for (Integer i = 0; i < s; ++i)
		    {
                Integer pos = ptr_ri[i];
                Integer rm, cm;
                gd::pos2ind(pos,mat.rows(), rm, cm);
			    ptr_mat[rm+cm*mat.ld()] = val;
		    };
        };
        mat.get_struct().reset(is_zero);
		return;
	}
	else
	{
        if (mat.ld() == mat.rows())
        {
		    for (Integer i = 0, pos = ci.r_start-1; i < ci.r_size; ++i, pos += ci.r_step)
		    {
			    ptr_mat[pos] = val;
		    };
        }
        else
        {
		    for (Integer i = 0, pos = ci.r_start-1; i < ci.r_size; ++i, pos += ci.r_step)
		    {
                while (pos >= mat.rows())
                {
                    pos -= mat.rows();
                    ptr_mat += mat.ld();
                };
			    ptr_mat[pos] = val;
		    };
        };
        mat.get_struct().reset(is_zero);
		return;
	};
};

template<class DM>
DM del_rows_dense_functor<DM>::eval(const DM& mat,const mmlib::details::colon_info& ci)
{
	Integer s = ci.rows();
	if (s == 0)
	{
		return mat;
	};

    gr::IntegerMatrix ci_ri = ci.get_ri();

	Integer r0 = mat.rows(), c0 = mat.cols();

	if (ci.r_flag == 0)
	{		
		raw::IntegerMatrix ritmp = ci_ri.copy();
        const Integer* ptr_ri = ritmp.ptr();
        ritmp.get_struct().reset(false);

		utils::sort_q(ritmp.ptr(),s);

		Integer ce = ptr_ri[0];
		error::check_row(ce, r0, c0);
		Integer ne = 1;

		for (Integer i = 1; i < s; ++i)
		{
			Integer ce2 = ptr_ri[i];
			error::check_row(ce2, r0, c0);
			if (ce2 != ce)
			{
				++ne;
			};
			ce = ce2;
		}

		if (!c0)
		{
			DM out(mat.get_ti(),r0-ne,c0);
            return out;
		};

		if (ne == r0)
		{
			DM out(mat.get_ti(),0,c0);
            return out;
		};

		Integer r1 = r0 - ne;		
		DM out(mat.get_ti(),r1,c0);
        DM::value_type* ptr_out = out.ptr();
        const DM::value_type* ptr_mat = mat.ptr();

		for (Integer j = 0; j < c0; ++j)
		{
			for (Integer i = 0, ii = 0, k = 0; i < r0; ++i)
			{
				if (i+1 == ptr_ri[k])
				{
					while(i+1 == ptr_ri[k])
					{
						++k;
					};
				}
				else
				{
					ptr_out[ii] = ptr_mat[i];
                    ++ii;
				};
			};
            ptr_mat += mat.ld();
            ptr_out += out.ld();
		};

		return out;
	}
	else
	{
		Integer ne = s;
		if (!c0)
		{
			DM out(mat.get_ti(),r0-ne,0);
            return out;
		};

		if (ne == r0)
		{
			DM out(mat.get_ti(),0,c0);
            return out;
		};

		Integer r1 = r0 - ne;		
		DM out(mat.get_ti(),r1,c0);

        DM::value_type* ptr_out = out.ptr();
        const DM::value_type* ptr_mat = mat.ptr();

		Integer rs = ci.r_step, rf, rl;
		if (rs < 0)
		{
			rs = -rs;
			rf = ci.r_end;
			rl = ci.r_start;
		}
		else
		{
			rf = ci.r_start;		
			rl = ci.r_end;
		};

		for (Integer j = 1; j <= c0; ++j)
		{
            Integer ii = 0, iii = 0;
			for (Integer i = 1; i < rf; ++i, ++ii)
			{
				ptr_out[iii++] = ptr_mat[ii];
			};
			if (rs == 1)
			{
				ii += ne;
			}
			else
			{
				for (Integer i = rf; i <= rl; ++i, ++ii)
				{
					if (((i-rf) % rs) != 0)
					{
						ptr_out[iii++] = ptr_mat[ii];
					};
				};
			}
			for (Integer i = rl + 1; i <= r0; ++i, ++ii)
			{
				ptr_out[iii++] = ptr_mat[ii];
			};

            ptr_mat += mat.ld();
            ptr_out += out.ld();
		};
		return out;
	};
};

template<class DM>
DM del_cols_dense_functor<DM>::eval(const DM& mat,const mmlib::details::colon_info& ci)
{
	Integer s = ci.rows();
	if (s == 0)
	{
		return mat;
	};

    gr::IntegerMatrix ci_ri = ci.get_ri();

	Integer r0 = mat.rows(), c0 = mat.cols();

    const DM::value_type* ptr_mat = mat.ptr();

	if (ci.r_flag == 0)
	{		
		raw::IntegerMatrix ritmp = ci_ri.copy();
        const Integer* ptr_ri = ritmp.ptr();
        ritmp.get_struct().reset(false);

		utils::sort_q(ritmp.ptr(),s);

		Integer ce = ptr_ri[0];
		error::check_col(ce, r0, c0);
		Integer ne = 1;

		for (Integer i = 1; i < s; ++i)
		{
			Integer ce2 = ptr_ri[i];
			error::check_col(ce2, r0, c0);
			if (ce2 != ce)
			{
				++ne;
			};
			ce = ce2;
		}

		if (!r0)
		{
			DM out(mat.get_ti(),0,c0-ne);
            return out;
		};

		if (ne == c0)
		{
			DM out(mat.get_ti(),r0,0);
            return out;
		};

		Integer c1 = c0 - ne;		
		DM out(mat.get_ti(),r0,c1);

        DM::value_type* ptr_out = out.ptr();

		for (Integer j = 1, k = 0; j <= c0; ++j)
		{
			if (j == ptr_ri[k])
			{
				while (j == ptr_ri[k])
				{
					++k;
				};
			}
			else
			{
				for (Integer i = 0; i < r0; ++i)
				{			
					ptr_out[i] = ptr_mat[i];
				};
                ptr_out += out.ld();
			};

            ptr_mat += mat.ld();            
		};
        
		return out;
	}
	else
	{
		Integer ne = s;
		if (!r0)
		{
			DM out(mat.get_ti(),0,c0-ne);
            return out;
		};

		if (ne == c0)
		{
			DM out(mat.get_ti(),r0,0);
            return out;
		};

		Integer c1 = c0 - ne;		
		DM out(mat.get_ti(),r0,c1);

        DM::value_type* ptr_out = out.ptr();

		Integer cs = ci.r_step, cf, cl;
		if (cs < 0)
		{
			cs = -cs;
			cf = ci.r_end;
			cl = ci.r_start;
		}
		else
		{
			cf = ci.r_start;		
			cl = ci.r_end;
		};

		for (Integer j = 1; j < cf; ++j)
		{
			for (Integer i = 0; i < r0; ++i)
			{
				ptr_out[i] = ptr_mat[i];
			};

            ptr_mat += mat.ld();
            ptr_out += out.ld();
		};
		if (cs == 1)
		{
			ptr_mat += imult(ne,mat.ld());
		}
		else
		{
			for (Integer j = cf; j <= cl; ++j)
			{
				if (((j-cf) % cs) != 0)
				{
					for (Integer i = 0; i < r0; ++i)
					{
						ptr_out[i] = ptr_mat[i];
					};
                    ptr_out += out.ld();
				};
                ptr_mat += mat.ld();
			};
		};
		for (Integer j = cl + 1; j <= c0; ++j)
		{
			for (Integer i = 0; i < r0; ++i)
			{
				ptr_out[i] = ptr_mat[i];
			};
            ptr_mat += mat.ld();
            ptr_out += out.ld();
		};

		return out;
	};
};

template<class DM>
void dense_change_diag_functor<DM>::eval(DM& mat, Integer d, const DM& val)
{
    Integer r = mat.rows();
    Integer c = mat.cols();

    error::check_diag(d,r,mat.cols());

	Integer st, s;
    if (d >= 0)
    {
        st = imult(d,r);
        s = (r + d >= c) ? c - d : r;
    }
    else
    {
        st = - d;
        s = (r + d >= c) ? c : r + d;
    }

    error::check_assign(s,1,val.size(),1);

	if (s == 0)
	{
		return;
	};

	value_type * ptr = mat.ptr() + st;
    DM val_tmp = val.make_explicit();
    const value_type* val_ptr = val_tmp.ptr();

    for (Integer i = 0; i < s; ++i)
	{
		*(ptr) = *(val_ptr++);
		ptr += mat.ld() + 1;
	}

    mat.set_struct(mat.get_struct().get_set_diag(d,struct_flag::v_general));

    return;
};
template<class DM>
void dense_change_diag_functor<DM>::eval(DM& mat, Integer d, const value_type& val)
{
    Integer r = mat.rows();
    Integer c = mat.cols();

    error::check_diag(d,r,mat.cols());

	Integer st, s;
    if (d >= 0)
    {
        st = imult(d,r);
        s = (r + d >= c) ? c - d : r;
    }
    else
    {
        st = - d;
        s = (r + d >= c) ? c : r + d;
    }    

	if (s == 0)
	{
        error::check_assign(s,1,1,1);
		return;
	};

	value_type * ptr = mat.ptr() + st;

    for (Integer i = 0; i < s; ++i)
	{
		*(ptr) = val;
		ptr += mat.ld() + 1;
	}

    struct_flag::value_type vt = struct_flag::get_value_type(val);
    mat.set_struct(mat.get_struct().get_set_diag(d,vt));
    return;
};

};};};

template struct mmlib::algorithm::details::dense_change_entries_functor<mmlib::raw::IntegerMatrix>;
template struct mmlib::algorithm::details::dense_change_entries_functor<mmlib::raw::RealMatrix>;
template struct mmlib::algorithm::details::dense_change_entries_functor<mmlib::raw::ComplexMatrix>;
template struct mmlib::algorithm::details::dense_change_entries_functor<mmlib::raw::ObjectMatrix>;

template struct mmlib::algorithm::details::dense_change_entries_functor_2<mmlib::raw::IntegerMatrix>;
template struct mmlib::algorithm::details::dense_change_entries_functor_2<mmlib::raw::RealMatrix>;
template struct mmlib::algorithm::details::dense_change_entries_functor_2<mmlib::raw::ComplexMatrix>;
template struct mmlib::algorithm::details::dense_change_entries_functor_2<mmlib::raw::ObjectMatrix>;

template struct mmlib::algorithm::details::del_cols_dense_functor<mmlib::raw::IntegerMatrix>;
template struct mmlib::algorithm::details::del_cols_dense_functor<mmlib::raw::RealMatrix>;
template struct mmlib::algorithm::details::del_cols_dense_functor<mmlib::raw::ComplexMatrix>;
template struct mmlib::algorithm::details::del_cols_dense_functor<mmlib::raw::ObjectMatrix>;

template struct mmlib::algorithm::details::del_rows_dense_functor<mmlib::raw::IntegerMatrix>;
template struct mmlib::algorithm::details::del_rows_dense_functor<mmlib::raw::RealMatrix>;
template struct mmlib::algorithm::details::del_rows_dense_functor<mmlib::raw::ComplexMatrix>;
template struct mmlib::algorithm::details::del_rows_dense_functor<mmlib::raw::ObjectMatrix>;

template struct mmlib::algorithm::details::dense_change_diag_functor<mmlib::raw::IntegerMatrix>;
template struct mmlib::algorithm::details::dense_change_diag_functor<mmlib::raw::RealMatrix>;
template struct mmlib::algorithm::details::dense_change_diag_functor<mmlib::raw::ComplexMatrix>;
template struct mmlib::algorithm::details::dense_change_diag_functor<mmlib::raw::ObjectMatrix>;
