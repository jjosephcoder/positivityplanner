/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/algs/sparse_algs.h"
#include "mmlib/algs/sparse_algs_utils.h"
#include "mmlib/utils/sort.h"
#include "mmlib/error/error_check.h"
#include "mmlib/matrix.h"

#include <vector>

namespace mmlib { namespace algorithm { namespace details
{

class column_iterator_drop
{
	private:
		const mmlib::details::colon_info& ci;
		Integer pos;

	public:
		column_iterator_drop(const mmlib::details::colon_info& ci) : ci(ci) 
		{
			if (ci.c_flag == 0)
			{
				pos = 1;
			}
			else
			{
				pos = ci.c_start;
			};
		};

		Integer size()
		{
			return ci.cols();
		};
		Integer get()
		{
			if (ci.c_flag == 0)
			{
				return ci.get_ci().ptr()[(pos++) - 1];
			}
			else
			{
				Integer tmp = pos;
				pos += ci.c_step;
				return tmp;
			};
		};
	private:
		column_iterator_drop(const column_iterator_drop&);
		column_iterator_drop& operator=(const column_iterator_drop&);
};

template<class SM>
struct drop_entries_impl
{
	static SM eval_20(SM& in,const mmlib::details::colon_info& ci)
	{
		typedef SM::value_type value_type;

		Integer r = in.rows(), c = in.cols();
		raw::details::spdat<value_type>& Ad = in.rep();

		bool any_deleted	= false;

		Integer * Ad_c		= Ad.ptr_c();
		Integer * Ad_r		= Ad.ptr_r();
		value_type * Ad_x	= Ad.ptr_x();		

        Matrix ri(ci.get_ri(),false);
		Integer n = ci.get_ri().size();

		column_iterator_drop c_it(ci);

		if (imult(n,c) < r)
		{		
            ri.make_unique();
            raw::IntegerMatrix ri_raw = ri.impl<raw::IntegerMatrix>();
            const Integer* ptr_ri_raw = ri_raw.ptr();

			utils::sort_q(ri_raw.ptr(),n);

            Integer size = c_it.size();
			for (Integer i = 0; i < size; ++i)
			{
				Integer col = c_it.get() - 1;
				Integer nz_row = Ad_c[col+1] - Ad_c[col];

				if (nz_row == 0)
				{
					continue;
				};

				Integer la = Ad_c[col+1];

				Integer j = Ad_c[col];

				Integer k = 0;
				while(j < la && k < n)
				{
					Integer p = Ad_r[j];

					if (p < ptr_ri_raw[k]-1)
					{
						++j;
					}
					else if (p > ptr_ri_raw[k]-1)
					{
						++k;
					}
					else
					{
						Ad_r[j] = -1;
						any_deleted = true;
						++j;
						++k;
					};
				};
			};
		}
		else
		{
            raw::IntegerMatrix ri_raw = ri.impl<raw::IntegerMatrix>();
            const Integer* ptr_ri_raw = ri_raw.ptr();

			std::vector<Integer>		v_work_ind;
			bool work_initialized = false;
			Integer r_min = 0, r_max = 0;

            Integer cit_size = c_it.size();
            Integer ri_size = ri_raw.size();
			for (Integer i = 1; i <= cit_size; ++i)
			{
				Integer col = c_it.get() - 1;
				Integer nz_row = Ad_c[col+1] - Ad_c[col];

				if (nz_row > 0 && work_initialized == false)
				{
					init_row_selector(ri_raw,0,v_work_ind,r_min,r_max);                    
					for (Integer i = 0; i < ri_size; ++i)
					{
						v_work_ind[ptr_ri_raw[i]-1-r_min] = 1;
					};
					work_initialized = true;
				};
				for (Integer j = Ad_c[col]; j < Ad_c[col+1]; ++j)
				{
					Integer row = Ad_r[j];
					if (row < r_min || row > r_max)
					{
						continue;
					};			
					if (v_work_ind[row-r_min] == 1)
					{
						Ad_r[j] = -1;
						any_deleted = true;
					};
				};
			};
		};
		if (any_deleted == false)
		{
			return in;
		};
		for (Integer i = 0, pos = Ad.offset(); i < c; ++i)
		{
			for (Integer j = Ad_c[i]; j < Ad_c[i+1]; ++j)
			{
				if (Ad_r[j] == -1)
				{
					continue;
				};
				if (j == pos)
				{
					++pos;
					continue;
				};
				Ad_r[pos] = Ad_r[j];
				Ad_x[pos] = Ad_x[j];
				++pos;
			};
			Ad_c[i] = pos;
		};
		for (Integer i = c; i >0; --i)
		{
			Ad_c[i] = Ad_c[i-1];
		};
		Ad_c[0] = Ad.offset();

		Ad.memadd(-1);
        in.get_struct().reset(true);
        return in;
	};
	static SM eval_21(SM& in,const mmlib::details::colon_info& ci)
	{
		typedef SM::value_type value_type;

		Integer c = in.cols();
		raw::details::spdat<value_type>& Ad = in.rep();

		bool any_deleted	= false;

		Integer * Ad_c		= Ad.ptr_c();
		Integer * Ad_r		= Ad.ptr_r();
		value_type * Ad_x	= Ad.ptr_x();		

		Integer rs = ci.r_step, rf, rl;
		if (rs < 0)
		{
			rs = -rs;
			rf = ci.r_end;
			rl = ci.r_start;
		}
		else
		{
			rf = ci.r_start;		
			rl = ci.r_end;
		};
		--rf;
		--rl;

		column_iterator_drop c_it(ci);

        Integer c_it_size = c_it.size();
		for (Integer i = 1; i <= c_it_size; ++i)
		{
			Integer col = c_it.get() - 1;

			for (Integer j = Ad_c[col]; j < Ad_c[col+1]; ++j)
			{
				Integer row = Ad_r[j];
				if (row < rf || row > rl)
				{
					continue;
				};
				if ((row-rf)%rs == 0)
				{
					Ad_r[j] = -1;
					any_deleted = true;
				};
			};
		};

		if (any_deleted == false)
		{
			return in;
		};
		for (Integer i = 0, pos = Ad.offset(); i < c; ++i)
		{
			for (Integer j = Ad_c[i]; j < Ad_c[i+1]; ++j)
			{
				if (Ad_r[j] == -1)
				{
					continue;
				};
				if (j == pos)
				{
					++pos;
					continue;
				};
				Ad_r[pos] = Ad_r[j];
				Ad_x[pos] = Ad_x[j];
				++pos;
			};
			Ad_c[i] = pos;
		};
		for (Integer i = c; i >0; --i)
		{
			Ad_c[i] = Ad_c[i-1];
		};
		Ad_c[0] = Ad.offset();

		Ad.memadd(-1);
        in.get_struct().reset(true);
        return in;
	};

	static SM eval_0(SM& out,const mmlib::details::colon_info& ci)
	{
		typedef SM::value_type value_type;
		Integer r = out.rows(), c = out.cols();

        Matrix ri(ci.get_ri(),false);
        raw::IntegerMatrix ri_raw = ri.impl<raw::IntegerMatrix>();

		sort_type s_type = is_sorted(ri_raw);
		bool incr = true;
		if (s_type == sorted_increasing)
		{
		}
		else if (s_type == sorted_decreasing)
		{
			incr = false;
		} 
		else
		{
            ri.make_unique();
            raw::IntegerMatrix ri_tmp = ri.impl<raw::IntegerMatrix>();
			utils::sort_q(ri_tmp.ptr(),ri_tmp.size());
			ri_raw.assign(ri_tmp);
		};
		
		bool any_deleted	= false;

		raw::details::spdat<value_type>& Ad = out.rep();
		Integer * Ad_c		= Ad.ptr_c();
		Integer * Ad_r		= Ad.ptr_r();
		value_type * Ad_x	= Ad.ptr_x();		

		Integer step_ri;
		Integer pos, pos_row, pos_col;
		if (incr)
		{
			pos = 0;
			step_ri = 1;
		}
		else
		{
			pos = ri_raw.size()-1;
			step_ri = -1;
		};
		Integer or = ri_raw.size();
        const Integer* ptr_ri_raw = ri_raw.ptr();

		mmlib::details::pos2ind(ptr_ri_raw[pos],r,pos_row,pos_col);

		for (Integer j = 0; j < c; ++j)
		{
			if (j < pos_col)
			{
				continue;
			};

			for (Integer i = Ad_c[j]; i < Ad_c[j+1];++i)
			{
				Integer p = Ad_r[i];
				if (p < pos_row)
				{
					continue;
				};
				while (p > pos_row)
				{
					pos+=step_ri;
					if (pos > or-1 || pos < 0)
					{
						goto exit_flag;
					};
					mmlib::details::pos2ind(ptr_ri_raw[pos],r,pos_row,pos_col);
					if (j != pos_col)
					{
						goto exit_row_flag;
					};
				};
				while ( p == pos_row)
				{
					Ad_r[i] = -1;
					any_deleted = true;

					pos+=step_ri;
					if (pos > or-1 || pos < 0)
					{
						goto exit_flag;
					};
					mmlib::details::pos2ind(ptr_ri_raw[pos],r,pos_row,pos_col);
					if (j != pos_col)
					{
						goto exit_row_flag;
					};
				};
			};

			while (j == pos_col)
			{
				pos+= step_ri;
				if (pos > or-1 || pos < 0)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(ptr_ri_raw[pos],r,pos_row,pos_col);
			};

			exit_row_flag:
			continue;
		};

	exit_flag:

		if (any_deleted == false)
		{
			return out;
		};
		for (Integer i = 0, pos = Ad.offset(); i < c; ++i)
		{
			for (Integer j = Ad_c[i]; j < Ad_c[i+1]; ++j)
			{
				if (Ad_r[j] == -1)
				{
					continue;
				};
				if (j == pos)
				{
					++pos;
					continue;
				};
				Ad_r[pos] = Ad_r[j];
				Ad_x[pos] = Ad_x[j];
				++pos;
			};
			Ad_c[i] = pos;
		};
		for (Integer i = c; i >0; --i)
		{
			Ad_c[i] = Ad_c[i-1];
		};
		Ad_c[0] = Ad.offset();

		Ad.memadd(-1);
        out.get_struct().reset(true);
		return out;
	};
	static SM eval_1(SM& out,const mmlib::details::colon_info& ci)
	{
		typedef SM::value_type value_type;
		Integer r = out.rows(), c = out.cols();

		Integer rs = ci.r_step,rf,rl;
		if (rs < 0)
		{
			rs = -rs;
			rf = ci.r_end;
			rl = ci.r_start;
		}
		else
		{
			rl = ci.r_end;
			rf = ci.r_start;
		};
		bool any_deleted	= false;

		raw::details::spdat<value_type>& Ad = out.rep();
		Integer * Ad_c		= Ad.ptr_c();
		Integer * Ad_r		= Ad.ptr_r();
		value_type * Ad_x	= Ad.ptr_x();		

		Integer pos = rf, pos_row, pos_col;
		mmlib::details::pos2ind(pos,r,pos_row,pos_col);

		for (Integer j = 0; j < c; ++j)
		{
			if (j < pos_col)
			{
				continue;
			};

			for (Integer i = Ad_c[j]; i < Ad_c[j+1];++i)
			{
				Integer p = Ad_r[i];
				if (p < pos_row)
				{
					continue;
				};
				while (p > pos_row)
				{
					pos+=rs;
					if (pos > rl)
					{
						goto exit_flag;
					};
					mmlib::details::pos2ind(pos,r,pos_row,pos_col);
					if (j != pos_col)
					{
						goto exit_row_flag;
					};
				};
				while ( p == pos_row)
				{
					Ad_r[i] = -1;
					any_deleted = true;

					pos+=rs;
					if (pos > rl)
					{
						goto exit_flag;
					};
					mmlib::details::pos2ind(pos,r,pos_row,pos_col);
					if (j != pos_col)
					{
						goto exit_row_flag;
					};
				};
			};

			while (j == pos_col)
			{
				pos+= rs;
				if (pos > rl)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(pos,r,pos_row,pos_col);
			};

			exit_row_flag:
			continue;
		};

	exit_flag:

		if (any_deleted == false)
		{
			return out;
		};
		for (Integer i = 0, pos = Ad.offset(); i < c; ++i)
		{
			for (Integer j = Ad_c[i]; j < Ad_c[i+1]; ++j)
			{
				if (Ad_r[j] == -1)
				{
					continue;
				};
				if (j == pos)
				{
					++pos;
					continue;
				};
				Ad_r[pos] = Ad_r[j];
				Ad_x[pos] = Ad_x[j];
				++pos;
			};
			Ad_c[i] = pos;
		};
		for (Integer i = c; i > 0; --i)
		{
			Ad_c[i] = Ad_c[i-1];
		};
		Ad_c[0] = Ad.offset();

		Ad.memadd(-1);
        out.get_struct().reset(true);
		return out;
	};
};
template<class SM>
SM drop_entries_functor<SM>::eval(SM& A,const mmlib::details::colon_info& ci)
{
	if (ci.rows() == 0 || ci.cols() == 0 || A.nnz() == 0)
	{
		return A;
	};

	if (ci.r_flag == 0)
	{
		return drop_entries_impl<SM>::eval_20(A,ci);
	}
	else
	{
		return drop_entries_impl<SM>::eval_21(A,ci);
	};

};
template<class SM>
SM drop_entries_functor_2<SM>::eval(SM& A,const mmlib::details::colon_info& ci)
{
	if (ci.rows() == 0 || A.nnz() == 0)
	{
		return A;
	};
	if (ci.r_flag == 0)
	{
		return drop_entries_impl<SM>::eval_0(A,ci);
	}
	else
	{
		return drop_entries_impl<SM>::eval_1(A,ci);
	};
};

};};};

template struct mmlib::algorithm::details::drop_entries_functor<mmlib::raw::IntegerSparseMatrix>;
template struct mmlib::algorithm::details::drop_entries_functor<mmlib::raw::RealSparseMatrix>;
template struct mmlib::algorithm::details::drop_entries_functor<mmlib::raw::ComplexSparseMatrix>;
template struct mmlib::algorithm::details::drop_entries_functor<mmlib::raw::ObjectSparseMatrix>;

template struct mmlib::algorithm::details::drop_entries_functor_2<mmlib::raw::IntegerSparseMatrix>;
template struct mmlib::algorithm::details::drop_entries_functor_2<mmlib::raw::RealSparseMatrix>;
template struct mmlib::algorithm::details::drop_entries_functor_2<mmlib::raw::ComplexSparseMatrix>;
template struct mmlib::algorithm::details::drop_entries_functor_2<mmlib::raw::ObjectSparseMatrix>;
