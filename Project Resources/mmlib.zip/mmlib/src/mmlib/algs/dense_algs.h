/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/base/colon_info.h"

namespace mmlib { namespace algorithm
{
	namespace details
	{
		template<class DM>
		struct MMLIB_EXPORT dense_change_entries_functor
		{
			typedef typename DM::value_type value_type;
			static void eval(DM& mat,const mmlib::details::colon_info& ci, value_type val);
		};
		template<class DM>
		struct MMLIB_EXPORT dense_change_entries_functor_2
		{
			typedef typename DM::value_type value_type;
			static void eval(DM& mat,const mmlib::details::colon_info& ci, value_type val);
		};
		template<class DM>
		struct del_rows_dense_functor
		{
			static DM eval(const DM& mat,const mmlib::details::colon_info& ci);
		};
		template<class DM>
		struct del_cols_dense_functor
		{
			static DM eval(const DM& mat,const mmlib::details::colon_info& ci);
		};
		template<class DM>
		struct MMLIB_EXPORT dense_change_diag_functor
		{
            typedef typename DM::value_type value_type;
			static void eval(DM& mat, Integer d, const DM& val);
            static void eval(DM& mat, Integer d, const value_type& val);
		};
	};


//eval A(c) = val for given colon c
template<class value_type>
void dense_change_entries(raw::Matrix<value_type,struct_dense>& mat,
					const mmlib::details::colon_info& ci,
				    value_type val)
{
	typedef raw::Matrix<value_type,struct_dense> DenseMatrix;
	return details::dense_change_entries_functor<DenseMatrix>::eval(mat,ci,val);
};

//eval A(c1,c2) = val
template<class value_type>
void dense_change_entries_2(raw::Matrix<value_type,struct_dense>& mat,
					const mmlib::details::colon_info& ci,
				    value_type val)
{
	typedef raw::Matrix<value_type,struct_dense> DenseMatrix;
	return details::dense_change_entries_functor_2<DenseMatrix>::eval(mat,ci,val);
};

//eval A(c_i,:) = []
template<class value_type>
raw::Matrix<value_type,struct_dense> 
del_rows_dense(const raw::Matrix<value_type,struct_dense>& mat,
				  const mmlib::details::colon_info& ci)
{
	typedef raw::Matrix<value_type,struct_dense> DenseMatrix;
	return details::del_rows_dense_functor<DenseMatrix>::eval(mat,ci);
};
//eval A(:,c_i) = []
template<class value_type>
raw::Matrix<value_type,struct_dense> 
del_cols_dense(const raw::Matrix<value_type,struct_dense>& mat,
				  const mmlib::details::colon_info& ci)
{
	typedef raw::Matrix<value_type,struct_dense> DenseMatrix;
	return details::del_cols_dense_functor<DenseMatrix>::eval(mat,ci);
};

//eval A(d) = val for given diagonal
template<class value_type>
void dense_change_diag(raw::Matrix<value_type,struct_dense>& mat, Integer d, value_type val)
{
	typedef raw::Matrix<value_type,struct_dense> DenseMatrix;
	return details::dense_change_diag_functor<DenseMatrix>::eval(mat,d,val);
};

//eval A(d) = mat for given diagonal
template<class value_type>
void dense_change_diag(raw::Matrix<value_type,struct_dense>& mat, Integer d, 
                       const raw::Matrix<value_type,struct_dense>& val)
{
	typedef raw::Matrix<value_type,struct_dense> DenseMatrix;
	return details::dense_change_diag_functor<DenseMatrix>::eval(mat,d,val);
};

};};