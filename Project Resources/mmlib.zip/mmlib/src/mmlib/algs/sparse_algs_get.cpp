/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/algs/sparse_algs.h"
#include "mmlib/exception.h"
#include "mmlib/algs/sparse_algs_utils.h"
#include "mmlib/utils/sort.h"
#include "mmlib/func/raw/raw_manip.h"

namespace mmlib { namespace algorithm { namespace details
{
namespace gr = mmlib::raw;

template<class SM>
SM get_submatrix_functor<SM>::eval(const SM& A,const mmlib::details::colon_info& ci)
{
	if (ci.r_flag == 0 && ci.c_flag == 0)
	{
		return eval_00(A,ci.get_ri(),ci.get_ci());
	};
	if (ci.r_flag == 0 && ci.c_flag == 1)
	{
		return eval_01(A,ci);
	};
	if (ci.r_flag == 1 && ci.c_flag == 0)
	{
		return eval_10(A,ci);
	};
	if (ci.r_flag == 1 && ci.c_flag == 1)
	{
		return eval_11(A,ci);
	};
	assertion(0,"invalid colon info");
	throw;
}
template<class SM>
SM get_submatrix_functor<SM>::eval_00(const SM& A,const Vector& ri,const Vector& ci)
{
	if (ri.size() == 0 || ci.size() == 0 || A.nnz() == 0)
	{
		return SM(A.get_ti(),ri.size(),ci.size());
	};
	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = ri.size(), oc = ci.size();
	const raw::details::spdat<value_type>& Ad = A.rep();

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(or)*Real(oc)) + 1 + or;	
	raw::details::spdat<value_type> d(A.get_ti(),or, oc, onnz);

	Integer r_min = 0, r_max = 0;
	sort_type s_type = not_sorted;
	Integer n_dupl = 0;
	std::vector<Integer> v_work_ind;
	row_map m_row_map;

	bool workspace_initialized = false;	

	Integer nz					= 0;

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();

    Integer * d_c				= d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();

    const Integer* ptr_ri       = ri.ptr();
    const Integer* ptr_ci       = ci.ptr();

	for (Integer j = 0; j < oc; ++j)
	{
		Integer col             = ptr_ci[j]-1;	
		d_c[j]				    = nz;
		Integer nnz_row			= Ad_c[col+1] - Ad_c[col];

		if (nnz_row == 0)
		{
			continue;
		};

		if (workspace_initialized == false)
		{
			init_row_selector(ri,-1,v_work_ind,r_min,r_max);
			s_type = is_sorted(ri);

			for (Integer i = 0; i < or; ++i)
			{
				Integer pos = ptr_ri[i]-1-r_min;
				if (v_work_ind[pos] == -1)
				{
					v_work_ind[pos] = i;
				}
				else if (v_work_ind[pos] == -2)
				{
					++n_dupl;
					m_row_map.insert(pos,i);
				}
				else
				{
					// given row must be insterted many times
					++n_dupl;
					m_row_map.insert(pos,v_work_ind[pos]);
					m_row_map.insert(pos,i);
					v_work_ind[pos] = -2;
				};
			};

			workspace_initialized = true;
		};

		if (nz + nnz_row + n_dupl > d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row + n_dupl);
            d_c					= d.ptr_c();
			d_r					= d.ptr_r();
			d_x					= d.ptr_x();
		};	
		if (s_type == sorted_decreasing)
		{
			for (Integer k = Ad_c[col+1]-1; k >= Ad_c[col]; --k)
			{			
				Integer p	= Ad_r[k];
				if (p<r_min || p>r_max)
				{
					continue;
				};
				Integer pos = v_work_ind[p-r_min];
				if (pos == -1)
				{
					continue;
				}
				else if (pos == -2)
				{
					m_row_map.add_rows(p-r_min,Ad_x[k],d_x,d_r,nz);
				}
				else
				{
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			};
		}
		else
		{
			Integer nz_old = nz;

			for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
			{			
				Integer p	= Ad_r[k];
				if (p<r_min || p>r_max)
				{
					continue;
				};
				Integer pos = v_work_ind[p-r_min];
				if (pos == -1)
				{
					continue;
				}
				else if (pos == -2)
				{
					m_row_map.add_rows(p-r_min,Ad_x[k],d_x,d_r,nz);
				}
				else
				{
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			};
			if (s_type == not_sorted && (nz - nz_old > 1) )
			{
				utils::sort_q(d_r+nz_old,d_x + nz_old, nz - nz_old);
			};
		};
	};
	d_c[oc] = nz;
	d.memadd(-1);

	return raw::sparse_matrix_base<value_type>(d);
};
template<class SM>
SM get_submatrix_functor<SM>::eval_01(const SM& A,const mmlib::details::colon_info& colon_info)
{
	if (colon_info.get_ri().size() == 0 || colon_info.c_size == 0 || A.nnz() == 0)
	{
		SM out(A.get_ti(),colon_info.get_ri().size(),colon_info.c_size);
        return out;
	};
	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = colon_info.get_ri().size(), oc = colon_info.c_size;
	const raw::details::spdat<value_type>& Ad = A.rep();

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(or)*Real(oc)) + 1 + or;	
	raw::details::spdat<value_type> d(A.get_ti(),or, oc, onnz);

	Integer r_min = 0, r_max = 0;
	sort_type s_type = not_sorted;
	Integer n_dupl = 0;
	std::vector<Integer> v_work_ind;
	row_map m_row_map;

	raw::IntegerMatrix ri = colon_info.get_ri();
    const Integer* ptr_ri       = ri.ptr();

	bool workspace_initialized = false;	

	Integer nz					= 0;

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();

    Integer * d_c				= d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();

	for (Integer j = 1, col = colon_info.c_start-1, pos_c = 0; j <= colon_info.c_size; 
		                                    ++j, col += colon_info.c_step, ++pos_c)
	{
		d_c[pos_c]				= nz;

		Integer nnz_row			= Ad_c[col+1] - Ad_c[col];

		if (nnz_row == 0)
		{
			continue;
		};	

		if (workspace_initialized == false)
		{
			init_row_selector(ri,-1,v_work_ind,r_min,r_max);
			s_type = is_sorted(ri);

			for (Integer i = 0; i < or; ++i)
			{
				Integer pos = ptr_ri[i]-1-r_min;
				if (v_work_ind[pos] == -1)
				{
					v_work_ind[pos] = i;
				}
				else if (v_work_ind[pos] == -2)
				{
					++n_dupl;
					m_row_map.insert(pos,i);
				}
				else
				{					
					// given row must be insterted many times
					++n_dupl;
					m_row_map.insert(pos,v_work_ind[pos]);
					m_row_map.insert(pos,i);
					v_work_ind[pos] = -2;
				};
			};

			workspace_initialized = true;
		};

		if (nz + nnz_row  + n_dupl> d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row + n_dupl);
            d_c					= d.ptr_c();
			d_r					= d.ptr_r();
			d_x					= d.ptr_x();
		};	

		if (s_type == sorted_decreasing)
		{
			for (Integer k = Ad_c[col+1]-1; k >= Ad_c[col]; --k)
			{			
				Integer p	= Ad_r[k];
				if (p<r_min || p>r_max)
				{
					continue;
				};
				Integer pos = v_work_ind[p-r_min];
				if (pos == -1)
				{
					continue;
				}
				else if (pos == -2)
				{
					m_row_map.add_rows(p-r_min,Ad_x[k],d_x,d_r,nz);
				}
				else
				{
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			};
		}
		else
		{
			Integer nz_old = nz;

			for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
			{			
				Integer p	= Ad_r[k];
				if (p<r_min || p>r_max)
				{
					continue;
				};
				Integer pos = v_work_ind[p-r_min];
				if (pos == -1)
				{
					continue;
				}
				else if (pos == -2)
				{
					m_row_map.add_rows(p-r_min,Ad_x[k],d_x,d_r,nz);
				}
				else
				{
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			};
			if (s_type == not_sorted && (nz - nz_old > 1) )
			{
				utils::sort_q(d_r+nz_old,d_x + nz_old, nz - nz_old);
			};
		};
	};
	d_c[oc] = nz;
	d.memadd(-1);

	return raw::sparse_matrix_base<value_type>(d);
};
template<class SM>
SM get_submatrix_functor<SM>::eval_10(const SM& A,const mmlib::details::colon_info& colon_info)
{
	if (colon_info.r_size == 0 || colon_info.get_ci().size() == 0 || A.nnz() == 0)
	{
		SM out(A.get_ti(),colon_info.r_size,colon_info.get_ci().size());
        return out;
	};
	if (colon_info.r_start == 1 && colon_info.r_step == 1 && colon_info.r_end == A.rows())
	{
		return get_cols_0(A,colon_info);
	};

	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = colon_info.r_size, oc = colon_info.get_ci().size();
	const raw::details::spdat<value_type>& Ad = A.rep();

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(or)*Real(oc));	
	raw::details::spdat<value_type> d(A.get_ti(),or, oc, onnz);

	Integer r_start = colon_info.r_start - 1;
	Integer r_end = colon_info.r_end - 1;
	Integer r_step = colon_info.r_step;
	bool b_increasing = (r_step > 0);

	if (!b_increasing)
	{
		Integer tmp = r_start;
		r_start = r_end;
		r_end = tmp;
		r_step = - r_step;
	};

	Integer nz					= 0;

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();

    Integer * d_c				= d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();	

    gr::IntegerMatrix ci_ci     = colon_info.get_ci();
    const Integer* ptr_ci       = ci_ci.ptr();

	for (Integer j = 0; j < oc; ++j)
	{
		Integer col				= ptr_ci[j]-1;
		d_c[j]				    = nz;
		Integer nnz_row			= Ad_c[col+1] - Ad_c[col];

		if (nnz_row == 0)
		{
			continue;
		};

		if (nz + nnz_row > d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row);
            d_c				= d.ptr_c();
			d_r				= d.ptr_r();
			d_x				= d.ptr_x();	
		};

		if (b_increasing == false)
		{
			if (r_step == 1)
			{
				for (Integer k = Ad_c[col+1]-1; k >= Ad_c[col]; --k)
				{			
					Integer p	= Ad_r[k];
					if (p<r_start || p>r_end)
					{
						continue;
					};
					Integer pos = r_end-p;
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			}
			else
			{
				for (Integer k = Ad_c[col+1]-1; k >= Ad_c[col]; --k)
				{			
					Integer p	= Ad_r[k];
					if (p<r_start || p>r_end)
					{
						continue;
					};
					if ((r_end-p)%r_step != 0)
					{
						continue;
					};
					Integer pos = (r_end-p)/r_step;
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			};
		}
		else
		{
			if (r_step == 1)
			{
				for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
				{			
					Integer p	= Ad_r[k];
					if (p<r_start || p>r_end)
					{
						continue;
					};
					Integer pos = p-r_start;
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			}
			else
			{
				for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
				{			
					Integer p	= Ad_r[k];
					if (p<r_start || p>r_end)
					{
						continue;
					};
					if ((p-r_start)%r_step != 0)
					{
						continue;
					};
					Integer pos = (p-r_start)/r_step;
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			};
		};
	};
	d_c[oc] = nz;
	d.memadd(-1);

	return raw::sparse_matrix_base<value_type>(d);
};
template<class SM>
SM get_submatrix_functor<SM>::eval_11(const SM& A,const mmlib::details::colon_info& colon_info)
{
	if (colon_info.r_size == 0 || colon_info.c_size == 0 || A.nnz() == 0)
	{
		SM out(A.get_ti(),colon_info.r_size,colon_info.c_size);
        return out;
	};
	if (colon_info.r_start == 1 && colon_info.r_step == 1 && colon_info.r_end == A.rows())
	{
		return get_cols_1(A,colon_info);
	};
	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = colon_info.r_size, oc = colon_info.c_size;
	const raw::details::spdat<value_type>& Ad = A.rep();

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(or)*Real(oc));	
	raw::details::spdat<value_type> d(A.get_ti(),or, oc, onnz);

	Integer r_start = colon_info.r_start - 1;
	Integer r_end = colon_info.r_end - 1;
	Integer r_step = colon_info.r_step;
	bool b_increasing = (r_step > 0);

	if (!b_increasing)
	{
		Integer tmp = r_start;
		r_start = r_end;
		r_end = tmp;
		r_step = - r_step;
	};

	Integer nz					= 0;

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();

    Integer * d_c				= d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();	

	for (Integer j = 1, col = colon_info.c_start-1, pos_c = 0; j <= colon_info.c_size; 
			                                    ++j, col += colon_info.c_step, ++pos_c)
	{	
		d_c[pos_c]				= nz;

		Integer nnz_row			= Ad_c[col+1] - Ad_c[col];

		if (nnz_row == 0)
		{
			continue;
		};

		if (nz + nnz_row > d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row);
            d_c				= d.ptr_c();
			d_r				= d.ptr_r();
			d_x				= d.ptr_x();	
		};

		if (b_increasing == false)
		{
			if (r_step == 1)
			{
				for (Integer k = Ad_c[col+1]-1; k >= Ad_c[col]; --k)
				{			
					Integer p	= Ad_r[k];
					if (p<r_start || p>r_end)
					{
						continue;
					};
					Integer pos = r_end-p;
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			}
			else
			{
				for (Integer k = Ad_c[col+1]-1; k >= Ad_c[col]; --k)
				{			
					Integer p	= Ad_r[k];
					if (p<r_start || p>r_end)
					{
						continue;
					};
					if ((r_end-p)%r_step != 0)
					{
						continue;
					};
					Integer pos = (r_end-p)/r_step;
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			};
		}
		else
		{
			if (r_step == 1)
			{
				for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
				{			
					Integer p	= Ad_r[k];
					if (p<r_start || p>r_end)
					{
						continue;
					};
					Integer pos = p-r_start;
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			}
			else
			{
				for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
				{			
					Integer p	= Ad_r[k];
					if (p<r_start || p>r_end)
					{
						continue;
					};
					if ((p-r_start)%r_step != 0)
					{
						continue;
					};
					Integer pos = (p-r_start)/r_step;
					d_x[nz]		= Ad_x[k];
					d_r[nz]		= pos;
					++nz;
				};
			};
		};
	};
	d_c[oc] = nz;
	d.memadd(-1);

	return raw::sparse_matrix_base<value_type>(d);
};
template<class SM>
SM get_submatrix_functor<SM>::get_cols_0(const SM& A,const mmlib::details::colon_info& colon_info)
{
	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = r, oc = colon_info.get_ci().size();
	const raw::details::spdat<value_type>& Ad = A.rep();

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(oc));
	raw::details::spdat<value_type> d(A.get_ti(),or, oc, onnz);

	if (or == 0 || oc == 0 || A.nnz() == 0)
	{
		SM out= raw::sparse_matrix_base<value_type>(d);
        return out;
	};

	Integer nz					= 0;

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();

    Integer * d_c				= d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();	
    gr::IntegerMatrix ci_ci     = colon_info.get_ci();
    const Integer* ptr_ci       = ci_ci.ptr();

	for (Integer j = 0; j < oc; ++j)
	{
		Integer col				= ptr_ci[j]-1;	
		d_c[j]				    = nz;
		Integer nnz_row			= Ad_c[col+1] - Ad_c[col];

		if (nz + nnz_row > d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row);
            d_c				= d.ptr_c();
			d_r				= d.ptr_r();
			d_x				= d.ptr_x();	
		};	

		for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
		{
			d_x[nz]			= Ad_x[k];
			d_r[nz]			= Ad_r[k];
			++nz;
		};
	};
	d_c[oc] = nz;
	d.memadd(-1);

	return raw::sparse_matrix_base<value_type>(d);
};
template<class SM>
SM get_submatrix_functor<SM>::get_cols_1(const SM& A,const mmlib::details::colon_info& colon_info)
{
	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = r, oc = colon_info.c_size;
	const raw::details::spdat<value_type>& Ad = A.rep();

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(oc));
	raw::details::spdat<value_type> d(A.get_ti(),or, oc, onnz);

	if (or == 0 || oc == 0 || A.nnz() == 0)
	{
		SM out = raw::sparse_matrix_base<value_type>(d);
        return out;
	};

	Integer nz					= 0;

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();

    Integer * d_c				= d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();	

	for (Integer j = 1, col = colon_info.c_start-1, pos_c = 0; j <= colon_info.c_size; 
					++j, col+= colon_info.c_step, ++pos_c)
	{
		d_c[pos_c]				= nz;

		Integer nnz_row			= Ad_c[col+1] - Ad_c[col];

		if (nz + nnz_row > d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row);
            d_c				= d.ptr_c();
			d_r				= d.ptr_r();
			d_x				= d.ptr_x();	
		};	

		for (Integer k = Ad_c[col]; k < Ad_c[col+1]; ++k)
		{
			d_x[nz]			= Ad_x[k];
			d_r[nz]			= Ad_r[k];
			++nz;
		};
	};
	d_c[oc] = nz;
	d.memadd(-1);

	return raw::sparse_matrix_base<value_type>(d);
};

template<class SM>
SM get_submatrix_functor_2<SM>::eval(const SM& A,const mmlib::details::colon_info& ci)
{
	if (ci.r_flag == 0)
	{
		SM out = eval_0(A,ci.get_ri());
		return raw::reshape(out,ci.rep_rows(), ci.rep_cols());
	};
	if (ci.r_flag == 1)
	{
		SM out = eval_1(A,ci);
        if (out.rows() == ci.rep_rows())
        {
            return out;
        }
        else
        {
            return raw::reshape(out,ci.rep_rows(), ci.rep_cols());
        };
	};
	assertion(0,"invalid colon info");
	throw;
}
template<class SM>
SM get_submatrix_functor_2<SM>::eval_0(const SM& A,const Vector& ci)
{
	if (ci.size() == 0 || A.nnz() == 0)
	{
		SM out(A.get_ti(),ci.rows(),ci.cols());
        return out;
	};	
	sort_type s_type = is_sorted(ci);
	if (s_type == sorted_increasing)
	{
		Integer n_rep = number_dupl(ci);
		return eval_0_increasing(A,ci,n_rep);
	};
	if (s_type == sorted_decreasing)
	{
		Integer n_rep = number_dupl(ci);
		return eval_0_decreasing(A,ci,n_rep);
	};

	Vector ci2 = ci.copy();
    ci2.get_struct().reset(false);
	typedef SM::value_type value_type;

	Integer or = ci2.size();

	std::vector<Integer>	v_work_sort_ind(or);	
	for (Integer i = 0; i < or; ++i)
	{
		v_work_sort_ind[i] = i;
	};
	utils::sort_q(ci2.ptr(),&v_work_sort_ind[0],or);

	Integer n_rep = number_dupl(ci2);
	SM out = eval_0_increasing(A,ci2,n_rep);

    Integer off = out.rep().offset();
	Integer* d_r = out.rep().ptr_r() + off;
	Integer d_nnz = out.nnz();
	for (Integer i = 0; i < d_nnz; ++i)
	{
		d_r[i] = v_work_sort_ind[d_r[i]];
	};

	utils::sort_q(out.rep().ptr_r() + off,out.rep().ptr_x() + off,d_nnz);

    out.get_struct().reset(true);
	return out;
};
template<class SM>
SM get_submatrix_functor_2<SM>::eval_1(const SM& A,const mmlib::details::colon_info& ci)
{
	if (ci.rows() == 0 || A.nnz() == 0)
	{
		SM out(A.get_ti(),ci.rows(),1);
        return out;
	};
	if (ci.r_start < ci.r_end)
	{
		return eval_1_increasing(A,ci);
	}
	else
	{
		return eval_1_decreasing(A,ci);
	};
};
template<class SM>
SM get_submatrix_functor_2<SM>::eval_1_increasing(const SM& A,const mmlib::details::colon_info& ci)
{
	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = ci.rows();
	const raw::details::spdat<value_type>& Ad = A.rep();

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(or)) + 1;

	raw::details::spdat<value_type> d(A.get_ti(),or,1, onnz);	

	if (or == 0 || A.nnz() == 0)
	{
		SM out = raw::sparse_matrix_base<value_type>(d);
        return out;
	};

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();

	Integer pos = 1, pos_val = ci.r_start, pos_row, pos_col;
	mmlib::details::pos2ind(pos_val,r,pos_row,pos_col);

    Integer * d_c				= d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();	

	d_c[0]						= 0;
	Integer nz					= 0;

	for (Integer j = 0; j < c; ++j)
	{
		if (j < pos_col)
		{
			continue;
		};
		Integer nnz_row			= Ad_c[j+1] - Ad_c[j];

		if (nz + nnz_row > d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row);
		
            d_c				= d.ptr_c();
			d_r				= d.ptr_r();
			d_x				= d.ptr_x();	
		};

		for (Integer i = Ad_c[j]; i < Ad_c[j+1];++i)
		{
			Integer p = Ad_r[i];
			if (p < pos_row)
			{
				continue;
			};
			while (p > pos_row)
			{
				++pos;
				pos_val += ci.r_step;
				if (pos > or)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(pos_val,r,pos_row,pos_col);
				if (j != pos_col)
				{
					goto exit_row_flag;
				};
			};
			while ( p == pos_row)
			{
				d_x[nz]		= Ad_x[i];
				d_r[nz]		= pos-1;
				++nz;

				++pos;
				pos_val += ci.r_step;
				if (pos > or)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(pos_val,r,pos_row,pos_col);
				if (j != pos_col)
				{
					goto exit_row_flag;
				};
			};
		};

		exit_row_flag:

		while (j == pos_col)
		{
			++pos;
			pos_val += ci.r_step;
			if (pos > or)
			{
				goto exit_flag;
			};
			mmlib::details::pos2ind(pos_val,r,pos_row,pos_col);
			if (j != pos_col)
			{
				break;
			};
		};
	};

  exit_flag:

	d_c[1] = nz;
	d.memadd(-1);

	return raw::sparse_matrix_base<value_type>(d);
};
template<class SM>
SM get_submatrix_functor_2<SM>::eval_1_decreasing(const SM& A,const mmlib::details::colon_info& ci)
{
	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = ci.rows();
	const raw::details::spdat<value_type>& Ad = A.rep();

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(or)) + 1;

	raw::details::spdat<value_type> d(A.get_ti(),ci.rows(),1, onnz);	

	if (ci.rows() == 0 || A.nnz() == 0)
	{
		SM out = raw::sparse_matrix_base<value_type>(d);
        return out;
	};

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();

    Integer * d_c				= d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();	

	d_c[0]						= 0;
	Integer nz					= 0;

	Integer pos = 1, pos_val = ci.r_start, pos_row, pos_col;
	mmlib::details::pos2ind(pos_val,r,pos_row,pos_col);

	for (Integer j = c-1; j >= 0; --j)
	{
		if (j > pos_col)
		{
			continue;
		};
		Integer nnz_row			= Ad_c[j+1] - Ad_c[j];

		if (nz + nnz_row > d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row);
            d_c				= d.ptr_c();
			d_r				= d.ptr_r();
			d_x				= d.ptr_x();	
		};

		for (Integer i = Ad_c[j+1] - 1; i >= Ad_c[j]; --i)
		{
			Integer p = Ad_r[i];
			if (p > pos_row)
			{
				continue;
			};
			while (p < pos_row)
			{
				++pos;
				pos_val += ci.r_step;
				if (pos > or)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(pos_val,r,pos_row,pos_col);
				if (j != pos_col)
				{
					goto exit_row_flag;
				};
			};
			while ( p == pos_row)
			{
				d_x[nz]		= Ad_x[i];
				d_r[nz]		= pos-1;
				++nz;

				++pos;
				pos_val += ci.r_step;
				if (pos > or)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(pos_val,r,pos_row,pos_col);
				if (j != pos_col)
				{
					goto exit_row_flag;
				};
			};
		};

		exit_row_flag:

		while (j == pos_col)
		{
			++pos;
			pos_val += ci.r_step;
			if (pos > or)
			{
				goto exit_flag;
			};
			mmlib::details::pos2ind(pos_val,r,pos_row,pos_col);
			if (j != pos_col)
			{
				break;
			};
		};
	};

  exit_flag:

	d_c[1] = nz;
	d.memadd(-1);

	return raw::sparse_matrix_base<value_type>(d);
};

template<class SM>
SM get_submatrix_functor_2<SM>::eval_0_increasing(const SM& A,const Vector& ci,Integer n_rep)
{
	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = ci.size();
	const raw::details::spdat<value_type>& Ad = A.rep();

	if (r == 0 || c == 0 || A.nnz() == 0)
	{
		SM out(A.get_ti(),ci.rows(), ci.cols());
        return out;
	};

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(or)) + 1;

	raw::details::spdat<value_type> d(A.get_ti(),ci.size(), 1, onnz);	

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();    

    const Integer* ptr_ci       = ci.ptr();

	Integer pos = 0, pos_row, pos_col;
	mmlib::details::pos2ind(ptr_ci[pos],r,pos_row,pos_col);

    Integer * d_c		        = d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();

	d_c[0]						= 0;
	Integer nz					= 0;

	for (Integer j = 0; j < c; ++j)
	{
		if (j < pos_col)
		{
			continue;
		};
		Integer nnz_row			= Ad_c[j+1] - Ad_c[j];

		if (nz + nnz_row + n_rep > d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row + n_rep);
            d_c					= d.ptr_c();
			d_r					= d.ptr_r();
			d_x					= d.ptr_x();	
		};

		for (Integer i = Ad_c[j]; i < Ad_c[j+1];++i)
		{
			Integer p = Ad_r[i];
			if (p < pos_row)
			{
				continue;
			};
			while (p > pos_row)
			{
				++pos;
				if (pos >= or)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(ptr_ci[pos],r,pos_row,pos_col);
				if (j != pos_col)
				{
					goto exit_row_flag;
				};
			};
			while ( p == pos_row)
			{
				d_x[nz]		= Ad_x[i];
				d_r[nz]		= pos;
				++nz;

				++pos;
				if (pos >= or)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(ptr_ci[pos],r,pos_row,pos_col);
				if (j != pos_col)
				{
					goto exit_row_flag;
				};
			};
		};

		exit_row_flag:

		while (j == pos_col)
		{
			++pos;
			if (pos >= or)
			{
				goto exit_flag;
			};
			mmlib::details::pos2ind(ptr_ci[pos],r,pos_row,pos_col);
			if (j != pos_col)
			{
				break;
			};
		};
	};

  exit_flag:

	d_c[1] = nz;
	d.memadd(-1);

	SM out = raw::sparse_matrix_base<value_type>(d);	
	return out;
};
template<class SM>
SM get_submatrix_functor_2<SM>::eval_0_decreasing(const SM& A,const Vector& ci,Integer n_rep)
{
	typedef SM::value_type value_type;

	Integer r = A.rows(), c = A.cols();
	Integer or = ci.size();
	const raw::details::spdat<value_type>& Ad = A.rep();

	Integer onnz = icast(Real(A.nnz())/Real(r)/Real(c)*Real(or)) + 1;

	raw::details::spdat<value_type> d(A.get_ti(),ci.size(), 1, onnz);	

	if (A.nnz() == 0)
	{
		SM out = raw::sparse_matrix_base<value_type>(d);
        return out;
	};

	const Integer * Ad_c		= Ad.ptr_c();
	const Integer * Ad_r		= Ad.ptr_r();
	const value_type * Ad_x		= Ad.ptr_x();

    Integer * d_c				= d.ptr_c();
	Integer * d_r				= d.ptr_r();
	value_type * d_x			= d.ptr_x();	

	d_c[0]						= 0;
	Integer nz					= 0;

    const Integer* ptr_ci       = ci.ptr();

	Integer pos = 0, pos_row, pos_col;
	mmlib::details::pos2ind(ptr_ci[pos],r,pos_row,pos_col);

	for (Integer j = c-1; j >= 0; --j)
	{
		if (j > pos_col)
		{
			continue;
		};
		Integer nnz_row			= Ad_c[j+1] - Ad_c[j];

		if (nz + nnz_row + n_rep > d.nzmax()) 
		{
			d.memadd( d.nzmax() + nnz_row + n_rep);
            d_c				= d.ptr_c();
			d_r				= d.ptr_r();
			d_x				= d.ptr_x();	
		};

		for (Integer i = Ad_c[j+1] - 1; i >= Ad_c[j]; --i)
		{
			Integer p = Ad_r[i];
			if (p > pos_row)
			{
				continue;
			};
			while (p < pos_row)
			{
				++pos;
				if (pos >= or)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(ptr_ci[pos],r,pos_row,pos_col);
				if (j != pos_col)
				{
					goto exit_row_flag;
				};
			};
			while ( p == pos_row)
			{
				d_x[nz]		= Ad_x[i];
				d_r[nz]		= pos;
				++nz;

				++pos;
				if (pos >= or)
				{
					goto exit_flag;
				};
				mmlib::details::pos2ind(ptr_ci[pos],r,pos_row,pos_col);
				if (j != pos_col)
				{
					goto exit_row_flag;
				};
			};
		};

		exit_row_flag:

		while (j == pos_col)
		{
			++pos;
			if (pos >= or)
			{
				goto exit_flag;
			};
			mmlib::details::pos2ind(ptr_ci[pos],r,pos_row,pos_col);
			if (j != pos_col)
			{
				break;
			};
		};
	};

  exit_flag:

	d_c[1] = nz;
	d.memadd(-1);

	return raw::sparse_matrix_base<value_type>(d);
};

template struct get_submatrix_functor<raw::IntegerSparseMatrix>;
template struct get_submatrix_functor<raw::RealSparseMatrix>;
template struct get_submatrix_functor<raw::ComplexSparseMatrix>;
template struct get_submatrix_functor<raw::ObjectSparseMatrix>;

template struct get_submatrix_functor_2<raw::IntegerSparseMatrix>;
template struct get_submatrix_functor_2<raw::RealSparseMatrix>;
template struct get_submatrix_functor_2<raw::ComplexSparseMatrix>;
template struct get_submatrix_functor_2<raw::ObjectSparseMatrix>;

};};};
