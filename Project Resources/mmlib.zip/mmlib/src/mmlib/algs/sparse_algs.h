/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/config.h"
#include "mmlib/base/colon_info.h"

namespace mmlib { namespace algorithm
{
	namespace details
	{
		template<class SM>
		struct MMLIB_EXPORT drop_entries_functor
		{
			static SM eval(SM& mat,const mmlib::details::colon_info&);
		};
		template<class SM>
		struct MMLIB_EXPORT drop_entries_functor_2
		{
			static SM eval(SM& mat,const mmlib::details::colon_info&);
		};
		template<class SM>
		struct MMLIB_EXPORT change_entries_functor
		{
			typedef typename SM::value_type value_type;
			static SM eval(SM& mat,const mmlib::details::colon_info& ci, value_type val);
		};
		template<class SM>
		struct MMLIB_EXPORT change_entries_functor_2
		{
			typedef typename SM::value_type value_type;
			static SM eval(SM& mat,const mmlib::details::colon_info& ci, value_type val);
		};
		template<class SM>
		struct get_submatrix_functor
		{
			public:
				typedef raw::IntegerMatrix Vector;

				static SM eval(const SM& mat,const mmlib::details::colon_info& ci);

			private:
				static SM eval_00(const SM& mat,const Vector& ri,const Vector& ci);
				static SM eval_01(const SM& mat,const mmlib::details::colon_info& ci);
				static SM eval_10(const SM& mat,const mmlib::details::colon_info& ci);
				static SM eval_11(const SM& mat,const mmlib::details::colon_info& ci);

				static SM get_cols_0(const SM& mat,const mmlib::details::colon_info& ci);
				static SM get_cols_1(const SM& mat,const mmlib::details::colon_info& ci);
		};
		template<class SM>
		struct get_submatrix_functor_2
		{
			public:
				static SM eval(const SM& mat,const mmlib::details::colon_info& ci);

			private:
				typedef raw::IntegerMatrix Vector;

				static SM eval_0(const SM& mat,const Vector& ri);
				static SM eval_1(const SM& mat,const mmlib::details::colon_info& ci);

				static SM eval_0_increasing(const SM& mat,const Vector& ri, Integer n_rep);
				static SM eval_0_decreasing(const SM& mat,const Vector& ri, Integer n_rep);
				static SM eval_1_increasing(const SM& mat,const mmlib::details::colon_info& ci);
				static SM eval_1_decreasing(const SM& mat,const mmlib::details::colon_info& ci);
		};
		template<class SM1,class SM2>
		struct change_submatrix_functor
		{
			public:
				static SM1 eval(const SM1& mat, const mmlib::details::colon_info& ci,const SM2& mat2);
		};
		template<class SM1,class SM2>
		struct change_submatrix_functor_2
		{
			public:
				static SM1 eval(const SM1& mat,const mmlib::details::colon_info& ci,const SM2& mat2);
		};

		template<class SM1,class DM2>
		struct change_submatrix_dense_functor
		{
			public:
				static SM1 eval(const SM1& mat, const mmlib::details::colon_info& ci,const DM2& mat2);
		};
		template<class SM1,class DM2>
		struct change_submatrix_dense_functor_2
		{
			public:
				static SM1 eval(const SM1& mat,const mmlib::details::colon_info& ci,const DM2& mat2);
		};

		template<class SM1,class DM2>
		struct change_submatrix_band_functor
		{
			public:
				static SM1 eval(const SM1& mat, const mmlib::details::colon_info& ci,const DM2& mat2);
		};
		template<class SM1,class DM2>
		struct change_submatrix_band_functor_2
		{
			public:
				static SM1 eval(const SM1& mat,const mmlib::details::colon_info& ci,const DM2& mat2);
		};
		template<class SM>
		struct del_rows_sparse_functor
		{
			static SM eval(const SM& mat,const mmlib::details::colon_info& ci);
		};
		template<class SM>
		struct del_cols_sparse_functor
		{
			static SM eval(const SM& mat,const mmlib::details::colon_info& ci);
		};
		template<class value_type>
		struct MMLIB_EXPORT sparse_change_diag_functor
		{
            typedef raw::Matrix<value_type,struct_dense> DM;
            typedef raw::Matrix<value_type,struct_sparse> SM;
			static SM eval(SM& mat, Integer d, const DM& val);
            static SM eval(SM& mat, Integer d, const value_type& val);
		};

	};

//removes entries A(r,c) given by vectors of rows and columns
template<class value_type>
raw::Matrix<value_type,struct_sparse>
drop_entries(raw::Matrix<value_type,struct_sparse>& mat,
				  const mmlib::details::colon_info& ci)
{
	typedef raw::Matrix<value_type,struct_sparse> SparseMatrix;
	return details::drop_entries_functor<SparseMatrix>::eval(mat,ci);
};
//removes entries A(r_i,c_i), i=1..s, where r, c are vectors of row and column indices with number of elements s
template<class value_type>
raw::Matrix<value_type,struct_sparse> 
drop_entries_2(raw::Matrix<value_type,struct_sparse>& mat,
				    const mmlib::details::colon_info& ci)
{
	typedef raw::Matrix<value_type,struct_sparse> SparseMatrix;
	return details::drop_entries_functor_2<SparseMatrix>::eval(mat,ci);
};

//eval A(r,c) = val for given vectors of rows and columns
template<class value_type>
raw::Matrix<value_type,struct_sparse>
change_entries(raw::Matrix<value_type,struct_sparse>& mat,
				  const mmlib::details::colon_info& ci, value_type val)
{
	typedef raw::Matrix<value_type,struct_sparse> SparseMatrix;
	return details::change_entries_functor<SparseMatrix>::eval(mat,ci,val);
};
//eval A(r_i,c_i) = val, i=1..s, where r, c are vectors of row and column indices with number of elements s
template<class value_type>
raw::Matrix<value_type,struct_sparse>
change_entries_2(raw::Matrix<value_type,struct_sparse>& mat,
				  const mmlib::details::colon_info& ci, value_type val)
{
	typedef raw::Matrix<value_type,struct_sparse> SparseMatrix;
	return details::change_entries_functor_2<SparseMatrix>::eval(mat,ci,val);
};

//eval A(r,c) for given vectors of row and column indices
template<class value_type>
raw::Matrix<value_type,struct_sparse>
get_submatrix(const raw::Matrix<value_type,struct_sparse>& mat,
				  const mmlib::details::colon_info& ci)
{
	typedef raw::Matrix<value_type,struct_sparse> SparseMatrix;
	return details::get_submatrix_functor<SparseMatrix>::eval(mat,ci);
};

//eval B(i,1) = A(r_i,c_i), i=1..s, where r, c are vectors of row and column indices with number of elements s
template<class value_type>
raw::Matrix<value_type,struct_sparse>
get_submatrix_2(const raw::Matrix<value_type,struct_sparse>& mat,
				const mmlib::details::colon_info& ci)
{
	typedef raw::Matrix<value_type,struct_sparse> SparseMatrix;
	return details::get_submatrix_functor_2<SparseMatrix>::eval(mat,ci);
};

//eval A(r,c) = B, where r, c are vectors of row and column indices
template<class value_type_1,class value_type_2>
raw::Matrix<value_type_1,struct_sparse>
change_submatrix(const raw::Matrix<value_type_1,struct_sparse>& mat,
				   const mmlib::details::colon_info& ci,
				   const raw::Matrix<value_type_2,struct_sparse>& mat_2)
{
	typedef raw::Matrix<value_type_1,struct_sparse> SparseMatrix_1;
	typedef raw::Matrix<value_type_2,struct_sparse> SparseMatrix_2;
	return details::change_submatrix_functor<SparseMatrix_1,SparseMatrix_2>::eval(mat,ci,mat_2);
};

//eval A(r_i,c_i) = B(i,1), i=1..s, where r, c are vectors of row and column indices with number of elements s
template<class value_type_1,class value_type_2>
raw::Matrix<value_type_1,struct_sparse>
change_submatrix_2(const raw::Matrix<value_type_1,struct_sparse>& mat,
				  const mmlib::details::colon_info& ci,
				  const raw::Matrix<value_type_2,struct_sparse>& mat_2)
{
	typedef raw::Matrix<value_type_1,struct_sparse> SparseMatrix_1;
	typedef raw::Matrix<value_type_2,struct_sparse> SparseMatrix_2;
	return details::change_submatrix_functor_2<SparseMatrix_1,SparseMatrix_2>::eval(mat,ci,mat_2);
};

//eval A(r,c) = B, where r, c are vectors of row and column indices, B is a dense matrix
template<class value_type_1,class value_type_2>
raw::Matrix<value_type_1,struct_sparse>
change_submatrix_dense(const raw::Matrix<value_type_1,struct_sparse>& mat,
				   const mmlib::details::colon_info& ci,
				   const raw::Matrix<value_type_2,struct_dense>& mat_2)
{
	typedef raw::Matrix<value_type_1,struct_sparse> SparseMatrix_1;
	typedef raw::Matrix<value_type_2,struct_dense>  DenseMatrix_2;
	return details::change_submatrix_dense_functor<SparseMatrix_1,DenseMatrix_2>::eval(mat,ci,mat_2);
};

//eval A(r_i,c_i) = B(i,1), i=1..s, where r, c are vectors of row and column indices with number of elements s
//B is a dense matrix
template<class value_type_1,class value_type_2>
raw::Matrix<value_type_1,struct_sparse> 
change_submatrix_dense_2(const raw::Matrix<value_type_1,struct_sparse>& mat,
				  const mmlib::details::colon_info& ci,
				  const raw::Matrix<value_type_2,struct_dense>& mat_2)
{
	typedef raw::Matrix<value_type_1,struct_sparse> SparseMatrix_1;
	typedef raw::Matrix<value_type_2,struct_dense>  DenseMatrix_2;
	return details::change_submatrix_dense_functor_2<SparseMatrix_1,DenseMatrix_2>::eval(mat,ci,mat_2);
};

//eval A(r,c) = B, where r, c are vectors of row and column indices, B is a banded matrix
template<class value_type_1,class value_type_2>
raw::Matrix<value_type_1,struct_sparse>
change_submatrix_band(const raw::Matrix<value_type_1,struct_sparse>& mat,
				   const mmlib::details::colon_info& ci,
				   const raw::Matrix<value_type_2,struct_banded>& mat_2)
{
	typedef raw::Matrix<value_type_1,struct_sparse> SparseMatrix_1;
	typedef raw::Matrix<value_type_2,struct_banded>  DenseMatrix_2;
	return details::change_submatrix_band_functor<SparseMatrix_1,DenseMatrix_2>::eval(mat,ci,mat_2);
};

//eval A(r_i,c_i) = B(i,1), i=1..s, where r, c are vectors of row and column indices with number of elements s
//B is a band matrix
template<class value_type_1,class value_type_2>
raw::Matrix<value_type_1,struct_sparse>
change_submatrix_band_2(const raw::Matrix<value_type_1,struct_sparse>& mat,
				  const mmlib::details::colon_info& ci,
				  const raw::Matrix<value_type_2,struct_banded>& mat_2)
{
	typedef raw::Matrix<value_type_1,struct_sparse> SparseMatrix_1;
	typedef raw::Matrix<value_type_2,struct_banded>  DenseMatrix_2;
	return details::change_submatrix_band_functor_2<SparseMatrix_1,DenseMatrix_2>::eval(mat,ci,mat_2);
};

//eval A(c_i,:) = []
template<class value_type>
raw::Matrix<value_type,struct_sparse> 
del_rows_sparse(const raw::Matrix<value_type,struct_sparse>& mat,
				  const mmlib::details::colon_info& ci)
{
	typedef raw::Matrix<value_type,struct_sparse> SparseMatrix;
	return details::del_rows_sparse_functor<SparseMatrix>::eval(mat,ci);
};
//eval A(:,c_i) = []
template<class value_type>
raw::Matrix<value_type,struct_sparse> 
del_cols_sparse(const raw::Matrix<value_type,struct_sparse>& mat,
				  const mmlib::details::colon_info& ci)
{
	typedef raw::Matrix<value_type,struct_sparse> SparseMatrix;
	return details::del_cols_sparse_functor<SparseMatrix>::eval(mat,ci);
};

//eval A(d) = val for given diagonal
template<class value_type>
raw::Matrix<value_type,struct_sparse>
sparse_change_diag(raw::Matrix<value_type,struct_sparse>& mat, Integer d, value_type val)
{
	return details::sparse_change_diag_functor<value_type>::eval(mat,d,val);
};

//eval A(d) = mat for given diagonal
template<class value_type>
raw::Matrix<value_type,struct_sparse>
sparse_change_diag(raw::Matrix<value_type,struct_sparse>& mat, Integer d, 
                       const raw::Matrix<value_type,struct_dense>& val)
{
	return details::sparse_change_diag_functor<value_type>::eval(mat,d,val);
};

};};