/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/container/raw/type_decl.h"
#include "mmlib/base/colon_info.h"

namespace mmlib { namespace algorithm
{

	namespace details
	{
		template<class value_type>
		struct del_rows_banded_functor
		{
			typedef raw::Matrix<value_type,struct_sparse> SM;
			typedef raw::Matrix<value_type,struct_banded> BM;
			static SM eval(const BM& mat,const mmlib::details::colon_info& ci);
		};
		template<class value_type>
		struct del_cols_banded_functor
		{
			typedef raw::Matrix<value_type,struct_sparse> SM;
			typedef raw::Matrix<value_type,struct_banded> BM;
			static SM eval(const BM& mat,const mmlib::details::colon_info& ci);
		};
		template<class value_type>
		struct MMLIB_EXPORT band_change_diag_functor
		{
            typedef raw::Matrix<value_type,struct_dense> DM;
            typedef raw::Matrix<value_type,struct_banded> BM;
			static BM eval(const BM& mat, Integer d, const DM& val);
            static BM eval(const BM& mat, Integer d, const value_type& val);
		};
	};

//eval A(c_i,:) = []
template<class value_type>
raw::Matrix<value_type,struct_sparse> 
del_rows_banded(const raw::Matrix<value_type,struct_banded>& mat,
				  const mmlib::details::colon_info& ci)
{
	return details::del_rows_banded_functor<value_type>::eval(mat,ci);
};
//eval A(:,c_i) = []
template<class value_type>
raw::Matrix<value_type,struct_sparse> 
del_cols_banded(const raw::Matrix<value_type,struct_banded>& mat,
				  const mmlib::details::colon_info& ci)
{
	return details::del_cols_banded_functor<value_type>::eval(mat,ci);
};

//eval A(d) = val for given diagonal
template<class value_type>
raw::Matrix<value_type,struct_banded>
band_change_diag(const raw::Matrix<value_type,struct_banded>& mat, Integer d, value_type val)
{
	return details::band_change_diag_functor<value_type>::eval(mat,d,val);
};


//eval A(d) = mat for given diagonal
template<class value_type>
raw::Matrix<value_type,struct_banded>
band_change_diag(const raw::Matrix<value_type,struct_banded>& mat, Integer d, 
                       const raw::Matrix<value_type,struct_dense>& val)
{
	return details::band_change_diag_functor<value_type>::eval(mat,d,val);
};


};};