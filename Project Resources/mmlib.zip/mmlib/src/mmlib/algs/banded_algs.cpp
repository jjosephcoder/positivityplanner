/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
 
#pragma once

#include "mmlib/algs/banded_algs.h"
#include "mmlib/func/raw/converter.h"
#include "mmlib/utils/sort.h"
#include "mmlib/error/error_check.h"
#include <vector>
#include "mmlib/details/matrix_func_binary.inl"
#include "mmlib/details/matrix_func_unary.inl"
#include "mmlib/utils/utils.h"

namespace mmlib { namespace algorithm { namespace details
{

template<class value_type>
typename del_rows_banded_functor<value_type>::SM
del_rows_banded_functor<value_type>::eval(const BM& mat,const mmlib::details::colon_info& ci)
{
	Integer s = ci.rows();
	if (s == 0)
	{
		return mmlib::raw::converter<SM,BM>::eval(mat.get_ti(),mat);
	};

	Integer r0 = mat.rows(), c0 = mat.cols();

	if (ci.r_flag == 0)
	{		
		raw::IntegerMatrix ritmp = ci.get_ri();
        const Integer* ptr_r = ritmp.ptr();

		Integer ce = ptr_r[0];
		error::check_row(ce, r0, c0);

		std::vector<Integer> iwork(r0);
		for (Integer i = 0; i < s; ++i)
		{
			Integer ce2 = ptr_r[i];
			error::check_row(ce2, r0, c0);
			iwork[ce2-1] = -1;
		};
		Integer n_del = 0;
		for (Integer i = 0; i < r0; ++i)
		{
			if (iwork[i] == -1)
			{
				++n_del;
			}
			else
			{
				iwork[i] = i-n_del;
			};
		};

		if (!c0)
		{
			SM out(mat.get_ti(),r0-n_del,0);
            return out;
		};

		if (n_del == r0)
		{
			SM out(mat.get_ti(),0,c0);
            return out;
		};

		Integer r1 = r0 - n_del;		
		SM out(mat.get_ti(),r1,c0,mat.nnz());

		raw::details::spdat<value_type>& d = out.rep();
		Integer* d_c = d.ptr_c();
		Integer* d_r = d.ptr_r();
		value_type* d_x = d.ptr_x();
        const value_type* mat_ptr = mat.rep_ptr();

		Integer nz = 0;

		for (Integer j = 0, jj = 0; j < c0; ++j, jj += mat.ld())
		{
			d_c[j] = nz;

			Integer fr = mat.first_row(j);
			Integer lr = mat.last_row(j);
			Integer ii = jj + mat.first_elem_pos(j);
			for (Integer i = fr; i <= lr; ++i,++ii)
			{
				Integer np = iwork[i];
				if (np != -1)
				{
					value_type tmp = mat_ptr[ii];
					if (mmlib::details::is_zero(tmp))
					{
						continue;
					};
					d_r[nz] = np;
					d_x[nz] = tmp;
					++nz;
				};
			};
		};
		d_c[c0] = nz;
    	d.memadd(-1);

		return out;
	}
	else
	{
		Integer ne = s;
		if (!c0)
		{
			SM out(mat.get_ti(),r0-ne,0);
            return out;
		};

		if (ne == r0)
		{
			SM out(mat.get_ti(),0,c0);
            return out;
		};

		Integer r1 = r0 - ne;		
		SM out(mat.get_ti(),r1,c0,mat.nnz());

		raw::details::spdat<value_type>& d = out.rep();
		Integer* d_c = d.ptr_c();
		Integer* d_r = d.ptr_r();
		value_type* d_x = d.ptr_x();
        const value_type* mat_ptr = mat.rep_ptr();

		Integer rs = ci.r_step, rf, rl;
		if (rs < 0)
		{
			rs = -rs;
			rf = ci.r_end;
			rl = ci.r_start;
		}
		else
		{
			rf = ci.r_start;		
			rl = ci.r_end;
		};

        //make it 0-based
        rf = rf - 1;
        rl = rl - 1;

		Integer nz = 0;
		for (Integer j = 0, jj = 0; j < c0; ++j, jj += mat.ld())
		{
			d_c[j] = nz;

			Integer fr = mat.first_row(j);
			Integer lr = mat.last_row(j);
			Integer ii = jj + mat.first_elem_pos(j);
			Integer n_del = 0;
			if (fr > rf)
			{
				if (fr < rl)
				{
					n_del = 1+(fr-rf)/rs;
					if ((fr-rf)%rs == 0)
					{
						--n_del;
					};
				}
				else if (fr == rl)
				{
					n_del = ci.r_size - 1;
				}
				else
				{
					n_del = ci.r_size;
				};
			};

			for (Integer i = fr; i <= lr; ++i, ++ii)
			{
				if (i >= rf && i <= rl && (i-rf)%rs == 0)
				{
					++n_del;
					continue;
				};
				value_type tmp = mat_ptr[ii];
				if (mmlib::details::is_zero(tmp))
				{
					continue;
				};
				d_r[nz] = i-n_del;
				d_x[nz] = tmp;
				++nz;
			};
		};
		d_c[c0] = nz;
		d.memadd(-1);

		return out;
	};
};

template<class value_type>
typename del_cols_banded_functor<value_type>::SM
del_cols_banded_functor<value_type>::eval(const BM& mat,const mmlib::details::colon_info& ci)
{
	Integer s = ci.rows();
	if (s == 0)
	{
        return mmlib::raw::converter<SM,BM>::eval(mat.get_ti(),mat);
	};

	Integer r0 = mat.rows(), c0 = mat.cols();

	if (ci.r_flag == 0)
	{		
		raw::IntegerMatrix ritmp = ci.get_ri().copy();
        const Integer* ptr_r = ritmp.ptr();

        ritmp.get_struct().reset(false);

		mmlib::utils::sort_q(ritmp.ptr(),s);

		Integer ce = ptr_r[0];
		error::check_col(ce, r0, c0);
		Integer ne = 1;

		for (Integer i = 1; i < s; ++i)
		{
			Integer ce2 = ptr_r[i];
			error::check_col(ce2, r0, c0);
			if (ce2 != ce)
			{
				++ne;
			};
			ce = ce2;
		}

		if (!r0)
		{
			SM out(mat.get_ti(),0,c0-ne);
            return out;
		};

		if (ne == c0)
		{
			SM out(mat.get_ti(),r0,0);
            return out;
		};

		Integer c1 = c0 - ne;		
		Integer nnz = mat.nnz();
		SM out(mat.get_ti(),r0,c1,nnz);

		raw::details::spdat<value_type>& d = out.rep();
		Integer* d_c        = d.ptr_c();
		Integer* d_r        = d.ptr_r();
		value_type* d_x     = d.ptr_x();
        const value_type* mat_ptr = mat.rep_ptr();

		Integer nz = 0;
		for (Integer j = 0, k = 0, col = 0; j < c0; ++j)
		{
			if (j == ptr_r[k]-1)
			{
				while (j == ptr_r[k]-1)
				{
					++k;
				};
			}
			else
			{
				d_c[col] = nz;
				Integer fr = mat.first_row(j);
				Integer lr = mat.last_row(j);
				Integer ii = mat.first_elem_pos(j);

				for (Integer i = fr; i <= lr; ++i, ++ii)
				{			
					value_type tmp = mat_ptr[ii];
                    if (mmlib::details::is_zero(tmp))
					{
						continue;
					};
					d_r[nz] = i;
					d_x[nz] = tmp;
					++nz;
				};
				++col;
			};
            mat_ptr += mat.ld();
		};

		d_c[c1] = nz;
		d.memadd(-1);

		return out;
	}
	else
	{
		Integer ne = s;
		if (!r0)
		{
			SM out(mat.get_ti(),0,c0-ne);
            return out;
		};

		if (ne == c0)
		{
			SM out(mat.get_ti(),r0,0);
            return out;
		};

		Integer nnz = mat.nnz();
		Integer c1 = c0 - ne;
		SM out(mat.get_ti(),r0,c1,nnz);

		raw::details::spdat<value_type>& d = out.rep();
		Integer* d_c = d.ptr_c();
		Integer* d_r = d.ptr_r();
		value_type* d_x = d.ptr_x();
        const value_type* mat_ptr = mat.rep_ptr();

		Integer cs = ci.r_step, cf, cl;
		if (cs < 0)
		{
			cs = -cs;
			cf = ci.r_end;
			cl = ci.r_start;
		}
		else
		{
			cf = ci.r_start;		
			cl = ci.r_end;
		};

        //make it 0-based
        --cf;
        --cl;

		Integer jj = 0, nz = 0, col = 0;
		for (Integer j = 0; j < cf; ++j, jj += mat.ld())
		{
			d_c[col] = nz;

			Integer fr = mat.first_row(j);
			Integer lr = mat.last_row(j);
			Integer ii = jj + mat.first_elem_pos(j);

			for (Integer i = fr; i <= lr; ++i, ++ii)
			{			
				value_type tmp = mat_ptr[ii];
				if (mmlib::details::is_zero(tmp))
				{
					continue;
				};
				d_r[nz] = i;
				d_x[nz] = tmp;
				++nz;
			};

            ++col;
		};
		if (cs == 1)
		{
			jj += imult(ne,mat.ld());
		}
		else
		{
			for (Integer j = cf; j <= cl; ++j, jj += mat.ld())
			{
                d_c[col] = nz;

				if (((j-cf) % cs) == 0)
				{
					continue;
				};				

				Integer fr = mat.first_row(j);
				Integer lr = mat.last_row(j);
				Integer ii = jj + mat.first_elem_pos(j);

				for (Integer i = fr; i <= lr; ++i, ++ii)
				{			
					value_type tmp = mat_ptr[ii];
					if (mmlib::details::is_zero(tmp))
					{
						continue;
					};
					d_r[nz] = i;
					d_x[nz] = tmp;
					++nz;
				};

                ++col;
			};
		};
		for (Integer j = cl+1; j < c0; ++j, jj += mat.ld())
		{
			d_c[col] = nz;

			Integer fr = mat.first_row(j);
			Integer lr = mat.last_row(j);
			Integer ii = jj + mat.first_elem_pos(j);

			for (Integer i = fr; i <= lr; ++i, ++ii)
			{			
				value_type tmp = mat_ptr[ii];
				if (mmlib::details::is_zero(tmp))
				{
					continue;
				};
				d_r[nz] = i;
				d_x[nz] = tmp;
				++nz;
			};

            ++col;
		};

		d_c[c1] = nz;
		d.memadd(-1);

		return out;
	};
};

template<class V>
raw::Matrix<V,struct_banded> band_change_diag_functor<V>::eval(const BM& mat, Integer d, const DM& val)
{    
    Integer r = mat.rows();
    Integer c = mat.cols();
    Integer ld = mat.ldiags();
    Integer ud = mat.udiags();

    error::check_diag(d,r,c);

	Integer s, st;

    if (d > 0)
    {
        s = std::min(c - d, r);
    }
    else
    {
        s = std::min(r + d, c);
    }

    error::check_assign(s,1,val.size(),1);

	if (s == 0)
	{
		return mat;
	};

    BM A(mat.get_ti());
	if (d > ud)
	{
        ud = d;
        A.assign(mat.resize(mat.rows(),mat.cols(),ld,ud));
	}
	else if (-d > ld)
	{
        ld = -d;
        A.assign(mat.resize(mat.rows(),mat.cols(),ld,ud));
	}
    else
    {
        A.assign(mat);
    };

    if (d > 0)
    {
        st = imult(d,A.ld()) + ud - d;
    }
    else
    {
        st = ud - d;
    }
	
    DM val_tmp = val.make_explicit();
    const V* val_ptr = val_tmp.ptr();

    V * ptr_this = A.rep_ptr() + st;

    for (Integer i = 0; i < s; ++i)
	{
		*(ptr_this) = (*val_ptr);
		ptr_this += A.ld();
        val_ptr  += 1;
	};

    A.set_struct(mat.get_struct().get_set_diag(d,struct_flag::v_general));
    return A;
};
template<class V>
raw::Matrix<V,struct_banded> band_change_diag_functor<V>::eval(const BM& mat, Integer d, const V& val)
{
    Integer r = mat.rows();
    Integer c = mat.cols();
    Integer ld = mat.ldiags();
    Integer ud = mat.udiags();

    error::check_diag(d,r,c);
	
	Integer s, st;

    if (d > 0)
    {
        s = std::min(c - d, r);
    }
    else
    {
        s = std::min(r + d, c);
    }

	if (s == 0)
	{
        error::check_assign(s,1,1,1);
		return mat;
	};

    BM A(mat.get_ti());
	if (d > ud)
	{
        if (gd::is_zero(val))
        {
            return mat;
        };
        ud = d;
        A.assign(mat.resize(mat.rows(),mat.cols(),ld,ud));
	}
	else if (-d > ld)
	{
        ld = -d;
        if (gd::is_zero(val))
        {
            return mat;
        };
        A.assign(mat.resize(mat.rows(),mat.cols(),ld,ud));
	}
    else
    {
        A.assign(mat);
    };

    if (d > 0)
    {
        st = imult(d,A.ld()) + ud + 1 - d;
    }
    else
    {
        st = ud + 1 - d;
    }

    Integer lda  = A.ld();
	V * ptr_this = A.rep_ptr() + st - 1;

    for (Integer i = 0; i < s; ++i)
	{
		*(ptr_this) = val;
		ptr_this += lda;
	};

    struct_flag::value_type vt = struct_flag::get_value_type(val);
    A.set_struct(mat.get_struct().get_set_diag(d,vt));
    return A;
};


};};};

template struct mmlib::algorithm::details::del_cols_banded_functor<mmlib::Integer>;
template struct mmlib::algorithm::details::del_cols_banded_functor<mmlib::Real>;
template struct mmlib::algorithm::details::del_cols_banded_functor<mmlib::Complex>;
template struct mmlib::algorithm::details::del_cols_banded_functor<mmlib::Object>;

template struct mmlib::algorithm::details::del_rows_banded_functor<mmlib::Integer>;
template struct mmlib::algorithm::details::del_rows_banded_functor<mmlib::Real>;
template struct mmlib::algorithm::details::del_rows_banded_functor<mmlib::Complex>;
template struct mmlib::algorithm::details::del_rows_banded_functor<mmlib::Object>;

template struct mmlib::algorithm::details::band_change_diag_functor<mmlib::Integer>;
template struct mmlib::algorithm::details::band_change_diag_functor<mmlib::Real>;
template struct mmlib::algorithm::details::band_change_diag_functor<mmlib::Complex>;
template struct mmlib::algorithm::details::band_change_diag_functor<mmlib::Object>;
