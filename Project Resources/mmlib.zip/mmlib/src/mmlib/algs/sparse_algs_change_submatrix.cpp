/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/algs/sparse_algs.h"
#include "mmlib/algs/sparse_algs_utils.h"
#include "mmlib/error/error_check.h"
#include "mmlib/utils/sort.h"
#include <algorithm>
#include "mmlib/base/colon_info.h"
#include "mmlib/func/raw/converter.h"
#include "mmlib/func/raw/raw_manip.h"
#include "mmlib/base/sort_iterator.h"
#include "mmlib/details/matrix_func_binary.inl"

namespace mmlib { namespace algorithm { namespace details
{
template<class T>
class elem_getter1
{
	private:
		typedef mmlib::raw::Matrix<T,struct_sparse> SM;

		const SM&		A;
		const Integer * d_c;
		const Integer * d_r;
		const T *		d_x;
		Integer			step;
		Integer			pos_f;
		Integer			pos_l;
		Integer			row;
		Integer			elem;

	public:
		elem_getter1(const SM& A, bool decr)
			:A(A)
		{
			const raw::details::spdat<T>& Ad = A.rep();
			d_c	= Ad.ptr_c();
			d_r	= Ad.ptr_r();
			d_x	= Ad.ptr_x();
			
			if (decr)
			{
				step	= -1;
			}
			else
			{
				step	= 1;
			};
		};
		void set_col(Integer col)
		{		
			if (step < 0)
			{
				pos_f	= d_c[col]-1;
				pos_l	= d_c[col-1]-1;
				elem	= A.rows()-1;
			}
			else
			{
				pos_f	= d_c[col-1];
				pos_l	= d_c[col];
				elem	= 0;
			};
			if (pos_f == pos_l)
			{
				row	= -1;
			}
			else
			{
				row		= d_r[pos_f];	
			};						
		};

		T	get()
		{			
			if (pos_f == pos_l)
			{
				return mmlib::details::default_value<T>(A.get_ti());
			};
			T value = mmlib::details::default_value<T>(A.get_ti());
			if (elem == row)
			{
				value	= d_x[pos_f];
				pos_f	+= step;
				row		= d_r[pos_f];				
			}
			else
			{
				value	= mmlib::details::default_value<T>(A.get_ti());
			};			
			elem	+= step;
			return value;
		};
	private:
		elem_getter1(const elem_getter1&);
		elem_getter1& operator=(const elem_getter1&);
};
template<class T>
class elem_getter2
{
	private:
		typedef raw::Matrix<T,struct_sparse> SM;

		const SM&		A;
		const Integer * d_c;
		const Integer * d_r;
		const T *		d_x;

		Integer			m_rf;
		Integer			m_rf0;
		Integer			m_rl;
		Integer			m_rs;
		Integer			step;

		Integer			pos_f;
		Integer			pos_l;

	public:
		elem_getter2(const SM& A, Integer rf, Integer rs, Integer rl)
			:A(A)
		{
			const raw::details::spdat<T>& Ad = A.rep();
			d_c	= Ad.ptr_c();
			d_r	= Ad.ptr_r();
			d_x	= Ad.ptr_x();
			
			m_rf0	= rf;
			m_rs	= rs;
			if (rs < 0)
			{
				m_rf	= rl;
				m_rl	= rf;
				step	= -1;
			}
			else
			{	
				step	= 1;
				m_rf	= rf;
				m_rl	= rl;
			};
		};
		void set_col(Integer col, Integer& k)
		{		
			if (m_rs < 0)
			{
				pos_f	= d_c[col]-1;
				pos_l	= d_c[col-1]-1;			
			}
			else
			{
				pos_f	= d_c[col-1];
				pos_l	= d_c[col];
			};
			if (pos_f == pos_l)
			{
				k			= m_rl+1;
			}
			else
			{
				Integer r	= d_r[pos_f];
				k			= m_rf0 + imult(r,m_rs);
			};		
		};

		T	get(Integer& k)
		{			
			T value		= d_x[pos_f];			
			pos_f		+= step;

			if (pos_f == pos_l)
			{				
				k = m_rl+1;
			}
			else
			{
				Integer r	= d_r[pos_f];
				k			= m_rf0 + imult(r,m_rs);
			};
			return value;
		};
	private:
		elem_getter2(const elem_getter2&);
		elem_getter2& operator=(const elem_getter2&);
};
class column_iterator_2
{
	private:
		Integer					m_flag;
		Integer					m_size;
		Integer					m_dpos;
		Integer					m_dpos_col;
		Integer					m_column;
		raw::IntegerMatrix	    m_indices;
		bool					m_own_sort;

		raw::IntegerMatrix	    m_vec;		
		Integer					m_pos;	

	public:
		column_iterator_2(const ::mmlib::details::colon_info& c_inf)
            :m_indices(mmlib::details::get_raw_ti())
            ,m_vec(mmlib::details::get_raw_ti())
		{
            mmlib::details::type_info ti_int = mmlib::details::get_raw_ti();
			m_flag = c_inf.c_flag;
			if (m_flag == 0)
			{
				m_vec.assign(c_inf.get_ci());
				sort_type m_sort	= is_sorted(m_vec);
				m_dpos				= 1;
				m_own_sort			= false;
				if (m_sort == sorted_increasing)
				{
				}
				else if (m_sort == sorted_decreasing)
				{
					m_dpos			= -1;
				} 
				else
				{
					m_own_sort		= true;
					raw::IntegerMatrix ci2 = m_vec.copy();
                    ci2.get_struct().reset(false);
					m_indices.assign(raw::IntegerMatrix(ti_int,1,ci2.size()));
                    Integer* ptr_ind = m_indices.ptr();

                    Integer size = ci2.size();
					for (Integer i = 0; i < size; ++i)
					{
						ptr_ind[i] = i+1;
					};

					typedef mmlib::details::iterator_helper_2<Integer,Integer> iterator;
					iterator it_begin(ci2.ptr(),m_indices.ptr(),1);
					iterator it_end(ci2.ptr()+ci2.size(),m_indices.ptr()+ci2.size(),1);

					std::stable_sort(it_begin,it_end,mmlib::details::value_ind_compare<Integer,Integer>());

					m_vec.assign(ci2);
				};
				if (m_dpos > 0)
				{
					m_pos			= 1;
					m_column		= 1;
					m_dpos_col		= 1;
				}
				else
				{
					m_pos			= m_vec.size();
					m_column		= c_inf.cols();
					m_dpos_col		= -1;
				};
			}
			else
			{				
				m_dpos				= c_inf.c_step;
				if (m_dpos>0)
				{
					m_column		= 1;
					m_pos			= c_inf.c_start;
					m_dpos_col		= 1;
				}
				else
				{
					m_pos			= c_inf.c_end;
					m_dpos			= -m_dpos;
					m_dpos_col		= -1;
					m_column		= c_inf.c_size;
				};
			};
			m_size					= c_inf.cols();
		};

		bool valid() const
		{
			return m_size > 0;
		};

		Integer get() const
		{
			if (m_flag == 0)
			{
				return m_vec.ptr()[m_pos-1];
			}
			else
			{
				return m_pos;
			};
		};
		bool is_increasing() const
		{
			return m_dpos_col > 0;
		};

		void next()
		{
			m_pos		+= m_dpos;
			m_column	+= m_dpos_col;
			--m_size;
		};
		Integer column() const
		{
			if (m_flag == 0)
			{
				if (m_own_sort)
				{
					return m_indices.ptr()[m_pos-1];
				}
				else
				{
					return m_column;
				};				
			}
			else
			{
				return m_column;
			};
		};
};

template<class SM,class M2>
struct change_submatrix_0_impl
{
	static SM eval_dense(const SM& A, const mmlib::details::colon_info& ci, const M2& B)
	{
		typedef SM::value_type value_type;
		typedef M2::value_type value_type_B;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();
		M2 vB = B;

		raw::IntegerMatrix ri = ci.get_ri();
		sort_type s_type = is_sorted(ri);
		bool incr = true;
		if (s_type == sorted_increasing)
		{
		}
		else if (s_type == sorted_decreasing)
		{
			incr = false;
		} 
		else
		{
			raw::IntegerMatrix ri2 = ri.copy();
            ri2.get_struct().reset(false);
            vB.assign(B.copy());

			typedef mmlib::details::iterator_helper_2<Integer,value_type_B> iterator;
			iterator it_begin(ri2.ptr(),vB.ptr(),1);
			iterator it_end(ri2.ptr()+ri2.size(),vB.ptr()+ri2.size(),1);

			std::stable_sort(it_begin,it_end,mmlib::details::value_ind_compare<Integer,value_type_B>());
			ri.assign(ri2);
		};

		Integer step_ri;
		Integer pos, pos_row, pos_col;
		if (incr)
		{
			pos = 0;
			step_ri = 1;
		}
		else
		{
			pos = ri.size()-1;
			step_ri = -1;
		};

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + ri.size());

		Integer nz				= 0;

		Integer * d_c			= d.ptr_c();
		Integer * d_r			= d.ptr_r();
		value_type * d_x		= d.ptr_x();

		const Integer * Ad_c	= Ad.ptr_c();
		const Integer * Ad_r	= Ad.ptr_r();
		const value_type * Ad_x	= Ad.ptr_x();

        vB.assign(vB.make_explicit());

        const value_type_B* ptr_B = vB.ptr();

		Integer or = ri.size();
        const Integer* ptr_ri = ri.ptr();
		Integer old_pos = ptr_ri[pos];
		mmlib::details::pos2ind(ptr_ri[pos],r,pos_row,pos_col);

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j] = nz;

			if (j < pos_col)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer i;
			for (i = Ad_c[j]; i < Ad_c[j+1];)
			{
				Integer p = Ad_r[i];
				if (p < pos_row)
				{
					d_r[nz] = p;
					d_x[nz] = Ad_x[i];
					++nz;
					++i;
					continue;
				};				
				while (p > pos_row)
				{
					Integer elem_pos = pos;
					while (pos < or && pos >= 0 && ptr_ri[pos] == old_pos)
					{
						if(incr)
						{
							elem_pos = pos;
						};
						pos+=step_ri;
					};
					old_pos = ptr_ri[pos];
					mmlib::details::pos2ind(ptr_ri[elem_pos],r,pos_row,pos_col);

					value_type tmp(ptr_B[elem_pos]);
                    if (!mmlib::details::is_zero(tmp))
					{
						d_r[nz] = pos_row;
						d_x[nz] = tmp;
						++nz;
					};		

					if (pos > or-1 || pos < 0)
					{
						pos_row = r;
						pos_col = c;
						goto exit_row_flag;
					};
					mmlib::details::pos2ind(ptr_ri[pos],r,pos_row,pos_col);
					if (j != pos_col)
					{
						goto exit_row_flag;
					};
				};
				if (p == pos_row)
				{
					Integer elem_pos = pos;
					while (pos < or && pos >= 0 && ptr_ri[pos] == old_pos)
					{
						if(incr)
						{
							elem_pos = pos;
						};
						pos+=step_ri;
					};
					old_pos = ptr_ri[pos];
					mmlib::details::pos2ind(ptr_ri[elem_pos],r,pos_row,pos_col);

					value_type tmp(ptr_B[elem_pos]);
					if (!mmlib::details::is_zero(tmp))
					{
						d_r[nz] = pos_row;
						d_x[nz] = tmp;
						++nz;
					};
					++i;

					if (pos > or-1 || pos < 0)
					{
						pos_row = r;
						pos_col = c;
						goto exit_row_flag;
					};
					mmlib::details::pos2ind(ptr_ri[pos],r,pos_row,pos_col);
					if (j != pos_col)
					{
						goto exit_row_flag;
					};					
				};
			};
			while (j == pos_col)
			{
				Integer elem_pos = pos;
				while (pos < or && pos >= 0 && ptr_ri[pos] == old_pos)
				{
					if(incr)
					{
						elem_pos = pos;
					};
					pos+=step_ri;
				};
				old_pos = ptr_ri[pos];
				mmlib::details::pos2ind(ptr_ri[elem_pos],r,pos_row,pos_col);

				value_type tmp(ptr_B[elem_pos]);
				if (!mmlib::details::is_zero(tmp))
				{
					d_r[nz] = pos_row;
					d_x[nz] = tmp;
					++nz;
				};

				if (pos > or-1 || pos < 0)
				{
					pos_row = r;
					pos_col = c;
					goto exit_row_flag;
				};
				mmlib::details::pos2ind(ptr_ri[pos],r,pos_row,pos_col);
				if (j != pos_col)
				{
					goto exit_row_flag;
				};					
			};
			continue;

			exit_row_flag:

			for (; i < Ad_c[j+1];++i)
			{
				d_r[nz] = Ad_r[i];
				d_x[nz] = Ad_x[i];
				++nz;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
};
template<class SM,class M2>
struct change_submatrix_1_impl
{
	static SM eval_dense(const SM& A, const mmlib::details::colon_info& ci, const M2& B)
	{
		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		Integer rs = ci.r_step,rf,rl, pos_v, dpos_v;
		if (rs < 0)
		{
			rs      = -rs;
			rf      = ci.r_end;
			rl      = ci.r_start;
			pos_v   = ci.r_size-1;
			dpos_v  = -1;
		}
		else
		{
			rl      = ci.r_end;
			rf      = ci.r_start;
			pos_v   = 0;
			dpos_v  = 1;
		};

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + ci.rows());

		Integer nz				= 0;

		Integer * d_c			= d.ptr_c();
		Integer * d_r			= d.ptr_r();
		value_type * d_x		= d.ptr_x();

		const Integer * Ad_c	= Ad.ptr_c();
		const Integer * Ad_r	= Ad.ptr_r();
		const value_type * Ad_x	= Ad.ptr_x();
        const M2 B2             = B.make_explicit();
        const M2::value_type* ptr_B   = B2.ptr();

		Integer pos_row, pos_col, pos = rf;
		mmlib::details::pos2ind(rf,r,pos_row,pos_col);

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j] = nz;

			if (j < pos_col)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer i;
			for (i = Ad_c[j]; i < Ad_c[j+1];)
			{
				Integer p = Ad_r[i];
				if (p < pos_row)
				{
					d_r[nz] = p;
					d_x[nz] = Ad_x[i];
					++nz;
					++i;
					continue;
				};
				while (p >= pos_row)
				{
					value_type tmp(ptr_B[pos_v]);
					if (!mmlib::details::is_zero(tmp))
					{
						d_r[nz] = pos_row ;
						d_x[nz] = tmp;
						++nz;
					};
					if (p == pos_row)
					{
						++i;
					};

					pos+=rs;
					pos_v += dpos_v;
					if (pos > rl)
					{
						pos_row = r;
						pos_col = c;
						break;
					};
					mmlib::details::pos2ind(pos,r,pos_row,pos_col);
					if (j != pos_col)
					{
						goto exit_row_flag;
					};
				};
			};

			while (j == pos_col)
			{
				value_type tmp(ptr_B[pos_v]);
				if (!mmlib::details::is_zero(tmp))
				{
					d_r[nz] = pos_row;
					d_x[nz] = tmp;
					++nz;
				};

				pos+= rs;
				pos_v += dpos_v;
				if (pos > rl)
				{
					pos_row = r;
					pos_col = c;
					break;
				};
				mmlib::details::pos2ind(pos,r,pos_row,pos_col);
			};

			continue;

			exit_row_flag:

			for (; i < Ad_c[j+1];++i)
			{
				d_r[nz] = Ad_r[i];
				d_x[nz] = Ad_x[i];
				++nz;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM eval_sparse(const SM& A, const mmlib::details::colon_info& ci, const M2& B)
	{
		M2 vB = raw::vec(B);

		typedef SM::value_type value_type;
		typedef M2::value_type value_type_B;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		Integer rs = ci.r_step,rf,rl;
		bool decr;
		if (rs < 0)
		{
			rs = -rs;
			rf = ci.r_end;
			rl = ci.r_start;
			decr = true;
		}
		else
		{
			rl = ci.r_end;
			rf = ci.r_start;
			decr = false;
		};

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + B.nnz());	

		Integer nz				= 0;

		Integer * d_c			= d.ptr_c();
		Integer * d_r			= d.ptr_r();
		value_type * d_x		= d.ptr_x();

		const Integer * Ad_c	= Ad.ptr_c();
		const Integer * Ad_r	= Ad.ptr_r();
		const value_type * Ad_x	= Ad.ptr_x();

		Integer pos_row, pos_col, pos = rf;
		mmlib::details::pos2ind(rf,r,pos_row,pos_col);

		elem_getter1<value_type_B> B_elem(vB,decr);
		B_elem.set_col(1);

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j] = nz;

			if (j < pos_col)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer i;
			for (i = Ad_c[j]; i < Ad_c[j+1];)
			{
				Integer p = Ad_r[i];
				if (p < pos_row)
				{
					d_r[nz] = p;
					d_x[nz] = Ad_x[i];
					++nz;
					++i;
					continue;
				};
				while (p >= pos_row)
				{
					value_type tmp(B_elem.get());
					if (!mmlib::details::is_zero(tmp))
					{
						d_r[nz] = pos_row;
						d_x[nz] = tmp;
						++nz;
					};
					if (p == pos_row)
					{
						++i;
					};

					pos+=rs;
					if (pos > rl)
					{
						pos_row = r;
						pos_col = c;
						break;
					};
					mmlib::details::pos2ind(pos,r,pos_row,pos_col);
					if (j != pos_col)
					{
						goto exit_row_flag;
					};
				};
			};

			while (j == pos_col)
			{
				value_type tmp(B_elem.get());
				if (!mmlib::details::is_zero(tmp))
				{
					d_r[nz] = pos_row;
					d_x[nz] = tmp;
					++nz;
				};
				++i;

				pos+= rs;
				if (pos > rl)
				{
					pos_row = r;
					pos_col = c;
					break;
				};
				mmlib::details::pos2ind(pos,r,pos_row,pos_col);
			};

			continue;

			exit_row_flag:

			for (; i < Ad_c[j+1];++i)
			{
				d_r[nz] = Ad_r[i];
				d_x[nz] = Ad_x[i];
				++nz;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM eval_banded(const SM& A, const mmlib::details::colon_info& ci, const M2& B)
	{
		typedef SM::value_type val_type;
		typedef raw::Matrix<val_type,struct_sparse> SparseMatrix;

		SparseMatrix sB = raw::converter<SM,M2>::eval(A.get_ti(), B);
		return change_submatrix_1_impl<SM,SparseMatrix>::eval_sparse(A,ci,sB);
	};
};
template<class SM, class M2>
struct change_submatrix_20_impl
{
	static SM eval_dense(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		if (imult(c_in.rows(),c_in.cols()) < A.rows())
		{
			return eval_w(A,c_in,B);
		}
		else
		{
			return eval_s(A,c_in,B);
		};
	};
	static SM eval_sparse(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		if (imult(c_in.rows(),c_in.cols()) < A.rows())
		{
			return eval_sparse_w(A,c_in,B);
		}
		else
		{
			return eval_sparse_s(A,c_in,B);
		};
	};
	static SM eval_banded(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		typedef SM::value_type val_type;
		typedef raw::Matrix<val_type,struct_sparse> SparseMatrix;

		SparseMatrix sB = raw::converter<SM,M2>::eval(A.get_ti(), B);
		return change_submatrix_20_impl<SM,SparseMatrix>::eval_sparse(A,c_in,sB);
	}

	static SM eval_w(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

        Integer nzA = icast_c(Real(A.nnz()) + Real(c_in.rows())*Real(c_in.cols()));
		raw::details::spdat<value_type> d(A.get_ti(),r, c, nzA);

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();

		column_iterator_2 c_it(c_in);

		Integer nz					= 0;

		raw::IntegerMatrix ri		= c_in.get_ri();
        raw::IntegerMatrix ind(mmlib::details::get_raw_ti());

		sort_type rs_type			= is_sorted(ri);
		bool incr					= true;
		if (rs_type != sorted_increasing)
		{
			raw::IntegerMatrix ri2 = ri.copy();
            ri2.get_struct().reset(false);

			ind.reset_unique(1,ri.size());
            Integer* ptr_ind = ind.ptr();
            Integer size = ri.size();
			for(Integer i = 0; i < size; ++i)
			{
				ptr_ind[i] = i + 1;
			};

			typedef mmlib::details::iterator_helper_2<Integer,Integer> iterator;
			iterator it_begin(ri2.ptr(),ind.ptr(),1);
			iterator it_end(ri2.ptr()+ri2.size(),ind.ptr()+ri2.size(),1);

			std::stable_sort(it_begin,it_end,mmlib::details::value_ind_compare<Integer,Integer>());

			ri.assign(ri2);
			incr = false;
		};
		Integer n = ri.size();
        const Integer* ptr_ri = ri.ptr();
        const M2::value_type* ptr_B = B.ptr();
        Integer* ptr_ind = ind.ptr();

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer m_column = c_it.column();
			c_it.next();
			while (c_it.valid() && c_it.get() == j+1)
			{
				if (c_it.is_increasing())
				{
					m_column		= c_it.column();
				};
				c_it.next();
			};			

			Integer la			= Ad_c[j+1];
			Integer i			= Ad_c[j];
			Integer col			= imult(m_column-1,B.ld());
            ptr_B               = B.ptr() + col;

			Integer k = 0;
			while(i < la && k < n)
			{
				Integer p		= Ad_r[i];
				Integer pr		= ptr_ri[k]-1;
				while (k < n-1 && ptr_ri[k+1] == ptr_ri[k])
				{
					++k;
				};

				if (p < pr)
				{
					d_r[nz]		= Ad_r[i];
					d_x[nz]		= Ad_x[i];
					++nz;
					++i;
				}
				else
				{
                    value_type tmp = mmlib::details::default_value<value_type>(A.get_ti());
					if (incr)
					{
						tmp		= value_type(ptr_B[k]);
					}
					else
					{
						tmp		= value_type(ptr_B[ptr_ind[k] - 1]);
					};

					if (!mmlib::details::is_zero(tmp))
					{
						d_r[nz]		= pr;
						d_x[nz]		= tmp;
						++nz;
					};
					++k;
					if (p == pr)
					{
						++i;
					};
				};
			};
			while(i < la)
			{
				d_r[nz]			= Ad_r[i];
				d_x[nz]			= Ad_x[i];
				++nz;
				++i;
			};
			while(k < n)
			{
				while (k < n-1 && ptr_ri[k+1] == ptr_ri[k])
				{
					++k;
				};

				value_type tmp = mmlib::details::default_value<value_type>(A.get_ti());;
				if (incr)
				{
					tmp			= value_type(ptr_B[k]);
				}
				else
				{
					tmp			= value_type(ptr_B[ptr_ind[k] - 1]);
				};

				if (!mmlib::details::is_zero(tmp))
				{
					Integer pr	= ptr_ri[k]-1;
					d_r[nz]		= pr;
					d_x[nz]		= tmp;
					++nz;
				};
				++k;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM eval_sparse_w(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		typedef SM::value_type value_type;
		typedef M2::value_type value_type_B;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();
		const raw::details::spdat<value_type_B>& Bd = B.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

        Integer nzA = icast_c(Real(A.nnz()) + Real(c_in.rows())*Real(c_in.cols()));
		raw::details::spdat<value_type> d(A.get_ti(),r, c, nzA);

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();

		column_iterator_2 c_it(c_in);

		Integer nz					= 0;

		raw::IntegerMatrix ri		= c_in.get_ri();

		sort_type rs_type			= is_sorted(ri);
		bool incr					= true;

        raw::IntegerMatrix ind(mmlib::details::get_raw_ti());

		if (rs_type != sorted_increasing)
		{
			raw::IntegerMatrix ri2 = ri.copy();
            ri2.get_struct().reset(false);
            
			ind.reset_unique(1,ri.size());
            Integer* ptr_ind = ind.ptr();
            Integer size = ri.size();
			for(Integer i = 0; i < size;++i)
			{
				ptr_ind[i]	= i+1;
			};

			typedef mmlib::details::iterator_helper_2<Integer,Integer> iterator;
			iterator it_begin(ri2.ptr(),ind.ptr(),1);
			iterator it_end(ri2.ptr()+ri2.size(),ind.ptr()+ri2.size(),1);

			std::stable_sort(it_begin,it_end,mmlib::details::value_ind_compare<Integer,Integer>());

			ri.assign(ri2);
			incr = false;
		};
		Integer n = ri.size();
        const Integer* ptr_ri = ri.ptr();
        const Integer* ptr_ind = ind.ptr();

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer m_column = c_it.column();
			c_it.next();
			while (c_it.valid() && c_it.get() == j+1)
			{
				if (c_it.is_increasing())
				{
					m_column		= c_it.column();
				};
				c_it.next();
			};

			Integer la			= Ad_c[j+1];
			Integer i			= Ad_c[j];
			Integer col			= m_column-1;

			Integer k = 0;
			while(i < la && k < n)
			{
				Integer p		= Ad_r[i];
				Integer pr		= ptr_ri[k]-1;
				while (k < n-1 && ptr_ri[k+1] == ptr_ri[k])
				{
					++k;
				};

				if (p < pr)
				{
					d_r[nz]		= Ad_r[i];
					d_x[nz]		= Ad_x[i];
					++nz;
					++i;
				}
				else
				{
                    value_type tmp= mmlib::details::default_value<value_type>(A.get_ti()) ;
					if (incr)
					{
						tmp		= value_type(Bd.get_elem(k,col));
					}
					else
					{
						tmp		= value_type(Bd.get_elem(ptr_ind[k]-1,col));
					};

					if (!mmlib::details::is_zero(tmp))
					{
						d_r[nz]		= pr;
						d_x[nz]		= tmp;
						++nz;
					};
					++k;
					if (p == pr)
					{
						++i;
					};
				};
			};
			while(i < la)
			{
				d_r[nz]			= Ad_r[i];
				d_x[nz]			= Ad_x[i];
				++nz;
				++i;
			};
			while(k < n)
			{
				while (k < n-1 && ptr_ri[k+1] == ptr_ri[k])
				{
					++k;
				};

				value_type tmp = mmlib::details::default_value<value_type>(A.get_ti()) ;
				if (incr)
				{
					tmp			= value_type(Bd.get_elem(k,col));
				}
				else
				{
					tmp			= value_type(Bd.get_elem(ptr_ind[k]-1,col));
				};

				if (!mmlib::details::is_zero(tmp))
				{
					Integer pr	= ptr_ri[k]-1;
					d_r[nz]		= pr;
					d_x[nz]		= tmp;
					++nz;
				};
				++k;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	}
	static SM eval_s(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

        Integer nzA = icast_c(Real(A.nnz()) + Real(c_in.rows())*Real(c_in.cols()));
		raw::details::spdat<value_type> d(A.get_ti(),r, c, nzA);

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();
        const M2::value_type* ptr_B = B.ptr();

		column_iterator_2 c_it(c_in);

        typedef mmlib::details::vector<value_type> value_vector;

		value_vector		        work_x(A.get_ti(),r);
		std::vector<Integer>		work_ind(r,-1);
		raw::IntegerMatrix ri		= c_in.get_ri();

        Integer size = ri.size();
        const Integer* ptr_ri = ri.ptr();

		for (Integer k = 0; k < size; ++k)
		{
			Integer p			    = ptr_ri[k]-1;
			work_ind[p]			    = c+k+1;
		};

		Integer nz					= 0;

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer m_column = c_it.column();
			c_it.next();
			while (c_it.valid() && c_it.get() == j+1)
			{
				if (c_it.is_increasing())
				{
					m_column		= c_it.column();
				};
				c_it.next();
			};

			Integer nz_old		= nz;
			bool b_added		= false;

			Integer col			= imult(m_column-1,B.ld());
            ptr_B               = B.ptr() + col;
            Integer size        = ri.size();
			
            for (Integer k = 0; k < size; ++k, ++col)
			{
				Integer p		= ptr_ri[k]-1;
				value_type tmp(ptr_B[k]);
				if (!mmlib::details::is_zero(tmp) && work_ind[p] == c+k+1)
    			{
    				d_r[nz++]	= p;
					work_x[p]	= tmp;
					b_added		= true;
    			};
			};

			for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
			{
				Integer p		= Ad_r[k];
				if (work_ind[p] < j)
				{
					work_ind[p]	= j;	
					d_r[nz++]	= p;	
					work_x[p]	= Ad_x[k];
				};
			};

			Integer nz_new		= nz - nz_old;
			if (b_added && nz_new > 1)
			{
				utils::sort_q(d_r+nz_old,nz_new);
			};
			for (Integer k = d_c[j]; k < nz ; ++k) 
			{
				d_x[k]			= work_x[d_r[k]] ;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM eval_sparse_s(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		typedef SM::value_type value_type;
		typedef M2::value_type value_type_B;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();
		const raw::details::spdat<value_type_B>& Bd = B.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

		const Integer * Bd_c		= Bd.ptr_c();
		const Integer * Bd_r		= Bd.ptr_r();
		const value_type_B * Bd_x	= Bd.ptr_x();	

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + B.nnz());

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();

		column_iterator_2 c_it(c_in);
        typedef mmlib::details::vector<value_type> value_vector;

        value_vector		        work_x(A.get_ti(),r);
		std::vector<Integer>		work_ind(r,-1);
		raw::IntegerMatrix ri		= c_in.get_ri();

		Integer nz					= 0;

        Integer size = ri.size();
        const Integer* ptr_ri = ri.ptr();

		for (Integer k = 0; k < size; ++k)
		{
			Integer p			    = ptr_ri[k]-1;
			work_ind[p]			    = c + k;
		};

		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer m_column = c_it.column();
			c_it.next();
			while (c_it.valid() && c_it.get() == j+1)
			{
				if (c_it.is_increasing())
				{
					m_column		= c_it.column();
				};
				c_it.next();
			};

			Integer nz_old		= nz;
			bool b_added		= false;

			Integer col			= m_column-1;
			for (Integer k = Bd_c[col]; k < Bd_c[col+1]; ++k)
			{
				Integer row		= Bd_r[k];
				Integer p		= ptr_ri[row]-1;
				value_type tmp  = value_type(Bd_x[k]);
				if (!mmlib::details::is_zero(tmp) && work_ind[p]-c == row)
    			{
    				d_r[nz++]	= p;
					work_x[p]	= tmp;										
					b_added		= true;
    			};
			};
			for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
			{
				Integer p		= Ad_r[k];
				if (work_ind[p] < j)
				{
					work_ind[p]	= j;	
					d_r[nz++]	= p;	
					work_x[p]	= Ad_x[k];
				};
			};

			Integer nz_new		= nz - nz_old;
			if (b_added && nz_new > 1)
			{
				utils::sort_q(d_r+nz_old,nz_new);
			};
			for (Integer k = d_c[j]; k < nz ; ++k) 
			{
				d_x[k]			= work_x[d_r[k]] ;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
};
template<class SM, class M2>
struct change_submatrix_21_impl
{
	static SM eval_dense(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		if (c_in.r_start == 1 && c_in.r_end == A.rows() && c_in.r_step == 1)
		{
			return change_cols_dense(A,c_in,B);
		};

		typedef SM::value_type value_type;
		typedef M2::value_type value_type_B;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + B.nnz());

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();
        const value_type_B* ptr_B   = B.ptr();

		column_iterator_2 c_it(c_in);

		Integer nz					= 0;

		Integer rs = c_in.r_step, rf, rl, pos_v, dpos_v;
		if (rs < 0)
		{
			rs = -rs;
			rf = c_in.r_end;
			rl = c_in.r_start;
			pos_v = c_in.r_size-1;
			dpos_v = -1;
		}
		else
		{
			rf = c_in.r_start;		
			rl = c_in.r_end;
			pos_v = 0;
			dpos_v = 1;
		};
		--rf;
		--rl;
		
		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer m_column = c_it.column();
			c_it.next();
			while (c_it.valid() && c_it.get() == j+1)
			{
				if (c_it.is_increasing())
				{
					m_column		= c_it.column();
				};
				c_it.next();
			};

			Integer la			= Ad_c[j+1];
			Integer i			= Ad_c[j];
			Integer col			= imult(m_column-1,B.ld());
            ptr_B               = B.ptr() + col;

			Integer k           = rf;
            Integer pos_B       = pos_v;

			while(i < la && k <= rl)
			{
				Integer p		= Ad_r[i];

				if (p < k)
				{
					d_r[nz]		= Ad_r[i];
					d_x[nz]		= Ad_x[i];
					++nz;
					++i;
				}
				else 
				{
					value_type tmp(ptr_B[pos_B]);
                    if (!mmlib::details::is_zero(tmp))
					{
						d_r[nz]		= k;
						d_x[nz]		= tmp;
						++nz;
					};
					if (p == k)
					{
						++i;
					};
					k			+= rs;
					pos_B		+=dpos_v;
				};
			};
			while(i < la)
			{
				d_r[nz]			= Ad_r[i];
				d_x[nz]			= Ad_x[i];
				++nz;
				++i;
			};
			while(k <= rl)
			{
				value_type tmp(ptr_B[pos_B]);
				if (!mmlib::details::is_zero(tmp))
				{
					d_r[nz]		= k;
					d_x[nz]		= tmp;
					++nz;
				};

				k				+= rs;
				pos_B			+=dpos_v;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM eval_sparse(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		if (c_in.r_start == 1 && c_in.r_end == A.rows() && c_in.r_step == 1)
		{
			return change_cols_sparse(A,c_in,B);
		};

		typedef SM::value_type value_type;
		typedef M2::value_type value_type_B;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + B.nnz());

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();

		column_iterator_2 c_it(c_in);

		Integer nz					= 0;

		Integer rs = c_in.r_step, rf, rl;
		bool decr = false;
		if (rs < 0)
		{
			rs = -rs;
			rf = c_in.r_end;
			rl = c_in.r_start;
			decr = true;
		}
		else
		{
			rf = c_in.r_start;		
			rl = c_in.r_end;
		};
		--rf;
		--rl;

		elem_getter2<value_type_B> eg(B,c_in.r_start-1,c_in.r_step,c_in.r_end-1);
		
		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer m_column = c_it.column();
			c_it.next();
			while (c_it.valid() && c_it.get() == j+1)
			{
				if (c_it.is_increasing())
				{
					m_column		= c_it.column();
				};
				c_it.next();
			};

			Integer la			= Ad_c[j+1];
			Integer i			= Ad_c[j];
			Integer col			= m_column;
			Integer k			= rf;
			eg.set_col(col,k);

			while(i < la)
			{
				Integer p		= Ad_r[i];

				if (p >= rf)
				{
					break;
				};
				d_r[nz]			= Ad_r[i];
				d_x[nz]			= Ad_x[i];
				++nz;
				++i;
			};			

			while(i < la && k <= rl)
			{
				Integer p		= Ad_r[i];

				if (p < k) 
				{
					if ((k-p)% rs != 0)
					{
						d_r[nz]		= Ad_r[i];
						d_x[nz]		= Ad_x[i];
						++nz;
					};
					++i;
				}
				else if (p == k)
				{
					value_type tmp(eg.get(k));
                    if (!mmlib::details::is_zero(tmp))
					{
						d_r[nz]		= p;
						d_x[nz]		= tmp;
						++nz;
						++i;
					};
				}
				else 
				{
					Integer k_old	= k;
					value_type tmp(eg.get(k));
					if (!mmlib::details::is_zero(tmp))
					{
						d_r[nz]		= k_old;
						d_x[nz]		= tmp;
						++nz;
					};
				};
			};
			while(i < la)
			{
				Integer p		= Ad_r[i];

				if (p >= rf && p <= rl)
				{
					if ((p-rf)% rs != 0)
					{
						d_r[nz]		= p;
						d_x[nz]		= Ad_x[i];
						++nz;
					};
				}
				else
				{
					d_r[nz]		= p;
					d_x[nz]		= Ad_x[i];
					++nz;
				};
				++i;
			};
			while(k <= rl)
			{
				Integer k_old	= k;
				value_type tmp(eg.get(k));
				if (!mmlib::details::is_zero(tmp))
				{
					d_r[nz]		= k_old;
					d_x[nz]		= tmp;
					++nz;
				};
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM eval_banded(const SM& A, const mmlib::details::colon_info& ci, const M2& B)
	{
		typedef SM::value_type val_type;
		typedef raw::Matrix<val_type,struct_sparse> SparseMatrix;

		SparseMatrix sB = raw::converter<SM,M2>::eval(A.get_ti(), B);
		return change_submatrix_21_impl<SM,SparseMatrix>::eval_sparse(A,ci,sB);
	};
	static SM change_cols_dense(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		typedef SM::value_type value_type;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + B.nnz());

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();
        const M2::value_type* ptr_B = B.ptr();

		column_iterator_2 c_it(c_in);		

		Integer nz					= 0;
		
		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer m_column = c_it.column();
			c_it.next();
			while (c_it.valid() && c_it.get() == j+1)
			{
				if (c_it.is_increasing())
				{
					m_column		= c_it.column();
				};
				c_it.next();
			};

			Integer col				= imult(m_column-1,B.ld());
            ptr_B                   = B.ptr() + col;

			for (Integer i = 0; i < r; ++i)
			{
				value_type tmp(ptr_B[i]);
                if (mmlib::details::is_zero(tmp))
				{
					continue;
				};
				d_r[nz] = i;
				d_x[nz] = tmp;
				++nz;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
	static SM change_cols_sparse(const SM& A, const mmlib::details::colon_info& c_in, const M2& B)
	{
		typedef SM::value_type value_type;
		typedef M2::value_type value_type_B;

		Integer r = A.rows(), c = A.cols();
		const raw::details::spdat<value_type>& Ad = A.rep();
		const raw::details::spdat<value_type_B>& Bd = B.rep();

		const Integer * Ad_c		= Ad.ptr_c();
		const Integer * Ad_r		= Ad.ptr_r();
		const value_type * Ad_x		= Ad.ptr_x();	

		const Integer * Bd_c		= Bd.ptr_c();
		const Integer * Bd_r		= Bd.ptr_r();
		const value_type_B * Bd_x	= Bd.ptr_x();	

		raw::details::spdat<value_type> d(A.get_ti(),r, c, A.nnz() + B.nnz());

		Integer * d_c				= d.ptr_c();
		Integer * d_r				= d.ptr_r();
		value_type * d_x			= d.ptr_x();

		column_iterator_2 c_it(c_in);		

		Integer nz					= 0;
		
		for (Integer j = 0; j < c; ++j)
		{
			d_c[j]					= nz;

			if (!c_it.valid() || c_it.get() > j+1)
			{
				for (Integer k = Ad_c[j]; k < Ad_c[j+1]; ++k)
				{
					d_r[nz] = Ad_r[k];
					d_x[nz] = Ad_x[k];
					++nz;
				};
				continue;
			};

			Integer col = c_it.column();
			c_it.next();
			while (c_it.valid() && c_it.get() == j+1)
			{
				if (c_it.is_increasing())
				{
					col			= c_it.column();
				};
				c_it.next();
			};			

			for (Integer i = Bd_c[col-1]; i < Bd_c[col]; ++i)
			{
				d_r[nz] = Bd_r[i];
				d_x[nz] = value_type(Bd_x[i]);
				++nz;
			};
		};
		d_c[c] = nz;

		return raw::sparse_matrix_base<value_type>(d);
	};
};

template<class SM1,class DM2>
SM1 change_submatrix_dense_functor<SM1,DM2>::eval(const SM1& A, const mmlib::details::colon_info& ci, 
                                                   const DM2& B)
{
	if (ci.rows() == 0 || ci.cols() == 0)
	{
		return A;
	};

	if (ci.r_flag == 0)
	{
		return change_submatrix_20_impl<SM1,DM2>::eval_dense(A,ci,B);
	}
	else
	{
		return change_submatrix_21_impl<SM1,DM2>::eval_dense(A,ci,B);
	};
};
template<class SM1,class SM2>
SM1 change_submatrix_functor<SM1,SM2>::eval(const SM1& A, const mmlib::details::colon_info& ci, 
                                             const SM2& B)
{
	if (ci.rows() == 0)
	{
		return A;
	};

	if (ci.r_flag == 0)
	{
		return change_submatrix_20_impl<SM1,SM2>::eval_sparse(A,ci,B);
	}
	else
	{
		return change_submatrix_21_impl<SM1,SM2>::eval_sparse(A,ci,B);
	};
};
template<class SM1,class BM2>
SM1 change_submatrix_band_functor<SM1,BM2>::eval(const SM1& A, const mmlib::details::colon_info& ci, 
                                                  const BM2& B)
{
	if (ci.rows() == 0)
	{
		return A;
	};

	if (ci.r_flag == 0)
	{
		return change_submatrix_20_impl<SM1,BM2>::eval_banded(A,ci,B);
	}
	else
	{
		return change_submatrix_21_impl<SM1,BM2>::eval_banded(A,ci,B);
	};
};
template<class SM1,class DM2>
SM1 change_submatrix_dense_functor_2<SM1,DM2>::eval(const SM1& A, const mmlib::details::colon_info& ci, 
                                                     const DM2& B)
{
	if (ci.rows() == 0)
	{
		return A;
	};

	if (ci.r_flag == 0)
	{
		return change_submatrix_0_impl<SM1,DM2>::eval_dense(A,ci,B);
	}
	else
	{
		return change_submatrix_1_impl<SM1,DM2>::eval_dense(A,ci,B);
	};
};
template<class SM1,class BM2>
SM1 change_submatrix_band_functor_2<SM1,BM2>::eval(const SM1& A, const mmlib::details::colon_info& ci, 
                                                    const BM2& B)
{
	if (ci.rows() == 0)
	{
		return A;
	};

	typedef BM2::value_type value_type;
	typedef raw::Matrix<value_type,struct_dense> FullMatrix;

	if (ci.r_flag == 0)
	{
		FullMatrix vB = raw::converter<FullMatrix,BM2>::eval(B.get_ti(), B);
		return change_submatrix_0_impl<SM1,FullMatrix>::eval_dense(A,ci,vB);
	}
	else
	{
		return change_submatrix_1_impl<SM1,BM2>::eval_banded(A,ci,B);
	};
};
template<class SM1,class SM2>
SM1 change_submatrix_functor_2<SM1,SM2>::eval(const SM1& A, const mmlib::details::colon_info& ci, 
                                               const SM2& B)
{
	if (ci.rows() == 0)
	{
		return A;
	};
	typedef SM2::value_type value_type;
	typedef raw::Matrix<value_type,struct_dense> FullMatrix;	

	if (ci.r_flag == 0)
	{
		FullMatrix vB = raw::full(B);
		return change_submatrix_0_impl<SM1,FullMatrix>::eval_dense(A,ci,vB);
	}
	else
	{		
		return change_submatrix_1_impl<SM1,SM2>::eval_sparse(A,ci,B);
	};
};
template struct change_submatrix_functor<mmlib::raw::IntegerSparseMatrix,mmlib::raw::IntegerSparseMatrix>;
template struct change_submatrix_functor<mmlib::raw::RealSparseMatrix,mmlib::raw::IntegerSparseMatrix>;
template struct change_submatrix_functor<mmlib::raw::RealSparseMatrix,mmlib::raw::RealSparseMatrix>;
template struct change_submatrix_functor<mmlib::raw::ComplexSparseMatrix,mmlib::raw::IntegerSparseMatrix>;
template struct change_submatrix_functor<mmlib::raw::ComplexSparseMatrix,mmlib::raw::RealSparseMatrix>;
template struct change_submatrix_functor<mmlib::raw::ComplexSparseMatrix,mmlib::raw::ComplexSparseMatrix>;
//template struct change_submatrix_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::IntegerSparseMatrix>;
//template struct change_submatrix_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::RealSparseMatrix>;
//template struct change_submatrix_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ComplexSparseMatrix>;
template struct change_submatrix_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ObjectSparseMatrix>;

template struct change_submatrix_functor_2<mmlib::raw::IntegerSparseMatrix,mmlib::raw::IntegerSparseMatrix>;
template struct change_submatrix_functor_2<mmlib::raw::RealSparseMatrix,mmlib::raw::IntegerSparseMatrix>;
template struct change_submatrix_functor_2<mmlib::raw::RealSparseMatrix,mmlib::raw::RealSparseMatrix>;
template struct change_submatrix_functor_2<mmlib::raw::ComplexSparseMatrix,mmlib::raw::IntegerSparseMatrix>;
template struct change_submatrix_functor_2<mmlib::raw::ComplexSparseMatrix,mmlib::raw::RealSparseMatrix>;
template struct change_submatrix_functor_2<mmlib::raw::ComplexSparseMatrix,mmlib::raw::ComplexSparseMatrix>;
//template struct change_submatrix_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::IntegerSparseMatrix>;
//template struct change_submatrix_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::RealSparseMatrix>;
//template struct change_submatrix_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ComplexSparseMatrix>;
template struct change_submatrix_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ObjectSparseMatrix>;

template struct change_submatrix_dense_functor<mmlib::raw::IntegerSparseMatrix,mmlib::raw::IntegerMatrix>;
template struct change_submatrix_dense_functor<mmlib::raw::RealSparseMatrix,mmlib::raw::IntegerMatrix>;
template struct change_submatrix_dense_functor<mmlib::raw::RealSparseMatrix,mmlib::raw::RealMatrix>;
template struct change_submatrix_dense_functor<mmlib::raw::ComplexSparseMatrix,mmlib::raw::IntegerMatrix>;
template struct change_submatrix_dense_functor<mmlib::raw::ComplexSparseMatrix,mmlib::raw::RealMatrix>;
template struct change_submatrix_dense_functor<mmlib::raw::ComplexSparseMatrix,mmlib::raw::ComplexMatrix>;
//template struct change_submatrix_dense_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::IntegerMatrix>;
//template struct change_submatrix_dense_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::RealMatrix>;
//template struct change_submatrix_dense_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ComplexMatrix>;
template struct change_submatrix_dense_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ObjectMatrix>;

template struct change_submatrix_dense_functor_2<mmlib::raw::IntegerSparseMatrix,mmlib::raw::IntegerMatrix>;
template struct change_submatrix_dense_functor_2<mmlib::raw::RealSparseMatrix,mmlib::raw::IntegerMatrix>;
template struct change_submatrix_dense_functor_2<mmlib::raw::RealSparseMatrix,mmlib::raw::RealMatrix>;
template struct change_submatrix_dense_functor_2<mmlib::raw::ComplexSparseMatrix,mmlib::raw::IntegerMatrix>;
template struct change_submatrix_dense_functor_2<mmlib::raw::ComplexSparseMatrix,mmlib::raw::RealMatrix>;
template struct change_submatrix_dense_functor_2<mmlib::raw::ComplexSparseMatrix,mmlib::raw::ComplexMatrix>;
//template struct change_submatrix_dense_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::IntegerMatrix>;
//template struct change_submatrix_dense_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::RealMatrix>;
//template struct change_submatrix_dense_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ComplexMatrix>;
template struct change_submatrix_dense_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ObjectMatrix>;

template struct change_submatrix_band_functor<mmlib::raw::IntegerSparseMatrix,mmlib::raw::IntegerBandMatrix>;
template struct change_submatrix_band_functor<mmlib::raw::RealSparseMatrix,mmlib::raw::IntegerBandMatrix>;
template struct change_submatrix_band_functor<mmlib::raw::RealSparseMatrix,mmlib::raw::RealBandMatrix>;
template struct change_submatrix_band_functor<mmlib::raw::ComplexSparseMatrix,mmlib::raw::IntegerBandMatrix>;
template struct change_submatrix_band_functor<mmlib::raw::ComplexSparseMatrix,mmlib::raw::RealBandMatrix>;
template struct change_submatrix_band_functor<mmlib::raw::ComplexSparseMatrix,mmlib::raw::ComplexBandMatrix>;
//template struct change_submatrix_band_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::IntegerBandMatrix>;
//template struct change_submatrix_band_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::RealBandMatrix>;
//template struct change_submatrix_band_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ComplexBandMatrix>;
template struct change_submatrix_band_functor<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ObjectBandMatrix>;

template struct change_submatrix_band_functor_2<mmlib::raw::IntegerSparseMatrix,mmlib::raw::IntegerBandMatrix>;
template struct change_submatrix_band_functor_2<mmlib::raw::RealSparseMatrix,mmlib::raw::IntegerBandMatrix>;
template struct change_submatrix_band_functor_2<mmlib::raw::RealSparseMatrix,mmlib::raw::RealBandMatrix>;
template struct change_submatrix_band_functor_2<mmlib::raw::ComplexSparseMatrix,mmlib::raw::IntegerBandMatrix>;
template struct change_submatrix_band_functor_2<mmlib::raw::ComplexSparseMatrix,mmlib::raw::RealBandMatrix>;
template struct change_submatrix_band_functor_2<mmlib::raw::ComplexSparseMatrix,mmlib::raw::ComplexBandMatrix>;
//template struct change_submatrix_band_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::IntegerBandMatrix>;
//template struct change_submatrix_band_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::RealBandMatrix>;
//template struct change_submatrix_band_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ComplexBandMatrix>;
template struct change_submatrix_band_functor_2<mmlib::raw::ObjectSparseMatrix,mmlib::raw::ObjectBandMatrix>;

};};};