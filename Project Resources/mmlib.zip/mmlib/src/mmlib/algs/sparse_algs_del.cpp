/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/algs/sparse_algs.h"
#include "mmlib/error/error_check.h"
#include "mmlib/container/raw/type_decl.h"
#include <vector>
#include "mmlib/utils/sort.h"
#include "mmlib/utils/utils.h"
#include "mmlib/details/matrix_func_binary.inl"

namespace mmlib { namespace algorithm { namespace details
{

template<class SM>
SM del_rows_sparse_functor<SM>::eval(const SM& mat,const mmlib::details::colon_info& ci)
{
	typedef SM::value_type value_type;

	Integer s = ci.rows();
	if (s == 0)
	{
		return mat;
	};

	Integer r0 = mat.rows(), c0 = mat.cols();

	if (ci.r_flag == 0)
	{		
		raw::IntegerMatrix ritmp = ci.get_ri();
        const Integer* ptr_ri = ritmp.ptr();

		Integer ce = ptr_ri[0];
		error::check_row(ce, r0, c0);

		std::vector<Integer> iwork(r0);
		for (Integer i = 0; i < s; ++i)
		{
			Integer ce2 = ptr_ri[i];
			error::check_row(ce2, r0, c0);
			iwork[ce2-1] = -1;
		};
		Integer n_del = 0;
		for (Integer i = 0; i < r0; ++i)
		{
			if (iwork[i] == -1)
			{
				++n_del;
			}
			else
			{
				iwork[i] = i-n_del;
			};
		};

		if (!c0)
		{
			SM out(mat.get_ti(),r0-n_del,0);
            return out;
		};

		if (n_del == r0)
		{
			SM out(mat.get_ti(),0,c0);
            return out;
		};

		Integer r1 = r0 - n_del;		
		SM out(mat.get_ti(),r1,c0,mat.nnz());

		raw::details::spdat<value_type>& d = out.rep();
		Integer* d_c = d.ptr_c();
		Integer* d_r = d.ptr_r();
		value_type* d_x = d.ptr_x();

		const raw::details::spdat<value_type>& Ad = mat.rep();
		const Integer* Ad_c = Ad.ptr_c();
		const Integer* Ad_r = Ad.ptr_r();
		const value_type* Ad_x = Ad.ptr_x();

		Integer nz = 0;

		for (Integer j = 0; j < c0; ++j)
		{
			d_c[j] = nz;

			for (Integer i = Ad_c[j]; i < Ad_c[j+1]; ++i)
			{
				Integer p = Ad_r[i];
				Integer np = iwork[p];
				if (np != -1)
				{
					value_type tmp = Ad_x[i];
					if (mmlib::details::is_zero(tmp))
					{
						continue;
					};
					d_r[nz] = np;
					d_x[nz] = tmp;
					++nz;
				};
			};
		};
		d_c[c0] = nz;
		d.memadd(-1);

		return out;
	}
	else
	{
		Integer ne = s;
		if (!c0)
		{
			SM out(mat.get_ti(),r0-ne,c0);
            return out;
		};

		if (ne == r0)
		{
			SM out(mat.get_ti(),0,c0);
            return out;
		};

		Integer r1 = r0 - ne;		
		SM out(mat.get_ti(),r1,c0,mat.nnz());

		raw::details::spdat<value_type>& d = out.rep();
		Integer* d_c = d.ptr_c();
		Integer* d_r = d.ptr_r();
		value_type* d_x = d.ptr_x();

		const raw::details::spdat<value_type>& Ad = mat.rep();
		const Integer* Ad_c = Ad.ptr_c();
		const Integer* Ad_r = Ad.ptr_r();
		const value_type* Ad_x = Ad.ptr_x();

		Integer rs = ci.r_step, rf, rl;
		Integer r_size = ci.r_size;
		if (rs < 0)
		{
			rs = -rs;
			rf = ci.r_end;
			rl = ci.r_start;
		}
		else
		{
			rf = ci.r_start;		
			rl = ci.r_end;
		};

		Integer nz = 0;
		for (Integer j = 0; j < c0; ++j)
		{
			d_c[j] = nz;

			for (Integer i = Ad_c[j]; i < Ad_c[j+1]; ++i)
			{
				Integer p = Ad_r[i];
				if (p+1 >= rf && p+1 <= rl && (p+1-rf)%rs == 0)
				{
					continue;
				};
				value_type tmp = Ad_x[i];
				if (mmlib::details::is_zero(tmp))
				{
					continue;
				};
				if (p  < rf - 1)
				{
					d_r[nz] = p;
				}
				else if (p >= rl - 1) 
				{
					d_r[nz] = p-r_size;
				}
				else
				{
					d_r[nz] = p-(p-rf+1)/rs-1;					
				};
				d_x[nz] = tmp;
				++nz;
			};
		};
		d_c[c0] = nz;
		d.memadd(-1);

		return out;
	};
};

template<class SM>
SM del_cols_sparse_functor<SM>::eval(const SM& mat,const mmlib::details::colon_info& ci)
{
	typedef SM::value_type value_type;

	Integer s = ci.rows();
	if (s == 0)
	{
		return mat;
	};

	Integer r0 = mat.rows(), c0 = mat.cols();

	if (ci.r_flag == 0)
	{		
		raw::IntegerMatrix ritmp = ci.get_ri().copy();
        ritmp.get_struct().reset(false);
        Integer* ptr_ri = ritmp.ptr();

		mmlib::utils::sort_q(ptr_ri,s);

		Integer ce = ptr_ri[0];
		error::check_col(ce, r0, c0);
		Integer ne = 1;

		for (Integer i = 1; i < s; ++i)
		{
			Integer ce2 = ptr_ri[i];
			error::check_col(ce2, r0, c0);
			if (ce2 != ce)
			{
				++ne;
			};
			ce = ce2;
		}

		if (!r0)
		{
			SM out(mat.get_ti(),0,c0-ne);
            return out;
		};

		if (ne == c0)
		{
			SM out(mat.get_ti(),r0,0);
            return out;
		};

		Integer c1 = c0 - ne;		
		Integer nnz = mat.nnz();
		SM out(mat.get_ti(),r0,c1,nnz);

		raw::details::spdat<value_type>& d = out.rep();
		Integer* d_c = d.ptr_c();
		Integer* d_r = d.ptr_r();
		value_type* d_x = d.ptr_x();

		const raw::details::spdat<value_type>& Ad = mat.rep();
		const Integer* Ad_c = Ad.ptr_c();
		const Integer* Ad_r = Ad.ptr_r();
		const value_type* Ad_x = Ad.ptr_x();

		Integer nz = 0;
		for (Integer j = 0, k = 0, col = 0; j < c0; ++j)
		{
			if (j == ptr_ri[k]-1)
			{
				while(j == ptr_ri[k]-1)
				{
					++k;
				};
			}
			else
			{
				d_c[col] = nz;

				for (Integer i = Ad_c[j]; i < Ad_c[j+1]; ++i)
				{			
					Integer p = Ad_r[i];
					value_type tmp = Ad_x[i];
					if (mmlib::details::is_zero(tmp))
					{
						continue;
					};
					d_r[nz] = p;
					d_x[nz] = tmp;
					++nz;
				};
				++col;
			};
		};

		d_c[c1] = nz;
		d.memadd(-1);

		return out;
	}
	else
	{
		Integer ne = s;
		if (!r0)
		{
			SM out(mat.get_ti(),0,c0-ne);
            return out;
		};

		if (ne == c0)
		{
			SM out(mat.get_ti(),r0,0);
            return out;
		};

		Integer nnz = mat.nnz();
		Integer c1 = c0 - ne;
		SM out(mat.get_ti(),r0,c1,nnz);

		raw::details::spdat<value_type>& d = out.rep();
		Integer* d_c = d.ptr_c();
		Integer* d_r = d.ptr_r();
		value_type* d_x = d.ptr_x();

		const raw::details::spdat<value_type>& Ad = mat.rep();
		const Integer* Ad_c = Ad.ptr_c();
		const Integer* Ad_r = Ad.ptr_r();
		const value_type* Ad_x = Ad.ptr_x();

		Integer cs = ci.r_step, cf, cl;
		if (cs < 0)
		{
			cs = -cs;
			cf = ci.r_end;
			cl = ci.r_start;
		}
		else
		{
			cf = ci.r_start;		
			cl = ci.r_end;
		};

		Integer col = 0, nz = 0;
		for (Integer j = 1; j < cf; ++j)
		{
			d_c[col] = nz;

			for (Integer i = Ad_c[j-1]; i < Ad_c[j]; ++i)
			{			
				Integer p = Ad_r[i];
				value_type tmp = Ad_x[i];
				if (mmlib::details::is_zero(tmp))
				{
					continue;
				};
				d_r[nz] = p;
				d_x[nz] = tmp;
				++nz;
			};
			++col;
		};
		if (cs != 1)
		{
			for (Integer j = cf; j <= cl; ++j)
			{
				if (((j-cf) % cs) == 0)
				{
					continue;
				};
				d_c[col] = nz;

				for (Integer i = Ad_c[j-1]; i < Ad_c[j]; ++i)
				{			
					Integer p = Ad_r[i];
					value_type tmp = Ad_x[i];
					if (mmlib::details::is_zero(tmp))
					{
						continue;
					};
					d_r[nz] = p;
					d_x[nz] = tmp;
					++nz;
				};
				++col;
			};
		};
		for (Integer j = cl; j < c0; ++j)
		{
			d_c[col] = nz;

			for (Integer i = Ad_c[j]; i < Ad_c[j+1]; ++i)
			{			
				Integer p       = Ad_r[i];
				value_type tmp  = Ad_x[i];
				if (mmlib::details::is_zero(tmp))
				{
					continue;
				};
				d_r[nz] = p;
				d_x[nz] = tmp;
				++nz;
			};
			++col;
		};

		d_c[c1] = nz;
		d.memadd(-1);

		return out;
	};
};

};};};

template struct mmlib::algorithm::details::del_cols_sparse_functor<mmlib::raw::IntegerSparseMatrix>;
template struct mmlib::algorithm::details::del_cols_sparse_functor<mmlib::raw::RealSparseMatrix>;
template struct mmlib::algorithm::details::del_cols_sparse_functor<mmlib::raw::ComplexSparseMatrix>;
template struct mmlib::algorithm::details::del_cols_sparse_functor<mmlib::raw::ObjectSparseMatrix>;

template struct mmlib::algorithm::details::del_rows_sparse_functor<mmlib::raw::IntegerSparseMatrix>;
template struct mmlib::algorithm::details::del_rows_sparse_functor<mmlib::raw::RealSparseMatrix>;
template struct mmlib::algorithm::details::del_rows_sparse_functor<mmlib::raw::ComplexSparseMatrix>;
template struct mmlib::algorithm::details::del_rows_sparse_functor<mmlib::raw::ObjectSparseMatrix>;
