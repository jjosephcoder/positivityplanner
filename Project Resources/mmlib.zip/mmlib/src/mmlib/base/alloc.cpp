/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/base/alloc.h"
#include "mmlib/object.h"

namespace mmlib { namespace details
{


template<> Object* aligned_malloc<Object>(type_info ti, size_t n_elem)
{
	Object* ptr = (Object*)_aligned_malloc(n_elem*sizeof(Object),cash_line_size);
    Object* ptr_sav = ptr;
    for (size_t i = 0; i < n_elem; ++i, ++ptr)
    {
        new(ptr) Object(ti);
    };
    return ptr_sav;
};

template<> void aligned_free<Object>(Object* ptr, size_t n_elem)
{
    for (size_t i = 0; i < n_elem; ++i)
    {
        ptr[i].~Object();
    };
	_aligned_free(ptr);
};
template<> Object* aligned_realloc<Object>(type_info ti, Object* old_ptr, size_t old_size, size_t n_elem)
{
    if (old_ptr == NULL)
    {
        return aligned_malloc<Object>(ti,n_elem);
    };
    if (n_elem == 0)
    {
        aligned_free<Object>(old_ptr,old_size);
        return NULL;
    };
    if (n_elem == old_size)
    {
        return old_ptr;
    };
    if (n_elem < old_size)
    {
        for (size_t i = n_elem; i < old_size; ++i)
        {
            old_ptr[i].~Object();
        };

        Object* new_ptr = (Object*)_aligned_realloc(old_ptr,n_elem*sizeof(Object),cash_line_size);
        if (new_ptr != old_ptr)
        {
            for (size_t i = 0; i < n_elem; ++i)
            {
                new_ptr[i].location_changed(&old_ptr[i], &new_ptr[i]);
            };
        };
        return new_ptr;
    };

	Object* new_ptr = (Object*)_aligned_realloc(old_ptr,n_elem*sizeof(Object),cash_line_size);
    for (size_t i = old_size; i < n_elem; ++i)
    {
        new(&new_ptr[i]) Object(ti);
    };
    if (new_ptr != old_ptr)
    {
        for (size_t i = 0; i < old_size; ++i)
        {
            new_ptr[i].location_changed(&old_ptr[i], &new_ptr[i]);
        };
    };
    return new_ptr;
};

};};