/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/scalar_types.h"
#include "mmlib/base/integer.h"
#include "mmlib/constants.h"
#include "mmlib/exception.h"

namespace mmlib 
{

//safe mult
Integer mmlib::imult_s(Integer r, Integer c)
{
    Real out = Real(r)*Real(c);
    if (out > Real(constants::MaxInt))
    {
        return constants::MaxInt;
    }
    else if (out < Real(constants::MinInt))
    {
        return constants::MinInt;
    }
    else
    {
        return (Integer)out;
    };
};
//test if mult can be performed
bool mmlib::imult_t(Integer r, Integer c)
{
    Real out = Real(r)*Real(c);
    if (out > Real(constants::MaxInt) || out < Real(constants::MinInt))
    {
        return false;
    };
    return true;
};

mmlib::Integer imult_c(Integer a, Integer b)
{
    if (imult_t(a,b))
    {
        return a*b;
    }
    else
    {
        throw error::error_int_mult(a, b);
    };
};

//test if cast can be performed
bool mmlib::icast_t(Real a)
{
    if (a > Real(constants::MaxInt) || a < Real(constants::MinInt))
    {
        return false;
    };
    return true;
};
Integer mmlib::icast_c(Real a)
{
    if (icast_t(a) == true) 
    {
        return (Integer)a;
    }
    else
    {
        throw error::error_int_cast(a);
    };
};
};