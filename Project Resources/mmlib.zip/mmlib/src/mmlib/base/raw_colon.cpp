/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/base/raw_colon.h"

namespace mmlib { namespace raw
{

void colon::apply(Integer n, Integer &st, Integer &in, Integer &en, Integer &le) const
{
    st = in = en = le = 0;

    switch (_flag)
    {
        case 'r':
            if ((_i == 0 ) || ((_e - _s) / _i < 0 ))
            {
                le = 0;
            }
            else
            {
                st = _s;
				in = _i;
                en = _e - (_e - _s) % _i;
                le = (_e - _s) / _i + 1;
            }
            break;
        case 'a':
            if (n)
            {
                st = 1;
                in = 1;
                en = n;
                le = n;
			}
            else
            {
                le = 0;
            }
            break;
        case 'e':
            if ((_i == 0 ) || ((n - _s) / _i < 0 ))
            {
                le = 0;
            }
            else
            {
                st = _s;
                in = _i;
                en = n - (n - _s) % _i;
                le = (n - _s) / _i + 1;
            }
            break;
        case 'E':
            if ((_i == 0 ) || ((_e - n) / _i < 0 ))
            {
                le = 0;
            }
            else
            {
                st = n, in = _i; 
                en = _e - (_e - n) % _i;
                le = (_e - n) / _i + 1;
            }
    }
	if ((st == en) && in < 0)
	{
		in = -in;
	};
}

};};