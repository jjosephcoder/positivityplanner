/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/struct_flag.h"
#include "mmlib/exception.h"
#include "mmlib/utils/utils.h"
#include "mmlib/details/matrix_func_binary.inl"


namespace mmlib 
{

namespace gd = mmlib::details;


struct_flag struct_flag::get_trans() const
{
    switch (get())
    {
        case zero:
        case id:
        case diag:
        case sym:
        case her:
        case general:    
            return *this;
        case tril:
            return struct_flag(triu);
        case triu:    
            return struct_flag(tril);
        case unitary:
            return *this;
        case qtril:
            return struct_flag(qtriu);
        case qtriu:
            return struct_flag(qtril);
        default:
            assertion(0,"unknown case");
            throw;
    };
};
struct_flag struct_flag::get_ctrans() const
{
    switch (get())
    {
        case zero:
        case id:
        case diag:
        case sym:
        case her:
        case general:
        case unitary:
            return *this;
        case tril:
            return struct_flag(triu);
        case triu:
            return struct_flag(tril);
        case qtril:
            return struct_flag(qtriu);
        case qtriu:
            return struct_flag(qtril);
        default:
            assertion(0,"unknown case");
            throw;
    };
};
struct_flag struct_flag::get_tril(Integer d) const
{
    switch (get())
    {
        case zero:        
        case diag:
        case tril:
            return *this;
        case id:
            if (d >= 0)     return *this;
            else            return struct_flag(zero);
        case qtril:
            if (d >= 1)     return *this;
            else            return struct_flag(tril);
        case qtriu:
            if (d >= 1)     return *this;
            else            return struct_flag(tril);
        case triu:
            if (d >= 1)     return *this;
            else            return struct_flag(diag);
        case sym:
        case her:
        case general:
        case unitary:
            if (d >= 1)     return struct_flag(general);
            else            return struct_flag(tril);
        default:
            assertion(0,"unknown case");
            throw;
    };
};
struct_flag struct_flag::get_triu(Integer d) const
{
    switch (get())
    {
        case zero:
        case diag:
        case triu:
            return *this;
        case id:
            if (d <= 0)     return *this;
            else            return struct_flag(zero);
        case tril:
            if (d <= -1)    return *this;
            else            return struct_flag(diag);
        case qtriu:
            if (d <= -1)    return *this;
            else            return struct_flag(triu);
        case qtril:
            if (d <= -1)    return *this;
            else            return struct_flag(triu);
        case sym:
        case her:
        case general:
        case unitary:
            if (d <= -1)    return struct_flag(general);
            else            return struct_flag(triu);
        default:
            assertion(0,"unknown case");
            throw;
    };
};

bool struct_flag::is_trans_id() const
{
    switch (get())
    {
        case zero:
        case id:
        case diag:
        case sym:
            return true;
        case her:
        case general:
        case tril:
        case triu:    
        case qtriu:
        case qtril:
            return false;
        case unitary:
            return false;
        default:
            assertion(0,"unknown case");
            throw;
    };
};
bool struct_flag::is_ctrans_id() const
{
    switch (get())
    {
        case zero:
        case her:
        case id:
            return true;        
        case diag:
        case sym:        
        case general:
        case tril:
        case triu:    
        case qtriu:
        case qtril:
        case unitary:
            return false;
        default:
            assertion(0,"unknown case");
            throw;
    };
};
bool struct_flag::is_tril_id() const
{
    switch (get())
    {
        case zero:
        case id:
        case diag:
        case tril:
            return true;
        case sym:
        case her:
        case general:
        case triu:    
        case unitary:
        case qtriu:
        case qtril:
            return false;
        default:
            assertion(0,"unknown case");
            throw;
    };
};
bool struct_flag::is_triu_id() const
{
    switch (get())
    {
        case zero:
        case id:
        case diag:
        case triu:
            return true;
        case sym:
        case her:
        case general:
        case tril:    
        case qtriu:
        case qtril:
        case unitary:
            return false;
        default:
            assertion(0,"unknown case");
            throw;
    };
};
struct_flag struct_flag::get_set_diag(Integer d, value_type vt) const
{
    bool is_zero = (vt == v_zero);
    bool is_one = (vt == v_one);
    bool is_real = (vt == v_real);

    struct_flag out = *this;

    switch(get())
    {
        case struct_flag::zero:
        {
            if (is_zero)
            {
            }
            else if (d == 0)
            {
                out.set_diag_matrix();
            }
            else if (d > 0)
            {
                out.set_triu_matrix();
            }
            else
            {
                out.set_tril_matrix();
            };
            break;
        }
        case struct_flag::id:
        {
            if (d == 0)
            {
                if (is_zero)
                {
                    out.set_zero_matrix();
                }
                else if (is_one)
                {
                    out.set_id_matrix();
                }
                else
                {
                    out.set_diag_matrix();
                }
                break;
            }
            else if (is_zero)
            {
            }
            else if (d > 0)
            {
                out.set_triu_matrix();
            }
            else
            {
                out.set_tril_matrix();
            };
            break;
        }
        case struct_flag::diag:
        {
            if (d == 0)
            {
                if (is_zero)
                {
                    out.set_zero_matrix();
                }
                else
                {
                    out.set_diag_matrix();
                }
                break;
            }
            else if (is_zero)
            {
            }
            else if (d > 0)
            {
                out.set_triu_matrix();
            }
            else
            {
                out.set_tril_matrix();
            };
            break;
        }
        case struct_flag::tril:
        {
            if (d > 0 && is_zero == false)
            {
                out.reset(false);
            }
            break;
        }
        case struct_flag::triu:
        {
            if (d < 0 && is_zero == false)
            {
                out.reset(false);
            };
            break;
        }
        case struct_flag::qtril:
        {
            if (d > 0 && is_zero == false)
            {
                out.reset(false);
            };
            break;
        }
        case struct_flag::qtriu:
        {
            if (d < 0 && is_zero == false)
            {
                out.reset(false);
            };
            break;
        }
        case struct_flag::sym:
        {
            if (d != 0) 
            {
                out.reset(false);
            }
            break;
        }
        case struct_flag::her:
        {
            if (d == 0 && is_real)  
            {}
            else
            {
                out.reset(false);
            }
            break;
        }
        case struct_flag::unitary:
        {
            out.reset(false);
            break;
        }
    };

    return out;
};
struct_flag struct_flag::get_scal_mult(value_type vt) const
{
    bool is_zero = (vt == v_zero);
    bool is_one = (vt == v_one);
    bool is_real = (vt == v_real);

    struct_flag out = *this;

    switch(get())
    {
        case struct_flag::zero:
        {
            break;
        }
        case struct_flag::id:
        {
            if (is_zero)
            {
                out.set_zero_matrix();
            }
            else if (is_one)
            {
                out.set_id_matrix();
            }
            else
            {
                out.set_diag_matrix();
            }
            break;
        }
        case struct_flag::diag:
        {
            if (is_zero)
            {
                out.set_zero_matrix();
            }
            else
            {
                out.set_diag_matrix();
            }
            break;
        }
        case struct_flag::tril:
        case struct_flag::triu:
        case struct_flag::sym:
        case struct_flag::qtril:
        case struct_flag::qtriu:
        {
            break;
        }
        case struct_flag::her:
        {
            if (is_real)
            {
            }
            else
            {
                out.reset(false);
            }
            break;
        }
        case struct_flag::unitary:
        {
            if (is_one)
            {                
            }
            else
            {
                out.reset(false);
            }
        }
    };

    return out;
};
struct_flag struct_flag::get_unitary() const
{
    struct_flag out = *this;

    switch(get())
    {
        case struct_flag::zero:
        case struct_flag::id:
        case struct_flag::unitary:
            return out;        
        case struct_flag::tril:
        case struct_flag::triu:
        case struct_flag::sym:
        case struct_flag::her:        
        case struct_flag::general:
        case struct_flag::qtril:
        case struct_flag::qtriu:
        {
            out = struct_flag(unitary);
            break;
        }
    };

    return out;
};
struct_flag struct_flag::get_qtril() const
{
    struct_flag out = *this;

    switch(get())
    {
        case struct_flag::zero:
        case struct_flag::id:
        case struct_flag::unitary:
        case struct_flag::tril:
        case struct_flag::qtril:
            return out;                
        case struct_flag::triu:
        case struct_flag::sym:
        case struct_flag::her:        
        case struct_flag::general:
        case struct_flag::qtriu:
        {
            out = struct_flag(qtril);
            break;
        }
    };

    return out;
};
struct_flag struct_flag::get_rectangle_view(bool is_square) const
{
    struct_flag out = *this;

    switch(get())
    {
        case struct_flag::zero:
            return out;
        case struct_flag::id:
        {
            if (is_square)
            {
                return out;
            }
            else
            {
                out = struct_flag(diag);
                return out;
            };
        }
        case struct_flag::diag:
        case struct_flag::tril:
        case struct_flag::triu:
        case struct_flag::qtril:
        case struct_flag::qtriu:
            return out;
        case struct_flag::sym:
        case struct_flag::her:
        {
            if (is_square)
            {
                return out;
            }
            else
            {
                out = struct_flag(general);
                return out;
            };
        }
        case struct_flag::unitary:
        case struct_flag::general:
        {
            out = struct_flag(general);
            break;
        }
    };

    return out;
};
struct_flag struct_flag::get_qtriu() const
{
    struct_flag out = *this;

    switch(get())
    {
        case struct_flag::zero:
        case struct_flag::id:
        case struct_flag::unitary:
        case struct_flag::triu:
        case struct_flag::qtriu:
            return out;                
        case struct_flag::tril:
        case struct_flag::sym:
        case struct_flag::her:        
        case struct_flag::general:
        case struct_flag::qtril:
        {
            out = struct_flag(qtriu);
            break;
        }
    };

    return out;
};

struct_flag::value_type struct_flag::get_value_type(Integer val)
{
    if (gd::is_zero(val))                   return struct_flag::v_zero;
    else if (gd::is_one(val))               return struct_flag::v_one;
    else                                    return struct_flag::v_real;
};
struct_flag::value_type struct_flag::get_value_type(Real val)
{
    if (gd::is_zero(val))                   return struct_flag::v_zero;
    else if (gd::is_one(val))               return struct_flag::v_one;
    else                                    return struct_flag::v_real;
};
struct_flag::value_type struct_flag::get_value_type(Complex val)
{
    if (gd::is_zero(val))                   return struct_flag::v_zero;
    else if (gd::is_one(val))               return struct_flag::v_one;
    else if (gd::is_zero(imag(val)))        return struct_flag::v_real;
    else                                    return struct_flag::v_general;
};
struct_flag::value_type struct_flag::get_value_type(Object val)
{
    return struct_flag::v_general;
};
struct_flag struct_flag::mult_struct(struct_flag f1, struct_flag f2)
{
    return op_struct(f1,f2,op_mult);
};
struct_flag struct_flag::plus_struct(struct_flag f1, struct_flag f2)
{
    return op_struct(f1,f2,op_plus);
};
struct_flag struct_flag::minus_struct(struct_flag f1, struct_flag f2)
{
    if (f2.get() == id)
    {
        if (f1.get() == id)         return struct_flag(zero);
        else if (f1.get() == zero)  return struct_flag(diag);
    };
    return op_struct(f1,f2,op_plus);
};
struct_flag struct_flag::dmult_struct(struct_flag f1, struct_flag f2)
{
    return op_struct(f1,f2,op_dmult);
};
struct_flag struct_flag::op_struct(struct_flag f1, struct_flag f2, op_type op)
{
    switch(f1.get())
    {
        case general:   return op_struct_gen(f2,op);
        case zero:      return op_struct_zero(f2,op);
        case id:        return op_struct_id(f2,op);
        case diag:      return op_struct_diag(f2,op);
        case tril:      return op_struct_tril(f2,op);
        case triu:      return op_struct_triu(f2,op);
        case sym:       return op_struct_sym(f2,op);
        case her:       return op_struct_her(f2,op);
        case unitary:   return op_struct_unitary(f2,op);
        case qtriu:     return op_struct_qtriu(f2,op);
        case qtril:     return op_struct_qtril(f2,op);
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_gen(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(general);
                case diag:      return struct_flag(general);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_plus:
            return struct_flag(general);
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(qtriu);
                case qtril:     return struct_flag(qtril);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_zero(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            return struct_flag(zero);
        case op_plus:
            return f2;
        case op_dmult:
            return struct_flag(zero);
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_id(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            return f2;
        case op_plus:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(id);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(sym);
                case her:       return struct_flag(her);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(qtriu);
                case qtril:     return struct_flag(qtril);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(diag);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(id);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(diag);
                case triu:      return struct_flag(diag);
                case sym:       return struct_flag(diag);
                case her:       return struct_flag(diag);
                case unitary:   return struct_flag(diag);
                case qtriu:     return struct_flag(diag);
                case qtril:     return struct_flag(diag);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_diag(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_plus:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(diag);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(sym);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(qtriu);
                case qtril:     return struct_flag(qtril);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(diag);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(diag);
                case triu:      return struct_flag(diag);
                case sym:       return struct_flag(diag);
                case her:       return struct_flag(diag);
                case unitary:   return struct_flag(diag);
                case qtriu:     return struct_flag(diag);
                case qtril:     return struct_flag(diag);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_tril(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(tril);
                case diag:      return struct_flag(tril);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(qtril);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_plus:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(tril);
                case id:        return struct_flag(tril);
                case diag:      return struct_flag(tril);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(qtril);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(tril);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(diag);
                case sym:       return struct_flag(tril);
                case her:       return struct_flag(tril);
                case unitary:   return struct_flag(tril);
                case qtriu:     return struct_flag(tril);
                case qtril:     return struct_flag(tril);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_triu(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(triu);
                case diag:      return struct_flag(triu);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(qtriu);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_plus:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(triu);
                case id:        return struct_flag(triu);
                case diag:      return struct_flag(triu);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(qtriu);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(triu);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(diag);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(triu);
                case her:       return struct_flag(triu);
                case unitary:   return struct_flag(triu);
                case qtriu:     return struct_flag(triu);
                case qtril:     return struct_flag(triu);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_sym(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(sym);
                case diag:      return struct_flag(general);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_plus:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(sym);
                case id:        return struct_flag(sym);
                case diag:      return struct_flag(sym);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(sym);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(sym);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(qtriu);
                case qtril:     return struct_flag(qtril);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_her(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(her);
                case diag:      return struct_flag(general);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_plus:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(her);
                case id:        return struct_flag(her);
                case diag:      return struct_flag(general);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(her);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(her);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(qtriu);
                case qtril:     return struct_flag(qtril);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_unitary(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(unitary);
                case diag:      return struct_flag(general);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(unitary);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_plus:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(unitary);
                case id:        return struct_flag(general);
                case diag:      return struct_flag(general);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(qtriu);
                case qtril:     return struct_flag(qtril);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_qtriu(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(qtriu);
                case diag:      return struct_flag(qtriu);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(qtriu);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_plus:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(qtriu);
                case id:        return struct_flag(qtriu);
                case diag:      return struct_flag(qtriu);
                case tril:      return struct_flag(general);
                case triu:      return struct_flag(qtriu);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(qtriu);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(qtriu);
                case her:       return struct_flag(qtriu);
                case unitary:   return struct_flag(qtriu);
                case qtriu:     return struct_flag(qtriu);
                case qtril:     return struct_flag(qtriu);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
struct_flag struct_flag::op_struct_qtril(struct_flag f2, op_type op)
{
    switch(op)
    {
        case op_mult:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(qtril);
                case diag:      return struct_flag(qtril);
                case tril:      return struct_flag(qtril);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_plus:
            switch(f2.get())
            {
                case general:   return struct_flag(general);
                case zero:      return struct_flag(qtril);
                case id:        return struct_flag(qtril);
                case diag:      return struct_flag(qtril);
                case tril:      return struct_flag(qtril);
                case triu:      return struct_flag(general);
                case sym:       return struct_flag(general);
                case her:       return struct_flag(general);
                case unitary:   return struct_flag(general);
                case qtriu:     return struct_flag(general);
                case qtril:     return struct_flag(general);
                default:        assertion(0,"unknown case"); throw;
            };
        case op_dmult:
            switch(f2.get())
            {
                case general:   return struct_flag(qtril);
                case zero:      return struct_flag(zero);
                case id:        return struct_flag(diag);
                case diag:      return struct_flag(diag);
                case tril:      return struct_flag(tril);
                case triu:      return struct_flag(triu);
                case sym:       return struct_flag(qtril);
                case her:       return struct_flag(qtril);
                case unitary:   return struct_flag(qtril);
                case qtriu:     return struct_flag(qtril);
                case qtril:     return struct_flag(qtril);
                default:        assertion(0,"unknown case"); throw;
            };
        default:        assertion(0,"unknown case"); throw;
    };
};
bool struct_flag::is_diag() const
{ 
    struct_type t = get();
    return t == diag || t == zero || t == id;
};
struct_flag& struct_flag::set_warnings()
{
    switch(get())
    {
        case general:
        case zero:
        case id:
        case diag:
        case tril:
        case triu:
        case sym:
        case qtriu:
        case qtril:
            break;
        case her:
            set(sym);
            break;
        case unitary:
            set(general);
            break;
        default:
        {
            assertion(0,"unknown case"); throw;
        }
    };
    return *this;
};
struct_flag& struct_flag::link_struct(struct_flag other)
{
    if (this->get() <= other.get())
    {
        return *this;
    }
    else
    {
        *this = other;
        return *this;
    };
};
struct_flag struct_flag::eval_struct(struct_flag f1, bool is_zero_id)
{
    if (is_zero_id)
    {
        switch(f1.get())
        {
            case general:   return struct_flag(general);
            case zero:      return struct_flag(zero);
            case id:        return struct_flag(diag);
            case diag:      return struct_flag(diag);
            case tril:      return struct_flag(tril);
            case triu:      return struct_flag(triu);
            case sym:       return struct_flag(sym);
            case her:       return struct_flag(general);
            case unitary:   return struct_flag(general);
            case qtriu:     return struct_flag(qtriu);
            case qtril:     return struct_flag(qtril);
            default:        assertion(0,"unknown case"); throw;
        };
    }
    else
    {
        switch(f1.get())
        {
            case general:   return struct_flag(general);
            case zero:      return struct_flag(general);
            case id:        return struct_flag(general);
            case diag:      return struct_flag(general);
            case tril:      return struct_flag(general);
            case triu:      return struct_flag(general);
            case sym:       return struct_flag(sym);
            case her:       return struct_flag(general);//?
            case unitary:   return struct_flag(general);//?
            case qtriu:     return struct_flag(general);
            case qtril:     return struct_flag(general);
            default:        assertion(0,"unknown case"); throw;
        };
    };
};
struct_flag struct_flag::get_abs() const
{
    switch(get())
    {
        case her:       return struct_flag(sym);
        case unitary:   return struct_flag(general);
        default:        return *this;
    };
};
struct_flag struct_flag::get_real() const
{
    switch(get())
    {
        case her:       return struct_flag(sym);
        case unitary:   return struct_flag(general);
        default:        return *this;
    };
};
struct_flag struct_flag::get_conj() const
{
    switch(get())
    {
        case unitary:   return struct_flag(general);
        default:        return *this;
    };
};

struct_flag struct_flag::get_resize(bool is_sym) const
{
    switch(get())
    {
        case general:   return struct_flag(general);
        case zero:      return struct_flag(zero);
        case id:        return struct_flag(diag);
        case diag:      return struct_flag(diag);
        case tril:      return struct_flag(tril);
        case triu:      return struct_flag(triu);        
        case unitary:   return struct_flag(general);
        case qtriu:     return struct_flag(qtriu);
        case qtril:     return struct_flag(qtril);
        case her:       
        case sym:
        {
            if (is_sym) return struct_flag(get());
            else        return struct_flag(general);
        }
        default:        assertion(0,"unknown case"); throw;
    };
};
};