/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/container/raw/type_decl.h"
#include "mmlib/base/integer.h"

namespace mmlib { namespace details
{

struct colon_info
{
    public:
	    Integer r_start, r_step, r_end, r_size, r_rep_size, r_flag;
	    Integer c_start, c_step, c_end, c_size, c_rep_size, c_flag;

        colon_info()
            :ri(get_raw_ti()),ci(get_raw_ti())
        {
            r_start = r_step = r_end = r_size = r_rep_size = r_flag = 0;
            c_start = c_step = c_end = c_size = c_rep_size = c_flag = 0;
        };

	    Integer     rows() const;
	    Integer     cols() const;
        Integer     rep_rows() const                { return r_rep_size; };
	    Integer     rep_cols() const                { return c_rep_size; };
        const raw::IntegerMatrix    get_ri() const  { return ri; };
        const raw::IntegerMatrix    get_ci() const  { return ci; };

	    Integer     row_index(Integer row) const;
	    Integer     col_index(Integer col) const;

        void        set_ci(const raw::IntegerMatrix& m);
        void        set_ri(const raw::IntegerMatrix& m);

    private:
        //always vectors
        raw::IntegerMatrix ri,ci;
};

inline Integer colon_info::rows() const
{
	if (r_flag == 0)
	{
		return ri.size();
	};
	return r_size;
};
inline Integer colon_info::cols() const
{
	if (c_flag == 0)
	{
		return ci.size();
	};
	return c_size;
};

inline Integer colon_info::row_index(Integer row) const
{
	if (r_flag == 0)
	{
		return ri.ptr()[row-1];
	};
	return r_start + imult(r_step,row-1);
};
inline Integer colon_info::col_index(Integer col) const
{
	if (c_flag == 0)
	{
		return ci.ptr()[col-1];
	};
	return c_start + imult(c_step,col-1);
};

};};
