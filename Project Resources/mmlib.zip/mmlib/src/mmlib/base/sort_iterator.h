/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include <boost/iterator/iterator_facade.hpp>
#include "mmlib/details/scalfunc_helpers.h"

namespace mmlib { namespace details
{
template<class T>
struct less_nan
{
	static bool eval(T A, T B)
	{
        type_info ti_int = get_raw_ti();

		if (mmlib::raw::details::isnan_helper<T>::eval(ti_int,A))
		{
			return false;
		};
		if (mmlib::raw::details::isnan_helper<T>::eval(ti_int,B))
		{
			return true;
		};
		return mmlib::raw::details::lt_helper<T,T>::eval(ti_int,A,B);
	};
};

template<class T,class S> class value_ind_ref;
template<class T,class S>
class value_ind
{
	public:
		T			x;
		S			ind;		

	public:
		value_ind(T ptr, S index) : x(ptr),ind(index) {};

		value_ind(const value_ind_ref<T,S>& other) : x(other.x),ind(other.ind) {};

		bool operator<(const value_ind& other)
		{
			return less_nan<T>::eval(x,other.x);
		};

		value_ind&	operator=(const value_ind& other)
		{
			x	= other.x;
			ind = other.ind;
			return *this;
		};
		value_ind&	operator=(const value_ind_ref<T,S>& other)
		{
			x	= other.x;
			ind = other.ind;
			return *this;
		};
};
template<class T,class S>
class value_ind_ref
{
	public:
		T&			x;
		S&			ind;		

	public:
		value_ind_ref(T& ptr, S& index) : x(ptr),ind(index) {};

		value_ind_ref(value_ind<T,S>& other) : x(other.x),ind(other.ind) {};

		bool operator<(const value_ind_ref& other)
		{
			return less_nan<T>::eval(x,other.x);
		};

		value_ind_ref&	operator=(const value_ind_ref& other)
		{
			x	= other.x;
			ind = other.ind;
			return *this;
		};
		value_ind_ref&	operator=(const value_ind<T,S>& other)
		{
			x	= other.x;
			ind = other.ind;
			return *this;
		};
};
template <class T,class S> 
struct value_ind_compare 
{ 
    bool operator()(const  value_ind_ref<T,S>& t1, const value_ind_ref<T,S>& t2) 
    { 
		return less_nan<T>::eval(t1.x,t2.x); 
    } 
}; 

template<class T,class S>
class iterator_helper_2 : public boost::iterator_facade
								<	iterator_helper_2<T,S>,
									value_ind<T,S>, 
									std::random_access_iterator_tag,
									value_ind_ref<T,S>
								>
{
	private:
		T*				x_ptr;
		S*				ind_ptr;
		Integer			ld;

	public:
		iterator_helper_2() : x_ptr(0),ind_ptr(0),ld(0) {};
		iterator_helper_2(T* x_ptr, S* ind_ptr, Integer ld) 
			:x_ptr(x_ptr),ind_ptr(ind_ptr), ld(ld)
		{};

	private:
		friend class boost::iterator_core_access;

		void increment() 
		{ 
			x_ptr	+= ld; 
			ind_ptr	+= ld; 
		};
		void decrement() 
		{ 
			x_ptr	-= ld; 
			ind_ptr	-= ld; 
		};
		bool equal(iterator_helper_2 const& other) const
		{
			return this->x_ptr == other.x_ptr;
		}
		value_ind_ref<T,S> dereference() const
		{ 
			return value_ind_ref<T,S>(*x_ptr,*ind_ptr); 
		};
		difference_type distance_to(iterator_helper_2 j) const
		{
			return (j.x_ptr - this->x_ptr)/ld;
		}
		void advance(difference_type n)
		{
			this->x_ptr	+= imult(n,ld);
			this->ind_ptr += imult(n,ld);
		};
};


};};