/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/mp/promote_type.h"
#include "mmlib/base/functors_helpers.h"

namespace mmlib { namespace raw
{

namespace raw_functions
{
	enum functions
	{
		isnan,isinf,isfinite,real,abs,conj,imag,arg,angle,
		sqrt,pow2,log,exp,log2,log10,floor,ifloor,ceil,iceil,round,iround,fix,ifix,trunc,itrunc,sign,isign,
		sin,cos,tan,cot,sec,csc, asin,acos,atan,acot,asec,acsc, 
		sinh,cosh,tanh,coth,sech,csch, asinh,acosh,atanh,acoth,asech,acsch,
		op_unary_minus,op_neg,is_true,nnz,
		trans,ctrans,vec,flipud,fliplr,reshape,tril,triu,repmat,
		sum,prod,cumsum,cumprod,sumsq,min,max,mean,std,all,any,
		sort,sortrows,sortcols,sortrows_2,sortcols_2,issorted,issorted_rows,issorted_cols,
        find,find2,find3,
		op_mult,op_div,kron,op_or,op_and,op_eeq,op_leq,op_geq,op_neq,op_lt,op_gt,xor,pow,mul,div,idiv,
        max2,min2,min_2,max_2,min_abs,max_abs,min_abs2,max_abs2,
		op_plus,op_minus,mod,rem,atan2
	};
};

namespace details
{
    template<class T> struct real_or_object     {   typedef Real type; };
    template<> struct real_or_object<Object>    {   typedef Object type; };

    template<class T1,class T2> 
    struct object_or_min_type 
    {   
        typedef typename mmlib::details::min_type<T1,T2>::type type;
    };
    template<class T2> 
    struct object_or_min_type<Object,T2>    
    {   
        typedef Object type; 
    };
    

	template<class MP,enum raw_functions::functions func>
	struct return_type_impl {};

	template<class MP,enum raw_functions::functions func>
	struct return_type_scal_impl {};

	template<class MP1, class MP2,enum raw_functions::functions func, class arg>
	struct return_type_mat_mat_impl
	{};
	template<class MP1, class MP2,enum raw_functions::functions func, class arg>
	struct return_type_mat_scal_impl
	{};
	template<class MP1, class MP2,enum raw_functions::functions func, class arg>
	struct return_type_scal_mat_impl
	{};
	template<class MP1, class MP2,enum raw_functions::functions func, class arg>
	struct return_type_scal_scal_impl
	{};

	template<class MP>
	struct return_type_impl<MP,raw_functions::vec> 
	{
		typedef typename manip_reshape_helper<MP>::ret_type_vec type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::vec> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::reshape> 
	{
		typedef typename manip_reshape_helper<MP>::ret_type_reshape type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::reshape> 
	{
		typedef MP type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::isnan> 
	{
		typedef typename mappers_isa_helper<MP>::ret_type_nan type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::isnan> 
	{
		typedef bool type;
	};


	template<class MP>
	struct return_type_impl<MP,raw_functions::isinf> 
	{
		typedef typename mappers_isa_helper<MP>::ret_type_inf type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::isinf> 
	{
		typedef bool type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::isfinite> 
	{
		typedef typename mappers_isa_helper<MP>::ret_type_finite type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::isfinite> 
	{
		typedef bool type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::real> 
	{
		typedef typename mappers_real_helper<MP>::ret_type type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::real> 
	{
		typedef typename object_or_min_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::abs> 
	{
		typedef typename mappers_real_helper<MP>::ret_type type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::abs> 
	{
		typedef typename object_or_min_type<MP,Real>::type type;        
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::conj> 
	{
		typedef typename mappers_real_helper<MP>::ret_type_conj type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::conj> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::imag> 
	{
		typedef typename mappers_real_helper<MP>::ret_type_imag type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::imag> 
	{
		typedef typename object_or_min_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::arg> 
	{
		typedef typename mappers_real_helper<MP>::ret_type_arg type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::arg> 
	{
        typedef typename real_or_object<MP>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::angle> 
	{
		typedef typename mappers_real_helper<MP>::ret_type_arg type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::angle> 
	{
		typedef Real type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::sqrt> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_sqrt type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::sqrt> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::pow2> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_pow2 type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::pow2> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::log> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_log type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::log> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::exp> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_exp type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::exp> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::log2> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_log2 type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::log2> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::log10> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_log10 type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::log10> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::floor> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_floor type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::floor> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::ifloor> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_ifloor type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::ifloor> 
	{
		typedef Integer type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::ceil> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_ceil type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::ceil> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::iceil> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_iceil type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::iceil> 
	{
		typedef Integer type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::round> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_round type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::round> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::iround> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_iround type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::iround> 
	{
		typedef Integer type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::fix> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_fix type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::fix> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::ifix> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_ifix type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::ifix> 
	{
		typedef Integer type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::trunc> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_trunc type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::trunc> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::itrunc> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_itrunc type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::itrunc> 
	{
		typedef Integer type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::sign> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_sign type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::sign> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::isign> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_isign type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::isign> 
	{
		typedef Integer type;
	};


	template<class MP>
	struct return_type_impl<MP,raw_functions::sin> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_sin type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::sin> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::cos> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_cos type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::cos> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::tan> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_tan type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::tan> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::cot> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_cot type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::cot> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::sec> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_sec type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::sec> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::csc> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_csc type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::csc> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::asin> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_asin type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::asin> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::acos> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_acos type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::acos> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::atan> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_atan type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::atan> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::acot> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_acot type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::acot> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::asec> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_asec type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::asec> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::acsc> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_acsc type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::acsc> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::sinh> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_sinh type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::sinh> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::cosh> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_cosh type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::cosh> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::tanh> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_tanh type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::tanh> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::coth> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_coth type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::coth> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::sech> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_sech type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::sech> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::csch> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_csch type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::csch> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::asinh> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_asinh type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::asinh> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::acosh> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_acosh type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::acosh> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::atanh> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_atanh type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::atanh> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::acoth> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_acoth type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::acoth> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::asech> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_asech type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::asech> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::acsch> 
	{
		typedef typename mappers_func_helper<MP>::ret_type_acsch type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::acsch> 
	{
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::op_unary_minus> 
	{
		typedef typename unary_helper<MP>::ret_type_minus type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::op_unary_minus> 
	{
		typedef MP type;
	};


	template<class MP>
	struct return_type_impl<MP,raw_functions::op_neg> 
	{
		typedef typename unary_helper<MP>::ret_type_neg type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::op_neg> 
	{
		typedef bool type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::is_true> 
	{
		typedef typename unary_helper<MP>::ret_type_is_true type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::is_true> 
	{
		typedef bool type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::trans> 
	{
		typedef typename manip_trans_helper<MP>::ret_type type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::trans> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::ctrans> 
	{
		typedef typename manip_trans_helper<MP>::ret_type type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::ctrans> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::flipud> 
	{
		typedef typename manip_reshape_helper<MP>::ret_type_flip type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::flipud> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::fliplr> 
	{
		typedef typename manip_reshape_helper<MP>::ret_type_flip type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::fliplr> 
	{
		typedef MP type;
	};


	template<class MP>
	struct return_type_impl<MP,raw_functions::tril> 
	{
		typedef typename manip_tr_helper<MP>::ret_type_tril type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::tril> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::triu> 
	{
		typedef typename manip_tr_helper<MP>::ret_type_triu type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::triu> 
	{
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::repmat> 
	{
		typedef typename manip_reshape_helper<MP>::ret_type_repmat type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::repmat> 
	{		
		typedef Matrix<MP,struct_dense> type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::sum> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_sum type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::sum> 
	{		
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::nnz> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_nnz type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::nnz> 
	{		
		typedef Integer type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::prod> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_prod type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::prod> 
	{		
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::cumsum> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_cumsum type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::cumsum> 
	{		
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::cumprod> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_cumprod type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::cumprod> 
	{		
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::sumsq> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_sumsq type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::sumsq> 
	{		
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::min> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_min type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::min> 
	{		
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::min_abs> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_min_abs type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::min_abs> 
	{		
        typedef typename gd::real_type<MP>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::min_2> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_min_2 type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::min_2> 
	{		
        typedef std::pair<MP,IntegerMatrix> type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::min_abs2> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_min_abs2 type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::min_abs2> 
	{		
        typedef typename gd::real_type<MP>::type MPR;
        typedef std::pair<MPR,IntegerMatrix> type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::max> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_max type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::max> 
	{		
		typedef MP type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::max_abs> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_max_abs type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::max_abs> 
	{	
        typedef typename gd::real_type<MP>::type MPR;
		typedef MPR type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::max_2> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_max_2 type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::max_2> 
	{		
        typedef std::pair<MP,IntegerMatrix> type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::max_abs2> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_max_abs2 type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::max_abs2> 
	{	
        typedef typename gd::real_type<MP>::type MPR;
        typedef std::pair<MPR,IntegerMatrix> type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::mean> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_mean type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::mean> 
	{		
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::std> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_std type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::std> 
	{		
		typedef typename mmlib::details::max_type<MP,Real>::type type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::all> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_all type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::all> 
	{		
		typedef bool type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::any> 
	{
		typedef typename vec_manip_helper<MP>::ret_type_any type;
	};
	template<class MP>
	struct return_type_scal_impl<MP,raw_functions::any> 
	{		
		typedef bool type;
	};

	template<class MP>
	struct return_type_impl<MP,raw_functions::sort> 
	{
		typedef typename sort_helper<MP>::ret_type_sort type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::sortrows> 
	{
		typedef typename sort_helper<MP>::ret_type_sortrows type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::sortcols> 
	{
		typedef typename sort_helper<MP>::ret_type_sortcols type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::sortrows_2> 
	{
		typedef typename sort_helper<MP>::ret_type_sortrows_2 type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::sortcols_2> 
	{
		typedef typename sort_helper<MP>::ret_type_sortcols_2 type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::issorted> 
	{
		typedef typename sort_helper<MP>::ret_type_issorted type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::issorted_rows> 
	{
		typedef bool type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::issorted_cols> 
	{
		typedef bool type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::find> 
	{
		typedef typename find_helper<MP>::ret_type_find type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::find2> 
	{
		typedef typename find_helper<MP>::ret_type_find2 type;
	};
	template<class MP>
	struct return_type_impl<MP,raw_functions::find3> 
	{
		typedef typename find_helper<MP>::ret_type_find3 type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_mult,arg>
	{
		typedef typename mult_helper<MP1,MP2>::ret_type type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_mult,arg>
	{
		typedef typename scal_helper<MP1,MP2>::ret_type_mul type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_mult,arg>
	{
		typedef typename scal_helper<MP2,MP1>::ret_type_mul type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_mult,arg>
	{
		typedef Complex type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_div,arg>
	{
		typedef typename scal_helper<MP1,MP2>::ret_type_div type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_div,arg>
	{
		typedef Complex type;
	};


	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::kron,arg>
	{
		typedef typename kron_helper<MP1,MP2>::ret_type type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::kron,arg>
	{
		typedef typename kron_scal_helper<MP1,MP2>::ret_type_mul type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::kron,arg>
	{
		typedef typename kron_scal_helper<MP2,MP1>::ret_type_mul type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::kron,arg>
	{		
		typedef typename kron_scal_scal_helper<MP1,MP2>::val_ret type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_or,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_or type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_or,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_or type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_or,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_or type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_or,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_or type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_and,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_and type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_and,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_and type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_and,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_and type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_and,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_and type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_eeq,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_eeq type;
	};
	template<class MP1, class MP2>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_eeq,void>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_eeq type;
	};
	template<class MP1, class MP2>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_eeq,void>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_eeq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_eeq,arg>
	{
		typedef typename mat_func_scal_mat_arg_helper<MP1,MP2,arg>::ret_type_eeq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_eeq,arg>
	{
		typedef typename mat_func_mat_scal_arg_helper<MP1,MP2,arg>::ret_type_eeq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_eeq,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_eeq type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_leq,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_leq type;
	};
	template<class MP1, class MP2>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_leq,void>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_leq type;
	};
	template<class MP1, class MP2>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_leq,void>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_leq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_leq,arg>
	{
		typedef typename mat_func_scal_mat_arg_helper<MP1,MP2,arg>::ret_type_leq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_leq,arg>
	{
		typedef typename mat_func_mat_scal_arg_helper<MP1,MP2,arg>::ret_type_leq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_leq,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_leq type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_geq,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_geq type;
	};
	template<class MP1, class MP2>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_geq,void>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_geq type;
	};
	template<class MP1, class MP2>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_geq,void>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_geq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_geq,arg>
	{
		typedef typename mat_func_scal_mat_arg_helper<MP1,MP2,arg>::ret_type_geq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_geq,arg>
	{
		typedef typename mat_func_mat_scal_arg_helper<MP1,MP2,arg>::ret_type_geq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_geq,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_geq type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_neq,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_neq type;
	};
	template<class MP1, class MP2>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_neq,void>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_neq type;
	};
	template<class MP1, class MP2>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_neq,void>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_neq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_neq,arg>
	{
		typedef typename mat_func_scal_mat_arg_helper<MP1,MP2,arg>::ret_type_neq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_neq,arg>
	{
		typedef typename mat_func_mat_scal_arg_helper<MP1,MP2,arg>::ret_type_neq type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_neq,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_neq type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_lt,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_lt type;
	};
	template<class MP1, class MP2>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_lt,void>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_lt type;
	};
	template<class MP1, class MP2>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_lt,void>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_lt type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_lt,arg>
	{
		typedef typename mat_func_scal_mat_arg_helper<MP1,MP2,arg>::ret_type_lt type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_lt,arg>
	{
		typedef typename mat_func_mat_scal_arg_helper<MP1,MP2,arg>::ret_type_lt type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_lt,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_lt type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_gt,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_lt type;
	};
	template<class MP1, class MP2>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_gt,void>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_lt type;
	};
	template<class MP1, class MP2>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_gt,void>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_lt type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_gt,arg>
	{
		typedef typename mat_func_scal_mat_arg_helper<MP1,MP2,arg>::ret_type_lt type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_gt,arg>
	{
		typedef typename mat_func_mat_scal_arg_helper<MP1,MP2,arg>::ret_type_lt type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_gt,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_lt type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::xor,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_xor type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::xor,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_xor type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::xor,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_xor type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::xor,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_xor type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::pow,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_pow type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::pow,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_pow type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::pow,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_pow type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::pow,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_pow type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::mul,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_mul type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::mul,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_mul type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::mul,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_mul type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::mul,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_mul type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::div,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_div type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::div,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_div type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::div,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_div type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::div,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_div type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::idiv,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_idiv type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::idiv,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_idiv type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::idiv,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_idiv type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::idiv,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_idiv type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::max2,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_max type;
	};
	template<class MP1, class MP2>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::max2,void>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_max type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::max2,arg>
	{
		typedef typename mat_func_scal_mat_arg_helper<MP1,MP2,arg>::ret_type_max type;
	};
	template<class MP1, class MP2>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::max2,void>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_max type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::max2,arg>
	{
		typedef typename mat_func_mat_scal_arg_helper<MP1,MP2,arg>::ret_type_max type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::max2,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_max type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::min2,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_min type;
	};
	template<class MP1, class MP2>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::min2,void>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_min type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::min2,arg>
	{
		typedef typename mat_func_scal_mat_arg_helper<MP1,MP2,arg>::ret_type_min type;
	};
	template<class MP1, class MP2>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::min2,void>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_min type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::min2,arg>
	{
		typedef typename mat_func_mat_scal_arg_helper<MP1,MP2,arg>::ret_type_min type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::min2,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_min type;
	};


	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_plus,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_plus type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_plus,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_plus type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_plus,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_plus type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_plus,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_plus type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::op_minus,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_minus type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::op_minus,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_minus type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::op_minus,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_minus type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::op_minus,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_minus type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::mod,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_mod type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::mod,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_mod type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::mod,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_mod type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::mod,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_mod type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::rem,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_rem type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::rem,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_rem type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::rem,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_rem type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::rem,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_rem type;
	};

	template<class MP1, class MP2, class arg>
	struct return_type_mat_mat_impl<MP1,MP2,raw_functions::atan2,arg>
	{
		typedef typename mat_func_helper<MP1,MP2>::ret_type_atan2 type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_mat_impl<MP1,MP2,raw_functions::atan2,arg>
	{
		typedef typename mat_func_scal_mat_helper<MP1,MP2>::ret_type_atan2 type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_mat_scal_impl<MP1,MP2,raw_functions::atan2,arg>
	{
		typedef typename mat_func_mat_scal_helper<MP1,MP2>::ret_type_atan2 type;
	};
	template<class MP1, class MP2, class arg>
	struct return_type_scal_scal_impl<MP1,MP2,raw_functions::atan2,arg>
	{
		typedef typename mat_func_scal_scal_helper<MP1,MP2>::ret_type_atan2 type;
	};
};

template<class M,enum raw_functions::functions func>
struct return_type
{
	typedef typename promote_type<M>::type MP;
	typedef typename details::return_type_impl<MP,func>::type type;
};
template<class M,enum raw_functions::functions func>
struct return_type_scalar
{
	typedef typename mmlib::details::promote_scalar<M>::type MP;
	typedef typename details::return_type_scal_impl<MP,func>::type type;
};

template<class M1,class M2, enum raw_functions::functions func,class arg = void>
struct return_type_mat_mat
{
	typedef typename promote_type<M1>::type MP1;
	typedef typename promote_type<M2>::type MP2;
	typedef typename details::return_type_mat_mat_impl<MP1,MP2,func,arg>::type type;
};

template<class M1,class M2, enum raw_functions::functions func,class arg = void>
struct return_type_mat_scal
{
	typedef typename promote_type<M1>::type MP1;
	typedef typename mmlib::details::promote_scalar<M2>::type MP2;
	typedef typename details::return_type_mat_scal_impl<MP1,MP2,func,arg>::type type;
};

template<class M1,class M2, enum raw_functions::functions func, class arg = void>
struct return_type_scal_mat
{
	typedef typename promote_type<M2>::type MP2;
	typedef typename mmlib::details::promote_scalar<M1>::type MP1;
	typedef typename details::return_type_scal_mat_impl<MP1,MP2,func,arg>::type type;
};
template<class M1,class M2, enum raw_functions::functions func,class arg = void>
struct return_type_scal_scal
{
	typedef typename mmlib::details::promote_scalar<M1>::type MP1;
	typedef typename mmlib::details::promote_scalar<M2>::type MP2;
	typedef typename details::return_type_scal_scal_impl<MP1,MP2,func,arg>::type type;
};

};};