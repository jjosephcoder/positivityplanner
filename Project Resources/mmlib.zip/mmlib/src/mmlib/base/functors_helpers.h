/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/details/mpl.h"
#include "mmlib/details/isa.h"
#include "mmlib/details/utils.h"
#include "mmlib/details/type_codes.h"
#include "mmlib/container/raw/type_decl.h"
#include "mmlib/details/matfunc_helpers.h"

namespace mmlib { namespace raw { namespace details
{

	template<class MP>
	struct manip_reshape_helper
	{
		typedef typename MP::value_type								value_type;
		typedef typename MP::struct_type			struct_type;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<struct_type,struct_banded>::value,
				struct_sparse,
				struct_type
			>::type									struct_type_ret;

		typedef Matrix<value_type,struct_type_ret>	ret_type_vec;
		typedef Matrix<value_type,struct_type_ret>	ret_type_flip;
		typedef Matrix<value_type,struct_type_ret>	ret_type_reshape;
		typedef Matrix<value_type,struct_type_ret>	ret_type_repmat;

		static ret_type_vec		eval_vec(const MP& m);
		static ret_type_flip	eval_flipud(const MP& m);
		static ret_type_flip	eval_fliplr(const MP& m);
		static ret_type_reshape	eval_reshape(const MP& A, Integer m, Integer n);
		static ret_type_repmat  eval_repmat(const MP& A, Integer m, Integer n);
	};

	template<class M>
	struct mappers_isa_helper
	{
		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<typename M::value_type,Integer>::value,
				struct_sparse,
				typename M::struct_type
			>::type											struct_type;

		typedef Matrix<Integer,struct_type>					ret_type_nan;
		typedef Matrix<Integer,struct_type>					ret_type_inf;
		typedef Matrix<Integer,struct_dense>				ret_type_finite;


		static ret_type_nan			eval_is_nan(const M& m);
		static ret_type_inf			eval_is_inf(const M& m);
		static ret_type_finite		eval_is_finite(const M& m);
	};
	template<class MP>
	struct mappers_real_helper
	{
		typedef typename MP::value_type								value_type;
		typedef typename MP::struct_type							struct_type;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<value_type,Complex>::value,
				Matrix<Real,struct_type>,
				MP
			>::type													ret_type;

		typedef MP													ret_type_conj;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<value_type,Complex>::value,
				Matrix<Real,struct_type>,
				Matrix<typename mmlib::details::real_type<value_type>::type,struct_sparse>
			>::type													ret_type_imag;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<value_type,Complex>::value 
					|| mmlib::details::is_equal<value_type,Integer>::value,
				Matrix<Real,struct_type>,
				MP
			>::type													ret_type_arg;

		static ret_type			eval_real(const MP& m);
		static ret_type_imag	eval_imag(const MP& m);
		static ret_type_conj	eval_conj(const MP& m);
		static ret_type			eval_abs(const MP& m);				
		static ret_type_arg		eval_arg(const MP& m);
	};
	template<class MP, bool is_f_0>
	struct func_ret_type
	{
		typedef typename MP::value_type				value_type;
		typedef typename MP::struct_type			struct_type;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<value_type,Integer>::value,
				Real,
				value_type
			>::type									ret_val;

		typedef typename mmlib::details::select_if
			<
				!is_f_0,
				struct_dense,
				struct_type
			>::type									ret_str;

		typedef raw::Matrix<ret_val,ret_str>		type;
	};


	template<class MP>
	struct mappers_func_helper
	{
		typedef typename MP::struct_type				struct_type;
		typedef Matrix<Integer,struct_type>				integer_matrix;

		typedef MP										ret_type_floor;
		typedef MP										ret_type_ceil;
		typedef MP										ret_type_round;
		typedef MP										ret_type_fix;
		typedef MP										ret_type_trunc;
		typedef MP										ret_type_sign;

		typedef integer_matrix							ret_type_ifloor;
		typedef integer_matrix							ret_type_iceil;
		typedef integer_matrix							ret_type_iround;
		typedef integer_matrix							ret_type_ifix;
		typedef integer_matrix							ret_type_itrunc;
		typedef integer_matrix							ret_type_isign;

		typedef typename func_ret_type<MP,true>::type	ret_type_sqrt;
		typedef typename func_ret_type<MP,false>::type	ret_type_pow2;
		typedef typename func_ret_type<MP,false>::type	ret_type_log;
		typedef typename func_ret_type<MP,false>::type	ret_type_log2;
		typedef typename func_ret_type<MP,false>::type	ret_type_log10;
		typedef typename func_ret_type<MP,false>::type	ret_type_exp;

		typedef typename func_ret_type<MP,true>::type	ret_type_sin;
		typedef typename func_ret_type<MP,false>::type	ret_type_cos;
		typedef typename func_ret_type<MP,true>::type	ret_type_tan;
		typedef typename func_ret_type<MP,false>::type	ret_type_cot;
		typedef typename func_ret_type<MP,false>::type	ret_type_sec;
		typedef typename func_ret_type<MP,false>::type	ret_type_csc;

		typedef typename func_ret_type<MP,true>::type	ret_type_asin;
		typedef typename func_ret_type<MP,false>::type	ret_type_acos;
		typedef typename func_ret_type<MP,true>::type	ret_type_atan;
		typedef typename func_ret_type<MP,false>::type	ret_type_acot;
		typedef typename func_ret_type<MP,false>::type	ret_type_asec;
		typedef typename func_ret_type<MP,false>::type	ret_type_acsc;

		typedef typename func_ret_type<MP,true>::type	ret_type_sinh;
		typedef typename func_ret_type<MP,false>::type	ret_type_cosh;
		typedef typename func_ret_type<MP,true>::type	ret_type_tanh;
		typedef typename func_ret_type<MP,false>::type	ret_type_coth;
		typedef typename func_ret_type<MP,false>::type	ret_type_sech;
		typedef typename func_ret_type<MP,false>::type	ret_type_csch;

		typedef typename func_ret_type<MP,true>::type	ret_type_asinh;
		typedef typename func_ret_type<MP,false>::type	ret_type_acosh;
		typedef typename func_ret_type<MP,true>::type	ret_type_atanh;
		typedef typename func_ret_type<MP,false>::type	ret_type_acoth;
		typedef typename func_ret_type<MP,false>::type	ret_type_asech;
		typedef typename func_ret_type<MP,false>::type	ret_type_acsch;

		static ret_type_sqrt	eval_sqrt(const MP& m);
		static ret_type_pow2	eval_pow2(const MP& m);
		static ret_type_log		eval_log(const MP& m);
		static ret_type_log2	eval_log2(const MP& m);
		static ret_type_log10	eval_log10(const MP& m);
		static ret_type_exp		eval_exp(const MP& m);

		static ret_type_floor	eval_floor(const MP& m);
		static ret_type_ceil	eval_ceil(const MP& m);
		static ret_type_round	eval_round(const MP& m);
		static ret_type_fix		eval_fix(const MP& m);
		static ret_type_trunc	eval_trunc(const MP& m);
		static ret_type_sign	eval_sign(const MP& m);		

		static ret_type_ifloor	eval_ifloor(const MP& m);
		static ret_type_iceil	eval_iceil(const MP& m);
		static ret_type_iround	eval_iround(const MP& m);
		static ret_type_ifix	eval_ifix(const MP& m);
		static ret_type_itrunc	eval_itrunc(const MP& m);
		static ret_type_isign	eval_isign(const MP& m);

		static ret_type_sin		eval_sin(const MP& m);
		static ret_type_cos		eval_cos(const MP& m);
		static ret_type_tan		eval_tan(const MP& m);
		static ret_type_cot		eval_cot(const MP& m);
		static ret_type_sec		eval_sec(const MP& m);
		static ret_type_csc		eval_csc(const MP& m);

		static ret_type_asin	eval_asin(const MP& m);
		static ret_type_acos	eval_acos(const MP& m);
		static ret_type_atan	eval_atan(const MP& m);
		static ret_type_acot	eval_acot(const MP& m);
		static ret_type_asec	eval_asec(const MP& m);
		static ret_type_acsc	eval_acsc(const MP& m);

		static ret_type_sinh	eval_sinh(const MP& m);
		static ret_type_cosh	eval_cosh(const MP& m);
		static ret_type_tanh	eval_tanh(const MP& m);
		static ret_type_coth	eval_coth(const MP& m);
		static ret_type_sech	eval_sech(const MP& m);
		static ret_type_csch	eval_csch(const MP& m);

		static ret_type_asinh	eval_asinh(const MP& m);
		static ret_type_acosh	eval_acosh(const MP& m);
		static ret_type_atanh	eval_atanh(const MP& m);
		static ret_type_acoth	eval_acoth(const MP& m);
		static ret_type_asech	eval_asech(const MP& m);
		static ret_type_acsch	eval_acsch(const MP& m);
	};

	template<class MP>
	struct unary_helper
	{	
		typedef typename MP::struct_type str_type;

		typedef typename mmlib::details::select_if
			< 
			mmlib::details::is_equal<str_type,struct_dense>::value,
				struct_sparse,
				struct_dense
			>::type				str_neg;

		typedef MP							ret_type_minus;
		typedef Matrix<Integer,str_type>	ret_type_is_true;
		typedef Matrix<Integer,str_neg>		ret_type_neg;

		static ret_type_minus	eval_minus(const MP& m);
		static ret_type_neg		eval_neg(const MP& m);
		static ret_type_is_true	eval_is_true(const MP& m);
	};

	template<class MP> struct is_true_impl{};
	template<> struct is_true_impl<Integer>
	{
		static Integer eval(Integer val)
		{
			return (val==0)? 0 : 1;
		};
	};
	template<> struct is_true_impl<Real>
	{
		static Integer eval(Real val)
		{
			return (val==0.)? 0 : 1;
		};
	};
	template<> struct is_true_impl<Complex>
	{
		static Integer eval(const Complex& val)
		{
			return (real(val)== 0. && imag(val) == 0.)? 0 : 1;
		};
	};

	template<class MP>
	struct manip_trans_helper
	{
		typedef MP				ret_type;

		static ret_type			eval_trans(const MP& m);
		static ret_type			eval_ctrans(const MP& m);
	};


	template<class MP>
	struct manip_tr_helper
	{
		typedef MP				 ret_type_tril;				
		typedef MP				 ret_type_triu;

		static ret_type_tril	eval_tril(const MP& m, Integer d);
		static ret_type_triu	eval_triu(const MP& m, Integer d);
	};

	template<class MP>
	struct vec_manip_helper
	{
		typedef typename MP::value_type								value_type;
		typedef typename MP::struct_type							struct_type;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<value_type,Integer>::value,
				Real,
				value_type
			>::type													value_type_real;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<value_type,Complex>::value,
				Real,
				value_type
			>::type													real_value_type;

		typedef Matrix<value_type,struct_dense>						ret_type_sum;
        typedef Matrix<Integer,struct_dense>						ret_type_nnz;
		typedef Matrix<value_type,struct_dense>						ret_type_prod;
		typedef Matrix<value_type,struct_dense>						ret_type_cumsum;
		typedef Matrix<value_type,struct_dense>						ret_type_cumprod;
		typedef Matrix<value_type,struct_dense>						ret_type_sumsq;
		typedef Matrix<value_type,struct_dense>						ret_type_min;
		typedef Matrix<value_type,struct_dense>						ret_type_max;
		typedef Matrix<real_value_type,struct_dense>				ret_type_min_abs;
		typedef Matrix<real_value_type,struct_dense>				ret_type_max_abs;
		typedef Matrix<value_type_real,struct_dense>				ret_type_mean;		
		typedef Matrix<value_type_real,struct_dense>				ret_type_std;
		typedef Matrix<Integer,struct_dense>						ret_type_any;
		typedef Matrix<Integer,struct_dense>						ret_type_all;
        typedef std::pair<ret_type_min,IntegerMatrix>               ret_type_min_2;
        typedef std::pair<ret_type_max,IntegerMatrix>               ret_type_max_2;
        typedef std::pair<ret_type_min_abs,IntegerMatrix>           ret_type_min_abs2;
        typedef std::pair<ret_type_max_abs,IntegerMatrix>           ret_type_max_abs2;

        static ret_type_nnz		    eval_nnz(const MP& m, int dim);
		static ret_type_sum		    eval_sum(const MP& m, int dim);
		static ret_type_prod	    eval_prod(const MP& m, int dim);
		static ret_type_cumsum	    eval_cumsum(const MP& m, int dim);
		static ret_type_cumprod	    eval_cumprod(const MP& m, int dim);
		static ret_type_sumsq	    eval_sumsq(const MP& m, int dim);
		static ret_type_min		    eval_min(const MP& m, int dim);
		static ret_type_max		    eval_max(const MP& m, int dim);
		static ret_type_min_abs	    eval_min_abs(const MP& m, int dim);
		static ret_type_max_abs	    eval_max_abs(const MP& m, int dim);
		static ret_type_min_2	    eval_min2(const MP& m, int dim);
		static ret_type_max_2	    eval_max2(const MP& m, int dim);
		static ret_type_min_abs2	eval_min_abs2(const MP& m, int dim);
		static ret_type_max_abs2	eval_max_abs2(const MP& m, int dim);
		static ret_type_mean	    eval_mean(const MP& m, int dim);
		static ret_type_std		    eval_std(const MP& m, int dim);
		static ret_type_any		    eval_any(const MP& m, int dim);
		static ret_type_all		    eval_all(const MP& m, int dim);
		static ret_type_any		    eval_any(const MP& m, const test_function& t,int dim);
		static ret_type_all		    eval_all(const MP& m, const test_function& t,int dim);
	};

	template<class MP>
	struct sort_helper
	{	
		typedef typename MP::value_type			val_type;
		typedef typename MP::struct_type		str_type;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<str_type,struct_banded>::value,
				struct_sparse,
				str_type
			>::type								ret_str_type;

		typedef Matrix<val_type,ret_str_type>	ret_type_sort;
		typedef Matrix<val_type,ret_str_type>	ret_type_sortrows;
		typedef Matrix<val_type,ret_str_type>	ret_type_sortcols;
		typedef Matrix<Integer,struct_dense>	ret_type_issorted;

        typedef std::pair<ret_type_sortrows,IntegerMatrix>    ret_type_sortrows_2;
        typedef std::pair<ret_type_sortcols,IntegerMatrix>    ret_type_sortcols_2;


		static ret_type_sort		eval_sort(const MP& m, Integer dim);
		static ret_type_sort		eval_sort_2(const MP& m, Integer dim, IntegerMatrix& ind);

		static ret_type_sortrows	eval_sortrows(const MP& m);
		static ret_type_sortrows_2	eval_sortrows_2(const MP& m);

		static ret_type_sortrows	eval_sortrows(const MP& m, const IntegerMatrix& dims);
		static ret_type_sortrows_2	eval_sortrows_2(const MP& m, const IntegerMatrix& dims);

		static ret_type_sortrows	eval_sortcols(const MP& m);
		static ret_type_sortrows_2	eval_sortcols_2(const MP& m);

		static ret_type_sortrows	eval_sortcols(const MP& m, const IntegerMatrix& dims);
		static ret_type_sortrows_2	eval_sortcols_2(const MP& m, const IntegerMatrix& dims);

		static ret_type_issorted	eval_issorted(const MP& m, Integer dim);
		static bool					eval_issorted_rows(const MP& m);
		static bool					eval_issorted_cols(const MP& m);
	};
	template<class M1,class M2>
	struct mult_helper
	{
		typedef typename M1::value_type		val_type_1;
		typedef typename M2::value_type		val_type_2;
		typedef typename M1::struct_type	str_type_1;
		typedef typename M2::struct_type	str_type_2;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<str_type_1,struct_dense>::value 
					|| mmlib::details::is_equal<str_type_2,struct_dense>::value,
				struct_dense,
				typename mmlib::details::select_if
					<
						mmlib::details::is_equal<str_type_1,struct_sparse>::value 
							|| mmlib::details::is_equal<str_type_2,struct_sparse>::value,
						struct_sparse,
						struct_banded
					>::type	
			>::type							struct_type;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<val_type_1,Object>::value 
					|| mmlib::details::is_equal<val_type_2,Object>::value,
				Object,
				typename mmlib::details::select_if
					<
				        mmlib::details::is_equal<val_type_1,Complex>::value 
					        || mmlib::details::is_equal<val_type_2,Complex>::value,
				        Complex,
				        typename mmlib::details::select_if
					    <
						    mmlib::details::is_equal<val_type_1,Real>::value 
							    || mmlib::details::is_equal<val_type_2,Real>::value,
						    Real,
						    Integer
					    >::type	
                >::type	
			>::type							value_type;

		typedef Matrix<value_type,struct_type> ret_type;

		static ret_type eval(const M1& A, const M2& B);
	};

	template<class M1,class T>
	struct scal_helper_impl
	{
		typedef typename M1::value_type		val_type;
		typedef typename M1::struct_type	str_type;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<val_type,Object>::value 
					|| mmlib::details::is_equal<T,Object>::value,
				Object,
				typename mmlib::details::select_if
					<
				        mmlib::details::is_equal<val_type,Complex>::value 
					        || mmlib::details::is_equal<T,Complex>::value,
				        Complex,
				        typename mmlib::details::select_if
					    <
						    mmlib::details::is_equal<val_type,Real>::value 
							    || mmlib::details::is_equal<T,Real>::value,
						    Real,
						    Integer
					    >::type	
                    >::type	
			>::type							value_type_int;
		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<val_type,Object>::value 
					|| mmlib::details::is_equal<T,Object>::value,
				Object,
		        typename mmlib::details::select_if
			    <
    				mmlib::details::is_equal<val_type,Complex>::value 
	    				|| mmlib::details::is_equal<T,Complex>::value,
		    		Complex,
			    	Real
                >::type
			>::type							value_type;

		typedef Matrix<value_type,str_type> ret_type_div;
		typedef Matrix<value_type_int,str_type> ret_type_mul;

		static ret_type_mul	eval(const M1& A, T B);
		static ret_type_div eval_div(const M1& A, T B);
	};

    template<class T1, class T2>
    struct select_scal_helper_base
    {
        typedef val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;
        typedef scal_helper_impl<MT1,MT2> type;
    };
	template<class M1,class T>
    struct scal_helper : public select_scal_helper_base<M1,T>::type
	{
        typedef typename select_scal_helper_base<M1,T>::type base_type;
        typedef typename base_type::ret_type_mul ret_type_mul;
        typedef typename base_type::ret_type_div ret_type_div;
        typedef typename select_scal_helper_base<M1,T>::corrector corrector;

		static ret_type_mul	eval(const M1& A, T B)
        {
            mmlib::details::type_info ti = mmlib::details::return_mult_ti<M1,T>::eval(A,B);
            return base_type::eval(corrector::convert_1(ti,A),corrector::convert_2(ti,B));
        };
		static ret_type_div eval_div(const M1& A, T B)
        {
            mmlib::details::type_info ti = mmlib::details::return_div_ti<M1,T>::eval(A,B);
            return base_type::eval_div(corrector::convert_1(ti,A),corrector::convert_2(ti,B));
        };
	};

	//ZZ: func(0,0), ZN: func(0,x), NZ: func(x,0) for any x!= 0
	//value: true - always 0, false-always nonzero
	template<class str_1,class str_2,bool ZZ,bool ZN,bool NZ>
	struct stor_struct_cons
	{};
	/*
	ZZ			Z	Z	Z	Z	N	N	N	N
	ZN			Z	Z	N	N	Z	Z	N	N
	NZ			Z	N	Z	N	Z	N	Z	N
										
	GM	GM		GM	GM	GM	GM	GM	GM	GM	GM
	GM	SM		SM	GM	SM	GM	SM	GM	SM	GM
	GM	B		B	GM	B	GM	SM	GM	SM	GM
										
	SM	GM		SM	SM	GM	GM	SM	SM	GM	GM
	SM	SM		SM	SM	SM	SM	GM	GM	GM	GM
	SM	B		B	SM	B	SM	GM	GM	GM	GM
										
	B	GM		B	B	GM	GM	SM	SM	GM	GM
	B	SM		B	B	SM	SM	GM	GM	GM	GM
	B	B		B	B	B	B	GM	GM	GM	GM										
	*/

	template<class str_1,class str_2,bool ZZ,bool ZN,bool NZ>
	struct stor_struct_cons_ms
	{
		typedef typename mmlib::details::select_if
			<
				ZN == true,
				str_1,
				struct_dense
			>::type type;
	};
	/*
	ZZ			Z	Z	Z	Z	N	N	N	N
	ZN			Z	Z	N	N	Z	Z	N	N
	NZ			Z	N	Z	N	Z	N	Z	N
										
	GM	S		GM	GM	GM	GM	GM	GM	GM	GM
	SM	S		SM	SM	GM	GM	SM	SM	GM	GM
	B	S		B	B	GM	GM	B	B	GM	GM
	*/

	template<class str_1,class str_2,bool ZZ,bool ZN,bool NZ>
	struct stor_struct_cons_sm
	{
		typedef typename mmlib::details::select_if
			<
				NZ == true,
				str_2,
				struct_dense
			>::type type;
	};
	/*
	ZZ			Z	Z	Z	Z	N	N	N	N
	ZN			Z	Z	N	N	Z	Z	N	N
	NZ			Z	N	Z	N	Z	N	Z	N
										
	S	GM		GM	GM	GM	GM	GM	GM	GM	GM
	S	SM		SM	GM	SM	GM	SM	GM	SM	GM
	S	B		B	GM	B	GM	B	GM	B	GM
	*/

	template<class str> struct str_to_code{};
	template<> struct str_to_code<struct_dense>		{ static const int value = 0; };
	template<> struct str_to_code<struct_sparse>	{ static const int value = 1; };
	template<> struct str_to_code<struct_banded>	{ static const int value = 2; };

	template<int val> struct code_to_str{};
	template<> struct code_to_str<0>				{ typedef struct_dense type;  };
	template<> struct code_to_str<1>				{ typedef struct_sparse type;  };
	template<> struct code_to_str<2>				{ typedef struct_banded type;  };

	template <class str_1,class str_2>
	struct max_struct
	{
		static const int code_1 = str_to_code<str_1>::value;
		static const int code_2 = str_to_code<str_2>::value;

		typedef typename code_to_str<(code_1 > code_2)? code_1 : code_2>::type type;
	};
	template <class str_1,class str_2>
	struct min_struct
	{
		static const int code_1 = str_to_code<str_1>::value;
		static const int code_2 = str_to_code<str_2>::value;

		typedef typename code_to_str<(code_1 < code_2)? code_1 : code_2>::type type;
	};

	template<class str_1,class str_2>
	struct stor_struct_cons<str_1,str_2,true,true,true>
	{
		typedef typename max_struct<str_1,str_2>::type type;
	};
	template<class str_1,class str_2>
	struct stor_struct_cons<str_1,str_2,true,true,false>
	{
		typedef str_1							type;
	};
	template<class str_1,class str_2>
	struct stor_struct_cons<str_1,str_2,true,false,true>
	{
		typedef str_2							type;
	};
	template<class str_1,class str_2>
	struct stor_struct_cons<str_1,str_2,true,false,false>
	{
		typedef typename min_struct<str_1,str_2>::type type;
	};
	template<class str_1,class str_2>
	struct stor_struct_cons<str_1,str_2,false,true,true>
	{
		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<str_1,struct_dense>::value 
					&& !mmlib::details::is_equal<str_2,struct_dense>::value
				||mmlib::details::is_equal<str_2,struct_dense>::value 
					&& !mmlib::details::is_equal<str_1,struct_dense>::value,
				struct_sparse,
				struct_dense
			>::type								type;
	};

	template<class str_1,class str_2>
	struct stor_struct_cons<str_1,str_2,false,true,false>
	{
		typedef typename mmlib::details::select_if
			<
				!mmlib::details::is_equal<str_1,struct_dense>::value 
					&& mmlib::details::is_equal<str_2,struct_dense>::value,
				struct_sparse,
				struct_dense
			>::type								type;
	};

	template<class str_1,class str_2>
	struct stor_struct_cons<str_1,str_2,false,false,true>
	{
		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<str_1,struct_dense>::value 
					&& !mmlib::details::is_equal<str_2,struct_dense>::value,
				struct_sparse,
				struct_dense
			>::type								type;
	};

	template<class str_1,class str_2>
	struct stor_struct_cons<str_1,str_2,false,false,false>
	{
		typedef struct_dense					type;
	};

	template<class M1, class M2, bool ZZ, bool ZN, bool NZ,bool int_ret>
	struct ret_type_constructor
	{
		typedef typename M1::value_type								val_1;
		typedef typename M2::value_type								val_2;
		typedef typename M1::struct_type							str_1;
		typedef typename M2::struct_type							str_2;

		typedef typename stor_struct_cons<str_1,str_2,ZZ,ZN,NZ>::type ret_struct;

		typedef typename mmlib::details::select_if
			<
				int_ret,
				Integer,
				typename mmlib::details::select_if
				<
					mmlib::details::value_to_code<val_1>::value 
						>= mmlib::details::value_to_code<val_2>::value,
					val_1,
					val_2
				>::type
			>::type													ret_value;

		typedef Matrix<ret_value,ret_struct>						type;
	};
	template<class M1, class M2, bool ZZ, bool ZN, bool NZ,bool int_ret>
	struct ret_type_ms_cons
	{
		typedef typename M1::value_type								val_1;
		typedef M2													val_2;
		typedef typename M1::struct_type							str_1;
		typedef struct_dense										str_2;

		typedef typename stor_struct_cons_ms<str_1,str_2,ZZ,ZN,NZ>::type ret_struct;

		typedef typename mmlib::details::select_if
			<
				int_ret,
				Integer,
				typename mmlib::details::max_type<val_1,val_2>::type
			>::type													ret_value;

		typedef Matrix<ret_value,ret_struct>						type;
	};
	template<class M1, class M2, bool ZZ, bool ZN, bool NZ,bool int_ret>
	struct ret_type_sm_cons
	{
		typedef M1													val_1;
		typedef typename M2::value_type								val_2;
		typedef struct_dense										str_1;
		typedef typename M2::struct_type							str_2;

		typedef typename stor_struct_cons_sm<str_1,str_2,ZZ,ZN,NZ>::type ret_struct;

		typedef typename mmlib::details::select_if
			<
				int_ret,
				Integer,
				typename mmlib::details::max_type<val_1,val_2>::type
			>::type													ret_value;

		typedef Matrix<ret_value,ret_struct>						type;
	};
	template<class mat_type>
	struct correct_int_ret
	{
		typedef typename mat_type::value_type						value_type_0;
		typedef typename mat_type::struct_type						struct_type;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<value_type_0,Integer>::value,
				Real,
				value_type_0
			>::type													value_type;

		typedef Matrix<value_type,struct_type>						type;
	};

	template<class M1,class M2>
	struct mat_func_helper
	{
		typedef typename ret_type_constructor<M1,M2,1,0,0,true>::type	ret_type_or;
		typedef typename ret_type_constructor<M1,M2,1,1,1,true>::type	ret_type_and;
		typedef typename ret_type_constructor<M1,M2,0,1,1,true>::type	ret_type_eeq;
		typedef typename ret_type_constructor<M1,M2,1,0,0,true>::type	ret_type_neq;
		typedef typename ret_type_constructor<M1,M2,0,0,0,true>::type	ret_type_leq;
		typedef typename ret_type_constructor<M1,M2,0,0,0,true>::type	ret_type_geq;
		typedef typename ret_type_constructor<M1,M2,1,0,0,true>::type	ret_type_lt;
		typedef typename ret_type_constructor<M1,M2,1,0,0,true>::type	ret_type_gt;
		typedef typename ret_type_constructor<M1,M2,1,0,0,true>::type	ret_type_xor;

		typedef typename ret_type_constructor<M1,M2,1,1,1,false>::type	ret_type_mul;
		typedef typename ret_type_constructor<M1,M2,0,1,0,false>::type	ret_type_idiv;
		typedef typename correct_int_ret<ret_type_idiv>::type			ret_type_div;	
		typedef typename ret_type_constructor<M1,M2,0,0,0,false>::type	ret_type_pow_0;		
		typedef typename correct_int_ret<ret_type_pow_0>::type			ret_type_pow;	
		typedef typename ret_type_constructor<M1,M2,1,0,0,false>::type	ret_type_min;
		typedef typename ret_type_constructor<M1,M2,1,0,0,false>::type	ret_type_max;
		typedef typename ret_type_constructor<M1,M2,1,0,0,false>::type	ret_type_plus;		
		typedef typename ret_type_constructor<M1,M2,1,0,0,false>::type	ret_type_minus;
		typedef typename ret_type_constructor<M1,M2,1,1,1,false>::type	ret_type_mod;
		typedef typename ret_type_constructor<M1,M2,1,1,1,false>::type	ret_type_rem;
		typedef typename ret_type_constructor<M1,M2,1,0,0,false>::type	ret_type_atan2_0;		
		typedef typename correct_int_ret<ret_type_atan2_0>::type		ret_type_atan2;

		static ret_type_or		eval_or(const M1& A, const M2& B);
		static ret_type_and		eval_and(const M1& A, const M2& B);
		static ret_type_xor		eval_xor(const M1& A, const M2& B);
		static ret_type_eeq		eval_eeq(const M1& A, const M2& B);
		static ret_type_neq		eval_neq(const M1& A, const M2& B);
		static ret_type_leq		eval_leq(const M1& A, const M2& B);
		static ret_type_geq		eval_geq(const M1& A, const M2& B);
		static ret_type_lt		eval_lt(const M1& A, const M2& B);
		static ret_type_gt		eval_gt(const M1& A, const M2& B);

		static ret_type_mul		eval_mul(const M1& A, const M2& B);
		static ret_type_div		eval_div(const M1& A, const M2& B);
		static ret_type_idiv	eval_idiv(const M1& A, const M2& B);
		static ret_type_pow		eval_pow(const M1& A, const M2& B);
		static ret_type_min		eval_min(const M1& A, const M2& B);
		static ret_type_max		eval_max(const M1& A, const M2& B);
		static ret_type_plus	eval_plus(const M1& A, const M2& B);
		static ret_type_minus	eval_minus(const M1& A, const M2& B);

		static ret_type_mod		eval_mod(const M1& A, const M2& B);
		static ret_type_rem		eval_rem(const M1& A, const M2& B);

		static ret_type_atan2	eval_atan2(const M1& A, const M2& B);
	};

	template<class M1,class M2>
	struct mat_func_scal_mat_helper
	{
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,true>::type	ret_type_or;
		typedef typename ret_type_sm_cons<M1,M2,1,1,1,true>::type	ret_type_and;
		typedef typename ret_type_sm_cons<M1,M2,0,1,1,true>::type	ret_type_eeq;
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,true>::type	ret_type_neq;
		typedef typename ret_type_sm_cons<M1,M2,0,0,0,true>::type	ret_type_leq;
		typedef typename ret_type_sm_cons<M1,M2,0,0,0,true>::type	ret_type_geq;
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,true>::type	ret_type_lt;
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,true>::type	ret_type_gt;
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,true>::type	ret_type_xor;

		typedef typename ret_type_sm_cons<M1,M2,1,1,1,false>::type	ret_type_mul;
		typedef typename ret_type_sm_cons<M1,M2,0,1,0,false>::type	ret_type_idiv;
		typedef typename correct_int_ret<ret_type_idiv>::type		ret_type_div;	
		typedef typename ret_type_sm_cons<M1,M2,0,1,0,false>::type	ret_type_pow_0;		
		typedef typename correct_int_ret<ret_type_pow_0>::type		ret_type_pow;	
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,false>::type	ret_type_min;
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,false>::type	ret_type_max;
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,false>::type	ret_type_plus;		
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,false>::type	ret_type_minus;
		typedef typename ret_type_sm_cons<M1,M2,1,1,1,false>::type	ret_type_mod;
		typedef typename ret_type_sm_cons<M1,M2,1,1,1,false>::type	ret_type_rem;
		typedef typename ret_type_sm_cons<M1,M2,1,0,0,false>::type	ret_type_atan2_0;		
		typedef typename correct_int_ret<ret_type_atan2_0>::type	ret_type_atan2;

		static ret_type_or		eval_or(const M1& A, const M2& B);
		static ret_type_and		eval_and(const M1& A, const M2& B);
		static ret_type_xor		eval_xor(const M1& A, const M2& B);
		static ret_type_eeq		eval_eeq(const M1& A, const M2& B);
		static ret_type_neq		eval_neq(const M1& A, const M2& B);
		static ret_type_leq		eval_leq(const M1& A, const M2& B);
		static ret_type_geq		eval_geq(const M1& A, const M2& B);
		static ret_type_lt		eval_lt(const M1& A, const M2& B);
		static ret_type_gt		eval_gt(const M1& A, const M2& B);

		static ret_type_mul		eval_mul(const M1& A, const M2& B);
		static ret_type_div		eval_div(const M1& A, const M2& B);
		static ret_type_idiv	eval_idiv(const M1& A, const M2& B);
		static ret_type_pow		eval_pow(const M1& A, const M2& B);
		static ret_type_min		eval_min(const M1& A, const M2& B);
		static ret_type_max		eval_max(const M1& A, const M2& B);
		static ret_type_plus	eval_plus(const M1& A, const M2& B);
		static ret_type_minus	eval_minus(const M1& A, const M2& B);

		static ret_type_mod		eval_mod(const M1& A, const M2& B);
		static ret_type_rem		eval_rem(const M1& A, const M2& B);

		static ret_type_atan2	eval_atan2(const M1& A, const M2& B);
	};

	template<class M1,class M2>
	struct mat_func_mat_scal_helper
	{
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,true>::type	ret_type_or;
		typedef typename ret_type_ms_cons<M1,M2,1,1,1,true>::type	ret_type_and;
		typedef typename ret_type_ms_cons<M1,M2,0,1,1,true>::type	ret_type_eeq;
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,true>::type	ret_type_neq;
		typedef typename ret_type_ms_cons<M1,M2,0,0,0,true>::type	ret_type_leq;
		typedef typename ret_type_ms_cons<M1,M2,0,0,0,true>::type	ret_type_geq;
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,true>::type	ret_type_lt;
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,true>::type	ret_type_gt;
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,true>::type	ret_type_xor;

		typedef typename ret_type_ms_cons<M1,M2,1,1,1,false>::type	ret_type_mul;
		typedef typename ret_type_ms_cons<M1,M2,0,1,0,false>::type	ret_type_idiv;
		typedef typename correct_int_ret<ret_type_idiv>::type		ret_type_div;	
		typedef typename ret_type_ms_cons<M1,M2,0,1,0,false>::type	ret_type_pow_0;		
		typedef typename correct_int_ret<ret_type_pow_0>::type		ret_type_pow;	
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,false>::type	ret_type_min;
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,false>::type	ret_type_max;
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,false>::type	ret_type_plus;		
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,false>::type	ret_type_minus;
		typedef typename ret_type_ms_cons<M1,M2,1,1,1,false>::type	ret_type_mod;
		typedef typename ret_type_ms_cons<M1,M2,1,1,1,false>::type	ret_type_rem;
		typedef typename ret_type_ms_cons<M1,M2,1,0,0,false>::type	ret_type_atan2_0;		
		typedef typename correct_int_ret<ret_type_atan2_0>::type	ret_type_atan2;

		static ret_type_or		eval_or(const M1& A, const M2& B);
		static ret_type_and		eval_and(const M1& A, const M2& B);
		static ret_type_xor		eval_xor(const M1& A, const M2& B);
		static ret_type_eeq		eval_eeq(const M1& A, const M2& B);
		static ret_type_neq		eval_neq(const M1& A, const M2& B);
		static ret_type_leq		eval_leq(const M1& A, const M2& B);
		static ret_type_geq		eval_geq(const M1& A, const M2& B);
		static ret_type_lt		eval_lt(const M1& A, const M2& B);
		static ret_type_gt		eval_gt(const M1& A, const M2& B);

		static ret_type_mul		eval_mul(const M1& A, const M2& B);
		static ret_type_div		eval_div(const M1& A, const M2& B);
		static ret_type_idiv	eval_idiv(const M1& A, const M2& B);
		static ret_type_pow		eval_pow(const M1& A, const M2& B);
		static ret_type_min		eval_min(const M1& A, const M2& B);
		static ret_type_max		eval_max(const M1& A, const M2& B);
		static ret_type_plus	eval_plus(const M1& A, const M2& B);
		static ret_type_minus	eval_minus(const M1& A, const M2& B);

		static ret_type_mod		eval_mod(const M1& A, const M2& B);
		static ret_type_rem		eval_rem(const M1& A, const M2& B);

		static ret_type_atan2	eval_atan2(const M1& A, const M2& B);
	};

	template<class M1,class M2>
	struct mat_func_scal_mat_helper2
	{
		typedef typename M2::struct_type				struct_type;
		typedef typename M2::value_type					val_2;
		typedef M1										val_1;

		typedef typename mmlib::details::max_type<val_1,val_2>::type	max_val_type;

		typedef Matrix<Integer,struct_type>			ret_type_eeq;
		typedef Matrix<Integer,struct_type>			ret_type_neq;
		typedef Matrix<Integer,struct_type>			ret_type_leq;
		typedef Matrix<Integer,struct_type>			ret_type_geq;
		typedef Matrix<Integer,struct_type>			ret_type_lt;
		typedef Matrix<Integer,struct_type>			ret_type_gt;

		typedef Matrix<max_val_type,struct_type>	ret_type_min;
		typedef Matrix<max_val_type,struct_type>	ret_type_max;

		static ret_type_eeq		eval_eeq(const M1& A, const M2& B);
		static ret_type_neq		eval_neq(const M1& A, const M2& B);
		static ret_type_leq		eval_leq(const M1& A, const M2& B);
		static ret_type_geq		eval_geq(const M1& A, const M2& B);
		static ret_type_lt		eval_lt(const M1& A, const M2& B);
		static ret_type_gt		eval_gt(const M1& A, const M2& B);
		static ret_type_min		eval_min(const M1& A, const M2& B);
		static ret_type_max		eval_max(const M1& A, const M2& B);
	};

	template<class M1,class M2,class arg>
	struct mat_func_scal_mat_arg_base	{};
	template<class M1,class M2>
	struct mat_func_scal_mat_arg_base<M1,M2,mmlib::details::bool_type<false>>
	{
		typedef mat_func_scal_mat_helper<M1,M2> type;
	};
	template<class M1,class M2>
	struct mat_func_scal_mat_arg_base<M1,M2,mmlib::details::bool_type<true>>
	{
		typedef mat_func_scal_mat_helper2<M1,M2> type;
	};


	template<class M1,class M2,class arg>
	struct mat_func_scal_mat_arg_helper : mat_func_scal_mat_arg_base<M1,M2,arg>::type
	{};

	template<class M1,class M2>
	struct mat_func_mat_scal_helper2
	{
		typedef typename M1::struct_type				struct_type;
		typedef typename M1::value_type					val_1;
		typedef M2										val_2;

		typedef typename mmlib::details::max_type<val_1,val_2>::type	max_val_type;

		typedef Matrix<Integer,struct_type>			ret_type_eeq;
		typedef Matrix<Integer,struct_type>			ret_type_neq;
		typedef Matrix<Integer,struct_type>			ret_type_leq;
		typedef Matrix<Integer,struct_type>			ret_type_geq;
		typedef Matrix<Integer,struct_type>			ret_type_lt;
		typedef Matrix<Integer,struct_type>			ret_type_gt;

		typedef Matrix<max_val_type,struct_type>	ret_type_min;
		typedef Matrix<max_val_type,struct_type>	ret_type_max;

		static ret_type_eeq		eval_eeq(const M1& A, const M2& B);
		static ret_type_neq		eval_neq(const M1& A, const M2& B);
		static ret_type_leq		eval_leq(const M1& A, const M2& B);
		static ret_type_geq		eval_geq(const M1& A, const M2& B);
		static ret_type_lt		eval_lt(const M1& A, const M2& B);
		static ret_type_gt		eval_gt(const M1& A, const M2& B);
		static ret_type_min		eval_min(const M1& A, const M2& B);
		static ret_type_max		eval_max(const M1& A, const M2& B);
	};

	template<class M1,class M2,class arg>
	struct mat_func_mat_scal_arg_base	{};
	template<class M1,class M2>
	struct mat_func_mat_scal_arg_base<M1,M2,mmlib::details::bool_type<false>>
	{
		typedef mat_func_mat_scal_helper<M1,M2> type;
	};
	template<class M1,class M2>
	struct mat_func_mat_scal_arg_base<M1,M2,mmlib::details::bool_type<true>>
	{
		typedef mat_func_mat_scal_helper2<M1,M2> type;
	};

	template<class M1,class M2,class arg>
	struct mat_func_mat_scal_arg_helper : mat_func_mat_scal_arg_base<M1,M2,arg>::type
	{};

	template<class M1,class M2>
	struct mat_func_scal_scal_helper
	{
		typedef bool			ret_type_or;
		typedef bool			ret_type_and;
		typedef bool			ret_type_eeq;
		typedef bool			ret_type_neq;
		typedef bool			ret_type_leq;
		typedef bool			ret_type_geq;
		typedef bool			ret_type_lt;
		typedef bool			ret_type_gt;
		typedef bool			ret_type_xor;

		typedef typename mmlib::details::max_type<M1,M2>::type			ret_type_mul;
		typedef typename mmlib::details::max_type<M1,M2>::type			ret_type_idiv;
		typedef typename mmlib::details::max_type2<M1,M2,Real>::type		ret_type_div;	
		typedef typename mmlib::details::max_type2<M1,M2,Real>::type		ret_type_pow;	
		typedef typename mmlib::details::max_type<M1,M2>::type			ret_type_min;
		typedef typename mmlib::details::max_type<M1,M2>::type			ret_type_max;
		typedef typename mmlib::details::max_type<M1,M2>::type			ret_type_plus;		
		typedef typename mmlib::details::max_type<M1,M2>::type			ret_type_minus;
		typedef typename mmlib::details::max_type<M1,M2>::type			ret_type_mod;
		typedef typename mmlib::details::max_type<M1,M2>::type			ret_type_rem;
		typedef typename mmlib::details::max_type2<M1,M2,Real>::type		ret_type_atan2;

		static ret_type_or		eval_or(const M1& A, const M2& B)		{ return or_helper<M1,M2>::eval(A,B); };
		static ret_type_and		eval_and(const M1& A, const M2& B)		{ return and_helper<M1,M2>::eval(A,B); };
		static ret_type_xor		eval_xor(const M1& A, const M2& B)		{ return xor_helper<M1,M2>::eval(A,B); };
		static ret_type_eeq		eval_eeq(const M1& A, const M2& B)		{ return eeq_helper<M1,M2>::eval(A,B); };
		static ret_type_neq		eval_neq(const M1& A, const M2& B)		{ return neq_helper<M1,M2>::eval(A,B); };
		static ret_type_leq		eval_leq(const M1& A, const M2& B)		{ return leq_helper<M1,M2>::eval(A,B); };
		static ret_type_geq		eval_geq(const M1& A, const M2& B)		{ return geq_helper<M1,M2>::eval(A,B); };
		static ret_type_lt		eval_lt(const M1& A, const M2& B)		{ return lt_helper<M1,M2>::eval(A,B); };
		static ret_type_gt		eval_gt(const M1& A, const M2& B)		{ return gt_helper<M1,M2>::eval(A,B); };

		static ret_type_mul		eval_mul(const M1& A, const M2& B)		{ return mul_helper<M1,M2>::eval(A,B); };
		static ret_type_div		eval_div(const M1& A, const M2& B)		{ return div_helper<M1,M2>::eval(A,B); };
		static ret_type_idiv	eval_idiv(const M1& A, const M2& B)		{ return idiv_helper<M1,M2>::eval(A,B); };
		static ret_type_pow		eval_pow(const M1& A, const M2& B)		{ return pow_helper<M1,M2>::eval(A,B); };
		static ret_type_min		eval_min(const M1& A, const M2& B)		{ return min_helper<M1,M2>::eval(A,B); };
		static ret_type_max		eval_max(const M1& A, const M2& B)		{ return max_helper<M1,M2>::eval(A,B); };
		static ret_type_plus	eval_plus(const M1& A, const M2& B)		{ return plus_helper<M1,M2>::eval(A,B); };
		static ret_type_minus	eval_minus(const M1& A, const M2& B)	{ return minus_helper<M1,M2>::eval(A,B); };

		static ret_type_mod		eval_mod(const M1& A, const M2& B)		{ return mod_helper<M1,M2>::eval(A,B); };
		static ret_type_rem		eval_rem(const M1& A, const M2& B)		{ return rem_helper<M1,M2>::eval(A,B); };

		static ret_type_atan2	eval_atan2(const M1& A, const M2& B)	{ return atan2_helper<M1,M2>::eval(A,B); };
	};

	template<class M1,class M2, class functor>
	struct mat_func_compare_helper
	{
		static const bool ZZ = functor::zero_zero_is_zero;
		static const bool ZN = functor::zero_nonzero_is_zero;
		static const bool NZ = functor::nonzero_zero_is_zero;
		typedef typename ret_type_constructor<M1,M2,ZZ,ZN,NZ,true>::type	ret_type_compare;

		static ret_type_compare	eval_compare(const M1& A, const M2& B, const functor& func);
	};

	template<class M1,class M2, class functor>
	struct mat_func_compare_scal_mat_helper
	{
		static const bool ZZ = functor::zero_zero_is_zero;
		static const bool ZN = functor::zero_nonzero_is_zero;
		static const bool NZ = functor::nonzero_zero_is_zero;
		typedef typename ret_type_sm_cons<M1,M2,ZZ,ZN,NZ,true>::type	ret_type_compare;

		static ret_type_compare		eval_compare(const M1& A, const M2& B, const functor& func);
	};

	template<class M1,class M2, class functor>
	struct mat_func_compare_mat_scal_helper
	{
		static const bool ZZ = functor::zero_zero_is_zero;
		static const bool ZN = functor::zero_nonzero_is_zero;
		static const bool NZ = functor::nonzero_zero_is_zero;
		typedef typename ret_type_ms_cons<M1,M2,ZZ,ZN,NZ,true>::type	ret_type_compare;

		static ret_type_compare		eval_compare(const M1& A, const M2& B, const functor& func);
	};

	template<class M1, class M2>
	struct kron_helper
	{
		typedef typename M1::value_type		val_type_1;
		typedef typename M1::struct_type	str_type_1;

		typedef typename M2::value_type		val_type_2;
		typedef typename M2::struct_type	str_type_2;

		typedef typename mmlib::details::max_type<val_type_1,val_type_2>::type	val_ret;

		typedef typename mmlib::details::select_if
			<
				mmlib::details::is_equal<str_type_2,struct_dense>::value,
				typename mmlib::details::select_if
				<
					mmlib::details::is_equal<str_type_1,struct_banded>::value,
					struct_sparse,
					str_type_1
				>::type,
				struct_sparse
			>::type							str_ret;

		typedef Matrix<val_ret,str_ret>		ret_type;

		static ret_type eval(const M1& A, const M2& B);
	};
	template<class M1, class T>
	struct kron_scal_helper
	{
		typedef typename M1::value_type		val_type;
		typedef typename M1::struct_type	struct_type;
		typedef typename mmlib::details::max_type<val_type,T>::type	val_ret;

		typedef Matrix<val_ret,struct_type>	ret_type;

		static ret_type		eval(const M1& A, T B)
		{
			return A*B;
		};
	};
	template<class T1, class T2>
	struct kron_scal_scal_helper
	{
		typedef typename mmlib::details::max_type<T1,T2>::type	val_ret;

		static val_ret		eval(T1 A, T2 B)
		{
			return A*B;
		};
	};

	template<class MP>
	struct find_helper
	{	
		typedef typename MP::value_type			val_type;
		typedef Matrix<Integer,struct_dense>	ret_type_find;
		typedef Matrix<val_type,struct_dense>	ret_type_val;

        typedef std::pair<IntegerMatrix,IntegerMatrix>  ret_type_find2;
        typedef std::pair<ret_type_find2,ret_type_val>  ret_type_find3;

		static ret_type_find	eval_find(const MP& m);
		static ret_type_find	eval_find(const MP& m, const test_function& t);

		static ret_type_find2   eval_find_2(const MP& m);
		static ret_type_find2	eval_find_2(const MP& m, const test_function& t);

		static ret_type_find3   eval_find_3(const MP& m);
		static ret_type_find3	eval_find_3(const MP& m, const test_function& t);
	};

	template<class M>
	struct find_ret_value_type
	{
		typedef typename promote_type<M>::type MP;
		typedef typename MP::value_type val_type;
		typedef Matrix<val_type,struct_dense> type;
	};

};};};