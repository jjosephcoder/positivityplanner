/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/colon.h"
#include "mmlib/container/raw/type_decl.h"
#include "mmlib/mmlib_header.h"

namespace mmlib
{

colon::colon(const Matrix& mat)				
:m_s(0),m_i(0),m_e(0),m_flag(t_matrix)
{
    m_mat = Matrix(mat.impl<raw::IntegerMatrix>().make_explicit(),false);
    raw::IntegerMatrix imat = m_mat.get_impl<raw::IntegerMatrix>();
    if (imat.size() == 0)
    {
        return;
    }
    if (imat.size() == 1)
    {
        Integer p1 = *imat.ptr();
        m_s = p1;
        m_i = 1;
        m_e = p1;
        m_flag = t_range;
        return;
    };

    Integer* ptr = imat.ptr();

    Integer s = ptr[0], l = ptr[1];
    Integer i = l - s;
    if (i == 0)
    {
        //conversion to raw colon is not possible
        return;
    };

    for(Integer k = 2; k < imat.size(); ++k)
    {
        Integer c  = ptr[k];
        Integer di = c - l;
        l = c;

        if (di != i)
        {
            //conversion to raw colon is not possible
            return;
        };
    };

    m_s     = s;
    m_i     = i;
    m_e     = l;
    m_flag  = t_range;
    m_mat   = (mat_row(), mat.rows(), mat.cols());
};


};
