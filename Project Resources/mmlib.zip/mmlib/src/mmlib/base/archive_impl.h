/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#pragma warning(push)
#pragma warning(disable: 4127)  //warning C4127: conditional expression is constant
#pragma warning(disable: 4512)  //warning C4512: 'boost::archive::basic_streambuf_locale_saver<Ch,Tr>' : assignment operator could not be generated
#pragma warning(disable: 4244)  //warning C4244: 'initializing' : conversion from 'const int' to 'const boost::uint_least16_t', possible loss of data
#pragma warning(disable: 4996)  //warning C4996: 'std::basic_streambuf<_Elem,_Traits>::sgetn': Function call with parameters that may be unsafe - this call relies on the caller to check that the passed values are correct. To disable this warning, use -D_SCL_SECURE_NO_WARNINGS. See documentation on how to use Visual C++ 'Checked Iterators'
#pragma warning(disable: 4702)  //warning C4702: unreachable code
#pragma warning(disable: 4100)  //C4100: 'ar' : unreferenced formal parameter

#include "mmlib/extern/portable_iarchive.hpp"
#include "mmlib/extern/portable_oarchive.hpp"

#pragma warning(pop)

namespace mmlib 
{

typedef eos::portable_iarchive iarchive_impl;
typedef eos::portable_oarchive oarchive_impl;

};

#define SERIALIZE_MACRO                                             \
    friend class boost::serialization::access;                      \
	void serialize(oarchive_impl & ar, const unsigned int version)  \
    {                                                               \
        boost::serialization::split_member(ar, *this, version);     \
    };                                                              \
	void serialize(iarchive_impl & ar, const unsigned int version)  \
    {                                                               \
        boost::serialization::split_member(ar, *this, version);     \
    };