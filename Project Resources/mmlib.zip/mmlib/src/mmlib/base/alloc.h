/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/scalar_types.h"
#include "mmlib/details/type_info.h"
#include "mmlib/base/integer.h"

namespace mmlib { namespace details
{

enum
{
	cash_line_size = 64
};

template<class val_type> inline val_type* aligned_malloc(type_info ti, size_t n_elem);
template<> inline Integer* aligned_malloc<Integer>(type_info , size_t n_elem)
{
	return (Integer*)_aligned_malloc(imult_c(n_elem,sizeof(Integer)),cash_line_size);
};
template<> inline Real* aligned_malloc<Real>(type_info , size_t n_elem)
{
	return (Real*)_aligned_malloc(n_elem*sizeof(Real),cash_line_size);
};
template<> inline Complex* aligned_malloc<Complex>(type_info , size_t n_elem)
{
	return (Complex*)_aligned_malloc(n_elem*sizeof(Complex),cash_line_size);
};

template<class val_type> 
inline val_type* aligned_realloc(type_info ti, val_type* old_ptr, size_t old_size, size_t n_elem);
template<> 
inline Integer* aligned_realloc<Integer>(type_info , Integer* old_ptr, size_t /*old_size*/, size_t n_elem)
{
	return (Integer*)_aligned_realloc(old_ptr,imult_c(n_elem,sizeof(Integer)),cash_line_size);
};
template<> 
inline Real* aligned_realloc<Real>(type_info , Real* old_ptr, size_t /*old_size*/, size_t n_elem)
{
	return (Real*)_aligned_realloc(old_ptr,n_elem*sizeof(Real),cash_line_size);
};
template<> 
inline Complex* aligned_realloc<Complex>(type_info , Complex* old_ptr, size_t /*old_size*/, size_t n_elem)
{
	return (Complex*)_aligned_realloc(old_ptr,n_elem*sizeof(Complex),cash_line_size);
};

template<class val_type> inline void aligned_free(val_type* ptr, size_t n_elem);
template<> inline void aligned_free<Integer>(Integer* ptr, size_t /*n_elem*/)
{
	_aligned_free(ptr);
};
template<> inline void aligned_free<Real>(Real* ptr, size_t /*n_elem*/)
{
	_aligned_free(ptr);
};
template<> inline void aligned_free<Complex>(Complex* ptr, size_t /*n_elem*/)
{
	_aligned_free(ptr);
};

};};