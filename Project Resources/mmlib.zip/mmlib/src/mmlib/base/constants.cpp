/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/constants.h"
#include <limits>

#define _USE_MATH_DEFINES
#include "math.h"

#ifndef M_LOG10PI
	#define M_LOG10PI 0.49714987269413385418
#endif

namespace mmlib { namespace constants { namespace details
{

Real Eps()			{return std::numeric_limits< double >::epsilon();};
Real MinReal()		{return std::numeric_limits< double >::min();};
Real MaxReal()		{return std::numeric_limits< double >::max();};
Real Inf()			{return std::numeric_limits< double >::infinity();};
Real NaN()			{return std::numeric_limits< double >::quiet_NaN();};
Integer MaxInt()	{return std::numeric_limits<long int>::max();};
Integer MinInt()	{return std::numeric_limits<long int>::min();};
Complex I()			{return Complex(0, 1);};
Real e()			{return M_E;};
Real pi()			{return M_PI;};
Real pi_2()			{return M_PI_2;};
Real log2e()		{return M_LOG2E;};
Real log10pi()		{return M_LOG10PI;};
Real sqrt2()		{return M_SQRT2;};

};};};
