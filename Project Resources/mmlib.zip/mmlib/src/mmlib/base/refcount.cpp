/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/details/refcount.h"
#include "boost/pool/pool.hpp"
#include "boost/smart_ptr/detail/spinlock.hpp"

namespace mmlib { namespace details
{

struct refstruct_pool_impl : protected boost::pool<boost::default_user_allocator_malloc_free>
{
    private:
        typedef boost::pool<boost::default_user_allocator_malloc_free> base;
        typedef boost::detail::spinlock::scoped_lock scoped_lock;
        boost::detail::spinlock m_mutex;
        long n_item;

    public:
        refstruct_pool_impl()
            :base(sizeof(refcount_str))
        {
            m_mutex.v_ = 0;
            n_item = 0;
        };

        void* malloc()
        {
            scoped_lock lock(m_mutex);
            ++n_item;
            return base::malloc();
        };
        void free(void* ptr)
        {
            scoped_lock lock(m_mutex);
            --n_item;
            base::free(ptr);
        };
        long no_existing_objects()
        {
            return n_item;
        };
};

//must be alive while destructors of static objects are called
//does not create important memleaks
static refstruct_pool_impl* refcount_pool = new refstruct_pool_impl();

refcount_str* refstruct_pool::create(long val)
{
    refcount_str* ptr = (refcount_str*) refcount_pool->malloc();
    if (!ptr)
    {
        throw std::bad_alloc();
    };
    new(ptr) refcount_str(val);
    return ptr;
};
void refstruct_pool::destroy(refcount_str* ptr)
{
    return refcount_pool->free(ptr);
};

long details::no_existing_objects()
{
    return refcount_pool->no_existing_objects();
};

void details::close_refcount()
{
    delete refcount_pool;
    refcount_pool = NULL;
};

};};
