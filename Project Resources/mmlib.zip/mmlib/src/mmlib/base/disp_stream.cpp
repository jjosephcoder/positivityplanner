/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/disp_stream.h"
#include "mmlib/exception.h"
#include "mmlib/details/scalfunc_helpers.h"
#include <iomanip>

#pragma warning(push)
#pragma warning(disable:4244)
#include <boost/thread/thread.hpp>
#pragma warning(pop)

namespace mmlib 
{

namespace grd = mmlib::raw::details;
namespace gd  = mmlib::details;

output_stream::output_stream(std::ostream& of)
:stream(of)
{
    m_mutex = new boost::mutex();
};
output_stream::~output_stream()
{
    delete m_mutex;
};
void output_stream::disp(std::stringstream& of)
{
    boost::mutex::scoped_lock lock(*m_mutex);
    of.seekg(0, std::ios::beg);    
    stream << of.rdbuf();
    of.seekg(0, std::ios::end);
    stream.flush();
};

disp_stream::disp_stream(output_stream& os)	
:m_stream(os) 
{
    m_width.resize(max_matrix_cols());
};

void disp_stream::displaying_string()
{};

void disp_stream::displaying_scalar(enums::value_type)
{};

void disp_stream::displaying_dense_matrix(Integer r, Integer c, enums::value_type vt,
                                          details::struct_flag_impl::struct_type ty)
{
    m_vt = vt;
    new_line(0);
    std::string t = get_struct_name(ty);
    std::string v = get_value_name(vt);
    get_stream() << "dense " << v << " matrix, size: " << r << 'x' << c << ", type: " << t;
    end_line(0);
    get_stream() << '\n';
};
void disp_stream::displaying_sparse_matrix(Integer r, Integer c, Integer nz, enums::value_type vt,
                                           details::struct_flag_impl::struct_type ty)
{
    m_vt = vt;
    std::string t = get_struct_name(ty);
    std::string v = get_value_name(vt);
    new_line(0);
    get_stream()<< "sparse " << v << " matrix, size: " << r << 'x' << c << ", nnz: " << nz 
                << ", type: " << t;
    end_line(0);
    get_stream() << '\n';
};
std::string disp_stream::get_struct_name(details::struct_flag_impl::struct_type t) const
{
    switch(t)
    {         
        case details::struct_flag_impl::zero:      return "zero";
        case details::struct_flag_impl::id:        return "identity";
        case details::struct_flag_impl::diag:      return "diagonal";
        case details::struct_flag_impl::tril:      return "lower triangular";
        case details::struct_flag_impl::triu:      return "upper triangular";
        case details::struct_flag_impl::sym:       return "symmetric";
        case details::struct_flag_impl::her:       return "hermitian";
        case details::struct_flag_impl::unitary:   return "unitary";
        case details::struct_flag_impl::qtril:     return "quasi lower triangular";
        case details::struct_flag_impl::qtriu:     return "quasi upper triangular";
        case details::struct_flag_impl::general:   return "general";
        default:                                   return "unknown";
    };
};
std::string disp_stream::get_value_name(enums::value_type vt) const
{
    switch (vt)
    {
        case enums::value_integer:  return "integer";
        case enums::value_real:     return "real";
        case enums::value_complex:  return "complex";
        case enums::value_object:   return "object";
        default:
        {
            assertion(0,"unknown case");
            throw;
        }
    };
};
Integer disp_stream::get_preffered_width(enums::value_type vt) const
{
    switch (vt)
    {
        case enums::value_integer:  return 2;
        case enums::value_real:     return 6;
        case enums::value_complex:  return 15;
        case enums::value_object:   return 8;
        default:
        {
            assertion(0,"unknown case");
            throw;
        }
    };
};
void disp_stream::disp_elem(Integer w, const std::string& s)
{
    get_stream() << std::setw(w) << s;
};
void disp_stream::disp_elem(Integer w, Integer v)
{
    get_stream() << std::setw(w) << v;
};
void disp_stream::disp_elem(Integer w, Real v)
{
    gd::type_info ti = gd::get_raw_ti();

    if (grd::isnan_helper<Real>::eval(ti,v))
    {
        get_stream() << std::setw(w) << "NaN";
        return;
    };
	if (grd::isinf_helper<Real>::eval(ti,v))
    {
        if (v > 0)  get_stream() << std::setw(w) << "Inf";
        else        get_stream() << std::setw(w) << "-Inf";
        return;
    };

    if ( v >= 1e100 )
    {
        Integer p = std::min(std::max(w-7,1L),3L);
        get_stream()<< std::scientific << std::setprecision(p) << std::setw(w) << v;
        return;
    };
    if ( v <= -1e100 )
    {
        Integer p = std::min(std::max(w-8,1L),3L);
        get_stream()<< std::scientific << std::setprecision(p) << std::setw(w) << v;
        return;
    };
    if ( v >= 1e4 )
    {
        Integer p = std::min(std::max(w-7,1L),4L);
        get_stream()<< std::scientific << std::setprecision(p) << std::setw(w) << v;
        return;
    }
    if ( v <= -1e4)
    {
        Integer p = std::min(std::max(w-8,1L),4L);
        get_stream()<< std::scientific << std::setprecision(p) << std::setw(w) << v;
        return;
    }
    if ( v >= 1e3 )
    {
        Integer p = std::min(std::max(w-5,1L),4L);
        get_stream()<< std::fixed << std::setprecision(p) << std::setw(w) << v;
        return;
    }
    if ( v <= -1e3)
    {
        Integer p = std::min(std::max(w-6,1L),4L);
        get_stream()<< std::fixed << std::setprecision(p) << std::setw(w) << v;
        return;
    }
    if ( v >= 1e2 )
    {
        Integer p = std::min(std::max(w-4,1L),5L);
        get_stream()<< std::fixed << std::setprecision(p) << std::setw(w) << v;
        return;
    };
    if ( v <= -1e2)
    {
        Integer p = std::min(std::max(w-5,1L),5L);
        get_stream()<< std::fixed << std::setprecision(p) << std::setw(w) << v;
        return;
    };
    if ( v >= 1e1 )
    {
        Integer p = std::min(std::max(w-3,1L),5L);
        get_stream()<< std::fixed << std::setprecision(p) << std::setw(w) << v;
        return;
    };
    if ( v <= -1e1)
    {
        Integer p = std::min(std::max(w-4,1L),5L);
        get_stream()<< std::fixed << std::setprecision(p) << std::setw(w) << v;
        return;
    };
    if ( v > 0  && v <= 1e-3)
    {
        Integer p = std::min(std::max(w-7,1L),2L);
        get_stream()<< std::scientific << std::setprecision(p) << std::setw(w) << v;
        return;
    };
    if ( v < 0  && v >= -1e-3)
    {
        Integer p = std::min(std::max(w-8,1L),2L);
        get_stream()<< std::scientific << std::setprecision(p) << std::setw(w) << v;
        return;
    };
    if ( v > 0 )
    {
        Integer p = std::min(std::max(w-2,1L),5L);
        get_stream()<< std::fixed << std::setprecision(p) << std::setw(w) << v;
        return;
    };
    if ( v < 0 )
    {
        Integer p = std::min(std::max(w-3,1L),5L);
        get_stream()<< std::fixed << std::setprecision(p) << std::setw(w) << v;
        return;
    };

    get_stream() << std::fixed << std::setprecision(0) << std::setw(w) << v;
    return;
};
void disp_stream::disp_elem(Integer w, const Complex& v)
{
    Real r = real(v);
    Real i = imag(v);

    Integer w1 = (w - 4)/2;
    Integer w0 = w - w1 - 4;
    disp_elem(w0,r);

    if (i < 0)  get_stream() << " - ";
    else        get_stream() << " + ";

    disp_elem(w1,abs(i));
    get_stream() << "i";
};
void disp_stream::disp_elem(Integer w, const Object& v)
{
    get_stream() <<  std::setw(w) << v.to_string();
};

Integer disp_stream::get_min_width(Integer v) const
{
    if (v == 0)     return 1;
    if (v > 0)
    {
        Integer d = (Integer)std::log10((double)v);
        if (v < 1e9)    return d + 1;
        else            return d + 2;
    }
    else
    {
        v = -v;
        Integer d = (Integer)std::log10((double)v);
        if (v < 1e9)    return d + 2;
        else            return d + 3;
    };
};
Integer disp_stream::get_min_width(Real r) const
{
    gd::type_info ti = gd::get_raw_ti();

    if (grd::isnan_helper<Real>::eval(ti,r))     return 3;
	if (grd::isinf_helper<Real>::eval(ti,r))     return (r > 0)? 3 : 4;

    if ( r >= 1e100 )                       return 8;
    if ( r <= -1e100 )                      return 9;
    if ( r >= 1e4 )                         return 8;
    if ( r <= -1e4 )                        return 9;
    if ( r >= 1e3 )                         return 6;
    if ( r <= -1e3 )                        return 7;
    if ( r >= 1e2)                          return 5;
    if ( r <= -1e2)                         return 6;
    if ( r >= 1e1)                          return 4;
    if ( r <= -1e1)                         return 5;
    if ( r > 0  && r <= 1e-3)               return 8;
    if ( r < 0  && r >= -1e-3)              return 9;
    if ( r > 0)                             return 4;
    if ( r < 0)                             return 5;
         
    return 1;
};

Integer disp_stream::get_min_width(const Complex& v) const
{
    Real r = real(v);
    Real i = imag(v);
    Integer w = std::max(get_min_width(r), get_min_width(i));

    return w + 1 + 1 + 1 + w + 1;
};

Integer disp_stream::get_min_width(const Object& v) const
{
    return v.to_string().size();
};


void disp_stream::display_empty_matrix(Integer r, Integer c)
{
	get_stream() << "[](" << r << 'x' << c << ")\n";
};

Integer	disp_stream::get_ternimal_width() const
{
	return 80;
};

Integer disp_stream::get_col_separator_width() const
{
    return 2;
};
Integer disp_stream::get_column_width(Integer c) const
{
    return m_width[c];
};
Integer disp_stream::get_first_col_separator_width() const
{
    return 3;
};
Integer disp_stream::get_row_headers_width() const
{
    Integer r = this->max_matrix_rows();
    return this->get_min_width(r);
};

Integer	disp_stream::max_matrix_cols() const
{
    return 20;
};
Integer	disp_stream::max_matrix_rows() const
{
    return 20;
};
void disp_stream::set_column_min_width(Integer c, Integer width)
{
    width = std::max(width,get_min_width(c));
    width = std::max(width,get_preffered_width(m_vt));
    m_width[c] = std::max(get_column_label_width(c),width);
};
Integer disp_stream::get_column_label_width(Integer ) const
{
    return 0;
};
Integer disp_stream::get_sparse_separator_width() const
{
    return 3;
};
void disp_stream::disp_sparse_separator(Integer w)
{
    get_stream() << std::setw(w) << std::string(w,' ');
};

void disp_stream::start_display()
{
	get_stream() << '\n';
};
void disp_stream::end_display()
{
    m_stream.disp(m_buf);
    m_buf.clear();
};

void disp_stream::end_line(Integer)
{
	get_stream() << '\n';
};
void disp_stream::new_line(Integer)
{
	get_stream() << ' ';
};
Integer disp_stream::new_line_width() const
{
    return 1;
};
Integer disp_stream::end_line_width() const
{
    return 0;
};

void disp_stream::disp_col_separator(Integer w, Integer )
{
    get_stream() << std::setw(w) << " ";
};
void disp_stream::disp_first_col_separator(Integer w)
{
    get_stream() << std::setw(w) << " | ";
};
void disp_stream::disp_col_header_row(Integer w)
{
    get_stream() << std::setw(w) << " ";
};
void disp_stream::disp_col_header_1sep(Integer w)
{
    get_stream() << std::setw(w) << " | ";
};
void disp_stream::disp_col_header_col(Integer c, Integer w)
{
    disp_elem(w,c+1);
};
void disp_stream::disp_col_header_col_separator(Integer c, Integer w)
{
    (void)c;
    get_stream() << std::setw(w) << " ";
};
bool disp_stream::do_disp_first_row_separator() const
{
    return true;
};
void disp_stream::disp_first_row_separator(Integer w)
{
    std::string sep = std::string(w,'-');
    get_stream() << std::setw(w) << sep;
};

void disp_stream::disp_row_header(Integer r, Integer w)
{
    disp_elem(w,r+1);
};
void disp_stream::sparse_row(Integer row,Integer col, Integer wr, Integer wc)
{
    if (row == -1)
    {
        std::string cd_r(std::min(3L,wr),'.');

        if (col == -1)
        {            
            std::string cd_c(std::min(3L,wc),'.');
            get_stream() << "(" << std::setw(wr) << cd_r << ", " << std::setw(wc) << cd_c << ")";
        }
        else
        {
            get_stream() << "(" << std::setw(wr) << cd_r << ", " << std::setw(wc) << col << ")";
        };
    }
    else
    {
        if (col == -1)
        {
            std::string cd_c(std::min(3L,wc),'.');
            get_stream() << "(" << std::setw(wr) << row << ", " << std::setw(wc) << cd_c << ")";
        }
        else
        {
            get_stream() << "(" << std::setw(wr) << row << ", " << std::setw(wc) << col << ")";
        };	    
    };
};


}