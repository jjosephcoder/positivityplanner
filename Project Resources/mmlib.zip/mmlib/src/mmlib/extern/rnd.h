#pragma once

#include <boost/shared_ptr.hpp>
#include "mmlib/config.h"

namespace mmlib
{

    struct rand_state;
    typedef boost::shared_ptr<rand_state> rand_state_ptr;
};

namespace mmlib { namespace details
{

MMLIB_EXPORT rand_state_ptr  get_rand_state();
MMLIB_EXPORT void            set_rand_state(rand_state_ptr st);

// Initialize Mersenne twister with a seed.
MMLIB_EXPORT void init_genrand(unsigned long s);
// Mersenne twister generator of unifomly distributed unsigned 32-bit integers.
MMLIB_EXPORT unsigned long genrand_int32(void);
// Mersenne twister generator of unifomly distributed numbers on [0,1].
MMLIB_EXPORT double genrand_real1(void);
// Mersenne twister generator of unifomly distributed numbers on [0,1).
MMLIB_EXPORT double genrand_real2(void);
// Mersenne twister generator of unifomly distributed numbers on (0,1).
MMLIB_EXPORT double genrand_real3(void);
// Standard normally distributed random variables.
MMLIB_EXPORT double gen_norm();

};};