#include<math.h>

#include "mmlib/extern/rnd.h"

/// <summary>
/// Required method for Designer support - do not modify
/// the contents of this method with the code editor.
/// </summary>
double mmlib::details::gen_norm(void)
{
    double u, v, s;
    static double b;
    static int flag = 0;

    if (flag) {
        flag = 0;
        return b;
    }

    do {
        u = 2. * genrand_real1() - 1.;
        v = 2. * genrand_real1() - 1.;
    } while (((s = u * u + v * v) >= 1.) || (s == 0.));

    s = sqrt(-2. * log(s) / s);

    b = v * s;
    flag = 1;

    return u * s;
}