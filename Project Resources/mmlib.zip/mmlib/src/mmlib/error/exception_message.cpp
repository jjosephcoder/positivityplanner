/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/exception_message.h"
#include "mmlib/matrix_traits.h"
#include "mmlib/exception.h"

#include <sstream>
#include <iostream>

namespace mmlib { namespace error
{

static exception_message_ptr messanger(new default_exception_message());

static std::string val_to_string(enums::value_type vt)
{
	switch (vt)
	{
		case enums::value_integer:      return "integer";
		case enums::value_real:         return "real";
		case enums::value_complex:      return "complex";
		case enums::value_object:       return "object";

		default:
			assertion(0,"unknown case");
			throw;
	};
};
static std::string struct_to_string(enums::struct_type st)
{
	switch (st)
	{
		case enums::struct_dense:
			return "dense matrix";
		case enums::struct_banded:
			return "banded matrix";
		case enums::struct_sparse:
			return "sparse matrix";
		case enums::struct_scalar:
			return "scalar";
		default:
			assertion(0,"unknown case");
			throw;
	};
};

static std::string matrix_type_string(enums::mat_type mt)
{
	enums::value_type val_type = matrix_traits::get_value_type(mt);
	enums::struct_type struct_type = matrix_traits::get_struct_type(mt);

	std::string val_name = val_to_string(val_type);
	std::string struct_name = struct_to_string(struct_type);

	return val_name + " " + struct_name; 
};

const char* default_exception_message:: error_general(const std::string& msg)
{
	current_message = msg;
    return current_message.c_str();
};
const char* default_exception_message::error_alloc(Integer size)
{
	std::ostringstream buf;

    buf << "failed to allocate ";
	if (size == 0)
	{
		buf << "memory";
	}
	else
	{
		if (size >= 1048576) buf << size/1048576 << "MB";
		else
		{
			if (size >= 1024) buf << size/1024 << "kB";
			else buf << size << "B";
		}
	};

	current_message = buf.str();
    return current_message.c_str();
};

const char* default_exception_message::error_size(Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "invalid matrix size: " << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_resize(Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "invalid matrix size: " << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};

const char* default_exception_message::error_int_mult(Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "unable to multply two integers: " << r << " and " << c << ", resulting value is too large";

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_int_cast(Real val)
{
	std::ostringstream buf;

    buf << "unable to cast real to integer: value " << val << "is too large";

	current_message = buf.str();
    return current_message.c_str();
};

const char* default_exception_message::error_single_index(Integer i,Integer size)
{
	std::ostringstream buf;

    buf << "invalid single index; index: " << i << ", object size: " << size;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_double_index(Integer i,Integer j,Integer r,Integer c)
{
	std::ostringstream buf;

    buf << "invalid double index; index: (" << i << "," << j
        << "); matrix size: " << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_diag(Integer d,Integer r,Integer c)
{
	std::ostringstream buf;

    buf << "invalid matrix diagonal; diagonal: "<< d << ", matrix size: " 
        << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};

const char* default_exception_message::error_index_band(Integer i,Integer j, Integer r, Integer c, 
									 Integer l, Integer u)
{
	std::ostringstream buf;

    buf << "invalid band matrix index; index: (" << i << "," << j
        << "); matrix size: " << r << "x" << c << " with " << l 
        << " subdiagonals and " << u << " superdiagonals";

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_size_band(Integer r, Integer c, Integer l, Integer u)
{
	std::ostringstream buf;

    buf << "invalid band matrix size: " << r << "x" << c << " with " 
        << l << " subdiagonals and " << u << " superdiagonals";

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_size_sp(Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "invalid sparse matrix size: " << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_invalid_return_type()
{
	current_message = "invalid return type";
    return current_message.c_str();
};
const char* default_exception_message::error_horzcat(Integer r1, Integer c1, Integer r2, Integer c2)
{
	std::ostringstream buf;

    buf << "cannot horizontally concatenate " << r1 << "x" << c1
        << " and " << r2 << "x" << c2;

	current_message = buf.str();
    return current_message.c_str();

};
const char* default_exception_message::error_vertcat(Integer r1, Integer c1, Integer r2, Integer c2)
{
	std::ostringstream buf;

    buf << "cannot vertically concatenate " << r1 << "x" << c1
        << " and " << r2 << "x" << c2;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_index(Integer i, Integer j, Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "invalid double index; index: (" << i << "," << j
        << "); matrix size: " << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_assign(Integer r1, Integer c1, Integer r2, Integer c2)
{
	std::ostringstream buf;

    buf << "nonconformant sizes in assigment; LHS is " << r1 << "x" << c1 
        << ", RHS is " << r2 << "x" << c2;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_row(Integer i, Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "invalid row; row: "<< i << ", object size: " << r 
        << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_col(Integer j, Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "invalid column; column: "<< j << ", object size: " << r 
        << "x" << c;


	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_reshape(Integer r1, Integer c1, Integer r2, Integer c2)
{
	std::ostringstream buf;

    buf << "cannot reshape " << r1 << "x" << c1 << " to " << r2 << "x" << c2;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_eeop(Integer r1, Integer c1, Integer r2, Integer c2)
{
	std::ostringstream buf;

    buf << "nonconfomant sizes in element by element operation; "
        << "first operand: " << r1 << "x" << c1
        << ", second operand: " << r2 << "x" << c2;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_mul(Integer r1, Integer c1, Integer r2, Integer c2)
{
	std::ostringstream buf;

    buf << "nonconfomant sizes in multiplication; "
        << "first operand: " << r1 << "x" << c1
        << ", second operand: " << r2 << "x" << c2;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_dim(Integer i, Integer d)
{
	std::ostringstream buf;

    buf << "invalid dimension; dimension: " << i 
        << ", object dimension: " << d;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_atan2_on_complex()
{
	current_message = "unable to evaluate function atan2, one of arguments if complex";
    return current_message.c_str();
};
const char* default_exception_message::error_bspdiags_nonconf()
{
	current_message = "nonconformant arguments supplied to `diags', `bdiags' or `spdiags'";
    return current_message.c_str();
};

const char* default_exception_message::error_randperm_arg_neg(Integer n)
{
	std::ostringstream buf;

	buf << "argument supplied to `randperm' function is negative; it is " << n;

	current_message = buf.str();
    return current_message.c_str();
};

const char* default_exception_message::error_bspdiag_1starg_not_vec(Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "1st argument supplied to `bdiag' or `spdiag' function is "
        << "not vector; its size is " << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_bspdiags_2ndarg_not_vec(Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "2nd argument supplied to `diags', `bdiags' or `spdiags' function is "
        << "not vector; its size is " << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_diag_arg_not_vec(Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "argument supplied to `diag' function is not vector; its size is "
        << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};		
const char* default_exception_message::error_linear_index_too_large(Integer r, Integer c, Integer rows)
{
	std::ostringstream buf;

    buf << "unable to create linear index, index is too large; row: " 
			<< r << ", column : " << c << ", number of rows:" << rows;

	current_message = buf.str();
    return current_message.c_str();
};	
const char* default_exception_message::error_alloc_ext()
{
	current_message = "memory allocation error in external routine";
    return current_message.c_str();
};	

const char* default_exception_message::error_scalar_required(Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "scalar or 1x1 matrix is required, matrix size is: " 
			<< r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};

const char* default_exception_message::error_unable_to_read_matrix()
{
	current_message = "unable to read matrix";
    return current_message.c_str();
};

const char* default_exception_message::error_unable_to_convert_invalid_code()
{
	current_message = "unable to convert matrix, invalid new matrix type code";
    return current_message.c_str();	
};

const char* default_exception_message::error_type_get(enums::mat_type ret, enums::mat_type in)
{
	std::ostringstream buf;

	std::string ret_type = matrix_type_string(ret);
	std::string in_type = matrix_type_string(in);

    buf << "unable to return " << ret_type << ", matrix type is " << in_type;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_type_get_rep(enums::mat_type ret, enums::mat_type in)
{
	std::ostringstream buf;

	std::string ret_type = matrix_type_string(ret);
	std::string in_type = matrix_type_string(in);

    buf << "unable to return " << ret_type << " raw representation, matrix type is " << in_type;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_unable_to_convert(enums::mat_type ret, enums::mat_type in)
{
	std::ostringstream buf;

	std::string ret_type = matrix_type_string(ret);
	std::string in_type = matrix_type_string(in);

    buf << "unable to convert " << in_type << " to " << ret_type;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_not_vec(Integer r, Integer c)
{
	std::ostringstream buf;

    buf << "matrix is not a vector, matrix size is " << r << "x" << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_invalid_vectors_spmat(Integer sr, Integer sc, Integer sx)
{
	std::ostringstream buf;

	buf << "invalid triplet representation, vectors size not match" << '\n' 
		<< "row indices size: " << sr << ", columns indiced size: " << sc << ", value size: " << sx;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_row_indices_sortcols(Integer s, Integer c)
{
	std::ostringstream buf;

	buf << "invalid matrix of row indices supplied to function sortcols, matrix size exceeded number of rows\n"
		<< "matrix size: " << s << ", number of rows: " << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_cols_indices_sortrows(Integer s, Integer c)
{
	std::ostringstream buf;

	buf << "invalid matrix of row indices supplied to function sortcols, matrix size exceeded number of rows\n"
		<< "matrix size: " << s << ", number of rows: " << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_row_indices_elem_sortcols(Integer elem, Integer c)
{
	std::ostringstream buf;

	buf << "invalid matrix of row indices supplied to function sortcols, invalid row index\n"
		<< "row index: " << elem << ", number of rows: " << c;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_col_indices_elem_sortrows(Integer elem, Integer c)
{
	std::ostringstream buf;

	buf << "invalid matrix of column indices supplied to function sortrows, invalid column index\n"
		<< "column index: " << elem << ", number of columns: " << c;

	current_message = buf.str();
    return current_message.c_str();
};

const char* default_exception_message::error_open_mmlibfile(const std::string& file, const std::string& msg)
{
	std::ostringstream buf;

	buf << "unable to open file " << file;
	if (msg.size() > 0)
	{
		buf <<", reason: " << msg;
	};

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_open_matfile(const std::string& file, const std::string& msg)
{
	std::ostringstream buf;

	buf << "unable to open file " << file;
	if (msg.size() > 0)
	{
		buf <<", reason: " << msg;
	};

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_matfile_not_opened()
{
	std::ostringstream buf;

	buf << "matfile not opened";
	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_read_matfile()
{
	std::ostringstream buf;

	buf << "error while reading matfile";
	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_read_matfile_var(const std::string& var_name)
{
	std::ostringstream buf;

	buf << "error while reading matfile, matrix " << var_name << " not found, or memory error occured";
	current_message = buf.str();
    return current_message.c_str();
};

const char* default_exception_message::error_write_matfile()
{
	std::ostringstream buf;

	buf << "error while writing to matfile";
	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_mmlibfile_locked()
{
	current_message = "mmlib file is locked";
    return current_message.c_str();
};
const char* default_exception_message::error_create_mmlibfile(const std::string& msg)
{
	std::ostringstream buf;

	buf << "unable to create mmlib file, reason: " << msg;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_read_mmlibfile(const std::string& msg)
{
	std::ostringstream buf;

	buf << "unable to read mmlib file, reason: " << msg;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_read_mmlibfile_mat_not_exist(const std::string& msg)
{
	std::ostringstream buf;

	buf << "matrix " << msg <<" does not exist in mmlib file";

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_write_mmlibfile_mat_already_exist(const std::string& msg)
{
	std::ostringstream buf;

	buf << "unable to save " << msg <<" matrix, matrix already exists";

	current_message = buf.str();
    return current_message.c_str();
};

const char* default_exception_message::error_unable_to_load_library(const std::string& path)
{
	std::ostringstream buf;

	buf << "unable to load library " << path;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_while_loading_library(const std::string& path)
{
	std::ostringstream buf;

	buf << "error while loading library " << path;

	current_message = buf.str();
    return current_message.c_str();
};
const char* default_exception_message::error_object_value_type_not_allowed()
{
	current_message = "object value type is not allowed, additional type info is required";
    return current_message.c_str();
};
const char* default_exception_message::error_integer_value_type_not_allowed()
{
	current_message = "integer value type is not allowed";
    return current_message.c_str();
};
const char* default_exception_message::error_square_matrix_required()
{
    current_message = std::string() + "square matrix is required";
    return current_message.c_str();
};
const char* default_exception_message::error_invalid_struct(struct_flag::struct_type fl)
{
	std::ostringstream buf;

    buf << "invalid struct flag: ";
    switch(fl)
    {
        case struct_flag::zero:    buf << "zero"; break;
        case struct_flag::id:      buf << "identity"; break;
        case struct_flag::diag:    buf << "diagonal"; break;
        case struct_flag::tril:    buf << "lower triangular"; break;
        case struct_flag::triu:    buf << "upper triangular"; break;
        case struct_flag::sym:     buf << "symmetric"; break;
        case struct_flag::her:     buf << "hermitian"; break;
        case struct_flag::unitary: buf << "unitary"; break;
        case struct_flag::qtril:   buf << "quasi lower triangular"; break;
        case struct_flag::qtriu:   buf << "quasi upper triangular"; break;
        case struct_flag::general: buf << "general matrix"; break;
        default:
        {
            buf << "unknown";
            throw;
        }
    };

	current_message = buf.str();
    return current_message.c_str();
};

void default_exception_message::warning_precision_lost_real_to_int(Real )
{
    warning("conversion of real scalar to integer scalar: precision is lost");
};
void default_exception_message::warning_precision_lost_compl_to_real(Complex )
{
    warning("conversion of complex scalar to real scalar: imaginary part ignored");
};
void default_exception_message::warning(const std::string& msg)
{
    std::cout << "warning: " << msg << "\n";
};
void error::set_global_messanger(exception_message_ptr msg)
{
    if (msg)
    {
        messanger = msg;
    };
};
exception_message& error::get_global_messanger()
{
    return *messanger;
};

};};
