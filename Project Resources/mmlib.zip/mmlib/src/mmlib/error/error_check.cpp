/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/error/error_check.h"
#include "mmlib/exception.h"
#include "mmlib/constants.h"
#include "mmlib/utils/utils.h"
#include "mmlib/base/integer.h"

namespace mmlib { namespace error
{

void error::check_resize(Integer r, Integer c)
{
    if ( c < 0 || r < 0)
	{
        throw error_resize(r, c);
	};
};

void error::check_alloc(void *ptr, Integer sz)
{
    if (!ptr) throw error_alloc(sz);
}

void error::check_size(Integer r, Integer c)
{
    if ((c < 0) || (r < 0) || imult_t(r,c) == false)
	{
        throw error_size(r, c);
	};
}

void error::check_index(Integer i , Integer j, Integer r, Integer c)
{
	if ((i < 1) || (i > r) || (j < 1) || (j > c))
	{
		throw error_double_index(i, j, r, c);
	};
};
void error::check_diag(Integer d, Integer r, Integer c)
{
    if (d != 0)
    {
        if (r == 0 || c == 0 || d + 1 > c || 1 - d > r)
	    {
		    throw error_diag(d, r, c);
	    };
    };
};

void error::check_index_band(Integer i, Integer j, Integer r, Integer c, Integer l, Integer u)
{
    if ((i < 1) || (j < 1) || (i > r) || (j > c) ||
        (std::max(1L, j - u) > i) || (i > std::min(r, j + l)))
	{
        throw error_index_band(i, j, r, c, l, u);
	};
}
void error::check_size_band(Integer r, Integer c, Integer l, Integer u)
{
	Integer diag_u = (c == 0)? 0 : 1;
	Integer diag_l = (r == 0)? 0 : 1;
    if (r < 0 || c < 0 || l < 0 || u < 0 || u + diag_u > c || l + diag_l > r)
	{
        throw error_size_band(r, c, l, u);
	};
}
void error::check_size_sp(Integer r, Integer c)
{
    if (r < 0 || c < 0)
	{
        throw error_size_sp(r, c);
	};
}

void error::check_horzcat(Integer r1, Integer c1, Integer r2, Integer c2)
{
    if (r1 != r2)
	{
		throw error_horzcat(r1, c1, r2, c2);
	};
}
void error::check_vertcat(Integer r1, Integer c1, Integer r2, Integer c2)
{
    if (c1 != c2)
	{
		throw error_vertcat(r1, c1, r2, c2);
	};
};
void error::check_assign(Integer r1, Integer c1, Integer r2, Integer c2)
{
    if ((r1 != r2 ) || (c1 != c2))
	{
		throw error_assign(r1, c1, r2, c2);
	};
}
void error::check_row(Integer i, Integer r, Integer c)
{
    if ((i < 1) || (i > r))
	{
		throw error_row(i, r, c);
	};
}
void error::check_col(Integer j, Integer r, Integer c)
{
    if ((j < 1) || (j > c))
	{
		throw error_col(j, r, c);
	};
}
void error::check_reshape(Integer r1, Integer c1, Integer r2, Integer c2)
{
    if (Real(r1)*Real(c1) != Real(r2)*Real(c2)) 
	{
		throw error_reshape(r1, c1, r2, c2);
	};
}

void error::check_eeop(Integer r1, Integer c1, Integer r2, Integer c2)
{
    if ((r1 != r2) || (c1 != c2))
	{
		throw error_eeop(r1, c1, r2, c2);
	};
}
void error::check_mul(Integer r1, Integer c1, Integer r2, Integer c2)
{
    if (c1 != r2)
	{
		throw error_mul(r1, c1, r2, c2);
	};
}

void error::check_dim(Integer i, Integer d)
{
    if ((i < 1) || (i > d))
	{
		throw error_dim(i, d);
	};
}

void error::check_randperm_arg(Integer n)
{
    if (n < 0) 
	{
		throw error_randperm_arg_neg(n);
	};
}
void error::check_bspdiag_1starg(Integer r, Integer c)
{
    if (r != 1 && c != 1)
	{
		throw error_bspdiag_1starg_not_vec(r, c);
	};
}
void error::check_bspdiags_2ndarg(Integer r, Integer c)
{
    if (r != 1 && c != 1)
	{
		throw error_bspdiags_2ndarg_not_vec(r, c);
	};
}
void error::check_diag_arg(Integer r, Integer c)
{
    if ((r != 1) && (c != 1))
	{
		throw error_diag_arg_not_vec(r, c);
	};
}

void error::check_linear_index(Integer r, Integer c, Integer rows)
{
    if ( icast_t(Real(r) + Real(c-1)*Real(rows)) == false)
	{
		throw error_linear_index_too_large(r,c,rows);
	};
    
}
void error::check_scalar(Integer r,Integer c)
{
	if (r != 1 || c != 1)
	{
		throw error_scalar_required(r,c);
	};
};

void error::chect_row_indices_sortcols(Integer size, Integer c)
{
	if (size > c || size < 0)
	{
		throw error::error_row_indices_sortcols(size,c);
	};
};
void error::chect_row_indices_elem_sortcols(Integer elem, Integer c)
{
	if (elem > c || elem < -c || elem == 0)
	{
		throw error::error_row_indices_elem_sortcols(elem,c);
	};
};
void error::chect_col_indices_sortrows(Integer size, Integer c)
{
	if (size > c || size < 0)
	{
		throw error::error_cols_indices_sortrows(size,c);
	};
};
void error::chect_col_indices_elem_sortrows(Integer elem, Integer c)
{
	if (elem > c || elem < -c || elem == 0)
	{
		throw error::error_col_indices_elem_sortrows(elem,c);
	};
};

};};
