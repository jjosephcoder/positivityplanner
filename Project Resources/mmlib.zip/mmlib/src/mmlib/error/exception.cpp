/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/exception.h"

#pragma warning( push )
#pragma warning(disable:4702)	// unreachable code
#include "boost/lexical_cast.hpp"
#pragma warning( pop )

namespace mmlib { namespace error
{

assert_exception::assert_exception(const std::string& file_, int line_, const std::string& message_)
    :file(file_),line(line_),message(message_)
{
	message = message + " in file: " + file_ + " at line " + boost::lexical_cast<std::string>(line);
};

std::string assert_exception::what() const
{
	return message;
};

const char* mmlib_exception::what() const
{
	m_message = what(get_global_messanger());
	return m_message.c_str();
};

const char* error_alloc::what(exception_message& em) const
{
	return em.error_alloc(m_size);
};

const char* error_size::what(exception_message& em) const
{
	return em.error_size(m_rows,m_cols);
};

const char* error_resize::what(exception_message& em) const
{
	return em.error_resize(m_rows,m_cols);
};

const char* error_int_mult::what(exception_message& em) const
{
	return em.error_int_mult(m_rows,m_cols);
};
const char* error_int_cast::what(exception_message& em) const
{
    return em.error_int_cast(m_val);
};


const char* error_single_index::what(exception_message& em) const
{
	return em.error_single_index(m_pos,m_size);
};

const char* error_double_index::what(exception_message& em) const
{
	return em.error_double_index(m_i,m_j,m_r,m_c);
};

const char* error_diag::what(exception_message& em) const
{
	return em.error_diag(m_d,m_r,m_c);
};


const char* error_index_band::what(exception_message& em) const
{
	return em.error_index_band(m_i,m_j,m_r,m_c,m_l,m_u);
};

const char* error_size_band::what(exception_message& em) const
{
	return em.error_size_band(m_r,m_c,m_l,m_u);
};

const char* error_size_sp::what(exception_message& em) const
{
	return em.error_size_sp(m_r,m_c);
};

const char* error_invalid_return_type::what(exception_message& em) const
{
	return em.error_invalid_return_type();
};

const char* error_horzcat::what(exception_message& em) const
{
	return em.error_horzcat(m_r1,m_c1,m_r2,m_c2);
};

const char* error_vertcat::what(exception_message& em) const
{
	return em.error_vertcat(m_r1,m_c1,m_r2,m_c2);
};
const char* error_index::what(exception_message& em) const
{
	return em.error_index(m_i,m_j,m_r,m_c);
};
const char* error_assign::what(exception_message& em) const
{
	return em.error_assign(m_r1,m_c1,m_r2,m_c2);
};

const char* error_row::what(exception_message& em) const
{
	return em.error_row(m_i,m_r,m_c);
};

const char* error_col::what(exception_message& em) const
{
	return em.error_col(m_j,m_r,m_c);
};

const char* error_reshape::what(exception_message& em) const
{
	return em.error_reshape(m_r1,m_c1,m_r2, m_c2);
};
const char* error_eeop::what(exception_message& em) const
{
	return em.error_eeop(m_r1,m_c1,m_r2, m_c2);
};
const char* error_mul::what(exception_message& em) const
{
	return em.error_mul(m_r1,m_c1,m_r2, m_c2);
};

const char* error_dim::what(exception_message& em) const
{
	return em.error_dim(m_i,m_d);
};

const char* error_atan2_on_complex::what(exception_message& em) const
{
	return em.error_atan2_on_complex();
};

const char* error_bspdiags_nonconf::what(exception_message& em) const
{
	return em.error_bspdiags_nonconf();
};

const char* error_randperm_arg_neg::what(exception_message& em) const
{
	return em.error_randperm_arg_neg(m_n);
};

const char* error_bspdiag_1starg_not_vec::what(exception_message& em) const
{
	return em.error_bspdiag_1starg_not_vec(m_r,m_c);
};

const char* error_bspdiags_2ndarg_not_vec::what(exception_message& em) const
{
	return em.error_bspdiags_2ndarg_not_vec(m_r,m_c);
};

const char* error_diag_arg_not_vec::what(exception_message& em) const
{
	return em.error_diag_arg_not_vec(m_r,m_c);
};

const char* error_linear_index_too_large::what(exception_message& em) const
{
	return em.error_linear_index_too_large(m_r,m_c,m_rows);
};

const char* error_alloc_ext::what(exception_message& em) const
{
	return em.error_alloc_ext();
};

const char* error_scalar_required::what(exception_message& em) const
{
	return em.error_scalar_required(m_r,m_c);
};
const char* error_type_get::what(exception_message& em) const
{
	return em.error_type_get(m_ret,m_in);
};
const char* error_type_get_rep::what(exception_message& em) const
{
	return em.error_type_get_rep(m_ret,m_in);
};
const char* error_unable_to_convert::what(exception_message& em) const
{
	return em.error_unable_to_convert(m_ret,m_in);
};
const char* error_unable_to_read_matrix::what(exception_message& em) const
{
	return em.error_unable_to_read_matrix();
};
const char* error_not_vec::what(exception_message& em) const
{
	return em.error_not_vec(m_r,m_c);
};
const char* error_invalid_vectors_spmat::what(exception_message& em) const
{
	return em.error_invalid_vectors_spmat(m_sr,m_sc,m_sx);
};
const char* error_unable_to_convert_invalid_code::what(exception_message& em) const
{
	return em.error_unable_to_convert_invalid_code();
};
const char* error_row_indices_sortcols::what(exception_message& em) const
{
	return em.error_row_indices_sortcols(m_s,m_c);
};
const char* error_cols_indices_sortrows::what(exception_message& em) const
{
	return em.error_cols_indices_sortrows(m_s,m_c);
};
const char* error_row_indices_elem_sortcols::what(exception_message& em) const
{
	return em.error_row_indices_elem_sortcols(m_elem,m_c);
};
const char* error_col_indices_elem_sortrows::what(exception_message& em) const
{
	return em.error_col_indices_elem_sortrows(m_elem,m_c);
};
const char* error_general::what(exception_message& em) const
{
	return em.error_general(msg);
};

const char* error_open_matfile::what(exception_message& em) const
{
	return em.error_open_matfile(file_name,msg);
};
const char* error_matfile_not_opened::what(exception_message& em) const
{
	return em.error_matfile_not_opened();
};
const char* error_read_matfile::what(exception_message& em) const
{
	return em.error_read_matfile();
};
const char* error_read_matfile_var::what(exception_message& em) const
{
	return em.error_read_matfile_var(var_name);
};

const char* error_write_matfile::what(exception_message& em) const
{
	return em.error_write_matfile();
};

const char* error_open_mmlibfile::what(exception_message& em) const
{
	return em.error_open_mmlibfile(file_name,msg);
};

const char* error_mmlibfile_locked::what(exception_message& em) const
{
	return em.error_mmlibfile_locked();
};
const char* error_create_mmlibfile::what(exception_message& em) const
{
	return em.error_create_mmlibfile(msg);
};
const char* error_read_mmlibfile::what(exception_message& em) const
{
	return em.error_read_mmlibfile(msg);
};
const char* error_read_mmlibfile_mat_not_exist::what(exception_message& em) const
{
	return em.error_read_mmlibfile_mat_not_exist(mat_name);
};
const char* error_write_mmlibfile_mat_already_exist::what(exception_message& em) const
{
	return em.error_write_mmlibfile_mat_already_exist(mat_name);
};

const char* error_unable_to_load_library::what(exception_message& em) const
{
	return em.error_unable_to_load_library(path);
};
const char* error_while_loading_library::what(exception_message& em) const
{
	return em.error_while_loading_library(path);
};
const char* error_object_value_type_not_allowed::what(exception_message& em) const
{
	return em.error_object_value_type_not_allowed();
};
const char* error_integer_value_type_not_allowed::what(exception_message& em) const
{
	return em.error_integer_value_type_not_allowed();
};

const char* error_square_matrix_required::what(exception_message& em) const
{
    return em.error_square_matrix_required();
};

const char* error_invalid_struct::what(exception_message& em) const
{
	return em.error_invalid_struct(st);
};

};};