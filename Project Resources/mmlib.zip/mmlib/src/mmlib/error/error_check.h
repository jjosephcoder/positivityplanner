/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/scalar_types.h"
#include "mmlib/config.h"
#include "mmlib/exception.h"

namespace mmlib { namespace error
{

MMLIB_EXPORT void check_alloc(void *ptr, Integer sz);
MMLIB_EXPORT void check_size(Integer r, Integer c);

inline void throw_error_single_index(Integer i, Integer size)
{
    throw error_single_index(i, size);
};
__forceinline void check_index(Integer i, Integer size)
{
    if (i < 1 || i > size)
	{
        throw_error_single_index(i,size);
	};
};
MMLIB_EXPORT void check_resize(Integer r, Integer c);
MMLIB_EXPORT void check_index(Integer i , Integer j, Integer r, Integer c);
MMLIB_EXPORT void check_diag(Integer d, Integer r, Integer c);
MMLIB_EXPORT void check_index_band(Integer i, Integer j, Integer r, Integer c, Integer l,Integer u);
MMLIB_EXPORT void check_size_band(Integer r, Integer c, Integer l, Integer u);
MMLIB_EXPORT void check_size_sp(Integer r, Integer c);
MMLIB_EXPORT void check_horzcat(Integer r1, Integer c1, Integer r2, Integer c2);
MMLIB_EXPORT void check_vertcat(Integer r1, Integer c1, Integer r2, Integer c2);
MMLIB_EXPORT void check_assign(Integer r1, Integer c1, Integer r2, Integer c2);
MMLIB_EXPORT void check_row(Integer i, Integer r, Integer c);
MMLIB_EXPORT void check_col(Integer j, Integer r, Integer c);
MMLIB_EXPORT void check_reshape(Integer r1, Integer c1, Integer r2, Integer c2);
MMLIB_EXPORT void check_eeop(Integer r1, Integer c1, Integer r2, Integer c2);
MMLIB_EXPORT void check_mul(Integer r1, Integer c1, Integer r2, Integer c2);
MMLIB_EXPORT void check_dim(Integer i, Integer d = 2);
MMLIB_EXPORT void check_randperm_arg(Integer n);
MMLIB_EXPORT void check_bspdiag_1starg(Integer r, Integer c);
MMLIB_EXPORT void check_bspdiags_2ndarg(Integer r, Integer c);
MMLIB_EXPORT void check_diag_arg(Integer r, Integer c);
MMLIB_EXPORT void check_linear_index(Integer r, Integer c, Integer rows);
MMLIB_EXPORT void check_scalar(Integer r,Integer c);
MMLIB_EXPORT void chect_row_indices_sortcols(Integer size, Integer c);
MMLIB_EXPORT void chect_row_indices_elem_sortcols(Integer size, Integer c);
MMLIB_EXPORT void chect_col_indices_sortrows(Integer size, Integer c);
MMLIB_EXPORT void chect_col_indices_elem_sortrows(Integer size, Integer c);
};};