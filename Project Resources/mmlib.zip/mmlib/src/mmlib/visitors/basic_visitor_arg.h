/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/visitors/visitor.h"
#include "mmlib/container/raw/type_decl.h"

namespace mmlib { namespace details
{

class basic_bin_visitor_plus: public bin_visitor<basic_bin_visitor_plus,Matrix>
{
	public:
		typedef bin_visitor<basic_bin_visitor_plus,Matrix>		base_type;

	private:
		Matrix			m_scal_1;
		Matrix			m_scal_2;

	public:
		basic_bin_visitor_plus(const Matrix& A, const Matrix& B, const Matrix& s1, const Matrix& s2)	
			:base_type(A,B),m_scal_1(s1),m_scal_2(s2){};

		template<class M1, class M2> Matrix		eval_scal_scal(const M1&, const M2&);
		template<class M1, class M2> Matrix		eval_scal_mat(const M1&, const M2&);
		template<class M1, class M2> Matrix		eval_mat_scal(const M1&, const M2&);
		template<class M1, class M2> Matrix		eval_mat_mat(const M1&, const M2&);
};

class basic_bin_visitor_plus_inpl: public bin_visitor<basic_bin_visitor_plus_inpl,void>
{
	public:
		typedef bin_visitor<basic_bin_visitor_plus_inpl,void>		base_type;

	private:
		Matrix&			out;
		Matrix			m_scal;

	public:
		basic_bin_visitor_plus_inpl(Matrix& out, const Matrix& A, const Matrix& s)	
			:base_type(out,A),out(out),m_scal(s){};

		template<class M1, class M2> void		eval_scal_scal(const M1&, const M2&);
		template<class M1, class M2> void		eval_scal_mat(const M1&, const M2&);
		template<class M1, class M2> void		eval_mat_scal(const M1&, const M2&);
		template<class M1, class M2> void		eval_mat_mat(const M1&, const M2&);
};

};};
