/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "mmlib/container/matrix2.inl"
#include "mmlib/visitors/assign_visitor_utils.h"
#include "mmlib/base/raw_colon.h"
#include "mmlib/error/error_check.h"
#include "mmlib/exception.h"
#include "mmlib/constants.h"
#include "mmlib/manip.h"
#include "mmlib/utils/utils.h"

namespace mmlib { namespace details
{


//s is referred only if c1.m_flag == t_last, t_end, t_rev_end, t_end_end;
bool to_raw_colon(Integer s, const colon& c1, raw::colon& c)
{
	switch (c1.m_flag)
	{
		case colon::t_all:
		{
			c = raw::colon();	break;
		}
		case colon::t_range:
		{				
			c = raw::colon(c1.m_s,c1.m_i,c1.m_e);	break;
		}
		case colon::t_end:
		{
			c = raw::colon(c1.m_s,c1.m_i,c1.m_end1.apply(s));	break;
		}
		case colon::t_rev_end:
		{
			c = raw::colon(c1.m_end1.apply(s),c1.m_i,c1.m_e);	break;
		}
		case colon::t_end_end:
		{
			c = raw::colon(c1.m_end1.apply(s),c1.m_i,c1.m_end2.apply(s));	break;
		}
		case colon::t_last:
		{
			Integer p = c1.m_end1.apply(s);
			c = raw::colon(p,p);	break;
		}
		case colon::t_matrix:
		default:
		{
			return false;
		}
	};
	return true;
};

static raw::IntegerMatrix make_index(Integer size, Integer row, Integer col, bool is_row, const colon& c)
{
	raw::colon cex;
	bool b1 = to_raw_colon(size,c,cex);

	if (b1)
	{
		Integer st, in, en, r;

		cex.apply(size, st, in, en, r);

		if (r)
		{
			if (is_row)
			{
				error::check_row(st, row, col);
				error::check_row(en, row, col);
			}
			else
			{
				error::check_col(st, row, col);
				error::check_col(en, row, col);
			};
		}

        raw::IntegerMatrix ind(get_raw_ti(),r,1);
        Integer* ptr_ind = ind.ptr();

		for (Integer i = 0, ii = st; i < r; ++i, ii += in)
		{
			ptr_ind[i] = ii;
		};

		return ind;
	};

	const Matrix&	mat_ind1 = c.m_mat;
	raw::IntegerMatrix ri = mat_ind1.impl<raw::IntegerMatrix>();

    Integer r = ri.size();
    const Integer* ptr_ri = ri.ptr();

	if (is_row)
	{
		for (Integer i = 0; i < r; ++i)
		{
			error::check_row(ptr_ri[i], row, col);
		}
	}
	else
	{
		for (Integer i = 0; i < r; ++i)
		{
			error::check_col(ptr_ri[i], row, col);
		}
	};

	return ri;
};
static void make_index(Integer size,Integer rows, Integer cols, bool is_row, const colon& c,
                       Integer& start,Integer& step,Integer& end, Integer& length)
{
	raw::colon cex;
	bool b1 = to_raw_colon(size,c,cex);

	if (b1)
	{
		Integer st, in, en, r;

		cex.apply(size, st, in, en, r);

		if (r)
		{
			if (is_row)
			{
				error::check_row(st, rows, cols);
				error::check_row(en, rows, cols);
			}
			else
			{
				error::check_col(st, rows, cols);
				error::check_col(en, rows, cols);
			};
		}
		else
		{
			st = 1;
			in = 1;
			en  = 0;
		};

		start = st;
		step = in;
		end = en;
		length = r;
		return;
	}
	else
	{
		assertion(0,"invalid colon type");
	};
};
static raw::IntegerMatrix make_index_2(Integer rows, Integer cols, const colon& c)
{
	const Matrix&	mat_ind1 = c.m_mat;
	raw::IntegerMatrix ri = mat_ind1.impl<raw::IntegerMatrix>();
    const Integer* ptr_ri = ri.ptr();

    Integer r   = ri.size();	
	Integer As  = imult_s(rows,cols);
    
	for (Integer i = 0; i < r; ++i)
	{
		error::check_index(ptr_ri[i], As);
	}
	return ri;
};
static void make_index_2(Integer rows, Integer cols, const colon& c,Integer& start,
                         Integer& step,Integer& end, Integer& length)
{
	raw::colon cex;
	bool b1;
	if (c.m_flag == colon::t_last || c.m_flag == colon::t_end || c.m_flag == colon::t_rev_end)
	{
		Integer As = imult_c(rows,cols);
		b1 = to_raw_colon(As,c,cex);
	}
	else
	{
		b1 = to_raw_colon(0,c,cex);
	};

	if (!b1)
	{
		assertion(0,"invalid colon type");
	};

	Integer As = imult_s(rows,cols);

	Integer st, in, en, s;

	if (c.m_flag == colon::t_range)
	{
		//matrix size is not reffered
		cex.apply(0, st, in, en, s);
	}
	else
	{
		imult_c(rows, cols);
		cex.apply(As, st, in, en, s);
	};	

	if (s)
	{
		// if colon is a range, then index <= MaxInt
		// in opposite case if As is too large, then exception is already thrown.
		error::check_index(st, As);
		error::check_index(en, As);
	}

	start = st;
	step = in;
	end = en;
	length = s;
	return;
};
void make_index(Integer rows, Integer cols, const colon& c1, const colon& c2, colon_info& c_info)
{
	switch (c1.m_flag)
	{			
		case colon::t_matrix:
		{
			c_info.set_ri(make_index(rows,rows,cols,true,c1));
			c_info.r_flag = 0;            
			break;
		}
		case colon::t_last:
		case colon::t_all:
		case colon::t_range:	
		case colon::t_rev_end:
		case colon::t_end:	
		case colon::t_end_end:	
		{
			make_index(rows,rows,cols, true,c1,c_info.r_start, c_info.r_step, c_info.r_end, c_info.r_size);
			c_info.r_flag = 1;
			break;
		}
	};
	switch (c2.m_flag)
	{			
		case colon::t_matrix:
		{
			c_info.set_ci(make_index(cols,rows,cols, false, c2));
			c_info.c_flag = 0;
			break;
		}
		case colon::t_last:
		case colon::t_all:
		case colon::t_range:	
		case colon::t_rev_end:
		case colon::t_end:
		case colon::t_end_end:
		{
			make_index(cols,rows,cols, false, c2,c_info.c_start, c_info.c_step, c_info.c_end,c_info.c_size);
			c_info.c_flag = 1;
			break;
		}
	};

    c_info.r_rep_size = c_info.rows();
    c_info.c_rep_size = c_info.cols();
};
void make_index(Integer rows, Integer cols, const colon& c, colon_info& c_info)
{
	switch (c.m_flag)
	{			
		case colon::t_matrix:
		{
			c_info.set_ri(make_index_2(rows,cols,c));
			c_info.r_flag = 0;
            c_info.c_flag = -1;
            c_info.r_rep_size = c_info.get_ri().rows();
            c_info.c_rep_size = c_info.get_ri().cols();
			break;
		}
		case colon::t_last:
		case colon::t_all:
		case colon::t_range:	
		case colon::t_rev_end:
		case colon::t_end:	
		case colon::t_end_end:
		{
			make_index_2(rows,cols, c,c_info.r_start, c_info.r_step, c_info.r_end, c_info.r_size);
			c_info.r_flag = 1;
            c_info.c_flag = -1;

            if (c.m_mat.is_scalar() == false)
            {
                c_info.r_rep_size = c.m_mat(1).get_scalar<Integer>();
                c_info.c_rep_size = c.m_mat(2).get_scalar<Integer>();
            }
            else
            {
                c_info.r_rep_size = c_info.rows();
                c_info.c_rep_size = 1;
            };
			break;
		}
	};
};


};};
