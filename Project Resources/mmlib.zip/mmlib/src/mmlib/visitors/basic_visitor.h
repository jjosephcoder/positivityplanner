/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/visitors/visitor.h"
#include "mmlib/visitors/extract_type_switch.h"
#include "mmlib/visitors/extract_type2_switch.h"

namespace mmlib { namespace details
{

struct unary_op
{
	enum operator_type
	{
		OP_SGN_MIN, OP_NEG, OP_FULL, OP_SPARSE, OP_BAND, OP_TRANS, OP_CTRANS, OP_CLONE, OP_VEC,
		OP_IS_FINITE,OP_IS_NAN,OP_IS_INF,OP_FLIPLR,OP_FLIPUD,OP_IMAG,OP_REAL,
		OP_ARG, OP_ABS, OP_CONJ, OP_IS_TRUE,
		OP_SQRT,OP_POW2,OP_LOG,OP_EXP,OP_LOG2,OP_LOG10,OP_FLOOR,OP_CEIL,OP_ROUND,OP_FIX,OP_TRUNC,
		OP_IFLOOR,OP_ICEIL,OP_IROUND,OP_IFIX,OP_ITRUNC,OP_ISIGN,
		OP_SIGN,OP_SIN,OP_COS,OP_TAN,OP_COT,OP_SEC,OP_CSC,OP_ASIN,OP_ACOS,OP_ATAN,OP_ACOT,
		OP_ASEC,OP_ACSC,OP_SINH,OP_COSH,OP_TANH,OP_COTH,OP_SECH,OP_CSCH,OP_ASINH,OP_ACOSH,
		OP_ATANH,OP_ACOTH,OP_ASECH,OP_ACSCH,

		OP_SQRT_NC, OP_LOG_NC, OP_LOG2_NC, OP_LOG10_NC, OP_ASIN_NC, OP_ACOS_NC, OP_ASEC_NC,
		OP_ACSC_NC, OP_ACOSH_NC, OP_ATANH_NC, OP_ACOTH_NC, OP_ASECH_NC,

		OP_RESHAPE, OP_TRIL, OP_TRIU, OP_DIAG, OP_REPMAT, OP_SUM, OP_PROD, 
		OP_CUMSUM, OP_CUMPROD, OP_SUMSQ, OP_MIN, OP_MAX, OP_MEAN, OP_STD, 
        OP_MIN_ABS, OP_MAX_ABS, OP_MIN_ABS2, OP_MAX_ABS2,
		OP_ALL, OP_ANY, OP_ANY_T, OP_ALL_T, OP_FIND, OP_FIND_T, OP_FIND_2, 
		OP_FIND_T_2, OP_FIND_3, OP_FIND_T_3, OP_SORT, OP_SORT2, OP_SORTROWS, 
		OP_SORTROWS2, OP_SORTROWS_DIM, OP_SORTROWS_DIM2, OP_MIN2, OP_MAX2,
		OP_SORTCOLS, OP_SORTCOLS2, OP_SORTCOLS_DIM, OP_SORTCOLS_DIM2,
		OP_ISSORTED, OP_ISSORTED_ROWS, OP_ISSORTED_COLS,
		OP_CONVERT, OP_EVAL_FUNC_SCAL,OP_CONVERT_OBJ,

        GET_UD, GET_LD, OP_NNZ
	};
};
template<class ret_type, enum unary_op::operator_type op>
class basic_unary_visitor_0 : public extract_type_switch_0<ret_type,basic_unary_visitor_0<ret_type,op>,true>
{};
template<class ret_type, enum unary_op::operator_type op>
class basic_unary_visitor_1 : public extract_type_switch_1<ret_type,basic_unary_visitor_1<ret_type,op>,true>
{};
template<class ret_type, enum unary_op::operator_type op>
class basic_unary_visitor_2 : public extract_type_switch_2<ret_type,basic_unary_visitor_2<ret_type,op>,true>
{};

struct binary_op
{
	enum operator_type
	{
		OP_PLUS, OP_MINUS, OP_MULT, OP_DIV, OP_DMUL, OP_DDIV, OP_POW, OP_MIN, OP_MAX,
		OP_XOR, OP_OR, OP_AND, OP_EEQ, OP_NEQ, OP_LT, OP_LEQ, OP_GT, OP_GEQ, OP_MOD, OP_REM,
		OP_ATAN2, OP_KRON, OP_DIDIV, OP_POW_NC
	};
};

struct basic_binary_visitor : public extract_type2_switch<Matrix,basic_binary_visitor,int>
{
    template<class T1, class T2>
    static Matrix eval_mat_mat(const T1& A, const T2& B, int code);
    template<class T1, class T2>
    static Matrix eval_mat_scal(const T1& A, const T2& B, int code);
    template<class T1, class T2>
    static Matrix eval_scal_mat(const T1& A, const T2& B, int code);
    template<class T1, class T2>
    static Matrix eval_scal_scal(const T1& A, const T2& B, int code);
};

};};