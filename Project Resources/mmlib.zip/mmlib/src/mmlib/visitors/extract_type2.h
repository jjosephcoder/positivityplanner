/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

namespace mmlib { namespace details
{

template<class ret,class owner>
struct vtable2_0
{
    typedef ret (*function_type)(const Matrix&,const Matrix&);
    static const size_t N = macro_last_matrix_type_code+1;
    typedef function_type table_type[N*N];

    static table_type* table;
    static function_type get(size_t code1,size_t code2)
    {
        return (*table)[code1*N+code2];
    };
    static table_type* init_table()
    {
        static table_type table;
        init_table_mat(table);
        init_table_scal(table);
        return &table;
    };
    static void init_table_mat(table_type& table)
    {
        {
            typedef raw::Matrix<Integer,struct_dense> type;
            init_table_mat_impl<enums::integer_dense,type>(table);
        };
        {
            typedef raw::Matrix<Real,struct_dense> type;
            init_table_mat_impl<enums::real_dense,type>(table);
        };
        {
            typedef raw::Matrix<Complex,struct_dense> type;
            init_table_mat_impl<enums::complex_dense,type>(table);
        };
        {
            typedef raw::Matrix<Object,struct_dense> type;
            init_table_mat_impl<enums::object_dense,type>(table);
        };

        {
            typedef raw::Matrix<Integer,struct_sparse> type;
            init_table_mat_impl<enums::integer_sparse,type>(table);
        };
        {
            typedef raw::Matrix<Real,struct_sparse> type;
            init_table_mat_impl<enums::real_sparse,type>(table);
        };
        {
            typedef raw::Matrix<Complex,struct_sparse> type;
            init_table_mat_impl<enums::complex_sparse,type>(table);
        };
        {
            typedef raw::Matrix<Object,struct_sparse> type;
            init_table_mat_impl<enums::object_sparse,type>(table);
        };

        {
            typedef raw::Matrix<Integer,struct_banded> type;
            init_table_mat_impl<enums::integer_band,type>(table);
        };
        {
            typedef raw::Matrix<Real,struct_banded> type;
            init_table_mat_impl<enums::real_band,type>(table);
        };
        {
            typedef raw::Matrix<Complex,struct_banded> type;
            init_table_mat_impl<enums::complex_band,type>(table);
        };
        {
            typedef raw::Matrix<Object,struct_banded> type;
            init_table_mat_impl<enums::object_band,type>(table);
        };
    };
    static void init_table_scal(table_type& table)
    {
        init_table_scal_impl<enums::integer_scalar,Integer>(table);
        init_table_scal_impl<enums::real_scalar,Real>(table);
        init_table_scal_impl<enums::complex_scalar,Complex>(table);
        init_table_scal_impl<enums::object_scalar,Object>(table);
    };
    template<enum enums::mat_type mt,class T1>
    static void init_table_mat_impl(table_type& table)
    {
        init_table_mat_mat<mt,T1>(table);
        init_table_mat_scal<mt,T1>(table);
    };
    template<enum enums::mat_type mt,class T1>
    static void init_table_scal_impl(table_type& table)
    {
        init_table_scal_mat<mt,T1>(table);
        init_table_scal_scal<mt,T1>(table);
    };
    template<enum enums::mat_type mt,class T1>
    static void init_table_mat_mat(table_type& table)
    {
        {
            typedef raw::Matrix<Integer,struct_dense> type;
            init_table_mat_mat_impl<mt,T1,enums::integer_dense,type>(table);
        };
        {
            typedef raw::Matrix<Real,struct_dense> type;
            init_table_mat_mat_impl<mt,T1,enums::real_dense,type>(table);
        };
        {
            typedef raw::Matrix<Complex,struct_dense> type;
            init_table_mat_mat_impl<mt,T1,enums::complex_dense,type>(table);
        };
        {
            typedef raw::Matrix<Object,struct_dense> type;
            init_table_mat_mat_impl<mt,T1,enums::object_dense,type>(table);
        };

        {
            typedef raw::Matrix<Integer,struct_sparse> type;
            init_table_mat_mat_impl<mt,T1,enums::integer_sparse,type>(table);
        };
        {
            typedef raw::Matrix<Real,struct_sparse> type;
            init_table_mat_mat_impl<mt,T1,enums::real_sparse,type>(table);
        };
        {
            typedef raw::Matrix<Complex,struct_sparse> type;
            init_table_mat_mat_impl<mt,T1,enums::complex_sparse,type>(table);
        };
        {
            typedef raw::Matrix<Object,struct_sparse> type;
            init_table_mat_mat_impl<mt,T1,enums::object_sparse,type>(table);
        };

        {
            typedef raw::Matrix<Integer,struct_banded> type;
            init_table_mat_mat_impl<mt,T1,enums::integer_band,type>(table);
        };
        {
            typedef raw::Matrix<Real,struct_banded> type;
            init_table_mat_mat_impl<mt,T1,enums::real_band,type>(table);
        };
        {
            typedef raw::Matrix<Complex,struct_banded> type;
            init_table_mat_mat_impl<mt,T1,enums::complex_band,type>(table);
        };
        {
            typedef raw::Matrix<Object,struct_banded> type;
            init_table_mat_mat_impl<mt,T1,enums::object_band,type>(table);
        };
    };
    template<enum enums::mat_type mt,class T1>
    static void init_table_scal_mat(table_type& table)
    {
        {
            typedef raw::Matrix<Integer,struct_dense> type;
            init_table_scal_mat_impl<mt,T1,enums::integer_dense,type>(table);
        };
        {
            typedef raw::Matrix<Real,struct_dense> type;
            init_table_scal_mat_impl<mt,T1,enums::real_dense,type>(table);
        };
        {
            typedef raw::Matrix<Complex,struct_dense> type;
            init_table_scal_mat_impl<mt,T1,enums::complex_dense,type>(table);
        };
        {
            typedef raw::Matrix<Object,struct_dense> type;
            init_table_scal_mat_impl<mt,T1,enums::object_dense,type>(table);
        };

        {
            typedef raw::Matrix<Integer,struct_sparse> type;
            init_table_scal_mat_impl<mt,T1,enums::integer_sparse,type>(table);
        };
        {
            typedef raw::Matrix<Real,struct_sparse> type;
            init_table_scal_mat_impl<mt,T1,enums::real_sparse,type>(table);
        };
        {
            typedef raw::Matrix<Complex,struct_sparse> type;
            init_table_scal_mat_impl<mt,T1,enums::complex_sparse,type>(table);
        };
        {
            typedef raw::Matrix<Object,struct_sparse> type;
            init_table_scal_mat_impl<mt,T1,enums::object_sparse,type>(table);
        };

        {
            typedef raw::Matrix<Integer,struct_banded> type;
            init_table_scal_mat_impl<mt,T1,enums::integer_band,type>(table);
        };
        {
            typedef raw::Matrix<Real,struct_banded> type;
            init_table_scal_mat_impl<mt,T1,enums::real_band,type>(table);
        };
        {
            typedef raw::Matrix<Complex,struct_banded> type;
            init_table_scal_mat_impl<mt,T1,enums::complex_band,type>(table);
        };
        {
            typedef raw::Matrix<Object,struct_banded> type;
            init_table_scal_mat_impl<mt,T1,enums::object_band,type>(table);
        };
    };
    template<enum enums::mat_type mt,class T1>
    static void init_table_mat_scal(table_type& table)
    {
        init_table_mat_scal_impl<mt,T1,enums::integer_scalar,Integer>(table);
        init_table_mat_scal_impl<mt,T1,enums::real_scalar,Real>(table);
        init_table_mat_scal_impl<mt,T1,enums::complex_scalar,Complex>(table);
        init_table_mat_scal_impl<mt,T1,enums::object_scalar,Object>(table);
    };
    template<enum enums::mat_type mt,class T1>
    static void init_table_scal_scal(table_type& table)
    {
        init_table_scal_scal_impl<mt,T1,enums::integer_scalar,Integer>(table);
        init_table_scal_scal_impl<mt,T1,enums::real_scalar,Real>(table);
        init_table_scal_scal_impl<mt,T1,enums::complex_scalar,Complex>(table);
        init_table_scal_scal_impl<mt,T1,enums::object_scalar,Object>(table);
    };
    template<enum enums::mat_type mt1,class T1,enum enums::mat_type mt2,class T2>
    static void init_table_mat_mat_impl(table_type& table)
    {
        table[mt1*N+mt2] = owner::make_mat_mat<T1,T2>;
    };
    template<enum enums::mat_type mt1,class T1,enum enums::mat_type mt2,class T2>
    static void init_table_mat_scal_impl(table_type& table)
    {
        table[mt1*N+mt2] = owner::make_mat_scal<T1,T2>;
    };
    template<enum enums::mat_type mt1,class T1,enum enums::mat_type mt2,class T2>
    static void init_table_scal_mat_impl(table_type& table)
    {
        table[mt1*N+mt2] = owner::make_scal_mat<T1,T2>;
    };
    template<enum enums::mat_type mt1,class T1,enum enums::mat_type mt2,class T2>
    static void init_table_scal_scal_impl(table_type& table)
    {
        table[mt1*N+mt2] = owner::make_scal_scal<T1,T2>;
    };
};
template<class ret,class owner>
typename vtable2_0<ret,owner>::table_type* 
vtable2_0<ret,owner>::table = vtable2_0<ret,owner>::init_table();


template<class ret, class derived,class T1, class T2, bool iso>
struct extract_type2_impl
{
    static ret eval_mat_mat(const T1& A, const T2& B)
    {
        return derived::eval_mat_mat<T1,T2>(A,B);
    };
    static ret eval_mat_scal(const T1& A, const T2& B)
    {
        return derived::eval_mat_scal<T1,T2>(A,B);
    };
    static ret eval_scal_mat(const T1& A, const T2& B)
    {
        return derived::eval_scal_mat<T1,T2>(A,B);
    };
    static ret eval_scal_scal(const T1& A, const T2& B)
    {
        return derived::eval_scal_scal<T1,T2>(A,B);
    };
};

template<class T>
struct object_matrix
{
    typedef Object type;
};
template<class V,class S>
struct object_matrix<raw::Matrix<V,S>>
{
    typedef raw::Matrix<Object,S> type;
};
template<class ret, class derived,class T1, class T2>
struct extract_type2_impl<ret,derived,T1,T2,true>
{
    static ret eval_mat_mat(const T1& A, const T2& B)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);

		return derived::eval_mat_mat<MT1,MT2>(corrector::convert_1(out_ti,A),
                                              corrector::convert_2(out_ti,B));
    };
    static ret eval_mat_scal(const T1& A, const T2& B)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);

		return derived::eval_mat_scal<MT1,MT2>(corrector::convert_1(out_ti,A),
                                              corrector::convert_2(out_ti,B));
    };
    static ret eval_scal_mat(const T1& A, const T2& B)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);

		return derived::eval_scal_mat<MT1,MT2>(corrector::convert_1(out_ti,A),
                                              corrector::convert_2(out_ti,B));
    };

    static ret eval_scal_scal(const T1& A, const T2& B)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);

		return derived::eval_scal_scal<MT1,MT2>(corrector::convert_1(out_ti,A),
                                              corrector::convert_2(out_ti,B));
    };
};
template<class T>
struct is_object
{
    static const bool value = is_equal<T,Object>::value;
};
template<class V,class S>
struct is_object<raw::Matrix<V,S>>
{
    static const bool value = is_equal<V,Object>::value;
};
template<class ret, class derived>
struct extract_type2
{
    static ret make(const Matrix& A, const Matrix& B)
    {
        typedef vtable2_0<ret,extract_type2> vtable_type;
        typedef typename vtable_type::function_type Func;
        Func f = vtable_type::get(A.matrix_type(),B.matrix_type());
        return f(A,B);
    };		
    template<class T1, class T2>
    static ret make_mat_mat(const Matrix& A, const Matrix& B)
    {
        static const bool iso = is_object<T1>::value || is_object<T2>::value;
        return extract_type2_impl<ret,derived,T1,T2,iso>
            ::eval_mat_mat(A.get_mat<T1>(),B.get_mat<T2>());
    };
    template<class T1, class T2>
    static ret make_mat_scal(const Matrix& A, const Matrix& B)
    {
        static const bool iso = is_object<T1>::value || is_object<T2>::value;
        return extract_type2_impl<ret,derived,T1,T2,iso>
            ::eval_mat_scal(A.get_mat<T1>(),B.get_scalar<T2>());
    };
    template<class T1, class T2>
    static ret make_scal_mat(const Matrix& A, const Matrix& B)
    {
        static const bool iso = is_object<T1>::value || is_object<T2>::value;
        return extract_type2_impl<ret,derived,T1,T2,iso>
            ::eval_scal_mat(A.get_scalar<T1>(),B.get_mat<T2>());
    };
    template<class T1, class T2>
    static ret make_scal_scal(const Matrix& A, const Matrix& B)
    {
        static const bool iso = is_object<T1>::value || is_object<T2>::value;
        return extract_type2_impl<ret,derived,T1,T2,iso>
            ::eval_scal_scal(A.get_scalar<T1>(),B.get_scalar<T2>());
    };
};

};};