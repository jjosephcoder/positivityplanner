/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/exception.h"

namespace mmlib { namespace details
{

template<class ret, class derived, bool cost_access>
struct extract_type_switch_0
{
    template<class c_type>
    static ret make(typename hide_type<c_type>::type ptr)
    {
        switch(ptr.matrix_type())
        {
            case enums::integer_dense:
            {
                typedef raw::Matrix<Integer,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::real_dense:
            {
                typedef raw::Matrix<Real,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::complex_dense:
            {
                typedef raw::Matrix<Complex,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::object_dense:
            {
                typedef raw::Matrix<Object,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::integer_sparse:
            {
                typedef raw::Matrix<Integer,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::real_sparse:
            {
                typedef raw::Matrix<Real,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::complex_sparse:
            {
                typedef raw::Matrix<Complex,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::object_sparse:
            {
                typedef raw::Matrix<Object,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::integer_band:
            {
                typedef raw::Matrix<Integer,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::real_band:
            {
                typedef raw::Matrix<Real,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::complex_band:
            {
                typedef raw::Matrix<Complex,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::object_band:
            {
                typedef raw::Matrix<Object,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>());
            }
            case enums::integer_scalar:
            {
                typedef Integer type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>());
            }
            case enums::real_scalar:
            {
                typedef Real type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>());
            }
            case enums::complex_scalar:
            {
                typedef Complex type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>());
            }
            case enums::object_scalar:
            {
                typedef Object type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>());
            }
            default:
                assertion(0,"invalid case");
                throw;
        };
    };		
};
template<class ret, class derived>
struct extract_type_switch_0<ret,derived,true>
{
    template<class c_type>
    static ret make(typename hide_type<c_type>::type ptr)
    {
        switch(ptr.matrix_type())
        {
            case enums::integer_dense:
            {
                typedef raw::Matrix<Integer,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::real_dense:
            {
                typedef raw::Matrix<Real,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::complex_dense:
            {
                typedef raw::Matrix<Complex,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::object_dense:
            {
                typedef raw::Matrix<Object,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::integer_sparse:
            {
                typedef raw::Matrix<Integer,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::real_sparse:
            {
                typedef raw::Matrix<Real,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::complex_sparse:
            {
                typedef raw::Matrix<Complex,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::object_sparse:
            {
                typedef raw::Matrix<Object,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::integer_band:
            {
                typedef raw::Matrix<Integer,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::real_band:
            {
                typedef raw::Matrix<Real,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::complex_band:
            {
                typedef raw::Matrix<Complex,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::object_band:
            {
                typedef raw::Matrix<Object,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>());
            }
            case enums::integer_scalar:
            {
                typedef Integer type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>());
            }
            case enums::real_scalar:
            {
                typedef Real type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>());
            }
            case enums::complex_scalar:
            {
                typedef Complex type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>());
            }
            case enums::object_scalar:
            {
                typedef Object type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>());
            }
            default:
                assertion(0,"invalid case");
                throw;
        };
    };		
};


template<class ret, class derived, bool cost_access>
struct extract_type_switch_1
{
    template<class c_type, class Arg1>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1)
    {
        switch(ptr.matrix_type())
        {
            case enums::integer_dense:
            {
                typedef raw::Matrix<Integer,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::real_dense:
            {
                typedef raw::Matrix<Real,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::complex_dense:
            {
                typedef raw::Matrix<Complex,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::object_dense:
            {
                typedef raw::Matrix<Object,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::integer_sparse:
            {
                typedef raw::Matrix<Integer,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::real_sparse:
            {
                typedef raw::Matrix<Real,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::complex_sparse:
            {
                typedef raw::Matrix<Complex,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::object_sparse:
            {
                typedef raw::Matrix<Object,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::integer_band:
            {
                typedef raw::Matrix<Integer,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::real_band:
            {
                typedef raw::Matrix<Real,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::complex_band:
            {
                typedef raw::Matrix<Complex,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::object_band:
            {
                typedef raw::Matrix<Object,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1);
            }
            case enums::integer_scalar:
            {
                typedef Integer type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1);
            }
            case enums::real_scalar:
            {
                typedef Real type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1);
            }
            case enums::complex_scalar:
            {
                typedef Complex type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1);
            }
            case enums::object_scalar:
            {
                typedef Object type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1);
            }
            default:
                assertion(0,"invalid case");
                throw;
        };
    };		
};
template<class ret, class derived>
struct extract_type_switch_1<ret,derived,true>
{
    template<class c_type, class Arg1>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1)
    {
        switch(ptr.matrix_type())
        {
            case enums::integer_dense:
            {
                typedef raw::Matrix<Integer,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::real_dense:
            {
                typedef raw::Matrix<Real,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::complex_dense:
            {
                typedef raw::Matrix<Complex,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::object_dense:
            {
                typedef raw::Matrix<Object,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::integer_sparse:
            {
                typedef raw::Matrix<Integer,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::real_sparse:
            {
                typedef raw::Matrix<Real,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::complex_sparse:
            {
                typedef raw::Matrix<Complex,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::object_sparse:
            {
                typedef raw::Matrix<Object,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::integer_band:
            {
                typedef raw::Matrix<Integer,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::real_band:
            {
                typedef raw::Matrix<Real,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::complex_band:
            {
                typedef raw::Matrix<Complex,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::object_band:
            {
                typedef raw::Matrix<Object,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1);
            }
            case enums::integer_scalar:
            {
                typedef Integer type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1);
            }
            case enums::real_scalar:
            {
                typedef Real type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1);
            }
            case enums::complex_scalar:
            {
                typedef Complex type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1);
            }
            case enums::object_scalar:
            {
                typedef Object type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1);
            }
            default:
                assertion(0,"invalid case");
                throw;
        };
    };		
};

template<class ret, class derived, bool cost_access>
struct extract_type_switch_2
{
    template<class c_type, class Arg1, class Arg2>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2)
    {
        switch(ptr.matrix_type())
        {
            case enums::integer_dense:
            {
                typedef raw::Matrix<Integer,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::real_dense:
            {
                typedef raw::Matrix<Real,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::complex_dense:
            {
                typedef raw::Matrix<Complex,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::object_dense:
            {
                typedef raw::Matrix<Object,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::integer_sparse:
            {
                typedef raw::Matrix<Integer,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::real_sparse:
            {
                typedef raw::Matrix<Real,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::complex_sparse:
            {
                typedef raw::Matrix<Complex,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::object_sparse:
            {
                typedef raw::Matrix<Object,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::integer_band:
            {
                typedef raw::Matrix<Integer,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::real_band:
            {
                typedef raw::Matrix<Real,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::complex_band:
            {
                typedef raw::Matrix<Complex,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::object_band:
            {
                typedef raw::Matrix<Object,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2);
            }
            case enums::integer_scalar:
            {
                typedef Integer type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2);
            }
            case enums::real_scalar:
            {
                typedef Real type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2);
            }
            case enums::complex_scalar:
            {
                typedef Complex type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2);
            }
            case enums::object_scalar:
            {
                typedef Object type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2);
            }
            default:
                assertion(0,"invalid case");
                throw;
        };
    };		
};
template<class ret, class derived>
struct extract_type_switch_2<ret,derived,true>
{
    template<class c_type, class Arg1, class Arg2>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2)
    {
        switch(ptr.matrix_type())
        {
            case enums::integer_dense:
            {
                typedef raw::Matrix<Integer,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::real_dense:
            {
                typedef raw::Matrix<Real,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::complex_dense:
            {
                typedef raw::Matrix<Complex,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::object_dense:
            {
                typedef raw::Matrix<Object,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::integer_sparse:
            {
                typedef raw::Matrix<Integer,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::real_sparse:
            {
                typedef raw::Matrix<Real,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::complex_sparse:
            {
                typedef raw::Matrix<Complex,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::object_sparse:
            {
                typedef raw::Matrix<Object,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::integer_band:
            {
                typedef raw::Matrix<Integer,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::real_band:
            {
                typedef raw::Matrix<Real,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::complex_band:
            {
                typedef raw::Matrix<Complex,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::object_band:
            {
                typedef raw::Matrix<Object,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2);
            }
            case enums::integer_scalar:
            {
                typedef Integer type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2);
            }
            case enums::real_scalar:
            {
                typedef Real type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2);
            }
            case enums::complex_scalar:
            {
                typedef Complex type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2);
            }
            case enums::object_scalar:
            {
                typedef Object type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2);
            }
            default:
                assertion(0,"invalid case");
                throw;
        };
    };		
};

template<class ret, class derived, bool cost_access>
struct extract_type_switch_3
{
    template<class c_type, class Arg1, class Arg2, class Arg3>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2, Arg3 arg3)
    {
        switch(ptr.matrix_type())
        {
            case enums::integer_dense:
            {
                typedef raw::Matrix<Integer,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::real_dense:
            {
                typedef raw::Matrix<Real,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::complex_dense:
            {
                typedef raw::Matrix<Complex,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::object_dense:
            {
                typedef raw::Matrix<Object,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::integer_sparse:
            {
                typedef raw::Matrix<Integer,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::real_sparse:
            {
                typedef raw::Matrix<Real,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::complex_sparse:
            {
                typedef raw::Matrix<Complex,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::object_sparse:
            {
                typedef raw::Matrix<Object,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::integer_band:
            {
                typedef raw::Matrix<Integer,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::real_band:
            {
                typedef raw::Matrix<Real,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::complex_band:
            {
                typedef raw::Matrix<Complex,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::object_band:
            {
                typedef raw::Matrix<Object,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl_unique<type>(),arg1,arg2,arg3);
            }
            case enums::integer_scalar:
            {
                typedef Integer type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2,arg3);
            }
            case enums::real_scalar:
            {
                typedef Real type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2,arg3);
            }
            case enums::complex_scalar:
            {
                typedef Complex type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2,arg3);
            }
            case enums::object_scalar:
            {
                typedef Object type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2,arg3);
            }
            default:
                assertion(0,"invalid case");
                throw;
        };
    };		
};
template<class ret, class derived>
struct extract_type_switch_3<ret,derived,true>
{
    template<class c_type, class Arg1, class Arg2, class Arg3>
    static ret make(typename hide_type<c_type>::type ptr, Arg1 arg1, Arg2 arg2, Arg3 arg3)
    {
        switch(ptr.matrix_type())
        {
            case enums::integer_dense:
            {
                typedef raw::Matrix<Integer,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::real_dense:
            {
                typedef raw::Matrix<Real,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::complex_dense:
            {
                typedef raw::Matrix<Complex,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::object_dense:
            {
                typedef raw::Matrix<Object,struct_dense> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::integer_sparse:
            {
                typedef raw::Matrix<Integer,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::real_sparse:
            {
                typedef raw::Matrix<Real,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::complex_sparse:
            {
                typedef raw::Matrix<Complex,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::object_sparse:
            {
                typedef raw::Matrix<Object,struct_sparse> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::integer_band:
            {
                typedef raw::Matrix<Integer,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::real_band:
            {
                typedef raw::Matrix<Real,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::complex_band:
            {
                typedef raw::Matrix<Complex,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::object_band:
            {
                typedef raw::Matrix<Object,struct_banded> type;
                return derived::eval(ptr,ptr.get_impl<type>(),arg1,arg2,arg3);
            }
            case enums::integer_scalar:
            {
                typedef Integer type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2,arg3);
            }
            case enums::real_scalar:
            {
                typedef Real type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2,arg3);
            }
            case enums::complex_scalar:
            {
                typedef Complex type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2,arg3);
            }
            case enums::object_scalar:
            {
                typedef Object type;
                return derived::eval_scalar(ptr,ptr.get_scalar<type>(),arg1,arg2,arg3);
            }
            default:
                assertion(0,"invalid case");
                throw;
        };
    };		
};
template<class ret, class derived>
struct extract_type_switch_type
{
    template<class Arg1>
    static ret make(enums::mat_type mt,Arg1 arg1)
    {
        switch(mt)
        {
            case enums::integer_dense:
            {
                typedef raw::Matrix<Integer,struct_dense> type;
                return derived::eval<type>(arg1);
            }
            case enums::real_dense:
            {
                typedef raw::Matrix<Real,struct_dense> type;
                return derived::eval<type>(arg1);
            }
            case enums::complex_dense:
            {
                typedef raw::Matrix<Complex,struct_dense> type;
                return derived::eval<type>(arg1);
            }
            case enums::object_dense:
            {
                typedef raw::Matrix<Object,struct_dense> type;
                return derived::eval<type>(arg1);
            }
            case enums::integer_sparse:
            {
                typedef raw::Matrix<Integer,struct_sparse> type;
                return derived::eval<type>(arg1);
            }
            case enums::real_sparse:
            {
                typedef raw::Matrix<Real,struct_sparse> type;
                return derived::eval<type>(arg1);
            }
            case enums::complex_sparse:
            {
                typedef raw::Matrix<Complex,struct_sparse> type;
                return derived::eval<type>(arg1);
            }
            case enums::object_sparse:
            {
                typedef raw::Matrix<Object,struct_sparse> type;
                return derived::eval<type>(arg1);
            }
            case enums::integer_band:
            {
                typedef raw::Matrix<Integer,struct_banded> type;
                return derived::eval<type>(arg1);
            }
            case enums::real_band:
            {
                typedef raw::Matrix<Real,struct_banded> type;
                return derived::eval<type>(arg1);
            }
            case enums::complex_band:
            {
                typedef raw::Matrix<Complex,struct_banded> type;
                return derived::eval<type>(arg1);
            }
            case enums::object_band:
            {
                typedef raw::Matrix<Object,struct_banded> type;
                return derived::eval<type>(arg1);
            }
            case enums::integer_scalar:
            {
                typedef Integer type;
                return derived::eval_scalar<type>(arg1);
            }
            case enums::real_scalar:
            {
                typedef Real type;
                return derived::eval_scalar<type>(arg1);
            }
            case enums::complex_scalar:
            {
                typedef Complex type;
                return derived::eval_scalar<type>(arg1);
            }
            case enums::object_scalar:
            {
                typedef Object type;
                return derived::eval_scalar<type>(arg1);
            }
            default:
            {
                assertion(0,"invalid case");
                throw;
            }
        };
    };		
};
};};