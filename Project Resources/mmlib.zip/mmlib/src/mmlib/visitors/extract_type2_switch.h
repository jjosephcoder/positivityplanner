/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/mp/promote_type.h"
#include "mmlib/container/raw/type_decl.h"

namespace mmlib { namespace details
{

#define EXPAND_CASE_MAT(macro,arg)      \
    macro(enums::integer_dense,arg)     \
    macro(enums::real_dense,arg)        \
    macro(enums::complex_dense,arg)     \
    macro(enums::object_dense,arg)      \
    macro(enums::integer_sparse,arg)    \
    macro(enums::real_sparse,arg)       \
    macro(enums::complex_sparse,arg)    \
    macro(enums::object_sparse,arg)     \
    macro(enums::integer_band,arg)      \
    macro(enums::real_band,arg)         \
    macro(enums::complex_band,arg)      \
    macro(enums::object_band,arg)       

#define EXPAND_CASE_MAT_2(macro,arg)    \
    macro(enums::integer_dense,arg)     \
    macro(enums::real_dense,arg)        \
    macro(enums::complex_dense,arg)     \
    macro(enums::object_dense,arg)      \
    macro(enums::integer_sparse,arg)    \
    macro(enums::real_sparse,arg)       \
    macro(enums::complex_sparse,arg)    \
    macro(enums::object_sparse,arg)     \
    macro(enums::integer_band,arg)      \
    macro(enums::real_band,arg)         \
    macro(enums::complex_band,arg)      \
    macro(enums::object_band,arg)       

#define EXPAND_CASE_SCAL(macro,arg)     \
    macro(enums::integer_scalar,arg)    \
    macro(enums::real_scalar,arg)       \
    macro(enums::complex_scalar,arg)    \
    macro(enums::object_scalar,arg)     

#define EXPAND_CASE_SCAL_2(macro,arg)   \
    macro(enums::integer_scalar,arg)    \
    macro(enums::real_scalar,arg)       \
    macro(enums::complex_scalar,arg)    \
    macro(enums::object_scalar,arg)     

#define EXPAND_CASE_MAT_MAT_IMPL(code_2,code_1) \
    case code_1*N + code_2:                     \
    return make_mat_mat<code_to_type<code_1>::type,code_to_type<code_2>::type>(A,B,arg1);

#define EXPAND_CASE_MAT_SCAL_IMPL(code_2,code_1) \
    case code_1*N + code_2:                     \
    return make_mat_scal<code_to_type<code_1>::type,code_to_type<code_2>::type>(A,B,arg1);

#define EXPAND_CASE_SCAL_MAT_IMPL(code_2,code_1) \
    case code_1*N + code_2:                     \
    return make_scal_mat<code_to_type<code_1>::type,code_to_type<code_2>::type>(A,B,arg1);

#define EXPAND_CASE_SCAL_SCAL_IMPL(code_2,code_1) \
    case code_1*N + code_2:                     \
    return make_scal_scal<code_to_type<code_1>::type,code_to_type<code_2>::type>(A,B,arg1);

#define EXPAND_CASE_MAT_MAT_2(code_1,arg)       \
EXPAND_CASE_MAT_2(EXPAND_CASE_MAT_MAT_IMPL,code_1)    

#define EXPAND_CASE_MAT_SCAL_2(code_1,arg)       \
EXPAND_CASE_SCAL_2(EXPAND_CASE_MAT_SCAL_IMPL,code_1)    

#define EXPAND_CASE_SCAL_MAT_2(code_1,arg)       \
EXPAND_CASE_MAT_2(EXPAND_CASE_SCAL_MAT_IMPL,code_1)    

#define EXPAND_CASE_SCAL_SCAL_2(code_1,arg)       \
EXPAND_CASE_SCAL_2(EXPAND_CASE_SCAL_SCAL_IMPL,code_1)    


#define EXPAND_CASE_MAT_MAT             \
EXPAND_CASE_MAT(EXPAND_CASE_MAT_MAT_2,)     

#define EXPAND_CASE_MAT_SCAL             \
EXPAND_CASE_MAT(EXPAND_CASE_MAT_SCAL_2,)     

#define EXPAND_CASE_SCAL_MAT             \
EXPAND_CASE_SCAL(EXPAND_CASE_SCAL_MAT_2,)     

#define EXPAND_CASE_SCAL_SCAL             \
EXPAND_CASE_SCAL(EXPAND_CASE_SCAL_SCAL_2,)     

template<class ret, class derived,class T1, class T2,class Arg1>
struct extract_type2_switch_impl
{
    static ret eval_mat_mat(const T1& A, const T2& B, Arg1 arg)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);

		return derived::eval_mat_mat<MT1,MT2>(corrector::convert_1(out_ti,A),
                                              corrector::convert_2(out_ti,B),arg);
    };
    static ret eval_mat_scal(const T1& A, const T2& B, Arg1 arg)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);

		return derived::eval_mat_scal<MT1,MT2>(corrector::convert_1(out_ti,A),
                                              corrector::convert_2(out_ti,B),arg);
    };
    static ret eval_scal_mat(const T1& A, const T2& B, Arg1 arg)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);

		return derived::eval_scal_mat<MT1,MT2>(corrector::convert_1(out_ti,A),
                                              corrector::convert_2(out_ti,B),arg);
    };

    static ret eval_scal_scal(const T1& A, const T2& B, Arg1 arg)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);

		return derived::eval_scal_scal<MT1,MT2>(corrector::convert_1(out_ti,A),
                                              corrector::convert_2(out_ti,B),arg);
    };
};

template<class ret, class derived,bool iso,class T1, class T2,class Arg1>
struct extract_type2_switch_nc_impl
{
    static ret eval_mat_mat(Matrix& h, T1& A, const T2& B, Arg1 arg)
    {
		return derived::eval_mat_mat(h,A,B,arg);
    };
    static ret eval_mat_scal(Matrix& h, T1& A, const T2& B, Arg1 arg)
    {
        return derived::eval_mat_scal(h,A,B,arg);
    };
    static ret eval_scal_mat(Matrix& h, T1& A, const T2& B, Arg1 arg)
    {
        return derived::eval_scal_mat(h,A,B,arg);
    };

    static ret eval_scal_scal(Matrix& h, T1& A, const T2& B, Arg1 arg)
    {
        return derived::eval_scal_scal(h,A,B,arg);
    };
};
template<class ret, class derived,class T1, class T2,class Arg1>
struct extract_type2_switch_nc_impl<ret,derived,true,T1,T2,Arg1>
{
    static ret eval_mat_mat(Matrix& h, T1& A, const T2& B, Arg1 arg)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);
        h = corrector::convert_1(out_ti,A);

		return derived::eval_mat_mat<MT1,MT2>(h,h.get_impl_unique<MT1>(),
                                              corrector::convert_2(out_ti,B),arg);
    };
    static ret eval_mat_scal(Matrix& h, T1& A, const T2& B, Arg1 arg)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);
        h = corrector::convert_1(out_ti,A);

		return derived::eval_mat_scal<MT1,MT2>(h,h.get_impl_unique<MT1>(),
                                              corrector::convert_2(out_ti,B),arg);
    };
    static ret eval_scal_mat(Matrix& h, T1& A, const T2& B, Arg1 arg)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);
        h = corrector::convert_1(out_ti,A);

		return derived::eval_scal_mat<MT1,MT2>(h,h.get_scalar_unique<MT1>(),
                                              corrector::convert_2(out_ti,B),arg);
    };
    static ret eval_scal_scal(Matrix& h, T1& A, const T2& B, Arg1 arg)
    {
        typedef mmlib::raw::val_type_corrector<T1,T2> corrector;
        typedef typename corrector::type_1 MT1;
        typedef typename corrector::type_2 MT2;

        type_info out_ti = return_ti<T1,T2>::eval(A,B);
        h = corrector::convert_1(out_ti,A);

		return derived::eval_scal_scal<MT1,MT2>(h,h.get_scalar_unique<MT1>(),
                                              corrector::convert_2(out_ti,B),arg);
    };
};

template<class ret, class derived, class Arg1>
struct extract_type2_switch
{
    static ret make(const Matrix& A, const Matrix& B, Arg1 arg1)
    {
        static const size_t N = macro_last_matrix_type_code+1;
        int code = A.matrix_type()*N + B.matrix_type();
        switch(code)
        {
            EXPAND_CASE_MAT_MAT
            EXPAND_CASE_MAT_SCAL
            EXPAND_CASE_SCAL_MAT
            EXPAND_CASE_SCAL_SCAL
            default:
                assertion(0,"unknown case");
                throw;
        };
    };		
    template<class T1, class T2>
    static ret make_mat_mat(const Matrix& A, const Matrix& B, Arg1 arg)
    {
        return extract_type2_switch_impl<ret,derived,T1,T2,Arg1>
            ::eval_mat_mat(A.get_impl<T1>(),B.get_impl<T2>(),arg);
    };
    template<class T1, class T2>
    static ret make_mat_scal(const Matrix& A, const Matrix& B, Arg1 arg)
    {
        return extract_type2_switch_impl<ret,derived,T1,T2,Arg1>
            ::eval_mat_scal(A.get_impl<T1>(),B.get_scalar<T2>(),arg);
    };
    template<class T1, class T2>
    static ret make_scal_mat(const Matrix& A, const Matrix& B, Arg1 arg)
    {
        return extract_type2_switch_impl<ret,derived,T1,T2,Arg1>
            ::eval_scal_mat(A.get_scalar<T1>(),B.get_impl<T2>(),arg);
    };
    template<class T1, class T2>
    static ret make_scal_scal(const Matrix& A, const Matrix& B, Arg1 arg)
    {
        return extract_type2_switch_impl<ret,derived,T1,T2,Arg1>
            ::eval_scal_scal(A.get_scalar<T1>(),B.get_scalar<T2>(),arg);
    };
};

template<class T>
struct is_object
{
    static const bool value = is_equal<T,Object>::value;
};
template<class V,class S>
struct is_object<raw::Matrix<V,S>>
{
    static const bool value = is_equal<V,Object>::value;
};

template<class ret, class derived, class Arg1>
struct extract_type2_switch_nc
{
    static ret make(Matrix& A, const Matrix& B, Arg1 arg1)
    {
        static const size_t N = macro_last_matrix_type_code+1;
        int code = A.matrix_type()*N + B.matrix_type();
        switch(code)
        {
            EXPAND_CASE_MAT_MAT
            EXPAND_CASE_MAT_SCAL
            EXPAND_CASE_SCAL_MAT
            EXPAND_CASE_SCAL_SCAL
            default:
                assertion(0,"unknown case");
                throw;
        };
    };		
    template<class T1, class T2>
    static ret make_mat_mat(Matrix& A, const Matrix& B, Arg1 arg)
    {
        static const bool iso = is_object<T1>::value || is_object<T2>::value;
        return extract_type2_switch_nc_impl<ret,derived,iso,T1,T2,Arg1>
            ::eval_mat_mat(A,A.get_impl_unique<T1>(),B.get_impl<T2>(),arg);
    };
    template<class T1, class T2>
    static ret make_mat_scal(Matrix& A, const Matrix& B, Arg1 arg)
    {
        static const bool iso = is_object<T1>::value || is_object<T2>::value;
        return extract_type2_switch_nc_impl<ret,derived,iso,T1,T2,Arg1>
            ::eval_mat_scal(A,A.get_impl_unique<T1>(),B.get_scalar<T2>(),arg);
    };
    template<class T1, class T2>
    static ret make_scal_mat(Matrix& A, const Matrix& B, Arg1 arg)
    {
        static const bool iso = is_object<T1>::value || is_object<T2>::value;
        return extract_type2_switch_nc_impl<ret,derived,iso,T1,T2,Arg1>
            ::eval_scal_mat(A,A.get_scalar_unique<T1>(),B.get_impl<T2>(),arg);
    };
    template<class T1, class T2>
    static ret make_scal_scal(Matrix& A, const Matrix& B, Arg1 arg)
    {
        static const bool iso = is_object<T1>::value || is_object<T2>::value;
        return extract_type2_switch_nc_impl<ret,derived,iso,T1,T2,Arg1>
            ::eval_scal_scal(A,A.get_scalar_unique<T1>(),B.get_scalar<T2>(),arg);
    };
};

};};