/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "test_set.h"
#include <vector>
#include "mmlib/mmlib_header.h"
#include "data_struct/logger.h"
#include "data_struct/options.h"
#include "test_functions/assign_functions_list.h"
#include "matrix_set/matrix_set_1.h"
#include "matrix_set/colon_set.h"


namespace mmlib { namespace test
{

class test_assign
{
	assign_functions_list&			tf;
	const test::options&			opts;

	public:
		test_assign(assign_functions_list& tf, const test::options& opts)
			:tf(tf),opts(opts)
		{
		};
		test_assign(const test_assign& ta)
			:tf(ta.tf),opts(ta.opts)
		{
		};

		void make()
		{
			//Matrix mat = tf.get_matrix(opts.first_matrix_code);
            Matrix mat = tf.get_matrix(121);

            /*
            try
			{
                Real dif		= 0;
                disp(full(mat));

                Integer d = 1;
		        Matrix mf = full(mat);
		        mf.diag(d) = 1;

                Matrix mf1		= full(mat);
		        Matrix mf2		= full(mat);
		        Matrix mf3		= full(mat);

		        mf1.diag(d)		= Integer(1);
		        mf2.diag(d)		= Real(1);
		        mf3.diag(d)		= Complex(1);

		        Matrix out1		= mat;
		        Matrix out2		= mat;
		        Matrix out3		= mat;

		        out1.diag(d)	= Integer(1);
		        out2.diag(d)	= Real(1);
		        out3.diag(d)	= Complex(1);

                disp(out1);

                out1.check_struct();
                out2.check_struct();
                out3.check_struct();

		        Real dif		= 0;
		        dif				+= norm_1(out1 - mf1);
		        dif				+= norm_1(out2 - mf2);
		        dif				+= norm_1(out3 - mf3);

		        dif				+= norm_1(out1.diag(d)-1);
		        dif				+= norm_1(out2.diag(d)-1);
		        dif				+= norm_1(out3.diag(d)-1);
			}
            catch(...)
            {};
            */

			tf.make(opts);
		};
		void operator()()
		{
			make();
		};

	private:		
		test_assign& operator=(const test_assign&);
};
void test::test_assign_st(rand_matrix_ptr rand)
{
	test::options opts;

	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = true;

		mat_set_1 ms1(rand);
		dynamic_mat_set ms(rand);
		assign_functions_list tf(ms1,ms);

		test_assign ta(tf,opts);
		ta.make();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};

void test::test_assign_mt(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = false;

		mat_set_2 ms1(rand);
		dynamic_mat_set ms(rand);
		assign_functions_list tf(ms1,ms);

		boost::thread_group tg;

		for (int i = 0; i < 10; i++)
		{
			tg.create_thread(test_assign(tf,opts));
		};

		tg.join_all();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};



};}