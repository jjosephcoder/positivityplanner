/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "test_set.h"
#include <vector>
#include "mmlib/mmlib_header.h"
#include "data_struct/logger.h"
#include "data_struct/options.h"

namespace mmlib { namespace test
{

class test_thread_cl
{
	private:
		const std::vector<Matrix>& mat_vec;
		const std::vector<Matrix>& mat_val;

	public:
		test_thread_cl(const std::vector<Matrix>& mat, const std::vector<Matrix>& val)	
			: mat_vec(mat), mat_val(val) {} ;
		test_thread_cl(const test_thread_cl& other)		
			: mat_vec(other.mat_vec), mat_val(other.mat_val) {};

		void make()
		{
			for (int i = 0; i < 10000; i++)
			{
				Integer pos = abs(irand())%mat_vec.size();			
				Matrix tmp = mat_vec[pos];
				make(tmp,100);
				Matrix out = sum(sum(tmp,1),2);
				Real diff = norm_1(out - mat_val[pos]);

				if (diff != 0.)
				{
					test::logger() << std::string() + "test_thread_cl: FAILED"  + "\n";
				};
			};
		};

		void operator()()
		{
			make();
		};
	private:
		void make(Matrix tmp, int n)
		{
			if (n > 0)
			{
				Matrix tmp2 = tmp;
				make(tmp2,n-1);
			};
		};
		test_thread_cl& operator=(const test_thread_cl&);

};


void test::test_thread()
{
	test::options opts;
	try
	{

		boost::thread_group tg;

		std::vector<Matrix> mat_vec(3);
		std::vector<Matrix> mat_val(3);
		for (int i = 0; i < 3; i++)
		{
			mat_vec[i] = randn(4,4);
			mat_val[i] = sum(sum(mat_vec[i],1),2);
		};

		for (int i = 0; i < 20; i++)
		{
			tg.create_thread(test_thread_cl(mat_vec,mat_val));
		};

		tg.join_all();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};

};};
