/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "test_set.h"
#include <vector>
#include "mmlib/mmlib_header.h"
#include "data_struct/logger.h"
#include "data_struct/options.h"
#include "test_functions/io_functions_list.h"
#include "matrix_set/matrix_set_bin_1.h"
#include "mmlib/archive.h"

namespace mmlib { namespace test
{

class test_io
{
	io_functions_list&			    tf;
	const test::options&			opts;

	public:
		test_io(io_functions_list& tf, const test::options& opts)
			:tf(tf),opts(opts)
		{
		};
		test_io(const test_io& ta)
			:tf(ta.tf),opts(ta.opts)
		{
		};

		void make()
		{
			typedef test::matrix_set_bin::matrix_pair matrix_pair;
			typedef test::matrix_set_bin::scalar_pair scalar_pair;

			matrix_pair mp = tf.get_matrix(0);
			tf.make(opts);
		};
		void operator()()
		{
			make();
		};

	private:		
		test_io& operator=(const test_io&);
};
void test::test_io_st(rand_matrix_ptr rand)
{
	test::options opts;

	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = true;

		mat_set_bin_1 ms1(rand);
		io_functions_list tf(ms1);

		test_io ta(tf,opts);
		ta.make();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};

void test::test_io_mt(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = false;

		mat_set_bin_2 ms1(rand);
		io_functions_list tf(ms1);

		boost::thread_group tg;

		for (int i = 0; i < 10; i++)
		{
			tg.create_thread(test_io(tf,opts));
		};

		tg.join_all();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};



};}