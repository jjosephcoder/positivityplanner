/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "test_set.h"
#include "mmlib/details/refcount.h"
#include <iostream>

namespace mmlib { namespace test
{

void test::test_all(rand_matrix_ptr rand)
{
    long N = 0;

	test::test_unary_st(rand);      N = details::no_existing_objects(); 
	test::test_unary_mt(rand);      N = details::no_existing_objects();

	test::test_bin_st(rand);        N = details::no_existing_objects();
	test::test_bin_mt(rand);        N = details::no_existing_objects();

    test::test_mult_st(rand);       N = details::no_existing_objects();
    test::test_mult_mt(rand);       N = details::no_existing_objects();
	test::test_kron_st(rand);       N = details::no_existing_objects();
    test::test_kron_mt(rand);       N = details::no_existing_objects();

	test::test_assign_st(rand);     N = details::no_existing_objects();
	test::test_assign_mt(rand);     N = details::no_existing_objects();

	test::test_io_st(rand);         N = details::no_existing_objects();
	test::test_io_mt(rand);         N = details::no_existing_objects();

    test::test_thread();    

	//test::test_linalg_st(rand);       N = details::no_existing_objects();    
	//test::test_linalg_mt(rand);       N = details::no_existing_objects();	
};

};};