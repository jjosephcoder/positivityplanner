/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "test_set.h"
#include <vector>
#include "mmlib/mmlib_header.h"
#include "data_struct/logger.h"
#include "data_struct/options.h"
#include "test_functions/unary_functions_list.h"
#include "matrix_set/matrix_set_1.h"

namespace mmlib { namespace test
{

class test_unary
{
	unary_functions_list&		tf;
	const test::options&		opts;

	public:
		test_unary(unary_functions_list& tf, const test::options& opts)
			:tf(tf),opts(opts)
		{
		};
		test_unary(const test_unary& tu)
			:tf(tu.tf),opts(tu.opts)
		{
		};

		void make()
		{
            Matrix mat = tf.get_matrix(102);
			tf.make(opts);
		};
		void operator()()
		{
			make();
		};

	private:		
		test_unary& operator=(const test_unary&);
};

void test::test_unary_st(rand_matrix_ptr rand)
{
	test::options opts;

	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = true;

		test::mat_set_1 ms1(rand);
		unary_functions_list tf(ms1,rand);
		
		test_unary tu(tf,opts);
		tu.make();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};

void test::test_unary_mt(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = false;

		test::mat_set_2 ms1(rand);
		unary_functions_list tf(ms1,rand);

		boost::thread_group tg;

		for (int i = 0; i < 10; i++)
		{
			tg.create_thread(test_unary(tf,opts));
		};

		tg.join_all();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};


};};