/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "test_set.h"
#include <vector>
#include "gmpp/gmpp_header.h"
#include "test/data_struct/logger.h"
#include "test/data_struct/options.h"
#include "test/test_functions/linalg_functions_list.h"
#include "test/matrix_set/matrix_set_1.h"
#include "gmpp/linalg.h"

namespace gmpp { namespace test
{

class test_linalg
{
	linalg_functions_list&		tf;
	const test::options&		opts;

	public:
		test_linalg(linalg_functions_list& tf, const test::options& opts)
			:tf(tf),opts(opts)
		{
		};
		test_linalg(const test_linalg& tu)
			:tf(tu.tf),opts(tu.opts)
		{
		};

		void make()
		{
            Matrix mat = tf.get_matrix(opts.first_matrix_code);
			tf.make(opts);
		};
		void operator()()
		{
			make();
		};

	private:		
		test_linalg& operator=(const test_linalg&);
};


void test::test_linalg_st(rand_matrix_ptr rand)
{
	test::options opts;

	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = true;

		test::mat_set_1 ms1(rand);
		linalg_functions_list tf(ms1);
		
		test_linalg tu(tf,opts);
		tu.make();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};

void test::test_linalg_mt(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = false;

		test::mat_set_2 ms1(rand);
		linalg_functions_list tf(ms1);

		boost::thread_group tg;

		for (int i = 0; i < 10; i++)
		{
			tg.create_thread(test_linalg(tf,opts));
		};

		tg.join_all();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};


};};