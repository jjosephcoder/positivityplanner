/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "test_set.h"
#include <vector>
#include "mmlib/mmlib_header.h"
#include "data_struct/logger.h"
#include "data_struct/options.h"
#include "test_functions/bin_functions_list.h"
#include "matrix_set/matrix_set_bin_1.h"

namespace mmlib { namespace test
{

class test_binary
{
	bin_functions_list&				tf;
	const test::options&			opts;

	public:
		test_binary(bin_functions_list& tf, const test::options& opts)
			:tf(tf),opts(opts)
		{};
		test_binary(const test_binary& tb)
			:tf(tb.tf),opts(tb.opts)
		{
		};

		void make()
		{
			typedef test::matrix_set_bin::matrix_pair matrix_pair;
			typedef test::matrix_set_bin::scalar_pair scalar_pair;

			//matrix_pair mp = tf.get_matrix(opts.first_matrix_code);
            matrix_pair mp = tf.get_matrix(2776);

            /*
			{
				Matrix mat1 = mp.first;
				Matrix mat2 = mp.second;

                disp(mat1);
                disp(mat2);

	            Matrix out_full = atan2(full(mat1),full(mat2));	
		        Matrix out		= atan2(mat1,mat2);
                out.check_struct();

                disp(out);
                disp(out_full);

		        Real dif		= norm_1(out - out_full);
			};
            */

			tf.make(opts);
		};
		template<class T1,class T2>
		void eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(mmlib::rem(a,b) - mmlib::rem(full(a),full(b)));;
			disp(mmlib::rem(to_real(a),b));
			disp(mmlib::rem(Complex(a),(b)));
			dif			+=norm_1(mmlib::rem(to_real(a),b) - mmlib::rem(Complex(a),(b)));;
			dif			+=norm_1(mmlib::rem(a,to_real(b)) - mmlib::rem((a),Complex(b)));;
			dif			+=norm_1(mmlib::rem(to_real(a),to_real(b)) - mmlib::rem(Complex(a),Complex(b)));;
			return;
		};

		void operator()()
		{
			make();
		};

	private:		
		test_binary& operator=(const test_binary&);
};
class test_mult
{
	bin_functions_list&				tf;
	const test::options&			opts;

	public:
		test_mult(bin_functions_list& tf, const test::options& opts)
			:tf(tf),opts(opts)
		{};
		test_mult(const test_mult& tb)
			:tf(tb.tf),opts(tb.opts)
		{
		};

		void make()
		{
			typedef test::matrix_set_bin::matrix_pair matrix_pair;
			//matrix_pair mp = tf.get_matrix(opts.first_matrix_code);
            matrix_pair mp = tf.get_matrix(9021);

            /*
			{
				Matrix mat1 = mp.first;
				Matrix mat2 = mp.second;

                disp(mat1);
                disp(mat2);

	            Matrix out_full = full(mat1) * full(mat2);	
		        Matrix out		= mat1 * mat2;

                disp(out_full);
                disp(out);
                
                out.check_struct();

		        Real dif		= norm_1(out - out_full);
                dif             = dif/(norm_1(out)+1e-15);
			};
            */

			tf.make_mult(opts);
		};
		void operator()()
		{
			make();
		};

	private:		
		test_mult& operator=(const test_mult&);
};
class test_kron
{
	bin_functions_list&				tf;
	const test::options&			opts;

	public:
		test_kron(bin_functions_list& tf, const test::options& opts)
			:tf(tf),opts(opts)
		{};
		test_kron(const test_kron& tb)
			:tf(tb.tf),opts(tb.opts)
		{
		};

		void make()
		{
			typedef test::matrix_set_bin::matrix_pair matrix_pair;
			matrix_pair mp = tf.get_matrix(opts.first_matrix_code);

			{
				Matrix mat1 = mp.first;
				Matrix mat2 = mp.second;
			};

			tf.make_kron(opts);
		};
		void operator()()
		{
			make();
		};

	private:		
		test_kron& operator=(const test_kron&);
};

void test::test_bin_st(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = false;
		opts.first_matrix_code = 0;
        opts.show_memleaks = true;

		test::mat_set_bin_1 ms(rand);
		bin_functions_list tf(ms,rand->is_nan_allowed());

		test_binary tbin (tf,opts);

		tbin.make();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};
void test::test_bin_mt(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = false;

		test::mat_set_bin_2 ms1(rand);
		bin_functions_list tf(ms1,rand->is_nan_allowed());

		boost::thread_group tg;

		for (int i = 0; i < 20; i++)
		{
			tg.create_thread(test_binary(tf,opts));
		};

		tg.join_all();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};

void test::test_mult_st(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = false;
		opts.first_matrix_code = 0;
        opts.show_memleaks = true;

		test::mat_set_bin_mult_1 ms(rand);
		bin_functions_list tf(ms,rand->is_nan_allowed());

		test_mult tbin (tf,opts);

		tbin.make();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};
void test::test_mult_mt(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = false;

		test::mat_set_bin_mult_2 ms1(rand);
		bin_functions_list tf(ms1,rand->is_nan_allowed());

		boost::thread_group tg;

		for (int i = 0; i < 20; i++)
		{
			tg.create_thread(test_mult(tf,opts));
		};

		tg.join_all();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};

void test::test_kron_st(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = false;
		opts.first_matrix_code = 0;
        opts.show_memleaks = true;

		test::mat_set_bin_kron_1 ms(rand);
		bin_functions_list tf(ms,rand->is_nan_allowed());

		test_kron tbin (tf,opts);

		tbin.make();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};
void test::test_kron_mt(rand_matrix_ptr rand)
{
	test::options opts;
	try
	{
		opts.show_partial_res = 0;
		opts.first_matrix_code = 0;
        opts.show_memleaks = false;

		test::mat_set_bin_kron_2 ms1(rand);
		bin_functions_list tf(ms1,rand->is_nan_allowed());

		boost::thread_group tg;

		for (int i = 0; i < 20; i++)
		{
			tg.create_thread(test_kron(tf,opts));
		};

		tg.join_all();
	}
	catch(const std::exception& ex)
	{
		test::logger() <<ex.what();
	};
};


};};