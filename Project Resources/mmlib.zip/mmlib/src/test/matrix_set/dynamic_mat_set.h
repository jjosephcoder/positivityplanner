/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "test_functions/unary_function.h"
#include "test_functions/bin_function.h"
#include "data_struct/options.h"
#include "matrix_set/matrix_rand.h"

#include <vector>
#include <map>

#pragma warning( push )
#pragma warning(disable:4244)	//  conversion from 'int' to 'unsigned short', possible loss of data
#include <boost/thread/mutex.hpp>
#pragma warning( pop )

namespace mmlib { namespace test
{

class dynamic_mat_set
{
	public:
		typedef std::vector<Matrix>			container;
		typedef std::pair<Integer,Integer>	index;
		typedef std::map<index,container>	cont_mat;
		typedef boost::mutex::scoped_lock	scoped_lock;

	private:
		cont_mat		m_map;
		boost::mutex	m_mutex;
        rand_matrix_ptr m_rand;

		void    insert(Integer r, Integer c,container& mc);
		void    add_matrices_band(container& mat, Integer m, Integer n, Integer ld, Integer ud);
        void    add_matrices_dense(container& mat, Integer m, Integer n);
        void    add_matrices_sparse(container& mat, Integer m, Integer n, Real d);
        Matrix  rand_dense(Integer r, Integer c);
        Matrix  rand_sparse(Integer r, Integer c);
        Matrix  rand_band(Integer r, Integer c);

	public:
        dynamic_mat_set(rand_matrix_ptr rand)   : m_rand(rand) {};

		const container&		get(Integer s);
		const container&		get(Integer r,Integer c);
        Matrix                  rand(Integer r, Integer c, Integer seed);
		void					clear();
};

};};