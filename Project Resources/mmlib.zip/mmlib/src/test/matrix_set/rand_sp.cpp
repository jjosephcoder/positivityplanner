/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "rand_sp.h"
#include "mmlib/container/raw/type_decl.h"


namespace mmlib { namespace test
{
Integer test::irandn_sp(bool)
{
	Integer val = abs(irand())%7;
	switch (val)
	{
		case 1:
			return 1;
		case 2:
			return -1;
		case 3:
			return 2;
		case 4:
			return -2;
        case 5:
            return -2000;
        case 6:
            return 2000;
		default:
			return 0;
	};
};
Real test::randn_sp(bool with_nan, bool with_inf)
{
	Integer val = abs(irand())%10;
	switch (val)
	{
		case 1:
			return 1.;
		case 2:
			return -1.;
		case 3:
			return 2.;
		case 4:
			return -2.;
		case 5:
            if (with_inf)
			    return constants::Inf;
            else
                return 0;
		case 6:
            if (with_inf)
			    return -constants::Inf;
            else
                return 0;
		case 7:
		{
			if (with_nan)
			{
				return constants::NaN;
			}
			else
			{
				return 0;
			};
		}
        case 8:
            if (with_inf)
                return 1.11e8;
            else
                return 1.11e2;
        case 9:
            if (with_inf)
                return -1.11e8;
            else
                return -1.11e2;
		default:
			return 0;
	};
};
Matrix test::randn_sp(Integer m, Integer n,bool with_nan, bool with_inf)
{
	Matrix out = UninitializedRealMatrix(m,n);
	Real* ptr = out.get_array_unique<Real>();
	for (Integer i = 0; i <m*n; i++)
	{
		ptr[i] = randn_sp(with_nan,with_inf);
	};
	return out;
};
Matrix	test::crandn_sp(Integer m, Integer n,bool with_nan)
{
	Matrix out = UninitializedComplexMatrix(m,n);
	Complex* ptr = out.get_array_unique<Complex>();
	for (Integer i = 0; i <m*n; i++)
	{
		ptr[i] = Complex(randn_sp(with_nan),randn_sp(with_nan));
	};
	return out;
};

Matrix	test::sprandn_sp(Integer m, Integer n, Real d,bool with_nan, bool with_inf)
{
	Matrix out = sparse(sprandn(m,n,d));
    Real* ptr = out.get_impl_unique<raw::RealSparseMatrix>().rep().ptr_x();

	for (Integer i = 0; i < out.nnz(); i++)
	{
		ptr[i] = randn_sp(with_nan,with_inf);
	};
	return out;
};

Matrix	test::csprandn_sp(Integer m, Integer n, Real d,bool with_nan)
{
	Matrix out = sparse(csprandn(m,n,d));
	Complex* ptr = out.get_impl_unique<raw::ComplexSparseMatrix>().rep().ptr_x();
	for (Integer i = 0; i < out.nnz(); i++)
	{
		ptr[i] = Complex(randn_sp(with_nan),randn_sp(with_nan));
	};
	return out;
};

Matrix	test::randn_band_sp(Integer m, Integer n, Integer ld, Integer ud,bool with_nan, bool with_inf)
{
	Matrix out = UninitializedRealBandMatrix(m,n,ld,ud);
	Real* ptr = out.get_impl_unique<raw::RealBandMatrix>().rep_ptr();
    Integer size = out.get_impl<raw::RealBandMatrix>().size();
	for (Integer i = 0; i < size; i++)
	{
		ptr[i] = randn_sp(with_nan,with_inf);
	};
	return out;
};

Matrix	test::crandn_band_sp(Integer m, Integer n, Integer ld, Integer ud,bool with_nan)
{
	Matrix out = UninitializedComplexBandMatrix(m,n,ld,ud);
	Complex* ptr = out.get_impl_unique<raw::ComplexBandMatrix>().rep_ptr();
    Integer size = out.get_impl<raw::ComplexBandMatrix>().size();
	for (Integer i = 0; i < size; i++)
	{
		ptr[i] = Complex(randn_sp(with_nan),randn_sp(with_nan));
	};
	return out;
};

};};