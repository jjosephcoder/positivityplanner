/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <boost/shared_ptr.hpp>
#include "mmlib/mmlib_header.h"

namespace mmlib { namespace test
{

class rand_matrix
{
    public:
        virtual ~rand_matrix() {};

        virtual Integer         rand_scalar_int() = 0;
        virtual Real            rand_scalar_real() = 0;
        virtual Complex         rand_scalar_compl() = 0;
        virtual mmlib::Matrix    rand_dense_int(Integer m,Integer n) = 0;
        virtual mmlib::Matrix    rand_dense_real(Integer m,Integer n) = 0;
        virtual mmlib::Matrix    rand_dense_compl(Integer m,Integer n) = 0;
        virtual mmlib::Matrix    rand_sparse_int(Integer m,Integer n, Real d) = 0;
        virtual mmlib::Matrix    rand_sparse_real(Integer m,Integer n, Real d) = 0;
        virtual mmlib::Matrix    rand_sparse_compl(Integer m,Integer n, Real d) = 0;
        virtual mmlib::Matrix    rand_band_int(Integer m,Integer n, Integer ld, Integer ud) = 0;
        virtual mmlib::Matrix    rand_band_real(Integer m,Integer n, Integer ld, Integer ud) = 0;
        virtual mmlib::Matrix    rand_band_compl(Integer m,Integer n, Integer ld, Integer ud) = 0;
        virtual bool            is_nan_allowed() const = 0;
};

typedef boost::shared_ptr<rand_matrix> rand_matrix_ptr;


class rand_matrix_1 : public rand_matrix
{
    public:
        virtual Integer         rand_scalar_int();
        virtual Real            rand_scalar_real();
        virtual Complex         rand_scalar_compl();
        virtual mmlib::Matrix    rand_dense_int(Integer m,Integer n);
        virtual mmlib::Matrix    rand_dense_real(Integer m,Integer n);
        virtual mmlib::Matrix    rand_dense_compl(Integer m,Integer n);
        virtual mmlib::Matrix    rand_sparse_int(Integer m,Integer n, Real d);
        virtual mmlib::Matrix    rand_sparse_real(Integer m,Integer n, Real d);
        virtual mmlib::Matrix    rand_sparse_compl(Integer m,Integer n, Real d);
        virtual mmlib::Matrix    rand_band_int(Integer m,Integer n, Integer ld, Integer ud);
        virtual mmlib::Matrix    rand_band_real(Integer m,Integer n, Integer ld, Integer ud);
        virtual mmlib::Matrix    rand_band_compl(Integer m,Integer n, Integer ld, Integer ud);

        virtual bool is_nan_allowed() const
        {
            return false;
        };
};

class rand_matrix_1_sp : public rand_matrix
{
    private:
        bool with_nan;

    public:
        rand_matrix_1_sp(bool with_nan);

        virtual Integer         rand_scalar_int();
        virtual Real            rand_scalar_real();
        virtual Complex         rand_scalar_compl();
        virtual mmlib::Matrix    rand_dense_int(Integer m,Integer n);
        virtual mmlib::Matrix    rand_dense_real(Integer m,Integer n);
        virtual mmlib::Matrix    rand_dense_compl(Integer m,Integer n);
        virtual mmlib::Matrix    rand_sparse_int(Integer m,Integer n, Real d);
        virtual mmlib::Matrix    rand_sparse_real(Integer m,Integer n, Real d);
        virtual mmlib::Matrix    rand_sparse_compl(Integer m,Integer n, Real d);
        virtual mmlib::Matrix    rand_band_int(Integer m,Integer n, Integer ld, Integer ud);
        virtual mmlib::Matrix    rand_band_real(Integer m,Integer n, Integer ld, Integer ud);
        virtual mmlib::Matrix    rand_band_compl(Integer m,Integer n, Integer ld, Integer ud);

        virtual bool is_nan_allowed() const
        {
            return with_nan;
        };
};

class rand_matrix_1_str : public rand_matrix
{
    public:
        rand_matrix_1_str();

        virtual Integer         rand_scalar_int();
        virtual Real            rand_scalar_real();
        virtual Complex         rand_scalar_compl();
        virtual mmlib::Matrix    rand_dense_int(Integer m,Integer n);
        virtual mmlib::Matrix    rand_dense_real(Integer m,Integer n);
        virtual mmlib::Matrix    rand_dense_compl(Integer m,Integer n);
        virtual mmlib::Matrix    rand_sparse_int(Integer m,Integer n, Real d);
        virtual mmlib::Matrix    rand_sparse_real(Integer m,Integer n, Real d);
        virtual mmlib::Matrix    rand_sparse_compl(Integer m,Integer n, Real d);
        virtual mmlib::Matrix    rand_band_int(Integer m,Integer n, Integer ld, Integer ud);
        virtual mmlib::Matrix    rand_band_real(Integer m,Integer n, Integer ld, Integer ud);
        virtual mmlib::Matrix    rand_band_compl(Integer m,Integer n, Integer ld, Integer ud);

        virtual bool is_nan_allowed() const
        {
            return false;
        };
};

};};

