/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "colon_set.h"

namespace mmlib { namespace test
{

colon_set::colon_set()
{
	init();
};
int colon_set::size() const
{
	return (int)m_colons.size();
};
const colon& colon_set::get(int pos) const
{
	return m_colons[pos];
};
void colon_set::init()
{
	m_colons.push_back(colon());
	m_colons.push_back(colon(3));
	m_colons.push_back(colon(2,4));
	m_colons.push_back(colon(4,2));
	m_colons.push_back(colon(1,2,4));
	m_colons.push_back(colon(3,-1,1));
	m_colons.push_back(colon(4,-2,1));
    m_colons.push_back(colon(2,8,23));
    m_colons.push_back(colon(23,-8,2));

	m_colons.push_back(colon((mat_row(), 3, 1, 2)));
	m_colons.push_back(colon((mat_row(), 1, 2, 2, 3)));
	m_colons.push_back(colon((mat_row(), 3, 2, 2, 1)));
	m_colons.push_back(colon((mat_row(), 3, 1, 2, 3)));
    m_colons.push_back(colon((mat_row(), 1, 2, 22)));
    m_colons.push_back(colon((mat_row(), 2, 1, 22)));
    m_colons.push_back(colon((mat_row(), 22, 2, 1)));

};

};};