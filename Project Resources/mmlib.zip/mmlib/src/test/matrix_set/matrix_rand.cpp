/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "matrix_rand.h"
#include "rand_sp.h"
#include "rand_str.h"

namespace mmlib { namespace test
{

static Integer max_int = 1000;

//======================================================================
//                      rand_matrix_1
//======================================================================
Integer rand_matrix_1::rand_scalar_int()
{
    return irand()%max_int;
};

Real rand_matrix_1::rand_scalar_real()
{
    return randn();
};

Complex rand_matrix_1::rand_scalar_compl()
{
    return Complex(randn(),randn());
};

mmlib::Matrix rand_matrix_1::rand_dense_int(Integer m,Integer n)
{
    return iround(max_int*randn(m,n));
};

mmlib::Matrix rand_matrix_1::rand_dense_real(Integer m,Integer n)
{
    return randn(m,n);
};
mmlib::Matrix rand_matrix_1::rand_dense_compl(Integer m,Integer n)
{
    return crandn(m,n);
};
mmlib::Matrix rand_matrix_1::rand_sparse_int(Integer m,Integer n, Real d)
{
    Matrix tmp = sprandn(m,n,d);
    return iround(max_int*tmp);
};
mmlib::Matrix rand_matrix_1::rand_sparse_real(Integer m,Integer n, Real d)
{
    return sprandn(m,n,d);
};
mmlib::Matrix rand_matrix_1::rand_sparse_compl(Integer m,Integer n, Real d)
{
    return csprandn(m,n,d);
};
mmlib::Matrix rand_matrix_1::rand_band_int(Integer m,Integer n, Integer ld, Integer ud)
{
    return iround(max_int*randn_band(m,n,ld,ud));
};
mmlib::Matrix rand_matrix_1::rand_band_real(Integer m,Integer n, Integer ld, Integer ud)
{
    return randn_band(m,n,ld,ud);
};
mmlib::Matrix rand_matrix_1::rand_band_compl(Integer m,Integer n, Integer ld, Integer ud)
{
    return crandn_band(m,n,ld,ud);
};


//======================================================================
//                      rand_matrix_1_sp
//======================================================================
rand_matrix_1_sp::rand_matrix_1_sp(bool with_nan)
:with_nan(with_nan)
{};

Integer rand_matrix_1_sp::rand_scalar_int()
{
    return irandn_sp(with_nan);
};

Real rand_matrix_1_sp::rand_scalar_real()
{
    return randn_sp(with_nan);
};

Complex rand_matrix_1_sp::rand_scalar_compl()
{
    return Complex(randn_sp(with_nan),randn_sp(with_nan));
};

mmlib::Matrix rand_matrix_1_sp::rand_dense_int(Integer m,Integer n)
{
    return iround(max_int*randn_sp(m,n,false,false));
};

mmlib::Matrix rand_matrix_1_sp::rand_dense_real(Integer m,Integer n)
{
    return randn_sp(m,n,with_nan);
};
mmlib::Matrix rand_matrix_1_sp::rand_dense_compl(Integer m,Integer n)
{
    return crandn_sp(m,n,with_nan);
};
mmlib::Matrix rand_matrix_1_sp::rand_sparse_int(Integer m,Integer n, Real d)
{
    return iround(max_int*sprandn_sp(m,n,d,false,false));
};
mmlib::Matrix rand_matrix_1_sp::rand_sparse_real(Integer m,Integer n, Real d)
{
    return sprandn_sp(m,n,d,with_nan);
};
mmlib::Matrix rand_matrix_1_sp::rand_sparse_compl(Integer m,Integer n, Real d)
{
    return csprandn_sp(m,n,d,with_nan);
};
mmlib::Matrix rand_matrix_1_sp::rand_band_int(Integer m,Integer n, Integer ld, Integer ud)
{
    return iround(max_int*randn_band_sp(m,n,ld,ud,false,false));
};
mmlib::Matrix rand_matrix_1_sp::rand_band_real(Integer m,Integer n, Integer ld, Integer ud)
{
    return randn_band_sp(m,n,ld,ud,with_nan);
};
mmlib::Matrix rand_matrix_1_sp::rand_band_compl(Integer m,Integer n, Integer ld, Integer ud)
{
    return crandn_band_sp(m,n,ld,ud,with_nan);
};

//======================================================================
//                      rand_matrix_1_str
//======================================================================
rand_matrix_1_str::rand_matrix_1_str()
{};

Integer rand_matrix_1_str::rand_scalar_int()
{
    return irand() % max_int;
};

Real rand_matrix_1_str::rand_scalar_real()
{
    return randn();
};

Complex rand_matrix_1_str::rand_scalar_compl()
{
    return Complex(randn(),randn());
};

mmlib::Matrix rand_matrix_1_str::rand_dense_int(Integer m,Integer n)
{
    return iround(max_int*randn_str(m,n));
};

mmlib::Matrix rand_matrix_1_str::rand_dense_real(Integer m,Integer n)
{
    return randn_str(m,n);
};
mmlib::Matrix rand_matrix_1_str::rand_dense_compl(Integer m,Integer n)
{
    return crandn_str(m,n);
};
mmlib::Matrix rand_matrix_1_str::rand_sparse_int(Integer m,Integer n, Real d)
{
    return iround(max_int*sprandn_str(m,n,d));
};
mmlib::Matrix rand_matrix_1_str::rand_sparse_real(Integer m,Integer n, Real d)
{
    return sprandn_str(m,n,d);
};
mmlib::Matrix rand_matrix_1_str::rand_sparse_compl(Integer m,Integer n, Real d)
{
    return csprandn_str(m,n,d);
};
mmlib::Matrix rand_matrix_1_str::rand_band_int(Integer m,Integer n, Integer ld, Integer ud)
{
    return iround(max_int*randn_band_str(m,n,ld,ud));
};
mmlib::Matrix rand_matrix_1_str::rand_band_real(Integer m,Integer n, Integer ld, Integer ud)
{
    return randn_band_str(m,n,ld,ud);
};
mmlib::Matrix rand_matrix_1_str::rand_band_compl(Integer m,Integer n, Integer ld, Integer ud)
{
    return crandn_band_str(m,n,ld,ud);
};

};};

