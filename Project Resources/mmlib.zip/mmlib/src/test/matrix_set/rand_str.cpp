/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "rand_str.h"
#include "rand_sp.h"
#include "../container/raw/type_decl.h"

namespace mmlib { namespace test
{

template<class DM>
struct rand_struct_impl
{
    static Matrix eval_qtril(const Matrix& A)
    {
        if (A.cols() < 2)
        {
            return A;
        };

        Matrix B = tril(A,1);
        DM mat = B.impl<DM>();

        Integer s = std::min(B.rows(), B.cols()-1);
        DM::value_type* ptr = mat.ptr() + mat.ld();

        bool is_z = true;
        for (Integer i = 0; i < s; ++i)
        {
            if (ptr[0] == 0)
            {
                is_z = true;
            }
            else
            {
                if (is_z == true)
                {
                    is_z = false;
                }
                else
                {
                    ptr[0] = 0;
                    is_z = true;
                };
            };
            ptr += mat.ld() + 1;
        };
        return mat;
    };
    static Matrix eval_qtriu(const Matrix& A)
    {
        if (A.rows() < 2)
        {
            return A;
        };
        Matrix B = triu(A,-1);
        DM mat = B.impl<DM>();

        Integer s = std::min(B.rows()-1, B.cols());
        DM::value_type* ptr = mat.ptr() + 1;

        bool is_z = true;
        for (Integer i = 0; i < s; ++i)
        {
            if (ptr[0] == 0)
            {
                is_z = true;
            }
            else
            {
                if (is_z == true)
                {
                    is_z = false;
                }
                else
                {
                    ptr[0] = 0;
                    is_z = true;
                };
            };
            ptr += mat.ld() + 1;
        };
        return mat;
    };
};
static Matrix qtril(const Matrix& A)
{    
    switch(A.value_type())
    {
        case enums::value_object:
        {
            typedef raw::Matrix<Integer,struct_dense> DM;
            return rand_struct_impl<DM>::eval_qtril(A);
        }
        case enums::value_real:
        {
            typedef raw::Matrix<Real,struct_dense> DM;
            return rand_struct_impl<DM>::eval_qtril(A);
        }
        case enums::value_complex:
        {
            typedef raw::Matrix<Complex,struct_dense> DM;
            return rand_struct_impl<DM>::eval_qtril(A);
        }
        default:
            assertion(0,"unknown case");
            throw;
    };
};
static Matrix qtriu(const Matrix& A)
{
    switch(A.value_type())
    {
        case enums::value_object:
        {
            typedef raw::Matrix<Integer,struct_dense> DM;
            return rand_struct_impl<DM>::eval_qtriu(A);
        }
        case enums::value_real:
        {
            typedef raw::Matrix<Real,struct_dense> DM;
            return rand_struct_impl<DM>::eval_qtriu(A);
        }
        case enums::value_complex:
        {
            typedef raw::Matrix<Complex,struct_dense> DM;
            return rand_struct_impl<DM>::eval_qtriu(A);
        }
        default:
            assertion(0,"unknown case");
            throw;
    };
};
/*
static Matrix unitary(const Matrix& A)
{
    Matrix U;
    if (A.rows() == A.cols())
    {
        U = svd(A).get<1>();
    }
    else
    {
        U = A;
    };
    return U;
};
*/

Matrix rand_str(const Matrix& A)
{
    Matrix B = A;
    Integer c = abs(irand())%10;
    switch(c)
    {
        case 0:
        {
            //zero
            B = 0*A;
            B.set_struct(struct_flag(struct_flag::zero));
            break;
        }
        case 1:
        {
            //id
            B = speye(A.rows(),A.cols());
            if (A.rows() == A.cols())
            {
                B.set_struct(struct_flag(struct_flag::id));
            };
            break;
        }
        case 2:
        {
            //diag
            B = bdiags(get_diag(A),0,A.rows(),A.cols());
            B.set_struct(struct_flag(struct_flag::diag));
            break;
        }
        case 3:
        {
            //tril
            B = tril(A);
            B.set_struct(struct_flag(struct_flag::tril));
            break;
        }
        case 4:
        {
            //triu
            B = triu(A);
            B.set_struct(struct_flag(struct_flag::triu));
            break;
        }
        case 5:
        {
            //general
            break;
        }
        case 6:
        {
            //sym
            if (A.is_square())
            {
                B = A + trans(A);
                B.set_struct(struct_flag(struct_flag::sym));
            };
            break;
        }
        case 7:
        {
            //her
            if (A.is_square())
            {
                B = A + ctrans(A);
                if (B.value_type() == enums::value_complex)
                {
                    B.set_struct(struct_flag(struct_flag::her));
                }
                else
                {
                    B.set_struct(struct_flag(struct_flag::sym));
                };
            };
            break;
        }
        case 8:
        {
            //qtril
            B = qtril(A);
            B.set_struct(struct_flag(struct_flag::qtril));
            break;
        }
        case 9:
        {
            //qtriu
            B = qtriu(A);
            B.set_struct(struct_flag(struct_flag::qtriu));
            break;
        }
        /*
        case 10:
        {
            //unitary
            B = unitary(A);
            if (B.rows() == B.cols())
            {
                B.set_struct(struct_flag(struct_flag::unitary));
            };
            break;
        }
        */
    };

    B.check_struct();
    return B;
};
Matrix test::randn_str(Integer m, Integer n)
{
	Matrix out = randn(m,n);
    return full(rand_str(out));
};
Matrix test::crandn_str(Integer m, Integer n)
{
	Matrix out = crandn(m,n);
    return full(rand_str(out));
};
Matrix test::sprandn_str(Integer m, Integer n, Real d)
{
	Matrix out = sprandn(m,n,d);
    return sparse(rand_str(out));
};
Matrix test::csprandn_str(Integer m, Integer n, Real d)
{
	Matrix out = csprandn(m,n,d);
    return sparse(rand_str(out));
};
Matrix test::randn_band_str(Integer m, Integer n, Integer ld, Integer ud)
{
    Matrix out = randn_band(m,n,ld,ud);
    return band(rand_str(out));
};

Matrix	test::crandn_band_str(Integer m, Integer n, Integer ld, Integer ud)
{
	Matrix out = crandn_band(m,n,ld,ud);
    return band(rand_str(out));
};

};};