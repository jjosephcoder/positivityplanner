/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <vector>
#include <string>
#include "mmlib/mmlib_header.h"
#include "matrix_set/matrix_set.h"

namespace mmlib { namespace test
{

class assign_functions_list
{
	private:
		const matrix_set&		m_tests;
		options					m_options;
    public:
		dynamic_mat_set&		ms;

	public:
		void		make(options opts);

		Matrix		get_matrix(int code) const;

	private:
		void		test_get_int();			void		test_get_int_int();
		void		test_get_colon();		void		test_get_colon_colon();
		void		test_delcols();			void		test_delrows();
		void		test_drop_int();		void		test_drop_int_int();
		void		test_drop_colon();		void		test_drop_colon_colon();
		void		test_del_int();			void		test_del_int_int();
		void		test_del_colon();		void		test_del_colon_colon();
		void		test_set_int_scal();	void		test_set_int2_scal();
		void		test_set_col_scal();	void		test_set_col2_scal();
		void		test_set_int_mat();		void		test_set_int2_mat();
		void		test_set_col_mat();		void		test_set_col2_mat();
        void		test_get_diag();		void		test_set_diag_scal();
        void		test_set_diag_mat();

	public:
		assign_functions_list(const matrix_set& ms_bin, dynamic_mat_set& ms);

	private:
		assign_functions_list(const assign_functions_list&);
		assign_functions_list& operator=(const assign_functions_list&);
};

};};