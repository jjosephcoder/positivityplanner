/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "io_functions_list.h"
#include <iostream>
#include "test_functions.h"
#include "data_struct/logger.h"

using namespace std;

namespace mmlib { namespace test
{

void io_functions_list::make(options opts)
{
	m_options = opts;

	test_io();
	test_serialize();
};

io_functions_list::matrix_pair io_functions_list::get_matrix(int code) const
{
	return m_tests.get_matrix(code);
};
io_functions_list::scalar_pair io_functions_list::get_scalar(int code) const
{
	return m_tests.get_scalar(code);
};

void io_functions_list::test_io()
{
	Real out = 0.;
	test_function_io_formatted2 tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "io: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "io: FAILED"  + "\n";
	};
};
void io_functions_list::test_serialize()
{
	Real out = 0.;
	test_function_serialize2 tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "serialize: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "serialize: FAILED"  + "\n";
	};
};

};};