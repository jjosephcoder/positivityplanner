/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "assign_functions_list.h"
#include <iostream>
#include "test_functions.h"
#include "data_struct/logger.h"
#include "matrix_set/colon_set.h"

using namespace std;

namespace mmlib { namespace test
{

static const Integer max_int = 1000;

assign_functions_list::assign_functions_list(const matrix_set& ms1, dynamic_mat_set& ms)
:ms(ms),m_tests(ms1)
{};

void assign_functions_list::make(options opts)
{
	m_options = opts;

    test_get_int();			
	test_get_int_int();	
	test_get_colon();
    test_get_colon_colon();
    test_get_diag();

	test_delcols();
	test_delrows();
	test_del_int();	
	test_del_int_int();
	test_del_colon();
	test_del_colon_colon();
	test_drop_int();		
	test_drop_int_int();
    test_drop_colon();
	test_drop_colon_colon();

	test_set_int_scal();	
	test_set_int2_scal();
	test_set_int_mat();		
	test_set_int2_mat();

	test_set_col_scal();
	test_set_col2_scal();
    test_set_col_mat();
    test_set_col2_mat();
    test_set_diag_scal();
    test_set_diag_mat();
};
Matrix assign_functions_list::get_matrix(int code) const
{
	return m_tests.get_matrix(code);
};

void assign_functions_list::test_get_int()
{
	Real out = 0.;
	{
		test_function_get_int tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_get_int tf(5);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() +   "get_int: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "get_int: FAILED"  + "\n";
	};
};
void assign_functions_list::test_get_int_int()
{
	Real out = 0.;
	{
		test_function_get_int_int tf(1,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_get_int_int tf(1,3);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_get_int_int tf(3,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_get_int_int tf(3,3);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "get_int_int: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "get_int_int: FAILED"  + "\n";
	};
};
void assign_functions_list::test_get_colon()
{
	Real out = 0.;

	colon_set cs;
	for (int i = 0; i < cs.size(); i++)
	{
		test_function_get_colon tf(cs.get(i));
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "get_colon: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "get_colon: FAILED"  + "\n";
	};
};
void assign_functions_list::test_get_colon_colon()
{
	Real out = 0.;

	colon_set cs1;
	colon_set cs2;
	for (int i = 0; i < cs1.size(); i++)
	{
		for (int j = 0; j < cs2.size(); j++)
		{
			//logger()  << i << " " << j + "\n";
			test_function_get_colon_colon tf(cs1.get(i),cs2.get(j));
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() +   "get_colon_colon: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "get_colon_colon: FAILED"  + "\n";
	};
};
void assign_functions_list::test_get_diag()
{
	Real out = 0.;

    {
	    test_function_get_diag2 tf(-1);
	    out += m_tests.make(&tf,m_options);
    }

    {
	    test_function_get_diag2 tf(0);
	    out += m_tests.make(&tf,m_options);
    }

    {
	    test_function_get_diag2 tf(1);
	    out += m_tests.make(&tf,m_options);
    }

	if (out == 0.)
	{
		logger() << std::string() +   "get_diag2: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "get_diag2: FAILED"  + "\n";
	};
};

void assign_functions_list::test_delcols()
{
	Real out = 0.;

	colon_set cs;
	for (int i = 0; i < cs.size(); i++)
	{
		//logger() << std::string() +   i<<"\n";
		test_function_delcols tf(cs.get(i));
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "delcols: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "delcols: FAILED"  + "\n";
	};
};
void assign_functions_list::test_delrows()
{
	Real out = 0.;

	colon_set cs;
	for (int i = 0; i < cs.size(); i++)
	{
		//logger()  << i + "\n";
		test_function_delrows tf(cs.get(i));
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "delrows: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "delrows: FAILED"  + "\n";
	};
};

void assign_functions_list::test_drop_int()
{
	Real out = 0.;
	{
		test_function_drop_int tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_drop_int tf(5);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() +   "drop_int: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "drop_int: FAILED"  + "\n";
	};
};
void assign_functions_list::test_drop_int_int()
{
	Real out = 0.;
	{
		test_function_drop_int_int tf(1,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_drop_int_int tf(1,3);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_drop_int_int tf(3,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_drop_int_int tf(3,3);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "drop_int_int: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "drop_int_int: FAILED"  + "\n";
	};
};
void assign_functions_list::test_drop_colon()
{
	Real out = 0.;

	colon_set cs;
	for (int i = 0; i < cs.size(); i++)
	{
		test_function_drop_colon tf(cs.get(i));
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "drop_colon: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "drop_colon: FAILED"  + "\n";
	};
};
void assign_functions_list::test_drop_colon_colon()
{
	Real out = 0.;

	colon_set cs1;
	colon_set cs2;
	for (int i = 0; i < cs1.size(); i++)
	{
		for (int j = 0; j < cs2.size(); j++)
		{
			//logger()  << i << " " << j + "\n";
			test_function_drop_colon_colon tf(cs1.get(i),cs2.get(j));
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() +   "drop_colon_colon: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "drop_colon_colon: FAILED"  + "\n";
	};
};

void assign_functions_list::test_del_int()
{
	Real out = 0.;
	{
		test_function_del_int tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_del_int tf(5);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() +   "del_int: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "del_int: FAILED"  + "\n";
	};
};
void assign_functions_list::test_del_int_int()
{
	Real out = 0.;
	{
		test_function_del_int_int tf(1,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_del_int_int tf(1,3);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_del_int_int tf(3,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_del_int_int tf(3,3);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "del_int_int: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "del_int_int: FAILED"  + "\n";
	};
};
void assign_functions_list::test_del_colon()
{
	Real out = 0.;

	colon_set cs;
	for (int i = 0; i < cs.size(); i++)
	{
		test_function_del_colon tf(cs.get(i));
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "del_colon: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "del_colon: FAILED"  + "\n";
	};
};
void assign_functions_list::test_del_colon_colon()
{
	Real out = 0.;

	colon_set cs1;
	colon_set cs2;
	for (int i = 0; i < cs1.size(); i++)
	{
		for (int j = 0; j < cs2.size(); j++)
		{
			//logger()  << i << " " << j + "\n";
			test_function_del_colon_colon tf(cs1.get(i),cs2.get(j));
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() +   "del_colon_colon: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "del_colon_colon: FAILED"  + "\n";
	};
};

void assign_functions_list::test_set_int_scal()
{
	Real out = 0.;
	{
		test_function_set_int_scal tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_set_int_scal tf(5);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() +   "set_int_scal: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_int_scal: FAILED"  + "\n";
	};
};
void assign_functions_list::test_set_int2_scal()
{
	Real out = 0.;
	{
		test_function_set_int2_scal tf(1,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_set_int2_scal tf(1,3);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_set_int2_scal tf(3,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_set_int2_scal tf(3,3);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "set_int2_scal: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_int2_scal: FAILED"  + "\n";
	};
};
void assign_functions_list::test_set_col_scal()
{
	Real out = 0.;

	colon_set cs;
	for (int i = 0; i < cs.size(); i++)
	{
		//logger()  << i + "\n";
		test_function_set_col_scal tf(cs.get(i));
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "set_col_scal: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_col_scal: FAILED"  + "\n";
	};
};
void assign_functions_list::test_set_col2_scal()
{
	Real out = 0.;

	colon_set cs1;
	colon_set cs2;
	for (int i = 0; i < cs1.size(); i++)
	{
		for (int j = 0; j < cs2.size(); j++)
		{
			//logger()  << i << " " << j + "\n";
			test_function_set_col2_scal tf(cs1.get(i),cs2.get(j));
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() +   "set_col2_scal: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_col2_scal: FAILED"  + "\n";
	};
};
void assign_functions_list::test_set_int_mat()
{
	Real out = 0.;
	{
		test_function_set_int_mat tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_set_int_mat tf(5);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() +   "set_int_mat: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_int_mat: FAILED"  + "\n";
	};
};

void assign_functions_list::test_set_int2_mat()
{
	Real out = 0.;
	{
		test_function_set_int2_mat tf(1,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_set_int2_mat tf(1,3);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_set_int2_mat tf(3,1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_set_int2_mat tf(3,3);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "set_int2_mat: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_int2_mat: FAILED"  + "\n";
	};
};
void assign_functions_list::test_set_col_mat()
{
	Real out = 0.;

	colon_set cs;

	for (int i = 0; i < cs.size(); i++)
	{
		//logger()  << i + "\n";
		colon c = cs.get(i);

		test_function_set_col_mat tf(c,ms);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "set_col_mat: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_col_mat: FAILED"  + "\n";
	};
};
void assign_functions_list::test_set_diag_scal()
{
	Real out = 0.;

    {
	    test_function_set_diag_scal tf(-1);
	    out += m_tests.make(&tf,m_options);
    }

    {
	    test_function_set_diag_scal tf(0);
	    out += m_tests.make(&tf,m_options);
    }

    {
	    test_function_set_diag_scal tf(1);
	    out += m_tests.make(&tf,m_options);
    }

	if (out == 0.)
	{
		logger() << std::string() +   "set_diag_scal: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_diag_scal: FAILED"  + "\n";
	};
};

void assign_functions_list::test_set_col2_mat()
{
	Real out = 0.;

	colon_set cs1;
	colon_set cs2;	

	for (int i = 0; i < cs1.size(); i++)
	{
		for (int j = 0; j < cs2.size(); j++)
		{
			//logger()  << i << " " << j + "\n";
			colon c1 = cs1.get(i);
			colon c2 = cs1.get(j);

			test_function_set_col2_mat tf(cs1.get(i),cs2.get(j),ms);
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() +   "set_col2_mat: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_col2_mat: FAILED"  + "\n";
	};
};

void assign_functions_list::test_set_diag_mat()
{
	Real out = 0.;

    {
	    test_function_set_diag_mat tf(-1,ms);
	    out += m_tests.make(&tf,m_options);
    }

    {
	    test_function_set_diag_mat tf(0,ms);
	    out += m_tests.make(&tf,m_options);
    }

    {
	    test_function_set_diag_mat tf(1,ms);
	    out += m_tests.make(&tf,m_options);
    }

    if (out == 0.)
	{
		logger() << std::string() +   "set_diag_mat: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "set_diag_mat: FAILED"  + "\n";
	};
};

};};