/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "mmlib/mmlib_header.h"
#include "matrix_set/matrix_set.h"

namespace mmlib { namespace test
{

class test_function_get_diag : public unary_function
{
	private:
		Integer d;

	public:
		test_function_get_diag(Integer d) : d(d) {};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_get_diag2 : public unary_function
{
	private:
		Integer d;

	public:
		test_function_get_diag2(Integer d) : d(d) {};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};

class test_function_tril : public unary_function
{
	private:
		Integer d;

	public:
		test_function_tril(Integer d) : d(d) {};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_triu : public unary_function
{
	private:
		Integer d;

	public:
		test_function_triu(Integer d) : d(d) {};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_rot90 : public unary_function
{
	private:
		Integer d;

	public:
		test_function_rot90(Integer d) : d(d) {};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_cat : public unary_function
{
	private:
		Integer         m;
		Integer         n;
		Integer         pos;
		Integer         type;
        Integer         seed;
        rand_matrix_ptr m_rand;

	public:
		test_function_cat(Integer m, Integer n, Integer pos, Integer type,
                        rand_matrix_ptr rand, Integer s) 
            : m(m), n(n), pos(pos), type(type), m_rand(rand), seed(s)
        {};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sum : public unary_function
{
	private:
		Integer d;

	public:
		test_function_sum(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_cumsum : public unary_function
{
	private:
		Integer d;

	public:
		test_function_cumsum(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_prod : public unary_function
{
	private:
		Integer d;

	public:
		test_function_prod(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_cumprod : public unary_function
{
	private:
		Integer d;

	public:
		test_function_cumprod(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sumsq : public unary_function
{
	private:
		Integer d;

	public:
		test_function_sumsq(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_min : public unary_function
{
	private:
		Integer d;

	public:
		test_function_min(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_min_abs : public unary_function
{
	private:
		Integer d;

	public:
		test_function_min_abs(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_max : public unary_function
{
	private:
		Integer d;

	public:
		test_function_max(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_max_abs : public unary_function
{
	private:
		Integer d;

	public:
		test_function_max_abs(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_min2 : public unary_function
{
	private:
		Integer d;

	public:
		test_function_min2(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_min_abs2 : public unary_function
{
	private:
		Integer d;

	public:
		test_function_min_abs2(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_max2 : public unary_function
{
	private:
		Integer d;

	public:
		test_function_max2(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_max_abs2 : public unary_function
{
	private:
		Integer d;

	public:
		test_function_max_abs2(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_nnz : public unary_function
{
	private:
		Integer d;

	public:
		test_function_nnz(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_mean : public unary_function
{
	private:
		Integer d;

	public:
		test_function_mean(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_std: public unary_function
{
	private:
		Integer d;

	public:
		test_function_std(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_repmat : public unary_function
{
	private:
		Integer m;
		Integer n;

	public:
		test_function_repmat(Integer m, Integer n) : m(m), n(n){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_op_un_minus : public unary_function
{
	private:
	public:
		test_function_op_un_minus()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_op_neg : public unary_function
{
	private:
	public:
		test_function_op_neg()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_is_true : public unary_function
{
	private:
	public:
		test_function_is_true()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_is_false : public unary_function
{
	private:
	public:
		test_function_is_false()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_all : public unary_function
{
	private:
		Integer d;

	public:
		test_function_all(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_any : public unary_function
{
	private:
		Integer d;

	public:
		test_function_any(Integer d) : d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_reshape : public unary_function
{
	public:
		test_function_reshape(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_find : public unary_function
{
	public:
		test_function_find(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_find2 : public unary_function
{
	public:
		test_function_find2(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_find3 : public unary_function
{
	public:
		test_function_find3(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sort : public unary_function
{
	private:
		Integer d;
		bool	is_asc;

	public:
		test_function_sort(Integer d, bool is_asc)	:d(d),is_asc(is_asc){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sort2 : public unary_function
{
	private:
		Integer d;
		bool	is_asc;

	public:
		test_function_sort2(Integer d, bool is_asc)	:d(d),is_asc(is_asc){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sortrows : public unary_function
{
	public:
		test_function_sortrows(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sortrows_dim : public unary_function
{
	private:
		Matrix m;

	public:
		test_function_sortrows_dim(const Matrix& m)	:m(m){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sortrows2 : public unary_function
{
	public:
		test_function_sortrows2(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sortrows_dim2 : public unary_function
{
	private:
		Matrix	m;

	public:
		test_function_sortrows_dim2(const Matrix& m)	:m(m){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sortcols : public unary_function
{
	public:
		test_function_sortcols(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sortcols_dim : public unary_function
{
	private:
		Matrix	m;

	public:
		test_function_sortcols_dim(const Matrix& m)	:m(m){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sortcols2 : public unary_function
{
	public:
		test_function_sortcols2(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sortcols_dim2 : public unary_function
{
	private:
		Matrix	m;

	public:
		test_function_sortcols_dim2(const Matrix& m)	:m(m){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};

class test_function_convert : public unary_function
{
	private:
		Integer code;
	public:
		test_function_convert(Integer code)	:code(code){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_delcols : public unary_function
{
	private:
		colon c1;

	public:
		test_function_delcols(const colon& c1)	:c1(c1){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_delrows : public unary_function
{
	private:
		colon c1;

	public:
		test_function_delrows(const colon& c1)	:c1(c1){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_eval_func : public unary_function
{
	public:
		test_function_eval_func(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_get_colon : public unary_function
{
	private:
		colon c1;

	public:
		test_function_get_colon(const colon& c1)	:c1(c1){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_get_colon_colon : public unary_function
{
	private:
		colon c1;
		colon c2;
	public:
		test_function_get_colon_colon(const colon& c1,const colon& c2) :c1(c1),c2(c2){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_get_int : public unary_function
{
	private:
		Integer i;
	public:
		test_function_get_int(Integer i)	:i(i){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_get_int_int : public unary_function
{
	private:
		Integer i;
		Integer j;
	public:
		test_function_get_int_int(Integer i,Integer j)	:i(i),j(j){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_get_array : public unary_function
{
	public:
		test_function_get_array(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_get_const_array : public unary_function
{
	public:
		test_function_get_const_array(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};

class test_function_get_scal : public unary_function
{
	public:
		test_function_get_scal(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_is_sorted : public unary_function
{
	private:
		Integer d;
		bool is_asc;

	public:
		test_function_is_sorted(Integer d,bool is_asc)	:d(d),is_asc(is_asc){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_is_sorted_cols : public unary_function
{
	public:
		test_function_is_sorted_cols(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_get_lu : public unary_function
{
	public:
		test_function_get_lu(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_resize_reserve : public unary_function
{
	public:
		test_function_resize_reserve(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_resize_reserve_b : public unary_function
{
	public:
		test_function_resize_reserve_b(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_is_sorted_rows : public unary_function
{
	public:
		test_function_is_sorted_rows(){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_del_colon: public unary_function
{
	private:
		colon c1;

	public:
		test_function_del_colon(const colon& c1)	:c1(c1){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_del_colon_colon : public unary_function
{
	private:
		colon c1;
		colon c2;
	public:
		test_function_del_colon_colon(const colon& c1,const colon& c2) :c1(c1),c2(c2){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_del_int : public unary_function
{
	private:
		Integer i;

	public:
		test_function_del_int(Integer i)	:i(i){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_del_int_int : public unary_function
{
	private:
		Integer i;
		Integer j;
	public:
		test_function_del_int_int(Integer i,Integer j)	:i(i),j(j){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_drop_colon : public unary_function
{
	private:
		colon c1;

	public:
		test_function_drop_colon(const colon& c1)	:c1(c1){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_drop_colon_colon : public unary_function
{
	private:
		colon c1;
		colon c2;
	public:
		test_function_drop_colon_colon(const colon& c1,const colon& c2)	:c1(c1),c2(c2){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_drop_int : public unary_function
{
	private:
		Integer i;
	public:
		test_function_drop_int(Integer i) :i(i){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_drop_int_int : public unary_function
{
	private:
		Integer i;
		Integer j;
	public:
		test_function_drop_int_int(Integer i,Integer j)	:i(i),j(j){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_set_int_scal : public unary_function
{
	private:
		Integer i;

	public:
		test_function_set_int_scal(Integer i)	:i(i){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_set_int2_scal : public unary_function
{
	private:
		Integer i;
		Integer j;
	public:
		test_function_set_int2_scal(Integer i,Integer j)	:i(i),j(j){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_set_col_scal : public unary_function
{
	private:
		colon c1;
	public:
		test_function_set_col_scal(const colon& c1)	:c1(c1){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_set_diag_scal : public unary_function
{
	private:
		Integer d;
	public:
		test_function_set_diag_scal(Integer d)	:d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};

class test_function_set_col2_scal : public unary_function
{
	private:
		colon c1;
		colon c2;
	public:
		test_function_set_col2_scal(const colon& c1,const colon& c2)	:c1(c1),c2(c2){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_set_col_mat : public unary_function
{
	private:
		colon		        c1;
		dynamic_mat_set&	ms;
        long                m_new_objects;

	public:
		test_function_set_col_mat(const colon& c1,dynamic_mat_set& ms)	
			:c1(c1),ms(ms),m_new_objects(0)
		{};

        virtual long n_new_objects()             { return m_new_objects; };
		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);

	private:
		test_function_set_col_mat(const test_function_set_col_mat&);
		test_function_set_col_mat& operator=(const test_function_set_col_mat&);
};
class test_function_set_diag_mat : public unary_function
{
	private:
		Integer		        d;
		dynamic_mat_set&	ms;
        long                m_new_objects;

	public:
		test_function_set_diag_mat(Integer d,dynamic_mat_set& ms)	
			:d(d),ms(ms),m_new_objects(0)
		{};

        virtual long n_new_objects()             { return m_new_objects; };
		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);

	private:
		test_function_set_diag_mat(const test_function_set_diag_mat&);
		test_function_set_diag_mat& operator=(const test_function_set_diag_mat&);
};

class test_function_set_col2_mat : public unary_function
{
	private:
		colon			    c1;
		colon			    c2;
		dynamic_mat_set&	ms;
        long                m_new_objects;

	public:
		test_function_set_col2_mat(const colon& c1,const colon& c2,dynamic_mat_set& ms)
			:c1(c1),c2(c2),ms(ms)
		{};

        virtual long n_new_objects()             { return m_new_objects; };
		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);

	private:
		test_function_set_col2_mat(const test_function_set_col2_mat&);
		test_function_set_col2_mat& operator=(const test_function_set_col2_mat&);
};
class test_function_set_int_mat : public unary_function
{
	private:
		Integer i;
	public:
		test_function_set_int_mat(Integer i)	:i(i){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_set_int2_mat : public unary_function
{
	private:
		Integer i;
		Integer j;
	public:
		test_function_set_int2_mat(Integer i,Integer j)	:i(i),j(j){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_sparse : public unary_function
{
	public:
		test_function_sparse()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_band : public unary_function
{
	public:
		test_function_band()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_clone : public unary_function
{
	public:
		test_function_clone()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_io_formatted : public unary_function
{
	public:
		test_function_io_formatted()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_serialize : public unary_function
{
	public:
		test_function_serialize()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};


class test_function_diag: public unary_function
{
	private:
		int d;
	public:
		test_function_diag(int d)	:d(d)	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_bdiag: public unary_function
{
	private:
		int d;
	public:
		test_function_bdiag(int d)	:d(d)	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_spdiag: public unary_function
{
	private:
		int d;
	public:
		test_function_spdiag(int d)	:d(d){};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_diags: public unary_function
{
	public:
		test_function_diags()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};

class test_function_bdiags: public unary_function
{
	public:
		test_function_bdiags()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_spdiags: public unary_function
{
	public:
		test_function_spdiags()	{};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};

class test_function_op_plus : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1((a+b) - (full(a)+full(b)));
			dif			+=norm_1((a+b) - (Complex(a)+(b)));
			dif			+=norm_1((a+b) - ((a)+Complex(b)));
			dif			+=norm_1((a+b) - (Complex(a)+Complex(b)));
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_minus : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1((a-b) - (full(a)-full(b)));
			dif			+=norm_1((a-b) - (Complex(a)-(b)));
			dif			+=norm_1((a-b) - ((a)-Complex(b)));
			dif			+=norm_1((a-b) - (Complex(a)-Complex(b)));
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_mult : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1((a*b) - (full(a)*full(b)));
			dif			+=norm_1((a*b) - (Complex(a)*(b)));
			dif			+=norm_1((a*b) - ((a)*Complex(b)));
			dif			+=norm_1((a*b) - (Complex(a)*Complex(b)));
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_chain_mult : public bin_function
{
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_div : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(div(a,b) - div(full(a),full(b)));;
			dif			+=norm_1(div(a,b) - div(Complex(a),(b)));;
			dif			+=norm_1(div(a,b) - div((a),Complex(b)));;
			dif			+=norm_1(div(a,b) - div(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_plus : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(plus(a,b) - plus(full(a),full(b)));;
			dif			+=norm_1(plus(a,b) - plus(Complex(a),(b)));;
			dif			+=norm_1(plus(a,b) - plus((a),Complex(b)));;
			dif			+=norm_1(plus(a,b) - plus(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_minus : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(minus(a,b) - minus(full(a),full(b)));;
			dif			+=norm_1(minus(a,b) - minus(Complex(a),(b)));;
			dif			+=norm_1(minus(a,b) - minus((a),Complex(b)));;
			dif			+=norm_1(minus(a,b) - minus(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_mul : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(mul(a,b) - mul(full(a),full(b)));;
			dif			+=norm_1(mul(a,b) - mul(Complex(a),(b)));;
			dif			+=norm_1(mul(a,b) - mul((a),Complex(b)));;
			dif			+=norm_1(mul(a,b) - mul(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_div : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(div(a,b) - div(full(a),full(b)));;
			dif			+=norm_1(div(a,b) - div(Complex(a),(b)));;
			dif			+=norm_1(div(a,b) - div((a),Complex(b)));;
			dif			+=norm_1(div(a,b) - div(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_idiv : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(idiv(a,b) - idiv(full(a),full(b)));;
			dif			+=norm_1(idiv(to_real(a),b) - idiv(Complex(a),(b)));;
			dif			+=norm_1(idiv(a,to_real(b)) - idiv((a),Complex(b)));;
			dif			+=norm_1(idiv(to_real(a),to_real(b)) - idiv(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};

class test_function_pow : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Matrix base = mmlib::pow(a,b);
			Real dif	= norm_1(base - mmlib::pow(full(a),full(b)));;
			dif			+=norm_1(base - mmlib::pow(Complex(a),(b)));;
			dif			+=norm_1(base - mmlib::pow((a),Complex(b)));;
			dif			+=norm_1(base - mmlib::pow(Complex(a),Complex(b)));;

			Matrix rel	= dif/(norm_1(base)+1e-15);
			if (is_scalar_true(rel < 1e-10))
			{
				dif		= 0.;
			};
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_pow_nc : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Matrix base = mmlib::pow(a,b);
			Real dif	= norm_1(base - mmlib::pow_nc(full(a),full(b)));;
			dif			+=norm_1(base - mmlib::pow_nc(Complex(a),(b)));;
			dif			+=norm_1(base - mmlib::pow_nc((a),Complex(b)));;
			dif			+=norm_1(base - mmlib::pow_nc(Complex(a),Complex(b)));;

			Matrix rel	= dif/(norm_1(base)+1e-15);
			if (is_scalar_true(rel < 1e-10))
			{
				dif		= 0.;
			};
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_max_bin : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(mmlib::max(a,b) - mmlib::max(full(a),full(b)));;
			dif			+=norm_1(mmlib::max(a,b) - mmlib::max(Complex(a),(b)));;
			dif			+=norm_1(mmlib::max(a,b) - mmlib::max((a),Complex(b)));;
			dif			+=norm_1(mmlib::max(a,b) - mmlib::max(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_min_bin : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(mmlib::min(a,b) - mmlib::min(full(a),full(b)));;
			dif			+=norm_1(mmlib::min(a,b) - mmlib::min(Complex(a),(b)));;
			dif			+=norm_1(mmlib::min(a,b) - mmlib::min((a),Complex(b)));;
			dif			+=norm_1(mmlib::min(a,b) - mmlib::min(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_xor : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(mmlib::xor(a,b) - mmlib::xor(full(a),full(b)));;
			dif			+=norm_1(mmlib::xor(a,b) - mmlib::xor(Complex(a),(b)));;
			dif			+=norm_1(mmlib::xor(a,b) - mmlib::xor((a),Complex(b)));;
			dif			+=norm_1(mmlib::xor(a,b) - mmlib::xor(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_rem : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(mmlib::rem(a,b) - mmlib::rem(full(a),full(b)));;
			dif			+=norm_1(mmlib::rem(to_real(a),b) - mmlib::rem(Complex(a),(b)));;
			dif			+=norm_1(mmlib::rem(a,to_real(b)) - mmlib::rem((a),Complex(b)));;
			dif			+=norm_1(mmlib::rem(to_real(a),to_real(b)) - mmlib::rem(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_mod : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(mmlib::mod(a,b) - mmlib::mod(full(a),full(b)));;
			dif			+=norm_1(mmlib::mod(to_real(a),b) - mmlib::mod(Complex(a),(b)));;
			dif			+=norm_1(mmlib::mod(a,to_real(b)) - mmlib::mod((a),Complex(b)));;
			dif			+=norm_1(mmlib::mod(to_real(a),to_real(b)) - mmlib::mod(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_kron : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif	= norm_1(mmlib::kron(a,b) - mmlib::kron(full(a),full(b)));;
			dif			+=norm_1(mmlib::kron(a,b) - mmlib::kron(Complex(a),(b)));;
			dif			+=norm_1(mmlib::kron(a,b) - mmlib::kron((a),Complex(b)));;
			dif			+=norm_1(mmlib::kron(a,b) - mmlib::kron(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_or : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			dif			+=norm_1(mmlib::or(a,b) - mmlib::or(full(a),full(b)));;
			dif			+=norm_1((a||b) - (full(a)|full(b)));;
			dif			+=norm_1(mmlib::or(a,b) - mmlib::or(Complex(a),(b)));;
			dif			+=norm_1(mmlib::or(a,b) - mmlib::or((a),Complex(b)));;
			dif			+=norm_1(mmlib::or(a,b) - mmlib::or(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_and : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			dif			+=norm_1(mmlib::and(a,b) - mmlib::and(full(a),full(b)));;
			dif			+=norm_1((a&&b) - (full(a)&full(b)));;
			dif			+=norm_1(mmlib::and(a,b) - mmlib::and(Complex(a),(b)));;
			dif			+=norm_1(mmlib::and(a,b) - mmlib::and((a),Complex(b)));;
			dif			+=norm_1(mmlib::and(a,b) - mmlib::and(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_eeq : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			dif			+=norm_1(mmlib::eeq(a,b) - mmlib::eeq(full(a),full(b)));;
			dif			+=norm_1((a==b) - (full(a)==full(b)));;
			dif			+=norm_1(mmlib::eeq(a,b) - mmlib::eeq(Complex(a),(b)));;
			dif			+=norm_1(mmlib::eeq(a,b) - mmlib::eeq((a),Complex(b)));;
			dif			+=norm_1(mmlib::eeq(a,b) - mmlib::eeq(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_neq : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			dif			+=norm_1(mmlib::neq(a,b) - mmlib::neq(full(a),full(b)));;
			dif			+=norm_1((a!=b) - (full(a)!=full(b)));;
			dif			+=norm_1(mmlib::neq(a,b) - mmlib::neq(Complex(a),(b)));;
			dif			+=norm_1(mmlib::neq(a,b) - mmlib::neq((a),Complex(b)));;
			dif			+=norm_1(mmlib::neq(a,b) - mmlib::neq(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_lt : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			dif			+=norm_1(mmlib::lt(a,b) - mmlib::lt(full(a),full(b)));;
			dif			+=norm_1((a<b) - (full(a)<full(b)));;
			dif			+=norm_1(mmlib::lt(a,b) - mmlib::lt(Complex(a),(b)));;
			dif			+=norm_1(mmlib::lt(a,b) - mmlib::lt((a),Complex(b)));;
			dif			+=norm_1(mmlib::lt(a,b) - mmlib::lt(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_leq : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			dif			+=norm_1(mmlib::leq(a,b) - mmlib::leq(full(a),full(b)));;
			dif			+=norm_1((a<=b) - (full(a)<=full(b)));;
			dif			+=norm_1(mmlib::leq(a,b) - mmlib::leq(Complex(a),(b)));;
			dif			+=norm_1(mmlib::leq(a,b) - mmlib::leq((a),Complex(b)));;
			dif			+=norm_1(mmlib::leq(a,b) - mmlib::leq(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_gt : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			dif			+=norm_1(mmlib::gt(a,b) - mmlib::gt(full(a),full(b)));;
			dif			+=norm_1((a>b) - (full(a)>full(b)));;
			dif			+=norm_1(mmlib::gt(a,b) - mmlib::gt(Complex(a),(b)));;
			dif			+=norm_1(mmlib::gt(a,b) - mmlib::gt((a),Complex(b)));;
			dif			+=norm_1(mmlib::gt(a,b) - mmlib::gt(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_op_geq : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			dif			+=norm_1(mmlib::geq(a,b) - mmlib::geq(full(a),full(b)));;
			dif			+=norm_1((a>=b) - (full(a)>=full(b)));;
			dif			+=norm_1(mmlib::geq(a,b) - mmlib::geq(Complex(a),(b)));;
			dif			+=norm_1(mmlib::geq(a,b) - mmlib::geq((a),Complex(b)));;
			dif			+=norm_1(mmlib::geq(a,b) - mmlib::geq(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_atan2 : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			dif			+=norm_1(mmlib::atan2(a,b) - mmlib::atan2(full(a),full(b)));;
			dif			+=norm_1(mmlib::atan2(a,b) - mmlib::atan2(Complex(a),(b)));;
			dif			+=norm_1(mmlib::atan2(a,b) - mmlib::atan2((a),Complex(b)));;
			dif			+=norm_1(mmlib::atan2(a,b) - mmlib::atan2(Complex(a),Complex(b)));;
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};

class test_function_io_formatted2 : public bin_function
{
	private:
		template<class T1,class T2>
		Real eval_scal_func(T1 a, T2 b)
		{
			Real dif = 0;
			Matrix tmp1,tmp2;
			{
				std::ostringstream ss;
				ss.precision(20);
				ss<<a;
				ss<<b;

				std::istringstream ss2(ss.str());
                ss2>>tmp1;
                ss2>>tmp2;

                tmp1.check_struct();
                tmp2.check_struct();
				
				dif += norm_1(a - tmp1);
				dif += norm_1(b - tmp2);
			};
			return dif;
		};
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};
class test_function_serialize2 : public bin_function
{
	public:
		virtual Real	eval_mat(const Matrix& mat1,const Matrix& mat2,int code);
		virtual Real	eval_scalar(const Scalar& s1, const Scalar& s2,int code);
};

struct h_vec		
{ 
	static Matrix eval(const Matrix& m)			{ return vec(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return vec(m); }; 
};

struct h_trans
{ 
	static Matrix eval(const Matrix& m)			{ return trans(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return trans(m); }; 
};
struct h_ctrans
{ 
	static Matrix eval(const Matrix& m)			{ return ctrans(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return ctrans(m); }; 
};
struct h_real
{ 
	static Matrix eval(const Matrix& m)			{ return real(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return real(m); }; 
};
struct h_imag
{ 
	static Matrix eval(const Matrix& m)			{ return imag(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return imag(m); }; 
};
struct h_abs
{ 
	static Matrix eval(const Matrix& m)			{ return abs(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return abs(m); }; 
};
struct h_arg
{ 
	static Matrix eval(const Matrix& m)			{ return arg(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return arg(m); }; 
};
struct h_angle
{ 
	static Matrix eval(const Matrix& m)			{ return angle(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return angle(m); }; 
};
struct h_conj
{ 
	static Matrix eval(const Matrix& m)			{ return conj(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return conj(m); }; 
};
struct h_flipud
{ 
	static Matrix eval(const Matrix& m)			{ return flipud(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return flipud(m); }; 
};
struct h_fliplr
{ 
	static Matrix eval(const Matrix& m)			{ return fliplr(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return fliplr(m); }; 
};
struct h_sqrt
{ 
	static Matrix eval(const Matrix& m)			{ return sqrt(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return sqrt(m,true); }; 
};
struct h_sqrt_nc
{ 
	static Matrix eval(const Matrix& m)			{ return sqrt(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return sqrt(m,false); }; 
};
struct h_pow2
{ 
	static Matrix eval(const Matrix& m)			{ return pow2(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return pow2(m); }; 
};
struct h_exp
{ 
	static Matrix eval(const Matrix& m)			{ return exp(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return exp(m); }; 
};
struct h_log
{ 
	static Matrix eval(const Matrix& m)			{ return log(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return log(m,true); }; 
};
struct h_log_nc
{ 
	static Matrix eval(const Matrix& m)			{ return log(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return log(m,false); }; 
};
struct h_log2
{ 
	static Matrix eval(const Matrix& m)			{ return log2(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return log2(m,true); }; 
};
struct h_log2_nc
{ 
	static Matrix eval(const Matrix& m)			{ return log2(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return log2(m,false); }; 
};
struct h_log10
{ 
	static Matrix eval(const Matrix& m)			{ return log10(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return log10(m,true); }; 
};
struct h_log10_nc
{ 
	static Matrix eval(const Matrix& m)			{ return log10(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return log10(m,false); }; 
};
struct h_floor
{ 
	static Matrix eval(const Matrix& m)			{ return floor(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return floor(m); }; 
};
struct h_ceil
{ 
	static Matrix eval(const Matrix& m)			{ return ceil(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return ceil(m); }; 
};
struct h_round
{ 
	static Matrix eval(const Matrix& m)			{ return round(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return round(m); }; 
};
struct h_fix
{ 
	static Matrix eval(const Matrix& m)			{ return fix(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return fix(m); }; 
};
struct h_trunc
{ 
	static Matrix eval(const Matrix& m)			{ return trunc(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return trunc(m); }; 
};
struct h_ifloor
{ 
	static Matrix eval(const Matrix& m)			{ return ifloor(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return ifloor(m); }; 
};
struct h_iceil
{ 
	static Matrix eval(const Matrix& m)			{ return iceil(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return iceil(m); }; 
};
struct h_iround
{ 
	static Matrix eval(const Matrix& m)			{ return iround(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return iround(m); }; 
};
struct h_ifix
{ 
	static Matrix eval(const Matrix& m)			{ return ifix(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return ifix(m); }; 
};
struct h_itrunc
{ 
	static Matrix eval(const Matrix& m)			{ return itrunc(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return itrunc(m); }; 
};
struct h_sign
{ 
	static Matrix eval(const Matrix& m)			{ return sign(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return sign(m); }; 
};
struct h_isign
{ 
	static Matrix eval(const Matrix& m)			{ return isign(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return isign(m); }; 
};
struct h_isinf
{ 
	static Matrix eval(const Matrix& m)			{ return is_inf(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return is_inf(m); }; 
};
struct h_isnan
{ 
	static Matrix eval(const Matrix& m)			{ return is_nan(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return is_nan(m); }; 
};
struct h_isfin
{ 
	static Matrix eval(const Matrix& m)			{ return is_finite(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return is_finite(m); }; 
};
struct h_isstrue
{ 
	static Matrix eval(const Matrix& m)			{ return is_scalar_true(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return is_scalar_true(m); }; 
};
struct h_issfalse
{ 
	static Matrix eval(const Matrix& m)			{ return is_scalar_false(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return is_scalar_false(m); }; 
};
struct h_sin
{ 
	static Matrix eval(const Matrix& m)			{ return sin(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return sin(m); }; 
};
struct h_cos
{ 
	static Matrix eval(const Matrix& m)			{ return cos(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return cos(m); }; 
};
struct h_tan
{ 
	static Matrix eval(const Matrix& m)			{ return tan(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return tan(m); }; 
};
struct h_cot
{ 
	static Matrix eval(const Matrix& m)			{ return cot(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return cot(m); }; 
};
struct h_sec
{ 
	static Matrix eval(const Matrix& m)			{ return sec(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return sec(m); }; 
};
struct h_csc
{ 
	static Matrix eval(const Matrix& m)			{ return csc(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return csc(m); }; 
};
struct h_asin
{ 
	static Matrix eval(const Matrix& m)			{ return asin(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return asin(m,true); }; 
};
struct h_asin_nc
{ 
	static Matrix eval(const Matrix& m)			{ return asin(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return asin(m,false); }; 
};
struct h_acos
{ 
	static Matrix eval(const Matrix& m)			{ return acos(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acos(m,true); }; 
};
struct h_acos_nc
{ 
	static Matrix eval(const Matrix& m)			{ return acos(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acos(m,false); }; 
};
struct h_atan
{ 
	static Matrix eval(const Matrix& m)			{ return atan(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return atan(m); }; 
};
struct h_acot
{ 
	static Matrix eval(const Matrix& m)			{ return acot(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acot(m); }; 
};
struct h_asec
{ 
	static Matrix eval(const Matrix& m)			{ return asec(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return asec(m,true); }; 
};
struct h_asec_nc
{ 
	static Matrix eval(const Matrix& m)			{ return asec(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return asec(m,false); }; 
};
struct h_acsc
{ 
	static Matrix eval(const Matrix& m)			{ return acsc(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acsc(m,true); }; 
};
struct h_acsc_nc
{ 
	static Matrix eval(const Matrix& m)			{ return acsc(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acsc(m,false); }; 
};
struct h_sinh
{ 
	static Matrix eval(const Matrix& m)			{ return sinh(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return sinh(m); }; 
};
struct h_cosh
{ 
	static Matrix eval(const Matrix& m)			{ return cosh(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return cosh(m); }; 
};
struct h_tanh
{ 
	static Matrix eval(const Matrix& m)			{ return tanh(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return tanh(m); }; 
};
struct h_coth
{ 
	static Matrix eval(const Matrix& m)			{ return coth(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return coth(m); }; 
};
struct h_sech
{	
	static Matrix eval(const Matrix& m)			{ return sech(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return sech(m); }; 
};
struct h_csch
{ 
	static Matrix eval(const Matrix& m)			{ return csch(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return csch(m); }; 
};
struct h_asinh
{ 
	static Matrix eval(const Matrix& m)			{ return asinh(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return asinh(m); }; 
};
struct h_acosh
{ 
	static Matrix eval(const Matrix& m)			{ return acosh(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acosh(m,true); }; 
};
struct h_acosh_nc
{ 
	static Matrix eval(const Matrix& m)			{ return acosh(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acosh(m,false); }; 
};
struct h_atanh
{ 
	static Matrix eval(const Matrix& m)			{ return atanh(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return atanh(m,true); }; 
};
struct h_atanh_nc
{ 
	static Matrix eval(const Matrix& m)			{ return atanh(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return atanh(m,false); }; 
};
struct h_acoth
{ 
	static Matrix eval(const Matrix& m)			{ return acoth(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acoth(m,true); }; 
};
struct h_acoth_nc
{ 
	static Matrix eval(const Matrix& m)			{ return acoth(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acoth(m,false); }; 
};
struct h_asech
{ 
	static Matrix eval(const Matrix& m)			{ return asech(m,true); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return asech(m,true); }; 
};
struct h_asech_nc
{ 
	static Matrix eval(const Matrix& m)			{ return asech(m,false); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return asech(m,false); }; 
};
struct h_acsch
{ 
	static Matrix eval(const Matrix& m)			{ return acsch(m); }; 
	template<class T>
	static Matrix eval_scal(T m)				{ return acsch(m); }; 
};

template<class func_helper>
class scal_func : public unary_function
{
	public:
		virtual Real eval_mat(const Matrix& mat,bool,int code )
		{
            (void)code;
			Matrix out_full = func_helper::eval(full(mat));
			try
			{		
                enums::mat_type nt = matrix_traits::get_matrix_type(enums::value_complex,mat.struct_type());
                Matrix mat_c    = convert(mat,nt);
				Matrix out		= func_helper::eval(mat);
                Matrix out_c	= func_helper::eval(mat_c);
                out.check_struct();
                Real dif        = norm_1(out - out_full);
                dif             += norm_1(out - out_c)/(norm_1(out) + constants::Eps);
                return dif;
			}
			catch(const std::exception& ex)
			{
				m_is_error = true;
				m_error = ex.what();
				return 1.;
			}
			catch(...)
			{
				m_is_error = true;
				m_error = "unknown error";
				return 1.;
			};
		};
		virtual Real eval_scalar(const Scalar& mat,bool,int code )
		{
            (void)code;
			switch (mat.value_type())
			{
				case enums::value_integer:
				{
					Integer val = mat.get_int();
					return norm_1(func_helper::eval_scal(val) - func_helper::eval(val));
				}
				case enums::value_real:
				{
					Real val		= mat.get_real();
					Complex val_c	= val;
					Real dif		= norm_1(func_helper::eval_scal(val) - func_helper::eval(val));
					dif				+=norm_1(func_helper::eval_scal(val) - func_helper::eval_scal(val_c));
					return dif;
				}
				case enums::value_complex:
				{
					Complex val = mat.get_complex();
					return norm_1(func_helper::eval_scal(val) - func_helper::eval(val));
				}
				default:
				{
					return 0;
				}
			};
		};
};

typedef unary_function tf;
typedef const char* ccp;

static const char* str_isstrue = "is_scalar_true";
static const char* str_issfals = "is_scalar_false";

struct function_vec		{ ccp name() { return "vec";};		scal_func<h_vec> f;		tf* function() { return &f;}; };
struct function_trans	{ ccp name() { return "trans";};	scal_func<h_trans> f;	tf* function() { return &f;}; };
struct function_ctrans	{ ccp name() { return "ctrans";};	scal_func<h_ctrans> f;	tf* function() { return &f;}; };			
struct function_real	{ ccp name() { return "real";};		scal_func<h_real> f;	tf* function() { return &f;}; };
struct function_imag	{ ccp name() { return "imag";};		scal_func<h_imag> f;	tf* function() { return &f;}; };			
struct function_abs		{ ccp name() { return "abs";};		scal_func<h_abs> f;		tf* function() { return &f;}; };
struct function_arg		{ ccp name() { return "arg";};		scal_func<h_arg> f;		tf* function() { return &f;}; };
struct function_angle	{ ccp name() { return "angle";};	scal_func<h_angle> f;	tf* function() { return &f;}; };
struct function_conj	{ ccp name() { return "conj";};		scal_func<h_conj> f;	tf* function() { return &f;}; };			
struct function_flipud	{ ccp name() { return "flipud";};	scal_func<h_flipud> f;	tf* function() { return &f;}; };
struct function_fliplr	{ ccp name() { return "fliplr";};	scal_func<h_fliplr> f;	tf* function() { return &f;}; };			
struct function_sqrt	{ ccp name() { return "sqrt";};		scal_func<h_sqrt> f;	tf* function() { return &f;}; };
struct function_pow2	{ ccp name() { return "pow2";};		scal_func<h_pow2> f;	tf* function() { return &f;}; };			
struct function_exp		{ ccp name() { return "exp";};		scal_func<h_exp> f;		tf* function() { return &f;}; };
struct function_log		{ ccp name() { return "log";};		scal_func<h_log> f;		tf* function() { return &f;}; };
struct function_log2	{ ccp name() { return "log2";};		scal_func<h_log2> f;	tf* function() { return &f;}; };
struct function_log10	{ ccp name() { return "log10";};	scal_func<h_log10> f;	tf* function() { return &f;}; };			
struct function_floor	{ ccp name() { return "floor";};	scal_func<h_floor> f;	tf* function() { return &f;}; };
struct function_ceil	{ ccp name() { return "ceil";};		scal_func<h_ceil> f;	tf* function() { return &f;}; };			
struct function_round	{ ccp name() { return "round";};	scal_func<h_round> f;	tf* function() { return &f;}; };
struct function_fix		{ ccp name() { return "fix";};		scal_func<h_fix> f;		tf* function() { return &f;}; };
struct function_trunc	{ ccp name() { return "trunc";};	scal_func<h_trunc> f;	tf* function() { return &f;}; };

struct function_ifloor	{ ccp name() { return "ifloor";};	scal_func<h_ifloor> f;	tf* function() { return &f;}; };
struct function_iceil	{ ccp name() { return "iceil";};	scal_func<h_iceil> f;	tf* function() { return &f;}; };			
struct function_iround	{ ccp name() { return "iround";};	scal_func<h_iround> f;	tf* function() { return &f;}; };
struct function_ifix	{ ccp name() { return "ifix";};		scal_func<h_ifix> f;	tf* function() { return &f;}; };
struct function_itrunc	{ ccp name() { return "itrunc";};	scal_func<h_itrunc> f;	tf* function() { return &f;}; };
struct function_isinf	{ ccp name() { return "is_inf";};	scal_func<h_isinf> f;	tf* function() { return &f;}; };
struct function_isnan	{ ccp name() { return "is_nan";};	scal_func<h_isnan> f;	tf* function() { return &f;}; };
struct function_isfin	{ ccp name() { return "is_finite";};scal_func<h_isfin> f;	tf* function() { return &f;}; };
struct function_isstrue	{ ccp name() { return str_isstrue;};scal_func<h_isstrue> f;	tf* function() { return &f;}; };
struct function_issfalse{ ccp name() { return str_issfals;};scal_func<h_issfalse> f;tf* function() { return &f;}; };

struct function_sign	{ ccp name() { return "sign";};		scal_func<h_sign> f;	tf* function() { return &f;}; };			
struct function_sin		{ ccp name() { return "sin";};		scal_func<h_sin> f;		tf* function() { return &f;}; };
struct function_cos		{ ccp name() { return "cos";};		scal_func<h_cos> f;		tf* function() { return &f;}; };
struct function_tan		{ ccp name() { return "tan";};		scal_func<h_tan> f;		tf* function() { return &f;}; };
struct function_cot		{ ccp name() { return "cot";};		scal_func<h_cot> f;		tf* function() { return &f;}; };
struct function_sec		{ ccp name() { return "sec";};		scal_func<h_sec> f;		tf* function() { return &f;}; };
struct function_csc		{ ccp name() { return "csc";};		scal_func<h_csc> f;		tf* function() { return &f;}; };
struct function_asin	{ ccp name() { return "asin";};		scal_func<h_asin> f;	tf* function() { return &f;}; };
struct function_acos	{ ccp name() { return "acos";};		scal_func<h_acos> f;	tf* function() { return &f;}; };			
struct function_atan	{ ccp name() { return "atan";};		scal_func<h_atan> f;	tf* function() { return &f;}; };
struct function_acot	{ ccp name() { return "acot";};		scal_func<h_acot> f;	tf* function() { return &f;}; };			
struct function_asec	{ ccp name() { return "asec";};		scal_func<h_asec> f;	tf* function() { return &f;}; };
struct function_acsc	{ ccp name() { return "acsc";};		scal_func<h_acsc> f;	tf* function() { return &f;}; };			
struct function_sinh	{ ccp name() { return "sinh";};		scal_func<h_sinh> f;	tf* function() { return &f;}; };
struct function_cosh	{ ccp name() { return "cosh";};		scal_func<h_cosh> f;	tf* function() { return &f;}; };			
struct function_tanh	{ ccp name() { return "tanh";};		scal_func<h_tanh> f;	tf* function() { return &f;}; };
struct function_coth	{ ccp name() { return "coth";};		scal_func<h_coth> f;	tf* function() { return &f;}; };			
struct function_sech	{ ccp name() { return "sech";};		scal_func<h_sech> f;	tf* function() { return &f;}; };
struct function_csch	{ ccp name() { return "csch";};		scal_func<h_csch> f;	tf* function() { return &f;}; };			
struct function_asinh	{ ccp name() { return "asinh";};	scal_func<h_asinh> f;	tf* function() { return &f;}; };
struct function_acosh	{ ccp name() { return "acosh";};	scal_func<h_acosh> f;	tf* function() { return &f;}; };			
struct function_atanh	{ ccp name() { return "atanh";};	scal_func<h_atanh> f;	tf* function() { return &f;}; };
struct function_acoth	{ ccp name() { return "acoth";};	scal_func<h_acoth> f;	tf* function() { return &f;}; };			
struct function_asech	{ ccp name() { return "asech";};	scal_func<h_asech> f;	tf* function() { return &f;}; };
struct function_acsch	{ ccp name() { return "acsch";};	scal_func<h_acsch> f;	tf* function() { return &f;}; };

struct function_sqrt_nc	{ ccp name() { return "sqrt_nc";};	scal_func<h_sqrt_nc> f;	tf* function() { return &f;}; };
struct function_log_nc	{ ccp name() { return "log_nc";};	scal_func<h_log_nc> f;	tf* function() { return &f;}; };
struct function_log2_nc	{ ccp name() { return "log_nc2";};	scal_func<h_log2_nc> f;	tf* function() { return &f;}; };
struct function_log10_nc{ ccp name() { return "log10_nc";};	scal_func<h_log10_nc> f;tf* function() { return &f;}; };			
struct function_asin_nc	{ ccp name() { return "asin_nc";};	scal_func<h_asin_nc> f;	tf* function() { return &f;}; };
struct function_acos_nc	{ ccp name() { return "acos_nc";};	scal_func<h_acos_nc> f;	tf* function() { return &f;}; };			
struct function_asec_nc	{ ccp name() { return "asec_nc";};	scal_func<h_asec_nc> f;	tf* function() { return &f;}; };
struct function_acsc_nc	{ ccp name() { return "acsc_nc";};	scal_func<h_acsc_nc> f;	tf* function() { return &f;}; };			
struct function_acosh_nc{ ccp name() { return "acosh_nc";};	scal_func<h_acosh_nc> f;tf* function() { return &f;}; };			
struct function_atanh_nc{ ccp name() { return "atanh_nc";};	scal_func<h_atanh_nc> f;tf* function() { return &f;}; };
struct function_acoth_nc{ ccp name() { return "acoth_nc";};	scal_func<h_acoth_nc> f;tf* function() { return &f;}; };			
struct function_asech_nc{ ccp name() { return "asech_nc";};	scal_func<h_asech_nc> f;tf* function() { return &f;}; };

class test_function_lu_partial : public unary_function
{
	public:
		test_function_lu_partial() {};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_lu_rook : public unary_function
{
	public:
		test_function_lu_rook() {};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};
class test_function_lu_complete : public unary_function
{
	public:
		test_function_lu_complete() {};

		virtual Real eval_mat(const Matrix& mat,bool show_res,int code);
		virtual Real eval_scalar(const Scalar& s, bool show_res,int code);
};

};};