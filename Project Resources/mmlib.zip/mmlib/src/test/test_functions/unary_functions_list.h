/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <vector>
#include <string>
#include "mmlib/mmlib_header.h"
#include "matrix_set/matrix_set.h"

namespace mmlib { namespace test
{

class unary_functions_list
{
	private:
		const matrix_set&	m_tests;
        rand_matrix_ptr     m_rand;
		options				m_options;
	public:
		void		make(options opts);

		Matrix		get_matrix(int code) const;

	private:

		void		test_cat();

		void		test_get_diag();		void		test_tril();
		void		test_triu();			void		test_rot90();
		void		test_vec();				void		test_trans();
		void		test_ctrans();			void		test_real();
		void		test_imag();			void		test_abs();
		void		test_arg();				void		test_angle();
		void		test_conj();			void		test_flipud();
		void		test_fliplr();			void		test_sqrt();
		void		test_pow2();			void		test_exp();
		void		test_log();				void		test_log2();
		void		test_log10();			void		test_floor();
		void		test_ceil();			void		test_round();
		void		test_fix();				void		test_trunc();
		void		test_sign();			void		test_sin();
		void		test_cos();				void		test_tan();
		void		test_cot();				void		test_sec();
		void		test_csc();				void		test_asin();
		void		test_acos();			void		test_atan();
		void		test_acot();			void		test_asec();
		void		test_acsc();			void		test_sinh();
		void		test_cosh();			void		test_tanh();
		void		test_coth();			void		test_sech();
		void		test_csch();			void		test_asinh();
		void		test_acosh();			void		test_atanh();
		void		test_acoth();			void		test_asech();
		void		test_acsch();			void		test_sum();
		void		test_cumsum();			void		test_prod();
		void		test_cumprod();			void		test_sumsq();
		void		test_repmat();			void		test_min();
		void		test_max();				void		test_mean();
        void        test_min_abs();         void        test_max_abs();
		void		test_std();				void		test_reshape();
        void        test_nnz();

        void        test_sqrt_nc();         void        test_log_nc();
        void        test_log2_nc();         void        test_log10_nc();
        void        test_asin_nc();         void        test_acos_nc();
        void        test_asec_nc();         void        test_acsc_nc();
        void        test_acosh_nc();        void        test_atanh_nc();
        void        test_acoth_nc();        void        test_asech_nc();

		void		test_op_un_minus();		void		test_op_neg();			
		void		test_is_true();			void		test_is_false();		
		void		test_min2();			void		test_max2();
        void		test_min_abs2();		void		test_max_abs2();
		void		test_all();				void		test_any();
		void		test_ifloor();			void		test_iceil();
		void		test_iround();			void		test_ifix();
		void		test_itrunc();			void		test_is_inf();
		void		test_is_nan();			void		test_is_finite();
		void		test_is_scalar_true();	void		test_is_scalar_false();	
		
		void		test_find();
		void		test_find2();			void		test_find3();
		void		test_sort();			void		test_sort2();
		void		test_sortrows();		void		test_sortrows2();
		void		test_sortrows_dim();	void		test_sortrows2_dim();
		void		test_sortcols();		void		test_sortcols2();
		void		test_sortcols_dim();	void		test_sortcols2_dim();
		void		test_is_sorted();		void		test_is_sorted_rows();
		void		test_is_sorted_cols();  void		test_get_lu();

		void		test_convert();			void		test_get_scalar();
		void		test_get_array();		void		test_get_const_array();
		void		test_eval_func();

		void		test_sparse();			void		test_clone();
		void		test_constructors();    void		test_band();

		void		test_diag();			void		test_bdiag();
		void		test_spdiag();			void		test_bdiags();
		void		test_spdiags();			void		test_diags();

        void        test_resize_reserve();  void        test_resize_reserve_b();

		template<class Func>
		void		test_function();

	public:
		unary_functions_list(const matrix_set&,rand_matrix_ptr rand);

	private:
		unary_functions_list(const unary_functions_list&);
		unary_functions_list& operator=(const unary_functions_list&);
};

};};