/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "bin_functions_list.h"
#include <iostream>
#include "test_functions.h"
#include "data_struct/logger.h"

using namespace std;

namespace mmlib { namespace test
{

static const Integer max_int = 1000;

void bin_functions_list::make(options opts)
{
	m_options = opts;

	test_op_plus();
	test_op_minus();
    test_op_mult();	
    test_chain_mult();

	test_op_div();
	test_plus();
	test_minus();
	test_mul();
	test_div();
	test_idiv();
	test_pow();
    test_pow_nc();

	test_max_bin();
	test_min_bin();
	test_xor();
    test_kron();

	test_rem();
	test_mod();	
	test_op_or();
	test_op_and();

	test_op_eeq();
	test_op_neq();

	if (!matrices_with_nan)
	{
		test_op_lt();
		test_op_leq();
		test_op_gt();
		test_op_geq();	
	};	
	test_atan2();
};
void bin_functions_list::make_mult(options opts)
{
	m_options = opts;

	test_op_mult();	
    test_chain_mult();
	test_kron();
};
void bin_functions_list::make_kron(options opts)
{
	m_options = opts;

	test_kron();
};

bin_functions_list::matrix_pair bin_functions_list::get_matrix(int code) const
{
	return m_tests.get_matrix(code);
};
bin_functions_list::scalar_pair bin_functions_list::get_scalar(int code) const
{
	return m_tests.get_scalar(code);
};

void bin_functions_list::test_op_plus()
{
	Real out = 0.;
	test_function_op_plus tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator+: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator+: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_minus()
{
	Real out = 0.;
	test_function_op_minus tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator-: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator-: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_mult()
{
	Real out = 0.;
	test_function_op_mult tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator*: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator*: FAILED"  + "\n";
	};
};
void bin_functions_list::test_chain_mult()
{
	Real out = 0.;
	test_function_chain_mult tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "chain mult: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "chain mult: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_div()
{
	Real out = 0.;
	test_function_op_div tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator/: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator/: FAILED"  + "\n";
	};
};
void bin_functions_list::test_plus()
{
	Real out = 0.;
	test_function_plus tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "plus: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "plus: FAILED"  + "\n";
	};
};
void bin_functions_list::test_minus()
{
	Real out = 0.;
	test_function_minus tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "minus: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "minus: FAILED"  + "\n";
	};
};
void bin_functions_list::test_mul()
{
	Real out = 0.;
	test_function_mul tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "mul: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "mul: FAILED"  + "\n";
	};
};
void bin_functions_list::test_div()
{
	Real out = 0.;
	test_function_div tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "div: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "div: FAILED"  + "\n";
	};
};
void bin_functions_list::test_idiv()
{
	Real out = 0.;
	test_function_idiv tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "idiv: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "idiv: FAILED"  + "\n";
	};
};
void bin_functions_list::test_atan2()
{
	Real out = 0.;
	test_function_atan2 tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "atan2: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "atan2: FAILED"  + "\n";
	};
};

void bin_functions_list::test_pow()
{
	Real out = 0.;
	test_function_pow tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "pow: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "pow: FAILED"  + "\n";
	};
};
void bin_functions_list::test_pow_nc()
{
	Real out = 0.;
	test_function_pow_nc tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "pow_nc: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "pow_nc: FAILED"  + "\n";
	};
};

void bin_functions_list::test_max_bin()
{
	Real out = 0.;
	test_function_max_bin tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "bin max: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "bin max: FAILED"  + "\n";
	};
};
void bin_functions_list::test_min_bin()
{
	Real out = 0.;
	test_function_min_bin tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "bin min: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "bin min: FAILED"  + "\n";
	};
};
void bin_functions_list::test_xor()
{
	Real out = 0.;
	test_function_xor tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "xor: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "xor: FAILED"  + "\n";
	};
};
void bin_functions_list::test_rem()
{
	Real out = 0.;
	test_function_rem tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "rem: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "rem: FAILED"  + "\n";
	};
};
void bin_functions_list::test_mod()
{
	Real out = 0.;
	test_function_mod tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "mod: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "mod: FAILED"  + "\n";
	};
};
void bin_functions_list::test_kron()
{
	Real out = 0.;
	test_function_kron tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "kron: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "krow: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_or()
{
	Real out = 0.;
	test_function_op_or tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator|: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator|: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_and()
{
	Real out = 0.;
	test_function_op_and tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator&: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator&: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_eeq()
{
	Real out = 0.;
	test_function_op_eeq tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator==: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator==: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_neq()
{
	Real out = 0.;
	test_function_op_neq tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator!=: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator!=: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_lt()
{
	Real out = 0.;
	test_function_op_lt tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator<: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator<: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_leq()
{
	Real out = 0.;
	test_function_op_leq tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator<=: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator<=: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_gt()
{
	Real out = 0.;
	test_function_op_gt tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator>: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator>: FAILED"  + "\n";
	};
};
void bin_functions_list::test_op_geq()
{
	Real out = 0.;
	test_function_op_geq tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator>=: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator>=: FAILED"  + "\n";
	};
};


};};