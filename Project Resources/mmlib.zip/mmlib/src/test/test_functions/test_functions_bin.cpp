/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "test_functions.h"
#include "mmlib/archive.h"

namespace mmlib { namespace test
{

static Real to_real(Integer val)
{
	return val;
};
static Real to_real(Real val)
{
	return val;
};
static Complex to_real(Complex val)
{
	return val;
};

Real test_function_op_plus::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = full(mat1) + full(mat2);	

	try
	{		
		Matrix out		= mat1+mat2;
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				= dif + norm_1(mat2+mat1-out);
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_plus::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_op_minus::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = full(mat1) - full(mat2);	

	try
	{		
		Matrix out		= mat1 - mat2;
        out.check_struct();
		Real dif		= norm_1(out - out_full);

		Matrix out2		= mat2 - mat1;
        out2.check_struct();
		dif				+= norm_1(out - (-out2));
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_minus::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_op_mult::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	if ((mat1.cols() != mat2.rows()) )
	{
		return 0.;
	};

	Matrix out_full = full(mat1) * full(mat2);	

	try
	{		
		Matrix out		= mat1 * mat2;
        out.check_struct();

		Real dif		= norm_1(out - out_full);
        dif             = dif/(norm_1(out)+1e-15);
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		if (mmlib::abs(dif) < 1e-12)
		{
			dif = 0;
		};
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_mult::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_chain_mult::eval_mat(const Matrix& mat0,const Matrix& mat2, int )
{
	if ((mat0.cols() != mat2.rows()) )
	{
		return 0.;
	};

	try
	{
        Matrix mat1 = mat0 + 0.;

	    Matrix out_full_1 = full(mat1) * full(mat2);
        Matrix out_full_2 = out_full_1 * full(trans(mat2)) * full(trans(mat1));
        Matrix out_full_3 = out_full_2 * full(mat1) * full(mat2);

		Matrix out_1	= chain_mult(mat1,mat2);
        Matrix out_2	= chain_mult(mat1,mat2,trans(mat2),trans(mat1));
        Matrix out_3	= chain_mult(mat1,mat2,trans(mat2),trans(mat1),mat1,mat2);

        out_1.check_struct();
        out_2.check_struct();
        out_3.check_struct();

		Real dif		= norm_1(out_1 - out_full_1);
        dif             = dif/(norm_1(out_1)+1e-15);
		dif				+= check_value_type(out_1,out_full_1);

		if (mmlib::abs(dif) < 1e-12)
		{
			dif = 0;
		}
        else
        {
		    return dif;
        }

		dif		        = norm_1(out_2 - out_full_2);
        dif             = dif/(norm_1(out_2)+1e-15);
		//dif			+= check_value_type(out_2,out_full_2);

		if (mmlib::abs(dif) < 1e-12)
		{
			dif = 0;
		}
        else
        {
		    return dif;
        }

		dif		        = norm_1(out_3 - out_full_3);
        dif             = dif/(norm_1(out_3)+1e-15);
		//dif			+= check_value_type(out_3,out_full_3);

		if (mmlib::abs(dif) < 1e-12)
		{
			dif = 0;
		};
		return dif;

	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_chain_mult::eval_scalar(const Scalar& , const Scalar& , int )
{
    return 0;
};

Real test_function_op_div::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	if (!mat2.is_scalar())
	{
		return 0.;
	};
	Matrix out_full = full(mat1) / full(mat2);	

	try
	{		
		Matrix out		= mat1 / mat2;
        out.check_struct();
		Real dif		= norm_1(out - out_full);
        if (is_scalar_true(mat2 != 0) && is_finite(mat2).is_scalar_true())
		{
			dif			= dif + norm_1(out*mat2-mat1);
		};
		if (abs(dif) <= 10000.*constants::Eps*norm_1(mat1))
		{
			dif = 0;
		};;
		dif				+= check_value_type(mat1,mat2,out,enums::value_real);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_div::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{	
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_plus::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = plus(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= plus(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+=norm_1(out - (mat1+mat2));
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_plus::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_minus::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = minus(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= minus(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+=norm_1(out - (mat1-mat2));
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_minus::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_mul::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = mul(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= mul(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				= dif + norm_1(out - mul(mat2,mat1));
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_mul::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_div::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = div(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= div(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		if (abs(dif) < 1e-9)
		{
			dif			= 0;
		};
		dif				+= check_value_type(mat1,mat2,out,enums::value_real);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_div::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_idiv::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = idiv(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= idiv(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_idiv::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_pow::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = pow(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= pow(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= check_value_type(mat1,mat2,out,enums::value_real);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_pow::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_pow_nc::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = pow_nc(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= pow_nc(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= check_value_type(mat1,mat2,out,enums::value_real);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_pow_nc::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_max_bin::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = max(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= max(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - max(mat2,mat1));
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_max_bin::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_min_bin::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = min(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= min(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - min(mat2,mat1));
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_min_bin::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_xor::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = xor(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= xor(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - xor(mat2,mat1));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_xor::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_rem::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = rem(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= rem(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_rem::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_mod::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = mod(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= mod(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_mod::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_kron::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = kron(full(mat1),full(mat2));	

	try
	{		
		Matrix out		= kron(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= check_value_type(mat1,mat2,out,enums::value_integer);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_kron::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_op_or::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = (full(mat1)|full(mat2));	

	try
	{		
		Matrix out		= (mat1|mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - (mat2|mat1));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_or::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_op_and::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = (full(mat1)&full(mat2));	

	try
	{		
		Matrix out		= (mat1&mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out -(mat2&mat1));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_and::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_op_eeq::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = (full(mat1)==full(mat2));	

	try
	{		
		Matrix out		= (mat1 == mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - (mat2==mat1));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_eeq::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_op_neq::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = (full(mat1)!=full(mat2));	

	try
	{		
		Matrix out		= (mat1 != mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - (mat2!=mat1));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_neq::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_op_lt::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = (full(mat1) < full(mat2));	

	try
	{		
		Matrix out		= (mat1 < mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - ~(mat1>=mat2));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_lt::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_op_leq::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = (full(mat1) <= full(mat2));	

	try
	{		
		Matrix out		= (mat1 <= mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - ~(mat1>mat2));
		dif				+= norm_1(out - ~(mat2<mat1));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_leq::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_op_gt::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = (full(mat1) > full(mat2));	

	try
	{		
		Matrix out		= (mat1 > mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - (mat2<mat1));
		dif				+= norm_1(out - ~(mat1<=mat2));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_gt::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_op_geq::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	Matrix out_full = (full(mat1) >= full(mat2));	

	try
	{		
		Matrix out		= (mat1 >= mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out - ~(mat1<mat2));
		dif				+= norm_1(out - (mat2<=mat1));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_geq::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_atan2::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	
	Matrix out_full;

	try
	{
		out_full = atan2(full(mat1),full(mat2));	
	}
	catch(...)
	{
		return 0;
	};

	try
	{		
		Matrix out		= atan2(mat1,mat2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
        if (abs(dif - constants::pi) < 1e-15)
        {
            dif = 0;
        };
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_atan2::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};


Real test_function_serialize2::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	try
	{	
		Real dif = 0;

		{
			std::ostringstream ss;
			ss.precision(15);
			oarchive ia(ss);
            save(ia,mat1);
            save(ia,mat2);

			Matrix tmp1, tmp2;
			std::istringstream ss2(ss.str());
			iarchive ia2(ss2);
            load(ia2,tmp1);
            load(ia2,tmp2);

            tmp1.check_struct();
            tmp2.check_struct();
			
			dif += norm_1(mat1 - tmp1);
			dif += norm_1(mat2 - tmp2);
		};
		{
			std::ostringstream ss;
			ss.precision(15);
			oarchive ia(ss);
            save(ia,mat1);
            save(ia,mat2);
            save(ia,mat1);
            save(ia,mat2);

			Matrix tmp1, tmp2, tmp3, tmp4;
			std::istringstream ss2(ss.str());
			iarchive ia2(ss2);
            load(ia2,tmp1);
            load(ia2,tmp2);
            load(ia2,tmp3);
            load(ia2,tmp4);

            tmp1.check_struct();
            tmp2.check_struct();
            tmp3.check_struct();
            tmp4.check_struct();
			
			dif += norm_1(mat1 - tmp1);
			dif += norm_1(mat2 - tmp2);
			dif += norm_1(mat1 - tmp3);
			dif += norm_1(mat2 - tmp4);
		};
		if (abs(dif)<1e-10)
		{
			dif = 0;
		};
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_serialize2::eval_scalar(const Scalar&, const Scalar&, int )
{
	return 0;
};



Real test_function_io_formatted2::eval_mat(const Matrix& mat1,const Matrix& mat2, int )
{
	try
	{	
		Real dif = 0;

		{
			std::ostringstream ss;
			ss.precision(15);
			ss<<mat1;
			ss<<mat2;

			Matrix tmp1,tmp2;
			std::istringstream ss2(ss.str());
            ss2>>tmp1;
            ss2>>tmp2;

            tmp1.check_struct();
            tmp2.check_struct();
			
			dif += norm_1(mat1 - tmp1);
			dif += norm_1(mat2 - tmp2);
		};
		if (abs(dif)<1e-10)
		{
			dif = 0;
		};
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};

Real test_function_io_formatted2::eval_scalar(const Scalar& s1, const Scalar& s2, int )
{
	switch(s1.value_type()*3+s2.value_type())
	{
		case enums::value_integer*3+enums::value_integer:
		{
			Integer value1 = s1.get_int();
			Integer value2 = s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_real:
		{
			Integer value1	= s1.get_int();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_integer*3+enums::value_complex:
		{
			Integer value1	= s1.get_int();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_integer:
		{
			Real value1		= s1.get_real();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_real:
		{
			Real value1		= s1.get_real();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_real*3+enums::value_complex:
		{
			Real value1		= s1.get_real();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_integer:
		{
			Complex value1	= s1.get_complex();
			Integer value2	= s2.get_int();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_real:
		{
			Complex value1	= s1.get_complex();
			Real value2		= s2.get_real();
			return eval_scal_func(value1,value2);
		}
		case enums::value_complex*3+enums::value_complex:
		{
			Complex value1	= s1.get_complex();
			Complex value2	= s2.get_complex();
			return eval_scal_func(value1,value2);
		}
		default:
		{
			return 0;
		}
	};
};

};};