/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <vector>
#include <string>
#include "mmlib/mmlib_header.h"
#include "matrix_set/matrix_set.h"

namespace mmlib { namespace test
{

class bin_functions_list
{
	public:
		typedef matrix_set_bin::matrix_pair matrix_pair;
		typedef matrix_set_bin::scalar_pair scalar_pair;

	private:
		const matrix_set_bin&	m_tests;
		options					m_options;
		bool					matrices_with_nan;

	public:
		bin_functions_list(const matrix_set_bin& t,bool matrices_with_nan) 
								: m_tests(t),matrices_with_nan(matrices_with_nan){};

		void			make(options opts);
		void			make_mult(options opts);
		void			make_kron(options opts);

		matrix_pair		get_matrix(int code) const;
		scalar_pair		get_scalar(int code) const;

	private:

		void		test_op_plus();
		void		test_op_minus();		void		test_op_mult();
		void		test_op_div();			void		test_plus();
		void		test_minus();			void		test_mul();
		void		test_div();				void		test_pow();
		void		test_max_bin();			void		test_min_bin();
		void		test_xor();				void		test_rem();
		void		test_mod();				void		test_kron();
        void        test_pow_nc();
		
		void		test_op_or();
		void		test_op_and();			void		test_op_eeq();
		void		test_op_neq();			void		test_op_lt();
		void		test_op_leq();			void		test_op_gt();
		void		test_op_geq();			void		test_idiv();
		void		test_atan2();           void		test_chain_mult();

	private:
		bin_functions_list(const bin_functions_list&);
		bin_functions_list& operator=(const bin_functions_list&);
};
};};