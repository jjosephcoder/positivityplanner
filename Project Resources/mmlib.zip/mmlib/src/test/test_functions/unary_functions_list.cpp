/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#include "unary_functions_list.h"
#include <iostream>
#include "test_functions.h"
#include "data_struct/logger.h"

using namespace std;

namespace mmlib { namespace test
{

static const Integer max_int = 1000;

unary_functions_list::unary_functions_list(const matrix_set& ms,rand_matrix_ptr rand)
:m_tests(ms), m_rand(rand)
{};

void unary_functions_list::make(options opts)
{
	m_options = opts;

    test_resize_reserve();
    test_resize_reserve_b();
    test_get_lu();
    test_nnz();

	test_sum();
	test_cumsum();
	test_prod();
	test_cumprod();
	test_sumsq();

	test_repmat();
	test_min();
	test_max();
	test_min_abs();
	test_max();
    test_max_abs();
	test_mean();
	test_std();

    test_cat();
    test_get_diag();
    test_tril();
    test_triu();    
    test_reshape();
    test_rot90();

	test_vec();
	test_trans();
	test_ctrans();
	test_real();
	test_imag();
	test_abs();
	test_arg();
	test_angle();
	test_conj();
	test_flipud();
	test_fliplr();

	test_sqrt();
	test_pow2();
	test_exp();
	test_log();
	test_log2();
	test_log10();
	test_floor();
	test_ceil();
	test_round();
	test_fix();
	test_trunc();
	test_sign();
	test_sin();
	test_cos();
	test_tan();
	test_cot();
	test_sec();
	test_csc();
	test_asin();
	test_acos();
	test_atan();
	test_acot();
	test_asec();
	test_acsc();
	test_sinh();
	test_cosh();
	test_tanh();
	test_coth();
	test_sech();
	test_csch();
	test_asinh();
	test_acosh();
	test_atanh();
	test_acoth();
	test_asech();
	test_acsch();

    test_sqrt_nc();
    test_log_nc();
    test_log2_nc();
    test_log10_nc();
    test_asin_nc();
    test_acos_nc();
    test_asec_nc();
    test_acsc_nc();
    test_acosh_nc();
    test_atanh_nc();
    test_acoth_nc();
    test_asech_nc();

	test_op_un_minus();
	test_op_neg();
	test_is_true();
	test_is_false();
	test_ifloor();
	test_iceil();
	test_iround();
	test_ifix();
	test_itrunc();

	test_min2();
	test_max2();
	test_min_abs2();
	test_max_abs2();
	test_any();
	test_all();

	test_is_inf();
	test_is_nan();
	test_is_finite();
	test_is_scalar_true();
	test_is_scalar_false();	

	test_get_scalar();
	test_get_array();
    test_get_const_array();

	test_convert();
	test_eval_func();
	test_sparse();
    test_band();
	test_clone();
	test_constructors();

	test_diag();
	test_bdiag();
    test_spdiag();
	test_diags();
	test_bdiags();
	test_spdiags();
	
	test_find();
	test_find2();
	test_find3();

    test_sort();
	test_sort2();
	test_sortrows();
	test_sortrows2();
	test_sortcols();
	test_sortcols2();

	test_sortrows_dim();
	test_sortrows2_dim();
	test_sortcols_dim();
	test_sortcols2_dim();
	test_is_sorted();
	test_is_sorted_cols();
	test_is_sorted_rows();
};
Matrix unary_functions_list::get_matrix(int code) const
{
	return m_tests.get_matrix(code);
};

void unary_functions_list::test_get_diag()
{
	Real out = 0.;
	{
		test_function_get_diag tf(0);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_get_diag tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_get_diag tf(-1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_get_diag tf(3);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_get_diag tf(-3);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() + "get_diag: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "get_diag: FAILED"  + "\n";
	};
};
void unary_functions_list::test_nnz()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_nnz tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "nnz: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "nnz: FAILED"  + "\n";
	};
};
void unary_functions_list::test_tril()
{
	Real out = 0.;
	{
		test_function_tril tf(0);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_tril tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_tril tf(-1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_tril tf(3);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_tril tf(-3);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() + "tril: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "tril: FAILED"  + "\n";
	};
};
void unary_functions_list::test_triu()
{
	Real out = 0.;
	{
		test_function_triu tf(0);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_triu tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_triu tf(-1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_triu tf(3);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_triu tf(-3);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() + "triu: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "triu: FAILED"  + "\n";
	};
};
void unary_functions_list::test_rot90()
{
	Real out = 0.;
	{
		test_function_rot90 tf(0);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_rot90 tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_rot90 tf(2);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_rot90 tf(3);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_rot90 tf(4);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() + "rot90: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "rot90: FAILED"  + "\n";
	};
};
void unary_functions_list::test_reshape()
{
	Real out = 0.;

	test_function_reshape tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() + "reshape: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "reshape: FAILED"  + "\n";
	};
};
void unary_functions_list::test_cat()
{
	Real out = 0.;
    Integer seed = 100;

	for (int i = 0; i <= 1; i++)
	{
		{
			test_function_cat tf(0,0,0,i,m_rand,seed);
			out += m_tests.make(&tf,m_options);
		};
		{
			test_function_cat tf(1,1,1,i,m_rand,seed);
			out += m_tests.make(&tf,m_options);
		};
		{
			test_function_cat tf(1,2,2,i,m_rand,seed);
			out += m_tests.make(&tf,m_options);
		};
		{
			test_function_cat tf(1,3,3,i,m_rand,seed);
			out += m_tests.make(&tf,m_options);
		};
		{
			test_function_cat tf(2,1,1,i,m_rand,seed);
			out += m_tests.make(&tf,m_options);
		};
		{
			test_function_cat tf(2,2,2,i,m_rand,seed);
			out += m_tests.make(&tf,m_options);
		};
		{
			test_function_cat tf(2,3,3,i,m_rand,seed);
			out += m_tests.make(&tf,m_options);
		};
		{
			test_function_cat tf(2,3,6,i,m_rand,seed);
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() + "cat: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "cat: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sum()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_sum tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "sum: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "sum: FAILED"  + "\n";
	};
};
void unary_functions_list::test_cumsum()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_cumsum tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "cumsum: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "cumsum: FAILED"  + "\n";
	};
};
void unary_functions_list::test_prod()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_prod tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "prod: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "prod: FAILED"  + "\n";
	};
};
void unary_functions_list::test_cumprod()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_cumprod tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "cumprod: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "cumprod: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sumsq()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_sumsq tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "sumsq: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "sumsq: FAILED"  + "\n";
	};
};
void unary_functions_list::test_min()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_min tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "min: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "min: FAILED"  + "\n";
	};
};
void unary_functions_list::test_min_abs()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_min_abs tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "min_abs: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "min_abs: FAILED"  + "\n";
	};
};
void unary_functions_list::test_min2()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_min2 tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "min2: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "min2: FAILED"  + "\n";
	};
};
void unary_functions_list::test_min_abs2()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_min_abs2 tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "min_abs2: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "min_abs2: FAILED"  + "\n";
	};
};
void unary_functions_list::test_max()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_max tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "max: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "max: FAILED"  + "\n";
	};
};
void unary_functions_list::test_max_abs()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_max_abs tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "max_abs: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "max_abs: FAILED"  + "\n";
	};
};
void unary_functions_list::test_max2()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_max2 tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "max2: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "max2: FAILED"  + "\n";
	};
};	
void unary_functions_list::test_max_abs2()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_max_abs2 tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() + "max_abs2: OK" + "\n";
	}
	else
	{
		logger() << std::string() + "max_abs2: FAILED"  + "\n";
	};
};	
void unary_functions_list::test_mean()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_mean tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "mean: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "mean: FAILED"  + "\n";
	};
};
void unary_functions_list::test_std()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_std tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "std: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "std: FAILED"  + "\n";
	};
};
void unary_functions_list::test_is_inf()
{
	return test_function<function_isinf>();
};
void unary_functions_list::test_is_nan()
{
	return test_function<function_isnan>();
};
void unary_functions_list::test_is_finite()
{
	return test_function<function_isfin>();
};
void unary_functions_list::test_is_scalar_true()
{
	return test_function<function_isstrue>();
};
void unary_functions_list::test_is_scalar_false()
{
	return test_function<function_issfalse>();
};	
void unary_functions_list::test_op_un_minus()
{
	Real out = 0.;
	test_function_op_un_minus tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator-: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator-: FAILED"  + "\n";
	};
};		
void unary_functions_list::test_op_neg()
{
	Real out = 0.;
	test_function_op_neg tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "operator~: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "operator~: FAILED"  + "\n";
	};
};			
void unary_functions_list::test_is_true()
{
	Real out = 0.;
	test_function_is_true tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "is_true: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "is_true: FAILED"  + "\n";
	};
};
void unary_functions_list::test_is_false()
{
	Real out = 0.;
	test_function_is_false tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "is_false: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "is_false: FAILED"  + "\n";
	};
};

void unary_functions_list::test_all()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_all tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "all: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "all: FAILED"  + "\n";
	};
};
void unary_functions_list::test_any()
{
	Real out = 0.;
	for (int i = 1; i <= 2; i++)
	{
		test_function_any tf(i);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "any: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "any: FAILED"  + "\n";
	};
};

void unary_functions_list::test_repmat()
{
	Real out = 0.;
	for (int j = 1; j <= 2; j++)
	{
		for (int i = 1; i <= 2; i++)
		{
			test_function_repmat tf(i,j);
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() +   "repmat: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "repmat: FAILED"  + "\n";
	};
};
template<class Func>
void unary_functions_list::test_function()
{
	Real out = 0.;
	Func func;
	out = m_tests.make(func.function(),m_options);


	if (out == 0.)
	{
		logger() << std::string() +   func.name() + ": OK" + "\n";
	}
	else
	{
		logger() << std::string() +   func.name() + ": FAILED"  + "\n";
	};
};
void unary_functions_list::test_vec()
{
	return test_function<function_vec>();
};
void unary_functions_list::test_trans()
{
	return test_function<function_trans>();
};
void unary_functions_list::test_ctrans()
{
	return test_function<function_ctrans>();
};;			
void unary_functions_list::test_real()
{
	return test_function<function_real>();
};;
void unary_functions_list::test_imag()
{
	return test_function<function_imag>();
};;			
void unary_functions_list::test_abs()
{
	return test_function<function_abs>();
};;
void unary_functions_list::test_arg()
{
	return test_function<function_arg>();
};;
void unary_functions_list::test_angle()
{
	return test_function<function_angle>();
};;
void unary_functions_list::test_conj()
{
	return test_function<function_conj>();
};;			
void unary_functions_list::test_flipud()
{
	return test_function<function_flipud>();
};;
void unary_functions_list::test_fliplr()
{
	return test_function<function_fliplr>();
};;			
void unary_functions_list::test_sqrt()
{
	return test_function<function_sqrt>();
};;
void unary_functions_list::test_pow2()
{
	return test_function<function_pow2>();
};;			
void unary_functions_list::test_exp()
{
	return test_function<function_exp>();
};;
void unary_functions_list::test_log()
{
	return test_function<function_log>();
};;
void unary_functions_list::test_log2()
{
	return test_function<function_log2>();
};;
void unary_functions_list::test_log10()
{
	return test_function<function_log10>();
};;			
void unary_functions_list::test_floor()
{
	return test_function<function_floor>();
};;
void unary_functions_list::test_ceil()
{
	return test_function<function_ceil>();
};;			
void unary_functions_list::test_round()
{
	return test_function<function_round>();
};;
void unary_functions_list::test_fix()
{
	return test_function<function_fix>();
};;
void unary_functions_list::test_trunc()
{
	return test_function<function_trunc>();
};;
void unary_functions_list::test_ifloor()
{
	return test_function<function_ifloor>();
};;
void unary_functions_list::test_iceil()
{
	return test_function<function_iceil>();
};;
void unary_functions_list::test_iround()
{
	return test_function<function_iround>();
};;
void unary_functions_list::test_ifix()
{
	return test_function<function_ifix>();
};;
void unary_functions_list::test_itrunc()
{
	return test_function<function_itrunc>();
};;

void unary_functions_list::test_sign()
{
	return test_function<function_sign>();
};;			
void unary_functions_list::test_sin()
{
	return test_function<function_sin>();
};;
void unary_functions_list::test_cos()
{
	return test_function<function_cos>();
};;
void unary_functions_list::test_tan()
{
	return test_function<function_tan>();
};;
void unary_functions_list::test_cot()
{
	return test_function<function_cot>();
};;
void unary_functions_list::test_sec()
{
	return test_function<function_sec>();
};;
void unary_functions_list::test_csc()
{
	return test_function<function_csc>();
};;
void unary_functions_list::test_asin()
{
	return test_function<function_asin>();
};;
void unary_functions_list::test_acos()
{
	return test_function<function_acos>();
};;			
void unary_functions_list::test_atan()
{
	return test_function<function_atan>();
};;
void unary_functions_list::test_acot()
{
	return test_function<function_acot>();
};;			
void unary_functions_list::test_asec()
{
	return test_function<function_asec>();
};;
void unary_functions_list::test_acsc()
{
	return test_function<function_acsc>();
};;			
void unary_functions_list::test_sinh()
{
	return test_function<function_sinh>();
};;
void unary_functions_list::test_cosh()
{
	return test_function<function_cosh>();
};;			
void unary_functions_list::test_tanh()
{
	return test_function<function_tanh>();
};;
void unary_functions_list::test_coth()
{
	return test_function<function_coth>();
};;			
void unary_functions_list::test_sech()
{
	return test_function<function_sech>();
};;
void unary_functions_list::test_csch()
{
	return test_function<function_csch>();
};;			
void unary_functions_list::test_asinh()
{
	return test_function<function_asinh>();
};;
void unary_functions_list::test_acosh()
{
	return test_function<function_acosh>();
};			
void unary_functions_list::test_atanh()
{
	return test_function<function_atanh>();
};
void unary_functions_list::test_acoth()
{
	return test_function<function_acoth>();
};			
void unary_functions_list::test_asech()
{
	return test_function<function_asech>();
};
void unary_functions_list::test_acsch()
{
	return test_function<function_acsch>();
};		

void unary_functions_list::test_sqrt_nc()
{
	return test_function<function_sqrt_nc>();
};		
void unary_functions_list::test_log_nc()
{
	return test_function<function_log_nc>();
};		
void unary_functions_list::test_log2_nc()
{
	return test_function<function_log2_nc>();
};		
void unary_functions_list::test_log10_nc()
{
	return test_function<function_log10_nc>();
};		
void unary_functions_list::test_asin_nc()
{
	return test_function<function_asin_nc>();
};		
void unary_functions_list::test_acos_nc()
{
	return test_function<function_acos_nc>();
};		
void unary_functions_list::test_asec_nc()
{
	return test_function<function_asec_nc>();
};		
void unary_functions_list::test_acsc_nc()
{
	return test_function<function_acsc_nc>();
};		
void unary_functions_list::test_acosh_nc()
{
	return test_function<function_acosh_nc>();
};		
void unary_functions_list::test_atanh_nc()
{
	return test_function<function_atanh_nc>();
};		
void unary_functions_list::test_acoth_nc()
{
	return test_function<function_acoth_nc>();
};		
void unary_functions_list::test_asech_nc()
{
	return test_function<function_asech_nc>();
};		

void unary_functions_list::test_find()
{
	Real out = 0.;
	test_function_find tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "find: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "find: FAILED"  + "\n";
	};
};
void unary_functions_list::test_find2()
{
	Real out = 0.;
	test_function_find2 tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "find2: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "find2: FAILED"  + "\n";
	};
};
void unary_functions_list::test_find3()
{
	Real out = 0.;
	test_function_find3 tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "find3: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "find3: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sort()
{
	Real out = 0.;
	for (int j = 1; j <= 2; j++)
	{
		for (int i = 1; i <= 2; i++)
		{
			bool is_asc = (j == 1);
			test_function_sort tf(i,is_asc);
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() +   "sort: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sort: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sort2()
{
	Real out = 0.;
	for (int j = 1; j <= 2; j++)
	{
		for (int i = 1; i <= 2; i++)
		{
			bool is_asc = (j == 1);
			test_function_sort2 tf(i,is_asc);
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() +   "sort2: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sort2: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sortrows()
{
	Real out = 0.;
	test_function_sortrows tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "sortrows: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sortrows: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sortrows2()
{
	Real out = 0.;
	test_function_sortrows2 tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "sortrows2: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sortrows2: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sortrows_dim()
{
	Real out = 0.;

	{
		Matrix dim = mat_row();
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 3);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 2, 3);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, -2, 3);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1, -2, -3);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 3, 2);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 3, -2);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1, -3, -2);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 3, 2, 1);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3, 2, 1);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3, -2, -1);
		test_function_sortrows_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "sortrows_dim: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sortrows_dim: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sortrows2_dim()
{
	Real out = 0.;
	{
		Matrix dim = mat_row();
		test_function_sortrows_dim2 tf(dim);
		//out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 3);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 2, 3);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, -2, 3);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1, -2, -3);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 3, 2);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 3, -2);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1, -3, -2);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 3, 2, 1);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3, 2, 1);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3, -2, -1);
		test_function_sortrows_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "sortrows_dim2: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sortrows_dim2: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sortcols()
{
	Real out = 0.;

	test_function_sortcols tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "sortcols: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sortcols: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sortcols2()
{
	Real out = 0.;

	test_function_sortcols2 tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "sortcols2: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sortcols2: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sortcols_dim()
{
	Real out = 0.;
	{
		Matrix dim = mat_row();
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 3);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 2, 3);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, -2, 3);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1, -2, -3);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 3, 2);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 3, -2);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1, -3, -2);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 3, 2, 1);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3, 2, 1);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3, -2, -1);
		test_function_sortcols_dim tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "sortcols_dim: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sortcols_dim: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sortcols2_dim()
{
	Real out = 0.;
	{
		Matrix dim = mat_row();
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 3);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 2, 3);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, -2, 3);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1, -2, -3);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 3, 2);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 1, 3, -2);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -1, -3, -2);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), 3, 2, 1);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3, 2, 1);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	{
		Matrix dim = (mat_row(), -3, -2, -1);
		test_function_sortcols_dim2 tf(dim);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "sortcols_dim2: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sortcols_dim2: FAILED"  + "\n";
	};
};
void unary_functions_list::test_is_sorted()
{
	Real out = 0.;
	for (int j = 1; j <= 2; j++)
	{
		for (int i = 1; i <= 2; i++)
		{
			bool is_asc = (j == 1);
			test_function_is_sorted tf(i,is_asc);
			out += m_tests.make(&tf,m_options);
		};
	};
	if (out == 0.)
	{
		logger() << std::string() +   "is_sorted: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "is_sorted: FAILED"  + "\n";
	};
};
void unary_functions_list::test_is_sorted_rows()
{
	Real out = 0.;
	test_function_is_sorted_rows tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "is_sorted_rows: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "is_sorted_rows: FAILED"  + "\n";
	};
};
void unary_functions_list::test_is_sorted_cols()
{
	Real out = 0.;
	test_function_is_sorted_cols tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "is_sorted_cols: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "is_sorted_cols: FAILED"  + "\n";
	};
};
void unary_functions_list::test_get_lu()
{
	Real out = 0.;
	test_function_get_lu tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "get_lu: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "get_lu: FAILED"  + "\n";
	};
};
void unary_functions_list::test_resize_reserve()
{
	Real out = 0.;
	test_function_resize_reserve tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "resize_reserve: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "resize_reserve: FAILED"  + "\n";
	};
};
void unary_functions_list::test_resize_reserve_b()
{
	Real out = 0.;
	test_function_resize_reserve_b tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "resize_reserve_band: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "resize_reserve_band: FAILED"  + "\n";
	};
};
void unary_functions_list::test_convert()
{
	Real out = 0.;
	for (Integer i = enums::integer_scalar;i<=enums::object_band;i++)
	{
        if (i%4 == 3)
        {
            continue;
        };
		test_function_convert tf(i);
		out += m_tests.make(&tf,m_options);
	};

	if (out == 0.)
	{
		logger() << std::string() +   "convert: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "convert: FAILED"  + "\n";
	};
};
void unary_functions_list::test_get_scalar()
{
	Real out = 0.;
	test_function_get_scal tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "get_scal: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "get_scal: FAILED"  + "\n";
	};
};
void unary_functions_list::test_get_array()
{
	Real out = 0.;
	test_function_get_array tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "get_array: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "get_array: FAILED"  + "\n";
	};
};
void unary_functions_list::test_get_const_array()
{
	Real out = 0.;
	test_function_get_const_array tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "get_const_array: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "get_const_array: FAILED"  + "\n";
	};
};
void unary_functions_list::test_eval_func()
{
	Real out = 0.;
	test_function_eval_func tf;
	out += m_tests.make(&tf,m_options);

	if (out == 0.)
	{
		logger() << std::string() +   "eval_func: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "eval_func: FAILED"  + "\n";
	};
};
void unary_functions_list::test_sparse()
{
	Real out = 0.;
	test_function_sparse tf;
	out += m_tests.make(&tf,m_options);
	if (out == 0.)
	{
		logger() << std::string() +   "sparse: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "sparse: FAILED"  + "\n";
	};
};		
void unary_functions_list::test_band()
{
	Real out = 0.;
	test_function_band tf;
	out += m_tests.make(&tf,m_options);
	if (out == 0.)
	{
		logger() << std::string() +   "band: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "band: FAILED"  + "\n";
	};
};	
void unary_functions_list::test_clone()
{
	Real out = 0.;
	test_function_clone tf;
	out += m_tests.make(&tf,m_options);
	if (out == 0.)
	{
		logger() << std::string() +   "clone: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "clone: FAILED"  + "\n";
	};
}
void unary_functions_list::test_constructors()
{
	Real out = 0.;
	try
	{
		Complex I	= constants::I;
		out			+= norm_1(IntegerMatrix(2,2)-zeros(2,2));
		out			+= norm_1(IntegerMatrix(0,2)-zeros(0,2));
		out			+= norm_1(IntegerMatrix(2,0)-zeros(2,0));
		out			+= norm_1(IntegerMatrix(0,0)-zeros(0,0));
		out			+= norm_1(IntegerMatrix(1,1)-zeros(1,1));

		out			+= norm_1(RealMatrix(2,2)-zeros(2,2));
		out			+= norm_1(RealMatrix(0,2)-zeros(0,2));
		out			+= norm_1(RealMatrix(2,0)-zeros(2,0));
		out			+= norm_1(RealMatrix(0,0)-zeros(0,0));
		out			+= norm_1(RealMatrix(1,1)-zeros(1,1));

		out			+= norm_1(ComplexMatrix(2,2)-zeros(2,2));
		out			+= norm_1(ComplexMatrix(0,2)-zeros(0,2));
		out			+= norm_1(ComplexMatrix(2,0)-zeros(2,0));
		out			+= norm_1(ComplexMatrix(0,0)-zeros(0,0));
		out			+= norm_1(ComplexMatrix(1,1)-zeros(1,1));

		out			+= norm_1(IntegerMatrix(1,2,2)-ones(2,2));
		out			+= norm_1(IntegerMatrix(1,0,2)-ones(0,2));
		out			+= norm_1(IntegerMatrix(1,2,0L)-ones(2,0));
		out			+= norm_1(IntegerMatrix(1,0,0L)-ones(0,0));
		out			+= norm_1(IntegerMatrix(1,1,1)-ones(1,1));

		out			+= norm_1(RealMatrix(1.,2,2)-ones(2,2));
		out			+= norm_1(RealMatrix(1.,0,2)-ones(0,2));
		out			+= norm_1(RealMatrix(1.,2,0)-ones(2,0));
		out			+= norm_1(RealMatrix(1.,0,0)-ones(0,0));
		out			+= norm_1(RealMatrix(1.,1,1)-ones(1,1));

		out			+= norm_1(ComplexMatrix(1+0*I,2,2)-ones(2,2));
		out			+= norm_1(ComplexMatrix(1+0*I,0,2)-ones(0,2));
		out			+= norm_1(ComplexMatrix(1+0*I,2,0L)-ones(2,0));
		out			+= norm_1(ComplexMatrix(1+0*I,0,0L)-ones(0,0));
		out			+= norm_1(ComplexMatrix(1+0*I,1,1)-ones(1,1));

		out			+= norm_1(IntegerSparseMatrix(2,2,2)-zeros(2,2));
		out			+= norm_1(IntegerSparseMatrix(0,2,2)-zeros(0,2));
		out			+= norm_1(IntegerSparseMatrix(2,0,2)-zeros(2,0));
		out			+= norm_1(IntegerSparseMatrix(0,0,2)-zeros(0,0));
		out			+= norm_1(IntegerSparseMatrix(1,1,2)-zeros(1,1));

		out			+= norm_1(RealSparseMatrix(2,2,2)-zeros(2,2));
		out			+= norm_1(RealSparseMatrix(0,2,2)-zeros(0,2));
		out			+= norm_1(RealSparseMatrix(2,0,2)-zeros(2,0));
		out			+= norm_1(RealSparseMatrix(0,0,2)-zeros(0,0));
		out			+= norm_1(RealSparseMatrix(1,1,2)-zeros(1,1));

		out			+= norm_1(ComplexSparseMatrix(2,2,2)-zeros(2,2));
		out			+= norm_1(ComplexSparseMatrix(0,2,2)-zeros(0,2));
		out			+= norm_1(ComplexSparseMatrix(2,0,2)-zeros(2,0));
		out			+= norm_1(ComplexSparseMatrix(0,0,2)-zeros(0,0));
		out			+= norm_1(ComplexSparseMatrix(1,1,2)-zeros(1,1));

		Matrix B,F,d1,d2;
		B			= IntegerBandMatrix2(0,2,2,0,0);
		out			+= norm_1(B-zeros(2,2));
		B			= IntegerBandMatrix2(0,2,2,1,0);
		out			+= norm_1(B-zeros(2,2));
		B			= IntegerBandMatrix2(0,2,2,0,1);
		out			+= norm_1(B-zeros(2,2));
		B			= IntegerBandMatrix2(0,2,2,1,1);
		out			+= norm_1(B-zeros(2,2));
		B			= IntegerBandMatrix2(0,2,2,2,2);
		out			+= norm_1(B-zeros(2,2));

		B			= IntegerBandMatrix2(1,2,2,0,0);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		B			= IntegerBandMatrix2(1,2,2,1,0);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		B			= IntegerBandMatrix2(1,2,2,0,1);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		B			= IntegerBandMatrix2(1,2,2,1,1);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		out			+= norm_1(B-1);
		B			= IntegerBandMatrix2(1,2,2,3,3);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);

		B			= RealBandMatrix2(0,2,2,0,0);
		out			+= norm_1(B-zeros(2,2));
		B			= RealBandMatrix2(0,2,2,1,0);
		out			+= norm_1(B-zeros(2,2));
		B			= RealBandMatrix2(0,2,2,0,1);
		out			+= norm_1(B-zeros(2,2));
		B			= RealBandMatrix2(0,2,2,1,1);
		out			+= norm_1(B-zeros(2,2));
		B			= RealBandMatrix2(0,2,2,3,3);
		out			+= norm_1(B-zeros(2,2));

		B			= RealBandMatrix2(1,2,2,0,0);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		B			= RealBandMatrix2(1,2,2,1,0);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		B			= RealBandMatrix2(1,2,2,0,1);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		B			= RealBandMatrix2(1,2,2,1,1);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		out			+= norm_1(B-1);
		B			= RealBandMatrix2(1,2,2,3,3);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);

		B			= ComplexBandMatrix2(0,2,2,0,0);
		out			+= norm_1(B-zeros(2,2));
		B			= ComplexBandMatrix2(0,2,2,1,0);
		out			+= norm_1(B-zeros(2,2));
		B			= ComplexBandMatrix2(0,2,2,0,1);
		out			+= norm_1(B-zeros(2,2));
		B			= ComplexBandMatrix2(0,2,2,1,1);
		out			+= norm_1(B-zeros(2,2));
		B			= ComplexBandMatrix2(0,2,2,3,3);
		out			+= norm_1(B-zeros(2,2));

		B			= ComplexBandMatrix2(1,2,2,0,0);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		B			= ComplexBandMatrix2(1,2,2,1,0);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		B			= ComplexBandMatrix2(1,2,2,0,1);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		B			= ComplexBandMatrix2(1,2,2,1,1);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);
		out			+= norm_1(B-1);
		B			= ComplexBandMatrix2(1,2,2,3,3);	tie(d1,d2,F) = find3(B);
		out			+= norm_1(F-1);

		B			= IntegerBandMatrix(2,2,0,0);
		out			+= norm_1(B-zeros(2,2));
		B			= IntegerBandMatrix(2,2,1,0);
		out			+= norm_1(B-zeros(2,2));
		B			= IntegerBandMatrix(2,2,0,1);
		out			+= norm_1(B-zeros(2,2));
		B			= IntegerBandMatrix(2,2,1,1);
		out			+= norm_1(B-zeros(2,2));
		B			= IntegerBandMatrix(2,2,3,3);
		out			+= norm_1(B-zeros(2,2));

		B			= RealBandMatrix(2,2,0,0);
		out			+= norm_1(B-zeros(2,2));
		B			= RealBandMatrix(2,2,1,0);
		out			+= norm_1(B-zeros(2,2));
		B			= RealBandMatrix(2,2,0,1);
		out			+= norm_1(B-zeros(2,2));
		B			= RealBandMatrix(2,2,1,1);
		out			+= norm_1(B-zeros(2,2));
		B			= RealBandMatrix(2,2,3,3);
		out			+= norm_1(B-zeros(2,2));

		B			= ComplexBandMatrix(2,2,0,0);
		out			+= norm_1(B-zeros(2,2));
		B			= ComplexBandMatrix(2,2,1,0);
		out			+= norm_1(B-zeros(2,2));
		B			= ComplexBandMatrix(2,2,0,1);
		out			+= norm_1(B-zeros(2,2));
		B			= ComplexBandMatrix(2,2,1,1);
		out			+= norm_1(B-zeros(2,2));
		B			= ComplexBandMatrix(2,2,3,3);
		out			+= norm_1(B-zeros(2,2));

		Matrix A;
		A			= irand(2,2);
		out			+= norm_1(IntegerMatrix(2,2,A.get_array<Integer>())-A);
		A			= irand(0,2);
		out			+= norm_1(IntegerMatrix(0,2,A.get_array<Integer>())-A);
		A			= irand(2,0);
		out			+= norm_1(IntegerMatrix(2,0,A.get_array<Integer>())-A);
		A			= irand(0,0);
		out			+= norm_1(IntegerMatrix(0,0,A.get_array<Integer>())-A);
		A			= irand(1,1);
		out			+= norm_1(IntegerMatrix(1,1,A.get_array<Integer>())-A);

		A			= randn(2,2);
		out			+= norm_1(RealMatrix(2,2,A.get_array<Real>())-A);
		A			= randn(0,2);
		out			+= norm_1(RealMatrix(0,2,A.get_array<Real>())-A);
		A			= randn(2,0);
		out			+= norm_1(RealMatrix(2,0,A.get_array<Real>())-A);
		A			= randn(0,0);
		out			+= norm_1(RealMatrix(0,0,A.get_array<Real>())-A);
		A			= randn(1,1);
		out			+= norm_1(RealMatrix(1,1,A.get_array<Real>())-A);

		A			= crandn(2,2);
		out			+= norm_1(ComplexMatrix(2,2,A.get_array<Complex>())-A);
		A			= crandn(0,2);
		out			+= norm_1(ComplexMatrix(0,2,A.get_array<Complex>())-A);
		A			= crandn(2,0);
		out			+= norm_1(ComplexMatrix(2,0,A.get_array<Complex>())-A);
		A			= crandn(0,0);
		out			+= norm_1(ComplexMatrix(0,0,A.get_array<Complex>())-A);
		A			= crandn(1,1);
		out			+= norm_1(ComplexMatrix(1,1,A.get_array<Complex>())-A);

		A			= randn(2,2);
		out			+= norm_1(ComplexMatrix(2,2,A.get_array<Real>(),A.get_array<Real>())-A- I*A);
		A			= randn(0,2);
		out			+= norm_1(ComplexMatrix(0,2,A.get_array<Real>(),A.get_array<Real>())-A- I*A);
		A			= randn(2,0);
		out			+= norm_1(ComplexMatrix(2,0,A.get_array<Real>(),A.get_array<Real>())-A- I*A);
		A			= randn(0,0);
		out			+= norm_1(ComplexMatrix(0,0,A.get_array<Real>(),A.get_array<Real>())-A- I*A);
		A			= randn(1,1);
		out			+= norm_1(ComplexMatrix(1,1,A.get_array<Real>(),A.get_array<Real>())-A- I*A);

		Matrix Ir,Ic,Ix,C,D;
		A			= isprand(5,5,.1);
		tie(Ir,Ic,Ix) = find3(A);
		Ir			= full(Ir);
		Ic			= full(Ic);
		Ix			= full(Ix);
		B			= SparseMatrix(Ir,Ic,Ix,5,5);
		C			= IntegerSparseMatrix(Ir.get_array<Integer>(),Ic.get_array<Integer>(),
							Ix.get_array<Integer>(),5,5,Ir.rows());
		out			+= norm_1(A-B);
		out			+= norm_1(A-C);

		A			= sprandn(5,5,.1);
		tie(Ir,Ic,Ix) = find3(A);
		Ir			= full(Ir);
		Ic			= full(Ic);
		Ix			= full(Ix);
		B			= SparseMatrix(Ir,Ic,Ix,5,5);
		C			= RealSparseMatrix(Ir.get_array<Integer>(),Ic.get_array<Integer>(),
							Ix.get_array<Real>(),5,5,Ir.rows());
		out			+= norm_1(A-B);
		out			+= norm_1(A-C);

		A			= csprandn(5,5,.1);
		tie(Ir,Ic,Ix) = find3(A);
		Ir			= full(Ir);
		Ic			= full(Ic);
		Ix			= full(Ix);
		B			= SparseMatrix(Ir,Ic,Ix,5,5);
		C			= ComplexSparseMatrix(Ir.get_array<Integer>(),Ic.get_array<Integer>(),
							Ix.get_array<Complex>(),5,5,Ir.rows());
		D			= ComplexSparseMatrix(Ir.get_array<Integer>(),Ic.get_array<Integer>(),
							full(real(Ix)).get_array<Real>(),full(imag(Ix)).get_array<Real>(),
							5,5,Ir.rows());
		out			+= norm_1(A-B);
		out			+= norm_1(A-C);
		out			+= norm_1(A-D);

		A			= isprand(5,5,.1);
		tie(Ir,Ic,Ix) = find3(A);
		Ir			= full(Ir);
		Ic			= full(Ic);
		Ix			= full(Ix);
		B			= SparseMatrix(Ir,Ic,Ix,5,5,5);
		C			= IntegerSparseMatrix(Ir.get_array<Integer>(),Ic.get_array<Integer>(),
							Ix.get_array<Integer>(),5,5,Ir.rows(),5);
		out			+= norm_1(A-B);
		out			+= norm_1(A-C);

		A			= sprandn(5,5,.1);
		tie(Ir,Ic,Ix) = find3(A);
		Ir			= full(Ir);
		Ic			= full(Ic);
		Ix			= full(Ix);
		B			= SparseMatrix(Ir,Ic,Ix,5,5,5);
		C			= RealSparseMatrix(Ir.get_array<Integer>(),Ic.get_array<Integer>(),
							Ix.get_array<Real>(),5,5,Ir.rows(),5);
		out			+= norm_1(A-B);
		out			+= norm_1(A-C);

		A			= csprandn(5,5,.1);
		tie(Ir,Ic,Ix) = find3(A);
		Ir			= full(Ir);
		Ic			= full(Ic);
		Ix			= full(Ix);
		B			= SparseMatrix(Ir,Ic,Ix,5,5,5);
		C			= ComplexSparseMatrix(Ir.get_array<Integer>(),Ic.get_array<Integer>(),
							Ix.get_array<Complex>(),5,5,Ir.rows(),5);
		D			= ComplexSparseMatrix(Ir.get_array<Integer>(),Ic.get_array<Integer>(),
							full(real(Ix)).get_array<Real>(),full(imag(Ix)).get_array<Real>(),
							5,5,Ir.rows(),5);
		out			+= norm_1(A-B);
		out			+= norm_1(A-C);
		out			+= norm_1(A-D);
	}
	catch(std::exception& ex)
	{
		logger()  <<  std::string() +ex.what() + "\n";
		out = 1;
	};
	if (out == 0.)
	{
		logger() << std::string() +   "constructors: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "constructors: FAILED"  + "\n";
	};
};


void unary_functions_list::test_diag()
{
	Real out = 0.;
	{
		test_function_diag tf(0);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_diag tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_diag tf(-1);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "diag: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "diag: FAILED"  + "\n";
	};
};
void unary_functions_list::test_bdiag()
{
	Real out = 0.;
	{
		test_function_bdiag tf(0);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_bdiag tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_bdiag tf(-1);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "bdiag: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "bdiag: FAILED"  + "\n";
	};
};
void unary_functions_list::test_spdiag()
{
	Real out = 0.;
	{
		test_function_spdiag tf(0);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_spdiag tf(1);
		out += m_tests.make(&tf,m_options);
	};
	{
		test_function_spdiag tf(-1);
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "spdiag: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "spdiag: FAILED"  + "\n";
	};
};
void unary_functions_list::test_diags()
{
	Real out = 0.;
	{
		test_function_diags tf;
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "diags: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "diags: FAILED"  + "\n";
	};
};

void unary_functions_list::test_bdiags()
{
	Real out = 0.;
	{
		test_function_bdiags tf;
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "bdiags: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "bdiags: FAILED"  + "\n";
	};
};
void unary_functions_list::test_spdiags()
{
	Real out = 0.;
	{
		test_function_spdiags tf;
		out += m_tests.make(&tf,m_options);
	};
	if (out == 0.)
	{
		logger() << std::string() +   "spdiags: OK" + "\n";
	}
	else
	{
		logger() << std::string() +   "spdiags: FAILED"  + "\n";
	};
};


};};