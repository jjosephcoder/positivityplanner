/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "test_functions.h"
#include <iostream>
#include "data_struct/logger.h"
#include "mmlib/details/type_info_utils.h"
#include "mmlib/archive.h"

#pragma warning(push)
#pragma warning(disable:4702)
#include "boost/lexical_cast.hpp"
#pragma warning(pop)

namespace mmlib { namespace raw { namespace details
{
	template<class value_type> struct rx
	{
		Integer		r;
		value_type	x;
	};
};};}

namespace gd = mmlib::details;

namespace mmlib { namespace test
{

Real test_function_cat::eval_mat(const Matrix& mat,bool,int code)
{
    dynamic_mat_set ds(m_rand);
	try
	{		
		Integer p = 1;
		mat_col mc;
		mat_col mc_full;
		for (Integer j = 1; j <= m; j++)
		{
			mat_row mr;
			mat_row mr_full;
			for (Integer i = 1; i <= n; i++)
			{
				if (p == pos)
				{
					(mr, mat);
					(mr_full, full(mat));
				}
				else
				{
					Matrix tmp;
					tmp = ds.rand(mat.rows(), mat.cols(),seed+code);
					(mr, tmp);
					(mr_full, full(tmp));
				};
				p++;
			};

			(mc, mr);
			(mc_full, mr_full);
		};
		
		Matrix out		= mc;
        Matrix out_full = mc_full;
        out.check_struct();

		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_cat::eval_scalar(const Scalar& ,bool,int code  )
{
    (void)code;
	return 0;
};
Real test_function_get_diag::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = get_diag(full(mat),d);	
	try
	{		
		Matrix out		= get_diag(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_get_diag::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(diag(value,d) - diag(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(diag(value,d) - diag(full(value),d));
			dif				+=norm_1(diag(value,d) - diag(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(diag(value,d) - diag(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_get_diag2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
    Matrix out_full = full(mat).diag(d);	
	try
	{		
        Matrix out		= mat.diag(d);
        out.check_struct();

        Real diff       = norm_1(out - out_full);
        diff            += norm_1(out - get_diag(mat,d));
		return diff;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_get_diag2::eval_scalar(const Scalar& ,bool,int code  )
{
    (void)code;
	return 0;
};


Real test_function_tril::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = tril(full(mat),d);	
	try
	{		
		Matrix out		= tril(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_tril::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	try
	{
		tril(full(1),d);
	}
	catch(...)
	{
		return 0;
	};

	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(tril(value,d) - tril(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(tril(value,d) - tril(full(value),d));
			dif				+=norm_1(tril(value,d) - tril(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(tril(value,d) - tril(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_triu::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = triu(full(mat),d);	
	try
	{		
		Matrix out		= triu(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_triu::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	try
	{
		triu(full(1),d);
	}
	catch(...)
	{
		return 0;
	};

	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(triu(value,d) - triu(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(triu(value,d) - triu(full(value),d));
			dif				+=norm_1(triu(value,d) - triu(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(triu(value,d) - triu(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_rot90::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = rot90(full(mat),d);	
	try
	{		
		Matrix out		= rot90(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_rot90::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(rot90(value,d) - rot90(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(rot90(value,d) - rot90(full(value),d));
			dif				+=norm_1(rot90(value,d) - rot90(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(rot90(value,d) - rot90(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_sum::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = sum(full(mat),d);	
	try
	{		
		Matrix out		= sum(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sum::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(sum(value,d) - sum(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(sum(value,d) - sum(full(value),d));
			dif				+=norm_1(sum(value,d) - sum(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(sum(value,d) - sum(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_cumsum::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = cumsum(full(mat),d);	
	try
	{		
		Matrix out		= cumsum(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_cumsum::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(cumsum(value,d) - cumsum(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(cumsum(value,d) - cumsum(full(value),d));
			dif				+=norm_1(cumsum(value,d) - cumsum(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(cumsum(value,d) - cumsum(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_prod::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = prod(full(mat),d);	
	try
	{		
		Matrix out		= prod(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_prod::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(prod(value,d) - prod(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(prod(value,d) - prod(full(value),d));
			dif				+=norm_1(prod(value,d) - prod(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(prod(value,d) - prod(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_cumprod::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = cumprod(full(mat),d);	
	try
	{		
		Matrix out		= cumprod(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_cumprod::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(cumprod(value,d) - cumprod(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(cumprod(value,d) - cumprod(full(value),d));
			dif				+=norm_1(cumprod(value,d) - cumprod(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(cumprod(value,d) - cumprod(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_sumsq::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = sumsq(full(mat),d);	
	try
	{		
		Matrix out		= sumsq(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sumsq::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(sumsq(value,d) - sumsq(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(sumsq(value,d) - sumsq(full(value),d));
			dif				+=norm_1(sumsq(value,d) - sumsq(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(sumsq(value,d) - sumsq(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_nnz::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = nnz(full(mat),d);	
	try
	{		
		Matrix out		= nnz(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_nnz::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(nnz(value,d) - nnz(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(nnz(value,d) - nnz(full(value),d));
			dif				+=norm_1(nnz(value,d) - nnz(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(nnz(value,d) - nnz(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_min::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = min_d(full(mat),d);	
	try
	{		
		Matrix out		= min_d(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_min::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(min_d(value,d) - min_d(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(min_d(value,d) - min_d(full(value),d));
			dif				+=norm_1(min_d(value,d) - min_d(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(min_d(value,d) - min_d(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_min_abs::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = min_abs_d(full(mat),d);	
	try
	{		
		Matrix out1	= min_abs_d(mat,d);
        out1.check_struct();
        Matrix out2	= min_d(abs(mat),d);
        out2.check_struct();
        Real nrm    = norm_1(out1 - out_full);
        nrm         = nrm + norm_1(out2 - out_full);
		return nrm;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_min_abs::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(min_abs_d(value,d) - min_abs_d(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(min_abs_d(value,d) - min_abs_d(full(value),d));
			dif				+=norm_1(min_abs_d(value,d) - min_abs_d(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(min_abs_d(value,d) - min_abs_d(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_max::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = max_d(full(mat),d);	
	try
	{		
		Matrix out		= max_d(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_max::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(max_d(value,d) - max_d(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(max_d(value,d) - max_d(full(value),d));
			dif				+=norm_1(max_d(value,d) - max_d(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(max_d(value,d) - max_d(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_max_abs::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = max_abs_d(full(mat),d);	
	try
	{		
		Matrix out1	= max_abs_d(mat,d);
        Matrix out2	= max_d(abs(mat),d);
        out1.check_struct();
        out2.check_struct();
        Real nrm    = norm_1(out1 - out_full);
        nrm         = nrm + norm_1(out2 - out_full);
		return nrm;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_max_abs::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(max_abs_d(value,d) - max_abs_d(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(max_abs_d(value,d) - max_abs_d(full(value),d));
			dif				+=norm_1(max_abs_d(value,d) - max_abs_d(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(max_abs_d(value,d) - max_abs_d(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_min2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
    Real dif = 0;

	Matrix out_full, iout_full;
	tie(out_full,iout_full) = min2(full(mat),d);	
    
	try
	{		
		Matrix out, iout;
		tie(out,iout) = min2(mat,d);
        out.check_struct();
        iout.check_struct();

		dif = norm_1(out - out_full);
		dif = dif + norm_1(iout - iout_full);

		Matrix pos;
		if (d == 1)
		{
			pos = iout;
			if (mat.rows()>0)
			{
				pos = pos + irange(0,mat.cols()-1)*mat.rows();
			};
		}
		else
		{
			pos = (iout-1)*mat.rows();
			if (mat.cols()>0)
			{
				pos = pos + trans(irange(1,mat.rows()));
			};
		};
		dif = dif + norm_1(out - mat(pos));
		dif = dif + norm_1(out - min_d(mat,d));
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};

    return dif;
};
Real test_function_min2::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(min2(value,d) - min2(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(min2(value,d) - min2(full(value),d));
			dif				+=norm_1(min2(value,d) - min2(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(min2(value,d) - min2(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_min_abs2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
    Real dif = 0;

	Matrix out_full, iout_full;
	tie(out_full,iout_full) = min_abs2(full(mat),d);	
    
	try
	{		
		Matrix out1, iout1;
		tie(out1,iout1) = min_abs2(mat,d);
        out1.check_struct();
        iout1.check_struct();

		Matrix out2, iout2;
		tie(out2,iout2) = min2(abs(mat),d);
        out2.check_struct();
        iout2.check_struct();

		dif = norm_1(out1 - out_full);
		dif = dif + norm_1(iout1 - iout_full);
		dif = norm_1(out2 - out_full);
		dif = dif + norm_1(iout2 - iout_full);

		Matrix pos;
		if (d == 1)
		{
			pos = iout1;
			if (mat.rows()>0)
			{
				pos = pos + irange(0,mat.cols()-1)*mat.rows();
			};
		}
		else
		{
			pos = (iout1-1)*mat.rows();
			if (mat.cols()>0)
			{
				pos = pos + trans(irange(1,mat.rows()));
			};
		};
		dif = dif + norm_1(out1 - abs(mat(pos)));
		dif = dif + norm_1(out1 - min_abs_d(mat,d));
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};

    return dif;
};
Real test_function_min_abs2::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
            Real dif = norm_1(min_abs2(value,d) - min_abs2(full(value),d));
            return dif;
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(min_abs2(value,d) - min_abs2(full(value),d));
			dif				+=norm_1(min_abs2(value,d) - min_abs2(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(min_abs2(value,d) - min_abs2(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_max2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full, iout_full;
	tie(out_full,iout_full) = max2(full(mat),d);	
	try
	{		
		Matrix out, iout;
		tie(out,iout) = max2(mat,d);
        out.check_struct();
        iout.check_struct();

		Real dif = norm_1(out - out_full);
		dif = dif + norm_1(iout - iout_full);

		Matrix pos;
		if (d == 1)
		{
			pos = iout;
			if (mat.rows()>0)
			{
				pos = pos + irange(0,mat.cols()-1)*mat.rows();
			};
		}
		else
		{
			pos = (iout-1)*mat.rows();
			if (mat.cols()>0)
			{
				pos = pos + trans(irange(1,mat.rows()));
			};
		};
		dif = dif + norm_1(out - mat(pos));
		dif = dif + norm_1(out - max_d(mat,d));

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_max2::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(max2(value,d) - max2(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(max2(value,d) - max2(full(value),d));
			dif				+=norm_1(max2(value,d) - max2(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(max2(value,d) - max2(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_max_abs2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
    Real dif = 0;

	Matrix out_full, iout_full;
	tie(out_full,iout_full) = max_abs2(full(mat),d);	
    
	try
	{		
		Matrix out1, iout1;
		tie(out1,iout1) = max_abs2(mat,d);
        out1.check_struct();
        iout1.check_struct();

		Matrix out2, iout2;
		tie(out2,iout2) = max2(abs(mat),d);
        out2.check_struct();
        iout2.check_struct();

		dif = norm_1(out1 - out_full);
		dif = dif + norm_1(iout1 - iout_full);
		dif = norm_1(out2 - out_full);
		dif = dif + norm_1(iout2 - iout_full);

		Matrix pos;
		if (d == 1)
		{
			pos = iout1;
			if (mat.rows()>0)
			{
				pos = pos + irange(0,mat.cols()-1)*mat.rows();
			};
		}
		else
		{
			pos = (iout1-1)*mat.rows();
			if (mat.cols()>0)
			{
				pos = pos + trans(irange(1,mat.rows()));
			};
		};
		dif = dif + norm_1(out1 - abs(mat(pos)));
		dif = dif + norm_1(out1 - max_abs_d(mat,d));
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};

    return dif;
};
Real test_function_max_abs2::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
            Real dif = norm_1(max_abs2(value,d) - max_abs2(full(value),d));
            return dif;
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(max_abs2(value,d) - max_abs2(full(value),d));
			dif				+=norm_1(max_abs2(value,d) - max_abs2(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(max_abs2(value,d) - max_abs2(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_mean::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = mean(full(mat),d);	
	try
	{		
		Matrix out		= mean(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_mean::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(mean(value,d) - mean(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(mean(value,d) - mean(full(value),d));
			dif				+=norm_1(mean(value,d) - mean(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(mean(value,d) - mean(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_std::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = std(full(mat),d);	
	try
	{		
		Matrix out		= std(mat,d);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_std::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(std(value,d) - std(full(value),d));
		}
		case enums::value_real:
		{
			Real value		= s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(std(value,d) - std(full(value),d));
			dif				+=norm_1(std(value,d) - std(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(std(value,d) - std(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_repmat::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = repmat(full(mat),m,n);	
	try
	{		
		Matrix out		= repmat(mat,m,n);
        out.check_struct();
		return norm_1(out - out_full);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_repmat::eval_scalar(const Scalar& ,bool,int code  )
{
    (void)code;
	return 0.;
};
Real test_function_op_un_minus::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = -full(mat);	
	try
	{		
		Matrix out		= -mat;
        out.check_struct();
		Real dif		= norm_1(out - out_full);
		dif				= dif + norm_1(-out - mat);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_un_minus::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(-value - (-full(value)));
		}
		case enums::value_real:
		{
			Real value = s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(-value - (-full(value)));
			dif				+=norm_1(-value - (-val_c));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(-value - (-full(value)));
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_op_neg::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = ~full(mat);	
	try
	{		
		Matrix out		= ~mat;
        out.check_struct();
		Real dif		= norm_1(out - out_full);
		dif				= dif + norm_1(~out - is_true(mat));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_op_neg::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(!value - (~full(value)));
		}
		case enums::value_real:
		{
			Real value = s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(!value - (~full(value)));
			dif				+=norm_1(!value - (!val_c));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(!value - (~full(value)));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_is_true::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = is_true(full(mat));	
	try
	{		
		Matrix out		= is_true(mat);
        out.check_struct();
		Matrix out2		= (mat != 0);
        out2.check_struct();
		Real dif		= norm_1(out - out_full);
		dif				= dif + norm_1(out - out2);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_is_true::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(is_true(value) - is_true(full(value)));
		}
		case enums::value_real:
		{
			Real value = s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(is_true(value) - is_true(full(value)));
			dif				+=norm_1(is_true(value) - is_true(val_c));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(is_true(value) - is_true(full(value)));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_is_false::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = is_false(full(mat));	
	try
	{		
		Matrix out		= is_false(mat);
        out.check_struct();
		Matrix out2		= (mat == 0);
        out2.check_struct();
		Real dif		= norm_1(out - out_full);
		dif				= dif + norm_1(out - out2);
		dif				= dif + norm_1(is_false(out) - is_true(mat));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_is_false::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(is_false(value) - is_false(full(value)));
		}
		case enums::value_real:
		{
			Real value = s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(is_false(value) - is_false(full(value)));
			dif				+=norm_1(is_false(value) - is_false(val_c));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(is_false(value) - is_false(full(value)));
		}
		default:
		{
			return 0;
		}
	};
};
class Test_all : public mmlib::test_function
{
	public:
		virtual bool eval(Integer v) const 
		{
			return v != 0;
		};
		virtual bool eval(Real v) const
		{
			return v != 0.;
		};
		virtual bool eval(const Complex& v) const
		{
			return v != 0.;
		};
		virtual bool eval(const Object& v) const
		{
			return v != 0.;
		};
};
Real test_function_all::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = all(full(mat),d);	

	try
	{		
		Matrix out		= all(mat,d);
        out.check_struct();

		Test_all ta;
		Matrix out2		= all(mat,ta,d);
        out2.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				= dif + norm_1(out - out2);
		dif				= dif + norm_1(out - ~any(~mat,d));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_all::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(all(value,d) - all(full(value),d));
		}
		case enums::value_real:
		{
			Real value = s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(all(value,d) - all(full(value),d));
			dif				+=norm_1(all(value,d) - all(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(all(value,d) - all(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};
Real test_function_any::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = any(full(mat),d);	

	try
	{		
		Matrix out		= any(mat,d);
        out.check_struct();

		Test_all ta;
		Matrix out2		= any(mat,ta,d);
        out2.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				= dif + norm_1(out - out2);
		dif				= dif + norm_1(out - ~all(~mat,d));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_any::eval_scalar(const Scalar& s,bool,int code  )
{
    (void)code;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return norm_1(any(value,d) - any(full(value),d));
		}
		case enums::value_real:
		{
			Real value = s.get_real();
			Complex val_c	= value;
			Real dif		= norm_1(any(value,d) - any(full(value),d));
			dif				+=norm_1(any(value,d) - any(val_c,d));
			return dif;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return norm_1(any(value,d) - any(full(value),d));
		}
		default:
		{
			return 0;
		}
	};
};


Real test_function_reshape::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Integer r = mat.rows();
	Integer c = mat.cols();
	Matrix mf = full(mat);
	Matrix out_full_1 = reshape(mf,r,c);	
	Matrix out_full_2 = reshape(mf,c,r);	
	Matrix out_full_3 = reshape(mf,r*c,1);	
	Matrix out_full_4 = reshape(mf,1,r*c);	
	Matrix out_full_5;
	Matrix out_full_6;

	if (r%2 == 0)
	{
		out_full_5 = reshape(mf,r/2,c*2);	
	}
	if (c%2 == 0)
	{
		out_full_6 = reshape(mf,r*2,c/2);	
	}

	try
	{		
		Matrix out_1 = reshape(mat,r,c);	
		Matrix out_2 = reshape(mat,c,r);	
		Matrix out_3 = reshape(mat,r*c,1);	
		Matrix out_4 = reshape(mat,1,r*c);	

		Matrix out_12 = reshape(out_1,r,c);	
		Matrix out_22 = reshape(out_2,r,c);	
		Matrix out_32 = reshape(out_3,r,c);	
		Matrix out_42 = reshape(out_4,r,c);	
		Matrix out_5, out_52;
		Matrix out_6, out_62;
		if (r%2 == 0)
		{
			out_5   = reshape(mat,r/2,c*2);	
            out_52  = reshape(out_5,r,c);
		}
		if (c%2 == 0)
		{
			out_6 = reshape(mat,r*2,c/2);	
            out_62  = reshape(out_6,r,c);
		}

        out_1.check_struct();
        out_2.check_struct();
        out_3.check_struct();
        out_4.check_struct();
        out_5.check_struct();
        out_6.check_struct();

		Real dif		= 0;
		dif				+=norm_1(out_1 - out_full_1);
		dif				+=norm_1(out_2 - out_full_2);
		dif				+=norm_1(out_3 - out_full_3);
		dif				+=norm_1(out_4 - out_full_4);
		dif			    +=norm_1(out_5 - out_full_5);
		dif			    +=norm_1(out_6 - out_full_6);

		dif				+=norm_1(mat - out_12);
		dif				+=norm_1(mat - out_22);
		dif				+=norm_1(mat - out_32);
		dif				+=norm_1(mat - out_42);

        if (r%2 == 0)
        {
            dif			+=norm_1(mat - out_52);
        }
        if (c%2 == 0)
        {
            dif		    +=norm_1(mat - out_62);
        }

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_reshape::eval_scalar(const Scalar& ,bool,int code  )
{
    (void)code;
	return 0.;
};
class Test_g0 : public mmlib::test_function
{
	public:
		virtual bool eval(Integer v) const 
		{
			return v > 0;
		};
		virtual bool eval(Real v) const
		{
			return v > 0.;
		};
		virtual bool eval(const Complex& v) const
		{
			return v > 0.;
		};
		virtual bool eval(const Object& v) const
		{
			return v > 0.;
		};
};

Real test_function_find::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = find(full(mat));	
	Matrix out_full2 = find(full(mat)>0);	

	try
	{		
		Matrix out		= find(mat);
		Matrix out2		= find(mat>0);
        out.check_struct();
        out2.check_struct();

		Real dif		= norm_1(out - out_full);
		dif				+= norm_1(out2 - out_full2);
		dif				+= (is_scalar_true(all(mat(out))) == false);
		dif				+= (is_scalar_true(all(mat(out2)>0)) == false);

		Matrix m1		= mat;
		Matrix m2		= mat;
		m1(out)			= zeros(0,0);
		m2(out2)		= zeros(0,0);

        m1.check_struct();
        m2.check_struct();

		dif				+= (is_scalar_false(any(m1)) == false);
		dif				+= (is_scalar_false(any(m2>0)) == false);

		Test_g0 ta;
		Matrix out3		= find(mat,ta);
        out3.check_struct();

		dif				+= norm_1(out2 - out3);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_find::eval_scalar(const Scalar& ,bool,int code  )
{
    (void)code;
	return 0.;
};

Real test_function_find2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	mat_tup_2 out_full = find2(full(mat));	
	mat_tup_2 out_full2 = find2(full(mat)>0);	

	try
	{		
		mat_tup_2 out	= find2(mat);
		mat_tup_2 out2	= find2(mat>0);
        out.get<1>().check_struct();
        out.get<2>().check_struct();
        out2.get<1>().check_struct();
        out2.get<2>().check_struct();

		Real dif		= norm_1(out.get<1>() - out_full.get<1>());
		dif				+= norm_1(out.get<2>() - out_full.get<2>());
		dif				+= norm_1(out2.get<1>() - out_full2.get<1>());
		dif				+= norm_1(out2.get<2>() - out_full2.get<2>());

		Test_g0 ta;
		mat_tup_2 out5	= find2(mat,ta);
        out5.get<1>().check_struct();
        out5.get<2>().check_struct();

		dif				+= norm_1(out2.get<1>() - out5.get<1>());
		dif				+= norm_1(out2.get<2>() - out5.get<2>());
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_find2::eval_scalar(const Scalar& ,bool,int code  )
{
    (void)code;
	return 0.;
};

Real test_function_find3::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	mat_tup_3 out_full = find3(full(mat));	
	mat_tup_3 out_full2 = find3(full(mat)>0);	

	try
	{		
		mat_tup_3 out	= find3(mat);
		mat_tup_3 out2	= find3(mat>0);

		Matrix out3		= mat(find(mat));
		Matrix out4		= find(mat>0);

		Real dif		= norm_1(out.get<1>() - out_full.get<1>());
		dif				+= norm_1(out.get<2>() - out_full.get<2>());
		dif				+= norm_1(out.get<3>() - out_full.get<3>());
		dif				+= norm_1(out2.get<1>() - out_full2.get<1>());
		dif				+= norm_1(out2.get<2>() - out_full2.get<2>());
		dif				+= norm_1(out2.get<3>() - out_full2.get<3>());
		dif				+= norm_1(out.get<3>() - out3);

		Test_g0 ta;
		mat_tup_3 out5	= find3(mat,ta);
		dif				+= norm_1(out2.get<1>() - out5.get<1>());
		dif				+= norm_1(out2.get<2>() - out5.get<2>());
		dif				+= norm_1(mat(out4) - out5.get<3>());

        out.get<1>().check_struct();
        out.get<2>().check_struct();
        out2.get<1>().check_struct();
        out2.get<2>().check_struct();
        out3.check_struct();
        out4.check_struct();
        out5.get<1>().check_struct();
        out5.get<2>().check_struct();

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_find3::eval_scalar(const Scalar& ,bool,int code  )
{
    (void)code;
	return 0.;
};

Real test_function_sort::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = sort(full(mat),d,is_asc);	

	try
	{		
		Matrix out		= sort(mat,d,is_asc);
        out.check_struct();
		Real dif		= norm_1(out - out_full);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sort::eval_scalar(const Scalar& ,bool,int code  )
{
    (void)code;
	return 0.;
};

Real test_function_sort2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	mat_tup_2 out_full = sort2(full(mat),d,is_asc);	

	try
	{		
		mat_tup_2 out	= sort2(mat,d,is_asc);
		Real dif		= norm_1(out.get<1>() - out_full.get<1>());
		dif				+=norm_1(out.get<2>() - out_full.get<2>());

        out.get<1>().check_struct();
        out.get<2>().check_struct();

		Matrix pos;
		Matrix iout = out.get<2>();
		if (d == 1)
		{
			pos = iout;
			if (mat.cols()>0)
			{
				pos = pos + iones(mat.rows(),1)*(irange(0,mat.cols()-1)*mat.rows());
			};
		}
		else
		{
			pos = (iout-1)*mat.rows();
			if (mat.rows() > 0)
			{
				pos = pos + trans(irange(1,mat.rows()))*iones(1,mat.cols());
			};
		};
		dif = dif + norm_1(out.get<1>() - mat(pos));
		dif = dif + norm_1(out.get<1>() - sort(mat,d,is_asc));

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sort2::eval_scalar(const Scalar& ,bool,int code)
{
    (void)code;
	return 0.;
};

Real test_function_sortrows::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = sortrows(full(mat));	

	try
	{		
		Matrix out		= sortrows(mat);
        out.check_struct();
		Real dif		= norm_1(out - out_full);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sortrows::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_sortrows_dim::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Integer c		= mat.cols();
	Matrix out1		= sortrows(mat,irange(1,c));
	Matrix out2		= sortrows(mat);

    out1.check_struct();
    out2.check_struct();
	Real dif		= norm_1(out1 - out2);

	Matrix out_full;
	try
	{
		out_full = sortrows(full(mat),m);	
	}
	catch(...)
	{
		return dif;
	};

	try
	{				
		Matrix out		= sortrows(mat,m);		
        out.check_struct();
		dif				+= norm_1(out - out_full); 
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sortrows_dim::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_sortrows2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	mat_tup_2 out_full = sortrows2(full(mat));	

	try
	{		
		mat_tup_2 out	= sortrows2(mat);
        out.get<1>().check_struct();
        out.get<2>().check_struct();

		Real dif		= norm_1(out.get<1>() - out_full.get<1>());
		dif				+=norm_1(out.get<2>() - out_full.get<2>());

		Matrix iout		= out.get<2>();
		dif				+= norm_1(out.get<1>() - mat(iout,colon()));
		dif				+= norm_1(out.get<1>() - sortrows(mat));

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sortrows2::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_sortrows_dim2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Integer c		= mat.cols();
	mat_tup_2 out1	= sortrows2(mat,irange(1,c));
	mat_tup_2 out2	= sortrows2(mat);
	Real dif		= norm_1(out1.get<1>() - out2.get<1>());
	dif				+= norm_1(out1.get<2>() - out2.get<2>());

    out1.get<1>().check_struct();
    out1.get<2>().check_struct();
    out2.get<1>().check_struct();
    out2.get<2>().check_struct();

	mat_tup_2 out_full;
	try
	{
		out_full		= sortrows2(full(mat),m);	
	}
	catch(...)
	{
		return dif;
	};

	try
	{		
		mat_tup_2 out	= sortrows2(mat,m);

        out.get<1>().check_struct();
        out.get<2>().check_struct();

		dif				+= norm_1(out.get<1>() - out_full.get<1>());
		dif				+=norm_1(out.get<2>() - out_full.get<2>());

		Matrix iout		= out.get<2>();
		dif				+= norm_1(out.get<1>() - mat(iout,colon()));
		dif				+= norm_1(out.get<1>() - sortrows(mat,m));

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sortrows_dim2::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_sortcols::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = sortcols(full(mat));	

	try
	{		
		Matrix out		= sortcols(mat);
        out.check_struct();
		Real dif		= norm_1(out - out_full);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};

};
Real test_function_sortcols::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_sortcols_dim::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Integer r		= mat.rows();
	Matrix out1		= sortcols(mat,irange(1,r));
	Matrix out2		= sortcols(mat);

    out1.check_struct();
    out2.check_struct();

	Real dif		= norm_1(out1 - out2);

	Matrix out_full;
	try
	{
		out_full = sortcols(full(mat),m);	
	}
	catch(...)
	{
		return dif;
	};

	try
	{				
		Matrix out		= sortcols(mat,m);		
        out.check_struct();
		dif				+= norm_1(out - out_full); 
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sortcols_dim::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_sortcols2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	mat_tup_2 out_full = sortcols2(full(mat));	

	try
	{		
		mat_tup_2 out	= sortcols2(mat);
        out.get<1>().check_struct();
        out.get<2>().check_struct();

		Real dif		= norm_1(out.get<1>() - out_full.get<1>());
		dif				+=norm_1(out.get<2>() - out_full.get<2>());

		Matrix iout		= out.get<2>();
		dif				+= norm_1(out.get<1>() - mat(colon(),iout));
		dif				+= norm_1(out.get<1>() - sortcols(mat));

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sortcols2::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_sortcols_dim2::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Integer r		= mat.rows();
	mat_tup_2 out1	= sortcols2(mat,irange(1,r));
	mat_tup_2 out2	= sortcols2(mat);

    out1.get<1>().check_struct();
    out1.get<2>().check_struct();
    out2.get<1>().check_struct();
    out2.get<2>().check_struct();

	Real dif		= norm_1(out1.get<1>() - out2.get<1>());
	dif				+= norm_1(out1.get<2>() - out2.get<2>());

	mat_tup_2 out_full;
	try
	{
		out_full		= sortcols2(full(mat),m);	
	}
	catch(...)
	{
		return dif;
	};

	try
	{		
		mat_tup_2 out	= sortcols2(mat,m);

        out.get<1>().check_struct();
        out.get<2>().check_struct();

		dif				+= norm_1(out.get<1>() - out_full.get<1>());
		dif				+=norm_1(out.get<2>() - out_full.get<2>());

		Matrix iout		= out.get<2>();
		dif			    += norm_1(out.get<1>() - mat(colon(),iout));
		dif				+= norm_1(out.get<1>() - sortcols(mat,m));

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sortcols_dim2::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};


Real test_function_convert::eval_mat(const Matrix& mat,bool,int )
{
	Matrix out_full;
	try
	{
		Matrix mf = full(mat);
		out_full = convert(mf,(enums::mat_type)code);	
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix out		= convert(mat,(enums::mat_type)code);
        out.check_struct();

		Real dif		= norm_1(out - out_full);

        bool isw        = mmlib::matrix_traits::get_value_type((enums::mat_type)code) 
                        < mmlib::matrix_traits::get_value_type(mat.matrix_type());
        if (!isw)
        {
		    dif			+=norm_1(out - mat);
        };

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_convert::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_delcols::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		Matrix mf = full(mat);
		out_full = mf.delcols(c1);	
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix out		= mat.delcols(c1);
        out.check_struct();

		Matrix c2		= irange(1,mat.cols());
		c2				= c2.delcols(c1);
		Real dif		= norm_1(out - out_full);

		Matrix out2		= mat(colon(),c2);
        out2.check_struct();

		dif				+=norm_1(out - out2);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_delcols::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_delrows::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		Matrix mf = full(mat);
		out_full = mf.delrows(c1);	
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix out		= mat.delrows(c1);
        out.check_struct();

		Real dif		= norm_1(out - out_full);
		Matrix c2		= irange(1,mat.rows());
		c2				= c2.delcols(c1);

		Matrix out2		= mat(c2,colon());
        out2.check_struct();

		dif				+=norm_1(out - out2);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_delrows::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

class func_sin : public scalar_function
{
	public:
		virtual enums::value_type return_value(enums::value_type vt,type_info in, type_info& ret) const
		{
            ret = in;
			return (enums::value_type)max((Integer)vt,(Integer)enums::value_real);
		};

		virtual void eval(Integer , Integer& ) const			{};
		virtual void eval(Integer v, Real& ret) const			{	ret = sin(v);	        };
		virtual void eval(Integer v, Complex& ret) const		{	ret = sin(v);	        };
        virtual void eval(Integer v, Object& ret) const		    
        {	
            ret = Object(ret.get_ti(),sin(v));	
        };

		virtual void eval(Real , Integer& ) const				{};
		virtual void eval(Real v, Real& ret) const				{	ret = sin(v);	        };
		virtual void eval(Real v, Complex& ret) const			{	ret = sin(v);	        };
        virtual void eval(Real v, Object& ret) const
        {	
            ret = Object(ret.get_ti(),sin(v));	
        };

		virtual void eval(const Complex& , Integer& ) const		{};
		virtual void eval(const Complex& , Real& ) const		{};
		virtual void eval(const Complex& v, Complex& ret) const	{	ret = sin(v);	        };
        virtual void eval(const Complex& v, Object& ret) const
        {	
            ret = Object(ret.get_ti(),sin(v));	
        };

		virtual void eval(const Object& , Integer& ) const		{};
		virtual void eval(const Object& , Real& ) const		    {};
		virtual void eval(const Object& , Complex& ) const	    {};
        virtual void eval(const Object& v, Object& ret) const
        {	
            ret = Object(ret.get_ti(),sin(v));	
        };
};
class func_cos : public scalar_function
{
	public:
		virtual enums::value_type return_value(enums::value_type vt,type_info in, type_info& ret) const
		{
            ret = in;
			return (enums::value_type)max((Integer)vt,(Integer)enums::value_real);
		};

		virtual void eval(Integer , Integer& ) const			{};
		virtual void eval(Integer v, Real& ret) const			{	ret = cos(v);	};
		virtual void eval(Integer v, Complex& ret) const		{	ret = cos(v);	};
        virtual void eval(Integer v, Object& ret) const		    
        {	
            ret = Object(ret.get_ti(),cos(v));	
        };

		virtual void eval(Real , Integer& ) const				{};
		virtual void eval(Real v, Real& ret) const				{	ret = cos(v);	};
		virtual void eval(Real v, Complex& ret) const			{	ret = cos(v);	};
        virtual void eval(Real v, Object& ret) const
        {	
            ret = Object(ret.get_ti(),cos(v));	
        };

		virtual void eval(const Complex& , Integer& ) const		{};
		virtual void eval(const Complex& , Real& ) const		{};
		virtual void eval(const Complex& v, Complex& ret) const	{	ret = cos(v);	};
        virtual void eval(const Complex& v, Object& ret) const	
        {	
            ret = Object(ret.get_ti(),cos(v));	
        };

		virtual void eval(const Object& , Integer& ) const		{};
		virtual void eval(const Object& , Real& ) const		    {};
		virtual void eval(const Object& , Complex& ) const	    {};
        virtual void eval(const Object& v, Object& ret) const	
        {	
            ret = Object(ret.get_ti(),cos(v));	
        };
};

class func_sin_t : public scalar_function_templ<func_sin_t>
{
	public:
		typedef Real		return_for_integer;
		typedef Real		return_for_real;
		typedef Complex		return_for_complex;
        typedef Object		return_for_object;

		template<class ret, class in>
		ret eval(in val) const
		{
			return sin(val);
		};

        gd::type_info return_type_info(gd::type_info in) const
        {
            return in;
        };
};
class func_cos_t : public scalar_function_templ<func_cos_t>
{
	public:
		typedef Real		return_for_integer;
		typedef Real		return_for_real;
		typedef Complex		return_for_complex;
        typedef Object		return_for_object;

		template<class ret, class in>
		ret eval(in val) const
		{
			return cos(val);
		};

        gd::type_info return_type_info(gd::type_info in) const
        {
            return in;
        };
};

Real test_function_eval_func::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{		
		Real dif = 0;
		{
			func_sin fs;
			Matrix out		= eval_func(mat,fs);
            out.check_struct();

			dif				+= norm_1(out - sin(mat));
		};
		{
			func_cos fc;
			Matrix out		= eval_func(mat,fc);
            out.check_struct();

			dif				+= norm_1(out - cos(mat));
		};
		{
			func_sin_t fs;
			Matrix out		= eval_func(mat,fs);
            out.check_struct();

			dif				+= norm_1(out - sin(mat));
		};
		{
			func_cos_t fc;
			Matrix out		= eval_func(mat,fc);
            out.check_struct();

			dif				+= norm_1(out - cos(mat));
		};

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_eval_func::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_get_colon::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		out_full = full(mat)(c1);	
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix out		= mat(c1);
        out.check_struct();
		Real dif		= norm_1(out - out_full);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_get_colon::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_get_colon_colon::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		out_full = full(mat)(c1,c2);	
	}
	catch(...)
	{
		return 0.;
	};
	try
	{		
		Matrix out		= mat(c1,c2);
        out.check_struct();

		Real dif		= norm_1(out - out_full);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_get_colon_colon::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_get_int::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		out_full = full(mat)(i);	
	}
	catch(...)
	{
		return 0.;
	};
	try
	{		
		Matrix out		= mat(i);
        out.check_struct();

		Real dif		= norm_1(out - out_full);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_get_int::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_get_int_int::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		out_full = full(mat)(i,j);	
	}
	catch(...)
	{
		return 0.;
	};
	try
	{		
		Matrix out		= mat(i,j);
        out.check_struct();

		Real dif		= norm_1(out - out_full);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_get_int_int::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};


Real test_function_get_array::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
    try
    {
	    Matrix A = full(mat);
	    enums::mat_type	mt = A.matrix_type();

	    if (A.rows() == 0 || A.cols() == 0)
	    {
		    return 0;
	    };

	    switch (mt)
	    {
		    case enums::integer_dense:
		    {
			    typedef Integer value_type;
			    value_type* ptr = A.get_array_unique<value_type>();
			    if (!ptr)
			    {
				    return 0;
			    };
			    Real dif = norm_1(A(1)-ptr[0]);
			    ptr[0] = 1;
			    dif += norm_1(A(1)-1);

			    return dif; 
		    }
		    case enums::real_dense:
		    {
			    typedef Real value_type;
			    value_type* ptr = A.get_array_unique<value_type>();
			    if (!ptr)
			    {
				    return 0;
			    };
			    Real dif = norm_1(A(1)-ptr[0]);
			    ptr[0] = 1;
			    dif += norm_1(A(1)-1);

			    return dif;
		    }
		    case enums::complex_dense:
		    {
			    typedef Complex value_type;
			    value_type* ptr = A.get_array_unique<value_type>();
			    if (!ptr)
			    {
				    return 0;
			    };
			    Real dif = norm_1(A(1)-ptr[0]);
			    ptr[0] = 1;
			    dif += norm_1(A(1)-1);

			    return dif;
		    };
	    };

	    return 0.;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_get_array::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_get_const_array::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
    try
    {
	    Matrix A = full(mat);
	    enums::mat_type	mt = A.matrix_type();

	    if (A.rows() == 0 || A.cols() == 0)
	    {
		    return 0;
	    };

	    switch (mt)
	    {
		    case enums::integer_dense:
		    {
			    typedef Integer value_type;
			    const value_type* ptr = A.get_array<value_type>();
			    if (!ptr)
			    {
				    return 0;
			    };
			    Real dif = norm_1(A(1)-ptr[0]);
			    return dif; 
		    }
		    case enums::real_dense:
		    {
			    typedef Real value_type;
			    const value_type* ptr = A.get_array<value_type>();
			    if (!ptr)
			    {
				    return 0;
			    };
			    Real dif = norm_1(A(1)-ptr[0]);
			    return dif;
		    }
		    case enums::complex_dense:
		    {
			    typedef Complex value_type;
			    const value_type* ptr = A.get_array<value_type>();
			    if (!ptr)
			    {
				    return 0;
			    };
			    Real dif = norm_1(A(1)-ptr[0]);
			    return dif;
		    };
	    };

	    return 0.;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_get_const_array::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};
Real test_function_get_scal::eval_mat(const Matrix& A,bool,int code )
{
    (void)code;
    try
    {
	    if (A.rows() != 1 || A.cols() != 1)
	    {
		    return 0;
	    };
	    enums::value_type	vt = A.value_type();

	    switch (vt)
	    {
		    case enums::value_integer:
		    {
			    Real dif = norm_1(A(1)-A.get_scalar<Integer>());
			    return dif; 
		    }
		    case enums::value_real:
		    {
			    Real dif = norm_1(A(1)-A.get_scalar<Real>());
			    return dif; 
		    }
		    case enums::value_complex:
		    {
			    Real dif = norm_1(A(1)-A.get_scalar<Complex>());
			    return dif; 
		    };
	    };
	    return 0;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_get_scal::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_is_sorted::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full = issorted(full(mat),d,is_asc);	

	try
	{		
		Matrix out		= issorted(mat,d,is_asc);
        out.check_struct();

		Real dif		= norm_1(out - out_full);

		Matrix ms		= sort(mat,d,is_asc);
		Matrix outs		= issorted(ms,d,is_asc);
        outs.check_struct();
        ms.check_struct();

		bool iss		= true;
		if (mat.rows() > 0 && mat.cols() > 0)
		{
			iss			= is_scalar_true(all(all(outs,1),2));
		};

		dif				+= (iss == false);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_is_sorted::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_is_sorted_cols::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	bool out_full	= issorted_cols(full(mat));	

	try
	{		
		bool out		= issorted_cols(mat);
		Real dif		= norm_1(out - out_full);

		Matrix ms		= sortcols(mat);
        ms.check_struct();
		bool outs		= issorted_cols(ms);

		dif				+= (outs == false);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_is_sorted_cols::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_resize_reserve::eval_mat(const Matrix& mat1,bool,int code )
{
    (void)code;
    try
    {
        Matrix mat = mat1;
        Matrix B = mat;
        mat.reserve(mat.rows() + 4, mat.cols() + 3);

        Matrix mat_f = full(mat1);
        Matrix B_f = mat_f;
        mat_f.reserve(mat_f.rows() + 4, mat_f.cols() + 3);

        mat.check_struct();
        Real diff = norm_1(B - mat);
        diff += norm_1(mat - mat_f);
        
        B.resize(mat.rows() + 2, mat.cols() + 2);
        B.check_struct();
        mat.resize(mat.rows() + 2, mat.cols() + 2);
        mat.check_struct();

        B_f.resize(mat_f.rows() + 2, mat_f.cols() + 2);
        mat_f.resize(mat_f.rows() + 2, mat_f.cols() + 2);
        diff += norm_1(B - mat);
        diff += norm_1(mat - mat_f);
        diff += norm_1(B - B_f);

        Matrix C = mat;
        mat.resize(mat.rows() - 1, mat.cols() - 1);
        Matrix tmp = C(colon(1,C.rows()-1),colon(1,C.cols()-1));
        tmp.check_struct();

        Matrix C_f = mat_f;
        mat_f.resize(mat_f.rows() - 1, mat_f.cols() - 1);
        Matrix tmp_f = C_f(colon(1,C_f.rows()-1),colon(1,C_f.cols()-1));

        diff += norm_1(mat - tmp);
        diff += norm_1(mat - mat_f);
        diff += norm_1(tmp - tmp_f);

        mat = C;
        mat.resize(mat.rows(), mat.cols() - 1);
        tmp = C(colon(),colon(1,C.cols()-1));
        tmp.check_struct();

        mat_f = C_f;
        mat_f.resize(mat_f.rows(), mat_f.cols() - 1);
        tmp_f = C_f(colon(),colon(1,C_f.cols()-1));

        diff += norm_1(mat - tmp);
        diff += norm_1(mat - mat_f);
        diff += norm_1(tmp - tmp_f);

        return diff;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};    
};
Real test_function_resize_reserve::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_resize_reserve_b::eval_mat(const Matrix& mat1,bool,int code )
{
    (void)code;
    try
    {
        if (mat1.struct_type() != enums::struct_banded)
        {
            return 0;
        };

        Matrix mat = mat1;
        Matrix B = mat;
        mat.reserve_band(mat.rows() + 4, mat.cols() + 3, mat.ldiags() + 2, mat.udiags() + 2);
        mat.check_struct();

        Matrix mat_f = full(mat1);
        Matrix B_f = mat_f;
        mat_f.reserve_band(mat_f.rows() + 4, mat_f.cols() + 3, mat_f.ldiags() + 2, mat_f.udiags() + 2);

        B.resize_band(mat.rows() + 3, mat.cols() + 3, mat.ldiags() + 1, mat.udiags() + 1);
        B.check_struct();        
        mat.resize_band(mat.rows() + 3, mat.cols() + 3, mat.ldiags() + 1, mat.udiags() + 1);
        mat.check_struct();

        B_f.resize_band(mat_f.rows() + 3, mat_f.cols() + 3, mat_f.ldiags() + 1, mat_f.udiags() + 1);
        mat_f.resize_band(mat_f.rows() + 3, mat_f.cols() + 3, mat_f.ldiags() + 1, mat_f.udiags() + 1);

        Real diff = norm_1(B - mat);
        diff += norm_1(B - B_f);
        diff += norm_1(mat - mat_f);

        Matrix C = mat;
        mat.resize_band(mat.rows() - 1, mat.cols() - 1, mat.ldiags() - 1, mat.udiags() - 1);
        Matrix tmp = C(colon(1,C.rows()-1),colon(1,C.cols()-1));
        {
            Integer l = std::max(C.ldiags() - 1,0L);
            Integer u = std::max(C.udiags() - 1,0L);
            tmp = tril(triu(tmp,-l),u);
        };
        tmp.check_struct();

        Matrix C_f = mat_f;
        mat_f.resize_band(mat_f.rows() - 1, mat_f.cols() - 1, mat_f.ldiags() - 1, mat_f.udiags() - 1);
        Matrix tmp_f = C_f(colon(1,C_f.rows()-1),colon(1,C_f.cols()-1));
        {
            Integer l = std::max(C_f.ldiags() - 1,0L);
            Integer u = std::max(C_f.udiags() - 1,0L);
            tmp_f = tril(triu(tmp_f,-l),u);
        }
        
        diff += norm_1(mat - tmp);
        diff += norm_1(mat - mat_f);
        diff += norm_1(tmp - tmp_f);

        mat = C;
        mat.resize_band(C.rows(), C.cols() - 1, C.ldiags() - 1, C.udiags() - 1);
        tmp = C(colon(),colon(1,C.cols()-1));
        {
            Integer l = std::max(C.ldiags() - 1,0L);
            Integer u = std::max(C.udiags() - 1,0L);
            tmp = tril(triu(tmp,-l),u);
        };
        tmp.check_struct();

        mat_f = C_f;
        mat_f.resize_band(C_f.rows(), C_f.cols() - 1, C_f.ldiags() - 1, C_f.udiags() - 1);
        tmp_f = C_f(colon(),colon(1,C_f.cols()-1));
        {
            Integer l = std::max(C_f.ldiags() - 1,0L);
            Integer u = std::max(C_f.udiags() - 1,0L);
            tmp_f = tril(triu(tmp_f,-l),u);
        };

        diff += norm_1(mat - tmp);
        diff += norm_1(mat - mat_f);
        diff += norm_1(tmp - tmp_f);
        return diff;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};    
};
Real test_function_resize_reserve_b::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_get_lu::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
    try
    {
        //Integer ld = mat.ldiags();
        //Integer ud = mat.udiags();

        Matrix mat_sp   = sparse(mat);
        Matrix mat_d    = full(mat);
        Matrix mat_bd   = band(mat);

        Integer ld_sp = get_ld(mat_sp);
        Integer ud_sp = get_ud(mat_sp);    

        Integer ld_d = get_ld(mat_d);
        Integer ud_d = get_ud(mat_d);

        Integer ld_bd = get_ld(mat_bd);
        Integer ud_bd = get_ud(mat_bd);

        if (ld_sp != ld_d || ld_bd != ld_d)
        {
            return 1.;
        };
        if (ud_sp != ud_d || ud_bd != ud_d)
        {
            return 1.;
        };

        return 0.;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};    
};
Real test_function_get_lu::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_is_sorted_rows::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	bool out_full	= issorted_rows(full(mat));	

	try
	{		
		bool out		= issorted_rows(mat);
		Real dif		= norm_1(out - out_full);

		Matrix ms		= sortrows(mat);
        ms.check_struct();
		bool outs		= issorted_rows(ms);

		dif				+= (outs == false);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_is_sorted_rows::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_del_colon::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		out_full = full(mat);	
		out_full(c1) = zeros(0,0);
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix out		= mat;
		out(c1)			= zeros(0,0);
        out.check_struct();

		Real dif		= norm_1(out - out_full);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_del_colon::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_del_colon_colon::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		out_full = full(mat);	
		out_full(c1,c2) = izeros(0,0);
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix out		= mat;
		out(c1,c2)		= izeros(0,0);
        out.check_struct();

		Real dif		= norm_1(out - out_full);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_del_colon_colon::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_del_int::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		out_full = full(mat);	
		out_full(i) = zeros(0,0);
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix out		= mat;
		out(i)			= zeros(0,0);
        out.check_struct();

		Real dif		= norm_1(out - out_full);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_del_int::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_del_int_int::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix out_full;
	try
	{
		out_full = full(mat);	
		out_full(i,j) = zeros(0,0);
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix out		= mat;
		out(i,j)		= zeros(0,0);
        out.check_struct();

		Real dif		= norm_1(out - out_full);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_del_int_int::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_drop_colon::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix mat2 = mat;
	try
	{
		Matrix mf = full(mat);
		mf(c1) = 0;		
		mat2(c1) = 1;
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		

		Matrix mf1_0 = full(mat);
		Matrix mf2_0 = full(mat);
		Matrix mf3_0 = full(mat);

		mf1_0(c1) = Integer();
		mf2_0(c1) = Real();
		mf3_0(c1) = Complex();

		Matrix out1_0	= mat;
		Matrix out2_0	= mat;
		Matrix out3_0	= mat;

		Matrix out1_1	= mat;
		Matrix out2_1	= mat;
		Matrix out3_1	= mat;

		out1_0(c1) = Integer();
		out2_0(c1) = Real();
		out3_0(c1) = Complex();

		out1_1(c1) = full(Integer());
		out2_1(c1) = full(Real());
		out3_1(c1) = full(Complex());        

        out1_0.check_struct();
        out2_0.check_struct();
        out3_0.check_struct();
        out1_1.check_struct();
        out2_1.check_struct();
        out3_1.check_struct();

		Real dif		= norm_1(out1_0 - mf1_0);
		dif				+= norm_1(out2_0 - mf2_0);
		dif				+= norm_1(out3_0 - mf3_0);

		dif				+= norm_1(out1_0(c1));
		dif				+= norm_1(out2_0(c1));
		dif				+= norm_1(out3_0(c1));

		dif				+= norm_1(out1_1(c1));
		dif				+= norm_1(out2_1(c1));
		dif				+= norm_1(out3_1(c1));

		dif				+= norm_1(mat2(c1)-1);
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_drop_colon::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_drop_colon_colon::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix mat2 = mat;
	try
	{
		Matrix mf = full(mat);
		mf(c1,c2) = 0;		
		mat2(c1,c2) = 1;
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1_0 = full(mat);
		Matrix mf2_0 = full(mat);
		Matrix mf3_0 = full(mat);

		mf1_0(c1,c2) = Integer();
		mf2_0(c1,c2) = Real();
		mf3_0(c1,c2) = Complex();

		Matrix out1_0	= mat;
		Matrix out2_0	= mat;
		Matrix out3_0	= mat;

		Matrix out1_1	= mat;
		Matrix out2_1	= mat;
		Matrix out3_1	= mat;

		out1_0(c1,c2) = Integer();
		out2_0(c1,c2) = Real();
		out3_0(c1,c2) = Complex();

		out1_1(c1,c2) = full(Integer());
		out2_1(c1,c2) = full(Real());
		out3_1(c1,c2) = full(Complex());

        out1_0.check_struct();
        out2_0.check_struct();
        out3_0.check_struct();

        out1_1.check_struct();
        out2_1.check_struct();
        out3_1.check_struct();

		Real dif		= norm_1(out1_0 - mf1_0);
		dif				+= norm_1(out2_0 - mf2_0);
		dif				+= norm_1(out3_0 - mf3_0);

		dif				+= norm_1(out1_0(c1,c2));
		dif				+= norm_1(out2_0(c1,c2));
		dif				+= norm_1(out3_0(c1,c2));

		dif				+= norm_1(out1_1(c1,c2));
		dif				+= norm_1(out2_1(c1,c2));
		dif				+= norm_1(out3_1(c1,c2));

		dif				+= norm_1(mat2(c1,c2)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_drop_colon_colon::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_drop_int::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix mat2 = mat;
	try
	{
		Matrix mf = full(mat);
		mf(i) = 0;		
		mat2(i) = 1;
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1_0 = full(mat);
		Matrix mf2_0 = full(mat);
		Matrix mf3_0 = full(mat);

		mf1_0(i) = Integer();
		mf2_0(i) = Real();
		mf3_0(i) = Complex();

		Matrix out1_0	= mat;
		Matrix out2_0	= mat;
		Matrix out3_0	= mat;

		Matrix out1_1	= mat;
		Matrix out2_1	= mat;
		Matrix out3_1	= mat;

		out1_0(i) = Integer();
		out2_0(i) = Real();
		out3_0(i) = Complex();

		out1_1(i) = full(Integer());
		out2_1(i) = full(Real());
		out3_1(i) = full(Complex());

        out1_0.check_struct();
        out2_0.check_struct();
        out3_0.check_struct();

        out1_1.check_struct();
        out2_1.check_struct();
        out3_1.check_struct();

		Real dif		= norm_1(out1_0 - mf1_0);
		dif				+= norm_1(out2_0 - mf2_0);
		dif				+= norm_1(out3_0 - mf3_0);

		dif				+= norm_1(out1_0(i));
		dif				+= norm_1(out2_0(i));
		dif				+= norm_1(out3_0(i));

		dif				+= norm_1(out1_1(i));
		dif				+= norm_1(out2_1(i));
		dif				+= norm_1(out3_1(i));

		dif				+= norm_1(mat2(i)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_drop_int::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_drop_int_int::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	Matrix mat2 = mat;
	try
	{
		Matrix mf = full(mat);
		mf(i,j) = 0;		
		mat2(i,j) = 1;
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1_0 = full(mat);
		Matrix mf2_0 = full(mat);
		Matrix mf3_0 = full(mat);

		mf1_0(i,j) = Integer();
		mf2_0(i,j) = Real();
		mf3_0(i,j) = Complex();

		Matrix out1_0	= mat;
		Matrix out2_0	= mat;
		Matrix out3_0	= mat;

		Matrix out1_1	= mat;
		Matrix out2_1	= mat;
		Matrix out3_1	= mat;

		out1_0(i,j) = Integer();
		out2_0(i,j) = Real();
		out3_0(i,j) = Complex();

		out1_1(i,j) = full(Integer());
		out2_1(i,j) = full(Real());
		out3_1(i,j) = full(Complex());

        out1_0.check_struct();
        out2_0.check_struct();
        out3_0.check_struct();

        out1_1.check_struct();
        out2_1.check_struct();
        out3_1.check_struct();

		Real dif		= norm_1(out1_0 - mf1_0);
		dif				+= norm_1(out2_0 - mf2_0);
		dif				+= norm_1(out3_0 - mf3_0);

		dif				+= norm_1(out1_0(i,j));
		dif				+= norm_1(out2_0(i,j));
		dif				+= norm_1(out3_0(i,j));

		dif				+= norm_1(out1_1(i,j));
		dif				+= norm_1(out2_1(i,j));
		dif				+= norm_1(out3_1(i,j));

		dif				+= norm_1(mat2(i,j)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_drop_int_int::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_set_int_scal::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{
		Matrix mf = full(mat);
		mf(i) = 1;
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1_0 = full(mat);
		Matrix mf2_0 = full(mat);
		Matrix mf3_0 = full(mat);

		Matrix mf1 = full(mat);
		Matrix mf2 = full(mat);
		Matrix mf3 = full(mat);

		mf1_0(i) = Integer();
		mf2_0(i) = Real();
		mf3_0(i) = Complex();

		mf1(i) = Integer(1);
		mf2(i) = Real(1);
		mf3(i) = Complex(1);

		Matrix out1_0	= mat;
		Matrix out2_0	= mat;
		Matrix out3_0	= mat;

		Matrix out1		= mat;
		Matrix out2		= mat;
		Matrix out3		= mat;

		out1_0(i)		= Integer();
		out2_0(i)		= Real();
		out3_0(i)		= Complex();

		out1(i)			= Integer(1);
		out2(i)			= Real(1);
		out3(i)			= Complex(1);

        out1_0.check_struct();
        out2_0.check_struct();
        out3_0.check_struct();

        out1.check_struct();
        out2.check_struct();
        out3.check_struct();

		Real dif		= norm_1(out1_0 - mf1_0);
		dif				+= norm_1(out2_0 - mf2_0);
		dif				+= norm_1(out3_0 - mf3_0);
		dif				+= norm_1(out1 - mf1);
		dif				+= norm_1(out2 - mf2);
		dif				+= norm_1(out3 - mf3);

		dif				+= norm_1(out1_0(i));
		dif				+= norm_1(out2_0(i));
		dif				+= norm_1(out3_0(i));

		dif				+= norm_1(out1(i)-1);
		dif				+= norm_1(out2(i)-1);
		dif				+= norm_1(out3(i)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_set_int_scal::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_set_int2_scal::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{
		Matrix mf = full(mat);
		mf(i,j) = 1;
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1_0 = full(mat);
		Matrix mf2_0 = full(mat);
		Matrix mf3_0 = full(mat);

		Matrix mf1 = full(mat);
		Matrix mf2 = full(mat);
		Matrix mf3 = full(mat);

		mf1_0(i,j) = Integer();
		mf2_0(i,j) = Real();
		mf3_0(i,j) = Complex();

		mf1(i,j) = Integer(1);
		mf2(i,j) = Real(1);
		mf3(i,j) = Complex(1);

		Matrix out1_0	= mat;
		Matrix out2_0	= mat;
		Matrix out3_0	= mat;

		Matrix out1		= mat;
		Matrix out2		= mat;
		Matrix out3		= mat;

		out1_0(i,j)		= Integer();
		out2_0(i,j)		= Real();
		out3_0(i,j)		= Complex();

		out1(i,j)			= Integer(1);
		out2(i,j)			= Real(1);
		out3(i,j)			= Complex(1);

        out1_0.check_struct();
        out2_0.check_struct();
        out3_0.check_struct();

        out1.check_struct();
        out2.check_struct();
        out3.check_struct();

		Real dif		= norm_1(out1_0 - mf1_0);
		dif				+= norm_1(out2_0 - mf2_0);
		dif				+= norm_1(out3_0 - mf3_0);
		dif				+= norm_1(out1 - mf1);
		dif				+= norm_1(out2 - mf2);
		dif				+= norm_1(out3 - mf3);

		dif				+= norm_1(out1_0(i,j));
		dif				+= norm_1(out2_0(i,j));
		dif				+= norm_1(out3_0(i,j));

		dif				+= norm_1(out1(i,j)-1);
		dif				+= norm_1(out2(i,j)-1);
		dif				+= norm_1(out3(i,j)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_set_int2_scal::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_set_col_scal::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{
		Matrix mf = full(mat);
		mf(c1) = 1;
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1		= full(mat);
		Matrix mf2		= full(mat);
		Matrix mf3		= full(mat);

		mf1(c1)			= Integer(1);
		mf2(c1)			= Real(1);
		mf3(c1)			= Complex(1);

		Matrix out1		= mat;
		Matrix out2		= mat;
		Matrix out3		= mat;

		out1(c1)		= Integer(1);
		out2(c1)		= Real(1);
		out3(c1)		= Complex(1);

        out1.check_struct();
        out2.check_struct();
        out3.check_struct();

		Real dif		= 0;
		dif				+= norm_1(out1 - mf1);
		dif				+= norm_1(out2 - mf2);
		dif				+= norm_1(out3 - mf3);

		dif				+= norm_1(out1(c1)-1);
		dif				+= norm_1(out2(c1)-1);
		dif				+= norm_1(out3(c1)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_set_col_scal::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0;
};

Real test_function_set_col2_scal::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{
		Matrix mf = full(mat);
		mf(c1,c2) = 1;
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1		= full(mat);
		Matrix mf2		= full(mat);
		Matrix mf3		= full(mat);

		mf1(c1,c2)		= Integer(1);
		mf2(c1,c2)		= Real(1);
		mf3(c1,c2)		= Complex(1);

		Matrix out1		= mat;
		Matrix out2		= mat;
		Matrix out3		= mat;

		out1(c1,c2)		= Integer(1);
		out2(c1,c2)		= Real(1);
		out3(c1,c2)		= Complex(1);

        out1.check_struct();
        out2.check_struct();
        out3.check_struct();

		Real dif		= 0;
		dif				+= norm_1(out1 - mf1);
		dif				+= norm_1(out2 - mf2);
		dif				+= norm_1(out3 - mf3);

		dif				+= norm_1(out1(c1,c2)-1);
		dif				+= norm_1(out2(c1,c2)-1);
		dif				+= norm_1(out3(c1,c2)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_set_col2_scal::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_set_diag_scal::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{
		Matrix mf = full(mat);
		mf.diag(d) = 1;
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1		= full(mat);
		Matrix mf2		= full(mat);
		Matrix mf3		= full(mat);

		mf1.diag(d)		= Integer(1);
		mf2.diag(d)		= Real(1);
		mf3.diag(d)		= Complex(1);

		Matrix out1		= mat;
		Matrix out2		= mat;
		Matrix out3		= mat;

		out1.diag(d)	= Integer(1);
		out2.diag(d)	= Real(1);
		out3.diag(d)	= Complex(1);

        out1.check_struct();
        out2.check_struct();
        out3.check_struct();

		Real dif		= 0;
		dif				+= norm_1(out1 - mf1);
		dif				+= norm_1(out2 - mf2);
		dif				+= norm_1(out3 - mf3);

		dif				+= norm_1(out1.diag(d)-1);
		dif				+= norm_1(out2.diag(d)-1);
		dif				+= norm_1(out3.diag(d)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_set_diag_scal::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0;
};

Real test_function_set_col_mat::eval_mat(const Matrix& mat,bool show_res,int code)
{
    (void)code;
    m_new_objects = 0;  

	Integer r, c;
	try
	{
		Matrix tmp = mat(c1);
		r = tmp.rows();
		c = tmp.cols();
	}
	catch(...)
	{
		return 0.;
	};

    Real dif		= 0;

	try
	{				
		typedef dynamic_mat_set::container container;
        long n1 = mmlib::details::no_existing_objects();
		const container& mc = ms.get(r*c);
        n1 = mmlib::details::no_existing_objects() - n1;
        m_new_objects = n1;

		size_t size = mc.size();

		for (size_t i = 0; i < size ; i ++ )
        {
			Matrix mf1		= full(mat);
			Matrix out1		= mat;
			Matrix out2		= mat;

			try
			{
				mf1(c1)		= mc[i];
			}
			catch(...)
			{
				continue;
			};
			out1(c1)		= mc[i];
			out2(c1)		= full(mc[i]);
			Matrix mat2		= mc[i];
		    	
            out1.check_struct();
            out2.check_struct();

			dif				+= norm_1(out1 - mf1);
			dif				+= norm_1(out1 - out2);
			if (show_res)
			{
				logger()  << boost::lexical_cast<std::string>(i) + " " 
							+ boost::lexical_cast<std::string>(dif) + "\n";
			};
		};		
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};

    return dif;
};
Real test_function_set_col_mat::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_set_col2_mat::eval_mat(const Matrix& mat,bool show_res,int code)
{
    (void)code;
    m_new_objects = 0;

	Integer r, c;
	try
	{
		Matrix tmp = mat(c1,c2);
		r = tmp.rows();
		c = tmp.cols();
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Real dif		= 0;

		typedef dynamic_mat_set::container container;
        
        long n1 = mmlib::details::no_existing_objects();
		const container& mc = ms.get(r,c);
        n1 = mmlib::details::no_existing_objects() - n1;
        m_new_objects = n1;

		size_t size = mc.size();

		for (size_t i = 0; i < size ; i ++ )
		{
			Matrix mf1		= full(mat);
			Matrix out1		= mat;
			Matrix out2		= mat;

			try
			{
				mf1(c1,c2)	= mc[i];
			}
			catch(...)
			{
				continue;
			};
			out1(c1,c2)		= mc[i];
			out2(c1,c2)		= full(mc[i]);
			Matrix mat2		= mc[i];
			
            out1.check_struct();
            out2.check_struct();

			dif				+= norm_1(out1 - mf1);
			dif				+= norm_1(out1 - out2);
			if (show_res)
			{
				logger()  << boost::lexical_cast<std::string>(i) + " " + boost::lexical_cast<std::string>(dif) + "\n";
			};

		};

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_set_col2_mat::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_set_diag_mat::eval_mat(const Matrix& mat,bool show_res,int code)
{
    (void)code;
    m_new_objects = 0;  

	Integer r, c;
	try
	{
		Matrix tmp = mat.diag(d);
		r = tmp.rows();
		c = tmp.cols();
	}
	catch(...)
	{
		return 0.;
	};

    Real dif		= 0;

	try
	{				
		typedef dynamic_mat_set::container container;
        long n1 = mmlib::details::no_existing_objects();
		const container& mc = ms.get(r,c);
        n1 = mmlib::details::no_existing_objects() - n1;
        m_new_objects = n1;

		size_t size = mc.size();

		for (size_t i = 0; i < size ; i ++ )
        {
			Matrix mf1		= full(mat);
			Matrix out1		= mat;
			Matrix out2		= mat;

			try
			{
				mf1.diag(d)	= mc[i];
			}
			catch(...)
			{
				continue;
			};
			out1.diag(d)	= mc[i];
			out2.diag(d)	= full(mc[i]);
			Matrix mat2		= mc[i];
		    	
            out1.check_struct();
            out2.check_struct();

			dif				+= norm_1(out1 - mf1);
			dif				+= norm_1(out1 - out2);
            dif				+= norm_1(out1.diag(d) - mat2);
			if (show_res)
			{
				logger()  << boost::lexical_cast<std::string>(i) + " " 
							+ boost::lexical_cast<std::string>(dif) + "\n";
			};
		};		
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};

    return dif;
};
Real test_function_set_diag_mat::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_set_int_mat::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{
		Matrix mf = full(mat);
		mf(i) = full(1);
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1_0 = full(mat);
		Matrix mf2_0 = full(mat);
		Matrix mf3_0 = full(mat);

		Matrix mf1 = full(mat);
		Matrix mf2 = full(mat);
		Matrix mf3 = full(mat);

		mf1_0(i) = full(Integer());
		mf2_0(i) = full(Real());
		mf3_0(i) = full(Complex());

		mf1(i) = full(Integer(1));
		mf2(i) = full(Real(1));
		mf3(i) = full(Complex(1));

		Matrix out1_0	= mat;
		Matrix out2_0	= mat;
		Matrix out3_0	= mat;

		Matrix out1		= mat;
		Matrix out2		= mat;
		Matrix out3		= mat;

		out1_0(i)		= full(Integer());
		out2_0(i)		= full(Real());
		out3_0(i)		= full(Complex());

		out1(i)			= full(Integer(1));
		out2(i)			= full(Real(1));
		out3(i)			= full(Complex(1));

        out1_0.check_struct();
        out2_0.check_struct();
        out3_0.check_struct();

        out1.check_struct();
        out2.check_struct();
        out3.check_struct();

		Real dif		= norm_1(out1_0 - mf1_0);
		dif				+= norm_1(out2_0 - mf2_0);
		dif				+= norm_1(out3_0 - mf3_0);
		dif				+= norm_1(out1 - mf1);
		dif				+= norm_1(out2 - mf2);
		dif				+= norm_1(out3 - mf3);

		dif				+= norm_1(out1_0(i));
		dif				+= norm_1(out2_0(i));
		dif				+= norm_1(out3_0(i));

		dif				+= norm_1(out1(i)-1);
		dif				+= norm_1(out2(i)-1);
		dif				+= norm_1(out3(i)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_set_int_mat::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_set_int2_mat::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{
		Matrix mf = full(mat);
		mf(i,j) = full(1);
	}
	catch(...)
	{
		return 0.;
	};

	try
	{		
		Matrix mf1_0 = full(mat);
		Matrix mf2_0 = full(mat);
		Matrix mf3_0 = full(mat);

		Matrix mf1 = full(mat);
		Matrix mf2 = full(mat);
		Matrix mf3 = full(mat);

		mf1_0(i,j) = full(Integer());
		mf2_0(i,j) = full(Real());
		mf3_0(i,j) = full(Complex());

		mf1(i,j) = full(Integer(1));
		mf2(i,j) = full(Real(1));
		mf3(i,j) = full(Complex(1));

		Matrix out1_0	= mat;
		Matrix out2_0	= mat;
		Matrix out3_0	= mat;

		Matrix out1		= mat;
		Matrix out2		= mat;
		Matrix out3		= mat;

		out1_0(i,j)		= full(Integer());
		out2_0(i,j)		= full(Real());
		out3_0(i,j)		= full(Complex());

		out1(i,j)			= full(Integer(1));
		out2(i,j)			= full(Real(1));
		out3(i,j)			= full(Complex(1));

        out1_0.check_struct();
        out2_0.check_struct();
        out3_0.check_struct();

        out1.check_struct();
        out2.check_struct();
        out3.check_struct();

		Real dif		= norm_1(out1_0 - mf1_0);
		dif				+= norm_1(out2_0 - mf2_0);
		dif				+= norm_1(out3_0 - mf3_0);
		dif				+= norm_1(out1 - mf1);
		dif				+= norm_1(out2 - mf2);
		dif				+= norm_1(out3 - mf3);

		dif				+= norm_1(out1_0(i,j));
		dif				+= norm_1(out2_0(i,j));
		dif				+= norm_1(out3_0(i,j));

		dif				+= norm_1(out1(i,j)-1);
		dif				+= norm_1(out2(i,j)-1);
		dif				+= norm_1(out3(i,j)-1);

		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_set_int2_mat::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_sparse::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{		
		Real dif		= norm_1(mat - sparse(mat));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_sparse::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};


Real test_function_band::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{		
		Real dif		= norm_1(mat - band(mat));
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_band::eval_scalar(const Scalar& ,bool,int code )
{
    (void)code;
	return 0.;
};

Real test_function_clone::eval_mat(const Matrix& mat,bool,int code )
{
    (void)code;
	try
	{	
		Real dif		= 0;
		{
			Matrix A		= clone(mat);
            A.check_struct();

			dif				= norm_1(mat - A);
			dif				+= (A.is_unique()==false);
		};
		{
			Matrix B		= mat;
			Matrix A		= clone(mat);
            A.check_struct();
			dif				= norm_1(mat - A);
			dif				+= (A.is_unique()==false);
		};
		{
			Matrix B		= mat;
			Matrix A		= clone(B);
            A.check_struct();
			dif				= norm_1(mat - A);
			dif				+= (A.is_unique()==false);
		};
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_clone::eval_scalar(const Scalar& ,bool,int code )
{
    (void) code;
	return 0.;
};


Real test_function_io_formatted::eval_mat(const Matrix& mat,bool,int code )
{
    (void) code;
	try
	{	
		Real dif = 0;

		{
			std::ostringstream ss;
			ss.precision(15);
			ss << mat;

			Matrix tmp;
			std::istringstream ss2(ss.str());
            ss2>>tmp;

            tmp.check_struct();
			
			dif += norm_1(mat - tmp);
		};
		{
			std::ostringstream ss;
			ss.precision(15);
			ss << mat;
			ss << mat;
			ss << mat;

			Matrix tmp1, tmp2, tmp3;
			std::istringstream ss2(ss.str());
            ss2 >> tmp1;
			ss2 >> tmp2;
			ss2 >> tmp3;
			
            tmp1.check_struct();
            tmp2.check_struct();
            tmp3.check_struct();

			dif += norm_1(mat - tmp1);
			dif += norm_1(mat - tmp2);
			dif += norm_1(mat - tmp3);
		};
		if (abs(dif)<1e-10)
		{
			dif = 0;
		};
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};

Real test_function_io_formatted::eval_scalar(const Scalar& s,bool,int code )
{
    (void) code;
	Real dif = 0;
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();			
			{
				std::ostringstream ss;
				ss.precision(15);
				ss << value;

				Matrix tmp;
				std::istringstream ss2(ss.str());
				ss2 >> tmp;

                tmp.check_struct();

				dif += norm_1(value - tmp);
			}
			{
				std::ostringstream ss;
				ss.precision(15);
				ss << value;
				ss << value;
				ss << value;

				Matrix tmp1, tmp2, tmp3;
				std::istringstream ss2(ss.str());
				ss2 >> tmp1;
				ss2 >> tmp2;
				ss2 >> tmp3;

                tmp1.check_struct();
                tmp2.check_struct();
                tmp3.check_struct();
				
				dif += norm_1(value - tmp1);
				dif += norm_1(value - tmp2);
				dif += norm_1(value - tmp3);
			};
			break;
		}
		case enums::value_real:
		{
			Real value = s.get_real();
			{
				std::ostringstream ss;
				ss.precision(15);
				ss << value;

				Matrix tmp;
				std::istringstream ss2(ss.str());
				ss2 >> tmp;

                tmp.check_struct();

				dif += norm_1(value - tmp);
			}
			{
				std::ostringstream ss;
				ss.precision(15);
				ss << value;
				ss << value;
				ss << value;

				Matrix tmp1, tmp2, tmp3;
				std::istringstream ss2(ss.str());
				ss2 >> tmp1;
				ss2 >> tmp2;
				ss2 >> tmp3;
				
                tmp1.check_struct();
                tmp2.check_struct();
                tmp3.check_struct();

				dif += norm_1(value - tmp1);
				dif += norm_1(value - tmp2);
				dif += norm_1(value - tmp3);
			};
			break;
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			{
				std::ostringstream ss;
				ss.precision(15);
				ss << value;

				Matrix tmp;
				std::istringstream ss2(ss.str());
				ss2 >> tmp;

                tmp.check_struct();

				dif += norm_1(value - tmp);
			}
			{
				std::ostringstream ss;
				ss.precision(15);
				ss << value;
				ss << value;
				ss << value;

				Matrix tmp1, tmp2, tmp3;
				std::istringstream ss2(ss.str());
				ss2 >> tmp1;
				ss2 >> tmp2;
				ss2 >> tmp3;

                tmp1.check_struct();
                tmp2.check_struct();
                tmp3.check_struct();
				
				dif += norm_1(value - tmp1);
				dif += norm_1(value - tmp2);
				dif += norm_1(value - tmp3);
			};
			break;
		}
		default:
		{
			return 0;
		}
	};
	if (abs(dif)<1e-4)
	{
		dif = 0;
	};
	return dif;
};
Real test_function_serialize::eval_mat(const Matrix& mat,bool,int code )
{
    (void) code;
	try
	{	
		Real dif = 0;

		{
			std::ostringstream ss;
			oarchive ia(ss);
			ia<< mat;

			std::istringstream ss2(ss.str());
			iarchive ia2(ss2);
			Matrix tmp;
			ia2>>tmp;

            tmp.check_struct();
			
			dif += norm_1(mat - tmp);
		};
		{
			std::ostringstream ss;
			oarchive ia(ss);
			ia<< mat << mat << mat;

			Matrix tmp1, tmp2, tmp3;
			std::istringstream ss2(ss.str());
			iarchive ia2(ss2);
			ia2 >> tmp1 >> tmp2 >> tmp3;

            tmp1.check_struct();
            tmp2.check_struct();
            tmp3.check_struct();
			
			dif += norm_1(mat - tmp1);
			dif += norm_1(mat - tmp2);
			dif += norm_1(mat - tmp3);
		};

		if (abs(dif) < 1e-10)
		{
			dif = 0;
		};
		return dif;
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_serialize::eval_scalar(const Scalar& s,bool b,int code)
{
	switch(s.value_type())
	{
		case enums::value_integer:
		{
			Integer value = s.get_int();
			return eval_mat(value,b,code);
		}
		case enums::value_real:
		{
			Real value = s.get_real();
			return eval_mat(value,b,code);
		}
		case enums::value_complex:
		{
			Complex value = s.get_complex();
			return eval_mat(value,b,code);
		}
		default:
		{
			return 0;
		}
	};
};

Real test_function_diag::eval_mat(const Matrix& mat,bool,int code )
{
    (void) code;
    try
    {
	    Real dif		= 0;
	    Matrix tmp		= vec(mat);
	    {
		    Matrix out	= diag(tmp,d);
            if (d > 0 && d > out.cols())
            {
                return 0;
            };
            if (d < 0 && -d > out.rows())
            {
                return 0;
            };
		    Matrix out2	= get_diag(out,d);

            out.check_struct();
            out2.check_struct();

		    dif			+= norm_1(out2 - tmp);
	    };
	    return dif;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_diag::eval_scalar(const Scalar& ,bool,int code )
{
    (void) code;
	return 0;
};

Real test_function_bdiag::eval_mat(const Matrix& mat,bool,int code )
{
    (void) code;
    try
    {
	    Real dif		= 0;
	    Matrix tmp		= vec(mat);
	    {
		    Matrix out	= bdiag(tmp,d);
            Matrix outd	= diag(tmp,d);

            if (d > 0 && d > out.cols())
            {
                return 0;
            };
            if (d < 0 && -d > out.rows())
            {
                return 0;
            };
		    Matrix out2	= get_diag(out,d);

            out.check_struct();
            out2.check_struct();

            dif			+= norm_1(out - outd);
		    dif			+= norm_1(out2 - tmp);
	    };
	    return dif;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_bdiag::eval_scalar(const Scalar& ,bool,int code )
{
    (void) code;
	return 0;
};

Real test_function_spdiag::eval_mat(const Matrix& mat,bool,int code )
{
    (void) code;
    try
    {
	    Real dif		= 0;
	    Matrix tmp		= vec(mat);
	    {
		    Matrix out	= spdiag(tmp,d);
            Matrix outd	= diag(tmp,d);

            if (d > 0 && d > out.cols())
            {
                return 0;
            };
            if (d < 0 && -d > out.rows())
            {
                return 0;
            };
		    Matrix out2	= get_diag(out,d);

            out.check_struct();
            out2.check_struct();

            dif			+= norm_1(out - outd);
		    dif			+= norm_1(out2 - tmp);
	    };
	    return dif;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_spdiag::eval_scalar(const Scalar& ,bool,int code )
{
    (void) code;
	return 0;
};
Real test_function_diags::eval_mat(const Matrix& mat,bool,int code )
{
    (void) code;
    try
    {
	    Real dif		= 0;
	    Matrix tmp		= vec(mat);
	    Integer m = mat.rows(), n = mat.cols();
	    {
		    Matrix out	= diags(tmp,(mat_row(), 0),m*n,m*n);
            out.check_struct();

		    dif			+= norm_1(out - diag(tmp,0));
	    };
        if (1 < m*n)
	    {
		    Matrix out	= diags(tmp,(mat_row(), 1),m*n,m*n);
            out.check_struct();

		    dif			+= norm_1(out - diag(tmp,1)(colon(1,m*n),colon(1,m*n)) );
	    };
        if (1 < m*n)
	    {
		    Matrix out	= diags(tmp,(mat_row(), -1),m*n,m*n);
            out.check_struct();

		    dif			+= norm_1(out - diag(tmp,-1)(colon(1,m*n),colon(1,m*n)) );
	    };	

        if (n > 1 && m > 1)
        {
            {
	            Matrix out	= diags(mat(colon(),colon(1,2)),(mat_row(), -1, 0),m,m);
                out.check_struct();

                dif			+= norm_1(get_diag(out,-1) - mat(colon(1,m-1),1));
	            dif			+= norm_1(get_diag(out,0) - mat(colon(),2));
            }
            {
	            Matrix out	= diags(mat(colon(),colon(1,2)),(mat_row(), 0, 1),m,m);
                out.check_struct();

	            dif			+= norm_1(get_diag(out,0) - mat(colon(),1));
                dif			+= norm_1(get_diag(out,1) - mat(colon(1,m-1),2));
            }
            {
	            Matrix out	= diags(mat(colon(),colon(1,2)),(mat_row(), -1, 1),m,m);
                out.check_struct();

	            dif			+= norm_1(get_diag(out,-1) - mat(colon(1,m-1),1));
                dif			+= norm_1(get_diag(out,1) - mat(colon(1,m-1),2));
            };
        };

	    return dif;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_diags::eval_scalar(const Scalar& ,bool,int code )
{
    (void) code;
	return 0;
};

Real test_function_bdiags::eval_mat(const Matrix& mat,bool,int code )
{
    (void) code;
    try
    {
	    Real dif		= 0;
	    Matrix tmp		= vec(mat);
	    Integer m = mat.rows(), n = mat.cols();
	    {
		    Matrix out	= bdiags(tmp,(mat_row(), 0),m*n,m*n);
            Matrix out2	= diags(tmp,(mat_row(), 0),m*n,m*n);
            out.check_struct();

		    dif			+= norm_1(out - out2);
	    };
        if (1 < m*n)
	    {
		    Matrix out	= bdiags(tmp,(mat_row(), 1),m*n,m*n);
            Matrix out2	= diags(tmp,(mat_row(), 1),m*n,m*n);
            out.check_struct();

		    dif			+= norm_1(out - out2);
	    };
        if (1 < m*n)
	    {
		    Matrix out	= bdiags(tmp,(mat_row(), -1),m*n,m*n);
            Matrix out2	= diags(tmp,(mat_row(), -1),m*n,m*n);
            out.check_struct();

		    dif			+= norm_1(out - out2);
	    };		

	    if (n > 1 && m > 1)
	    {
		    {
			    Matrix out	= bdiags(mat(colon(),colon(1,2)),(mat_row(), -1, 0),m,m);
                Matrix out2	= diags(mat(colon(),colon(1,2)),(mat_row(), -1, 0),m,m);
                out.check_struct();

                dif			+= norm_1(out - out2);
		    }
		    {
			    Matrix out	= bdiags(mat(colon(),colon(1,2)),(mat_row(), 0, 1),m,m);
                Matrix out2	= diags(mat(colon(),colon(1,2)),(mat_row(), 0, 1),m,m);
                out.check_struct();

                dif			+= norm_1(out - out2);
		    }
		    {
			    Matrix out	= bdiags(mat(colon(),colon(1,2)),(mat_row(), -1, 1),m,m);
                Matrix out2	= diags(mat(colon(),colon(1,2)),(mat_row(), -1, 1),m,m);
                out.check_struct();

			    dif			+= norm_1(out - out2);
		    };
	    };

	    return dif;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_bdiags::eval_scalar(const Scalar& ,bool,int code )
{
    (void) code;
	return 0;
};

Real test_function_spdiags::eval_mat(const Matrix& mat,bool,int code )
{
    (void) code;
    try
    {
	    Real dif		= 0;
	    Matrix tmp		= vec(mat);
	    Integer m = mat.rows(), n = mat.cols();
	    {
		    Matrix out	= spdiags(tmp,(mat_row(), 0),m*n,m*n);
            Matrix out2	= diags(tmp,(mat_row(), 0),m*n,m*n);
            out.check_struct();

		    dif			+= norm_1(out - out2);
	    };
        if (1 < m*n)
	    {
		    Matrix out	= spdiags(tmp,(mat_row(), 1),m*n,m*n);
            Matrix out2	= diags(tmp,(mat_row(), 1),m*n,m*n);
            out.check_struct();

		    dif			+= norm_1(out - out2);
	    };
        if (1 < m*n)
	    {
		    Matrix out	= spdiags(tmp,(mat_row(), -1),m*n,m*n);
            Matrix out2	= diags(tmp,(mat_row(), -1),m*n,m*n);
            out.check_struct();

		    dif			+= norm_1(out - out2);
	    };		

	    if (n > 1 && m > 1)
	    {
		    {
			    Matrix out	= spdiags(mat(colon(),colon(1,2)),(mat_row(), -1, 0),m,m);
                Matrix out2	= diags(mat(colon(),colon(1,2)),(mat_row(), -1, 0),m,m);
                out.check_struct();

                dif			+= norm_1(out - out2);
		    }
		    {
			    Matrix out	= spdiags(mat(colon(),colon(1,2)),(mat_row(), 0, 1),m,m);
                Matrix out2	= diags(mat(colon(),colon(1,2)),(mat_row(), 0, 1),m,m);
                out.check_struct();

                dif			+= norm_1(out - out2);
		    }
		    {
			    Matrix out	= spdiags(mat(colon(),colon(1,2)),(mat_row(), -1, 1),m,m);
                Matrix out2	= diags(mat(colon(),colon(1,2)),(mat_row(), -1, 1),m,m);
                out.check_struct();

			    dif			+= norm_1(out - out2);
		    };
	    };

	    return dif;
    }
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_spdiags::eval_scalar(const Scalar& ,bool,int code )
{
    (void) code;
	return 0;
};

};};