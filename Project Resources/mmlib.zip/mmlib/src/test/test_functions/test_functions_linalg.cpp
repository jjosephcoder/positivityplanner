/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include "test_functions.h"
#include "test/data_struct/logger.h"
#include "gmpp/linalg.h"


namespace gmpp { namespace test
{

Real test_function_lu_partial::eval_mat(const Matrix& mat,bool show, int code)
{
    (void) code;
    (void)show;
	try
	{		
        Matrix L, U, P, Q;
        lu_options opts;
        opts.pivot_type = lu_options::partial;
        tie(L,U,P,Q) = lu(mat,opts);

        L.check_struct();
        U.check_struct();
        P.check_struct();
        Q.check_struct();

        Matrix dif = L*U - mat(colon(P),colon(Q));
        dif.check_struct();

		return norm_1(dif);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_lu_partial::eval_scalar(const Scalar& ,bool , int code)
{
    (void) code;
	return 0;
};

Real test_function_lu_rook::eval_mat(const Matrix& mat,bool , int code)
{
    (void) code;
	try
	{		
        Matrix L, U, P, Q;
        lu_options opts;
        opts.pivot_type = lu_options::rook;
        tie(L,U,P,Q) = lu(mat,opts);

        L.check_struct();
        U.check_struct();
        P.check_struct();
        Q.check_struct();

        Integer M = mat.rows();
        Integer N = mat.cols();
        Integer K = min(M,N);

        if (L.cols() != K)
        {
            return 1;
        };

        Matrix dif = L*U - mat(colon(P),colon(Q));
        dif.check_struct();
		return norm_1(dif);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_lu_rook::eval_scalar(const Scalar& ,bool , int code)
{
    (void) code;
	return 0;
};

Real test_function_lu_complete::eval_mat(const Matrix& mat,bool , int code)
{
    (void) code;
	try
	{		
        Matrix L, U, P, Q;
        lu_options opts;
        opts.pivot_type = lu_options::complete;
        tie(L,U,P,Q) = lu(mat,opts);

        L.check_struct();
        U.check_struct();
        P.check_struct();
        Q.check_struct();

        Integer M = mat.rows();
        Integer N = mat.cols();
        Integer K = min(M,N);

        if (L.cols() != K)
        {
            return 1;
        };

        Matrix dif = L*U - mat(colon(P),colon(Q));
        dif.check_struct();
		return norm_1(dif);
	}
	catch(const std::exception& ex)
	{
		m_is_error = true;
		m_error = ex.what();
		return 1.;
	}
	catch(...)
	{
		m_is_error = true;
		m_error = "unknown error";
		return 1.;
	};
};
Real test_function_lu_complete::eval_scalar(const Scalar& ,bool, int code )
{
    (void) code;
	return 0;
};
};};