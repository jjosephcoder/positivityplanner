/*
 *  This file is a part of Morfa Matrix Lib.
 *
 *  Copyright (c) Pawe� Kowal 2011
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
#pragma once

#include <iostream>
#include <fstream>

#pragma warning( push )
#pragma warning(disable:4244)	//  conversion from 'int' to 'unsigned short', possible loss of data
#include <boost/thread/mutex.hpp>
#include <boost/thread/thread.hpp>
#pragma warning( pop )

namespace mmlib { namespace test
{

namespace details
{
	class logger_impl
	{
		private:
			typedef boost::mutex::scoped_lock scoped_lock;

		private:
			std::ofstream	file;
			boost::mutex	m_mutex;

		public:
			logger_impl()
				:file("log.txt")
			{};

			template<class T>
			logger_impl& operator<<(const T& arg)
			{
				scoped_lock lock(m_mutex);

				std::ostringstream os;
				os<<boost::this_thread::get_id();

				std::string msg = os.str() + " " + arg;
				
				file<< msg << std::flush;
				std::cout<< msg << std::flush;
				return *this;
			};
	};
};

class logger
{
	public:
		template<class T>
		logger& operator<<(const T& arg)
		{
			stream<<arg;
			return *this;
		};
	private:
		static details::logger_impl stream;
};


}};