====================================================================
                            MMLIB
====================================================================                                

  MMLIB(Morfa Matrix Library) is a set of C++ numerical routines pro-
  viding features similar to Matlab/Octave. MMLIB supports three basic 
  storage schemes: dense, sparse and banded matrices and supports 
  integer, real and complex arithmetics as well as special matrix types
  (including upper and lower triangular, symmetric, hermitian, ortho-
  gonal). Internal representation is hidden from users, the only publi-
  cally visible type is Matrix. MMLIB can change matrix internal repre-
  sentation if this allows for more efficient computations. MMLIb is 
  intended to be used as a dynamic library and can be used in projects
  written in other than C++ languages.